@echo off
cd /d "%~dp0"
echo.
echo   Starting Optimus...
echo.
echo   When it says "Application startup complete", open this in your browser:
echo.
echo       http://127.0.0.1:8123
echo.
echo   Leave this window open. Press Ctrl+C here to stop the tool.
echo.
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 127.0.0.1 --port 8123
echo.
echo   Optimus has stopped.
pause
