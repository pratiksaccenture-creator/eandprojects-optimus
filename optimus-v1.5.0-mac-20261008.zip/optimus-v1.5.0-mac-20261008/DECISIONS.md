# Decisions

Every choice made during the build that a reviewer might otherwise have to reverse-engineer,
with the reason. Brief §12 asks for this file to be reviewed alongside the demo.

Entries are grouped by what drove them. Where the brief and the fixture workbooks disagree,
**the fixture wins** — the brief was written against an earlier version of both files.

---

## 1. Stack rewritten from Node to Python

**Decision.** FastAPI + Jinja2 + HTMX, SQLAlchemy + SQLite, openpyxl, Pydantic, pytest, mypy.
Hand-written CSS with custom properties instead of Tailwind.

**Why.** Brief §2 mandates Next.js 15, Prisma, ExcelJS, Zod and Vitest. Node.js, npm and Git
are not installed on the build machine, so none of that stack can run and acceptance criterion
§11.1 (`npm install && npm run dev`) is unachievable. Python 3.14.7 is present. The user chose
to rewrite rather than install Node.

**Consequence.** §11's acceptance criteria are restated: `npm test` becomes `pytest`,
`tsc --noEmit` becomes `mypy`. The architectural requirements behind the stack choice are
unaffected — real persistence, real validation, formula-preserving Excel, a single-file model
provider swap — and all are honoured.

**No Tailwind** because there is no Node to run its build step, the Play CDN would need network
at page load (the demo must work offline), and the standalone binary is an extra download.
Brief §8 already forbids a component library and asks for hand-built components, so hand-written
CSS is consistent with the intent rather than a shortcut.

---

## 2. Where the brief is stale against the fixtures

The user edited both workbooks after the brief was written. Verified by parsing the raw xlsx
XML and cross-checking with openpyxl.

| Brief says | Fixture actually has |
|---|---|
| Input has 5 columns incl. `Batch No`, `Go Live` | **3 columns**: `Date`, `Category`, `Product URL` |
| Output has 14 columns A–N | **8 populated columns A–H** plus reserved `I` |
| `=LEN(J10)` / `=LEN(L10)` | `=LEN(E{n})` / `=LEN(G{n})` |
| §11: reference `M12` equals 160 | The cell is now **`H12`**; still exactly 160 |
| §3: brand suffix on **2 of 5** titles | **1 of 5** — only `E12` carries ` \| e&` |
| §3: `apple watch` appears **×4** in the keyword cell | `D12` holds **22 terms, 8 duplicated** twice each |
| §3: `Go Live` is dirty, sometimes `Will be shared when config Pages are live` | Column deleted from both files |
| §3: G–I reserved for Arabic | Arabic columns deleted; `I` survives as a single styled reserved column |

**`Go Live`** — `BatchRow.go_live_raw` is kept nullable so re-adding the column is painless,
but no UI is built for it.

**Column `I`** is empty, carries the bold header style and a custom width of 18.36328125. It is
preserved exactly as found; product name is appended to **column J** so nothing existing shifts,
per brief §9's stated intent.

**A defect the brief does not mention:** the AirPods 5 row (`D14`) carries `airpods 3` and
`apple airpods 3` — a superseded generation, the same class of defect §3 names only for the
Ultra 4 row. Found by the validator, covered by a test.

---

## 3. Decisions taken from the user

1. **One output row per input URL.** 21 rows in, 21 rows out, never consolidated. The reference
   file collapses variants into 5 rows and drops the rest; that is the defect being removed.
2. **Batch number is asked for at upload** as a required field. `Batch No` no longer exists in
   the input, and the export filename pattern needs it. Nothing is inferred from the sheet name.
3. **No page fetching.** Copy is grounded only in the category name and the URL. Keeps the demo
   offline with zero keys per §0, and guarantees no invented product specs. The cost is that
   copy cannot cite real specs unless a human adds them.
4. **Arabic deferred**, schema stays locale-aware. The user's cleanup deleted the Arabic columns,
   which answers §12's question.

---

## 4. Preprod rows are classified, not skipped

**Decision.** The three `preprodnew.eand.ae` rows get `fetch_status = unreachable` with a stated
reason and a visible warning, but they still generate copy and still occupy an export row.

**Why.** Since the tool never fetches pages (decision 3), reachability does not actually block
processing — nothing downstream depends on the page responding. Skipping those rows would drop
3 of 21 rows from the export, recreating the exact defect the tool exists to eliminate. The
honest position is: the row is processed, and the fact that nobody can verify the live page is
stated on screen rather than hidden.

**Also honest:** because no row is fetched, `fetch_status` is `unreachable` for preprod hosts
(known from the hostname) and `not_attempted` for every other row. No row is ever reported as
`ok`, because that would claim a successful fetch that never happened.

---

## 5. Product name is derived from Category

**Decision.** `product_name` comes from the `Category` column, title-cased for display with the
raw value preserved.

**Why.** With fetching off, `Category` is the only source of a product name in the input. The
brief never says where product name comes from. Consequence: for the 7 Smart Home rows and the
4 `iPhone - …` category rows, no generation number can be parsed, so `noStaleGeneration` cannot
run and reports `STALE_GEN_NOT_CHECKED` as a warning rather than silently passing.

---

## 6. Measurement — four counts, because they disagree

`chars` is **UTF-16 code units**, not `len()`. Excel's `LEN()` counts UTF-16, and the
`Character count (<60)` column has to mean the same thing as the validator. Verified: our
`char_count` matches Excel's own cached `LEN()` results on all ten copy cells in the reference
file. The counts diverge on astral characters — the UAE flag emoji is 2 code points but 4 UTF-16
units — which is why `len()` would be wrong.

`graphemes` uses `regex`'s `\X` (extended grapheme clusters); the standard library has no
grapheme segmentation. Expected counts are **not** ported from JavaScript's `Intl.Segmenter`,
because the bundled Unicode data versions drift apart.

`bytes` is NFC-normalised UTF-8, normalised *before* counting. Decomposed Arabic harakat roughly
double the byte count, and a store counts the bytes actually submitted.

**A question this raises that the brief does not answer:** for Arabic, Excel's `LEN()` counts
invisible tashkeel marks, so `مَرْحَبًا` is 9 characters and 5 graphemes. A character-based
`<60` limit becomes close to meaningless for Arabic. Whether the Arabic limit should be
character- or grapheme-based needs a decision before Arabic lands. Raised, not guessed.

---

## 7. Pixel width — source, accuracy, and where it is refused

**Source.** Advance widths extracted once from `C:\Windows\Fonts\arial.ttf` (Arial 7.06,
unitsPerEm 2048, 3506 glyphs) into `app/lib/advance_widths.json`, which records the font family,
revision, SHA-256 and extraction date so every pixel number on screen is attributable. Run
`tools/extract_font_metrics.py` to regenerate. No `node-canvas`, per §6.

**Licensing.** Arial is Monotype. It is used here for measurement only — never redistributed,
never rendered by the tool. If legal objects, Liberation Sans is metrically compatible by design
and OFL licensed; the extraction script already looks for it as a fallback and nothing else
changes.

**Accuracy, stated in the UI rather than buried.** Advance widths only: no kerning, no
ligatures, no OpenType shaping, no hinting or subpixel positioning, scaled linearly by font
size. Roughly ±3% for Latin text. Characters absent from the table are counted and surfaced as
`PIXEL_UNKNOWN_GLYPHS` rather than silently scoring zero.

**Refused for Arabic.** Per-codepoint advance widths are wrong by construction for Arabic, which
needs contextual shaping and ligatures. For `locale == "ar"` the pixel validators return
`PIXEL_UNSUPPORTED_LOCALE` as a warning instead of a number. A wrong number presented
confidently is worse than an admitted gap.

---

## 8. Two pixel models, because titles and descriptions truncate differently

A title renders on one line and is clipped at the container width. A description **wraps** and
is clipped after a line count — so a single-line width budget is the wrong model for it.

The brief gives only single-line figures, and they do not reconcile with its own character
guides at 14px Arial (mean advance ≈ 7px): 920px holds ≈131 characters against a stated 155
upper guide, and 680px holds ≈97 against a stated "first ~120 chars must fit". §6 calls these
values approximate and configurable, so **both models are kept** rather than one being quietly
discarded:

- `total_px_budget` holds the brief's figures verbatim (920 desktop / 680 mobile) and is what
  the `pixelLimit` validator gates on.
- `container_px × max_lines` drives the SERP preview's truncation mark, which is what a viewer
  actually sees.

Mobile is deliberately given a smaller wrapped budget than desktop (400×2 = 800px vs 600×2 =
1200px) to preserve the brief's ordering that mobile is tighter. Real mobile SERPs often show a
third line, which is why `max_lines` is configuration and not a constant.

**A finding worth showing leadership:** the reference file's `H12` description fails on *both*
gates — 160 characters against "under 160", and ~1019px against the 920px budget. The row is not
marginal.

---

## 9. Severity assignment for banned terms

Brief §6 lists banned terms as one validator but leaves severity per-finding. Assigned as:

**Errors (block export)** — currency and price references, recurring/tariff prices, instalment
terms, discounts, free-offer claims, stock and availability state, competitor telco trademarks.
These are the named defect in §1 rule 3, they are factual claims about money or stock, and they
go stale in a way that misleads someone reading a search result.

**Warnings (do not block)** — unproven superlatives (`best`, `ultimate`) and dating language
(`pre-order`, `coming soon`). These are weak copy that a human should reconsider, but blocking
every instance of "latest" would reject most legitimate launch copy and make the tool
unusable. Note that `Best smartphone UAE` appears in two reference titles, so this choice is
load-bearing for the demo.

Handset brands (Apple, Samsung) are **not** treated as competitor trademarks — e& sells them.
Only competing telcos are.

---

## 10. Stale-generation detection parses identity, not "a number"

`parse_identity` extracts `(family, line, generation)`. Parenthesised four-digit years are
stripped first so `Apple Watch SE 3 (2026)` yields generation 3 and not 2026. NFKC folding makes
Arabic-Indic digits parse. Model lines are collected in the order they appear, so
`iPhone 18 Pro Max` yields the compound line `pro max` rather than just `pro`.

**Only same-line comparisons are made.** An Apple Watch Ultra 2 is newer than a Series 9, so
"lower number" is meaningless across lines. This means `apple watch ultra 3` in the Series 12
row's keyword cell is *not* reported as a stale generation — it is a different product entirely.
That case is reported separately as `KEYWORD_CROSS_LINE`, a warning.

**Documented limitations.** Integers that are not generations (`128GB`, `45mm`, `5G`, `Wi-Fi 7`)
are excluded by a unit-stripping pass and covered by tests. Non-numeric generations (`SE`, `XS`,
`16e`, `Plus`) cannot be compared and yield `None` rather than a guess. Where no product name is
known, the validator emits `STALE_GEN_NOT_CHECKED` rather than passing silently.

---

## 11. Brand suffix is decided once per batch and persisted

`decide_brand_suffix` applies ` | e&` only if **every** title in the batch still fits both the
character and pixel budget with it. One long title switches it off for all rows, and the
decision names the blocking row so the UI can explain itself — otherwise "the suffix vanished"
reads as a bug.

The decision is persisted on `Batch`, not recomputed at export time. Without that, changing the
limits config later would make a re-export produce different bytes from the original, breaking
the byte-identical guarantee in §11.

---

## 12. Validators are pure; the database stays above them

Two tiers, neither touching the ORM:

- `FieldValidator(text, FieldContext) -> [Finding]` for anything decidable from one string.
- `BatchValidator(BatchSnapshot) -> [Finding]` for rules needing every row or the keyword
  registry. `BatchSnapshot` is a frozen value object built once by a repository.

Tests therefore construct snapshots as literals and touch no database at all. Registry *writes*
happen in a service at approve and export time, never inside a validator.

---

## 13. No HTMX. A hand-rolled ~150-line swap layer instead

**Decision.** `app/static/js/swap.js` implements the small subset of HTMX this tool needs:
fetch HTML, swap it into a target, and apply out-of-band fragments by `id`.

**Why.** HTMX would have to arrive either from a CDN, which needs network at page load and
breaks the offline guarantee in §0, or as a vendored download. The subset actually used here
is small enough to own outright, and doing so means the tool ships with **no third-party
JavaScript runtime at all** — which is both easier to get through a security review and a
fair thing to say in a demo.

**It is not HTMX and is not described as such anywhere.** The attribute names are
deliberately different (`data-get`, `data-swap-oob`) so nobody reads the templates and
assumes HTMX semantics apply.

**One non-obvious bug this surfaced**, worth keeping written down: assigning a `<tr>…</tr>`
fragment to `div.innerHTML` makes the HTML parser **silently discard the row and cell tags**,
because a table row is not valid as a child of a div — you get bare text back and the table
structure collapses. Both the keyword and generation tables swap `<tr>` fragments, so the
tables emptied themselves on first run. Parsing through a `<template>` element fixes it,
because a template parses any fragment in a content-agnostic context. Caught by driving the
real page in a browser; no unit test would have found it.

---

## 14. The brand suffix is decided in two phases

**Decision.** Generation runs in two passes. Every title is generated **without** the
suffix, then the batch decides whether ` | e&` fits every title, then it is appended to all
of them if so.

**Why.** Brief §6 requires one decision across the whole batch, but the decision depends on
whether every title still fits with the suffix — and there are no titles until generation
has run. Deciding first would mean deciding on no evidence, and the first implementation did
exactly that: it always concluded "no titles to decide on yet" and switched the suffix off
for every batch.

Applying the suffix is a **mechanical transformation**, not another generation attempt.
Asking the provider for a fresh attempt made the template treat it as "the last one failed,
shorten harder", which threw away the benefit clause from every title for no reason.

In the UI this is why the rows stream in and then a short "settling batch-wide rules" step
follows. The server detects the last row finishing and emits the trigger for it, so the
client never has to count outstanding requests.

---

## 15. The primary keyword is the most specific verified term, not the highest-volume one

**Decision.** `choose_primary` ranks by specificity first and uses volume only to break ties.

**Why.** Ranking by volume alone made **every one of the 21 rows** pick `apple` at 165,000 —
a bare manufacturer name that is unrankable for a product page and identical across the
batch, which would also have made every row cannibalise every other. Specificity-first gives
`iphone 18 pro max` (9,900) for the Pro Max row and `apple watch` (33,100) for the watches,
which is what a practitioner would choose.

Only **verified** terms are eligible. Promoting an unverified term to primary would be a
guess presented as a decision.

**What this exposes, and should:** six Apple Watch rows all resolve to `apple watch`, because
the seeded data has no variant-level volumes. That is a real finding about the keyword data,
not a bug, and the cannibalisation warnings say so.

---

## 16. Cannibalisation is checked three ways

Brief §8 names the same-category case. Two more were added because the same-category check
alone sees almost nothing in this batch:

| Code | Case |
|---|---|
| `CANNIBALISATION` | Two rows in the same category share a primary. The brief's case. |
| `CANNIBALISATION_BATCH` | Two rows in *different* categories share a primary. |
| `CANNIBALISATION_REGISTRY` | An earlier batch already claimed the term. |

The spreadsheet's categories are per-variant, so six Apple Watch rows sit under six different
category labels while competing for one term. All three are warnings: two pages sharing a
term is sometimes deliberate.

---

## 17. Character limits are exclusive for the spreadsheet, inclusive for the stores

`Character count (<60)` means **under** 60, so exactly 160 fails the description — that is the
reference file's `H12` defect and the whole point of the validator. But an Apple limit of 30
characters means **at most** 30; Apple accepts a 30-character subtitle. Failing one would be
the tool inventing a rule the store does not have.

`FieldContext.char_limit_inclusive` carries the distinction and defaults to the stricter
exclusive reading. Found because the seeded ASO subtitle is exactly 30 characters and was
being rejected.

---

## 18. Two adjustments so the validation panel stays worth reading

**Banned terms are much narrower for keyword lists than for copy.** A keyword list records
what people actually type. `apple watch price in uae` is in the seed data at 1,600 searches a
month; rejecting it as a "price reference" would discard real demand signal. Only rules about
associations we must never make at all — competitor trademarks — carry into keyword lists.
`no_banned_terms_in_keywords` is deliberately separate from `no_banned_terms`.

**Term density ignores function words and requires three repeats.** The first version
reported `"the" appears 2 times in 22 words` as a finding. A panel full of results like that
teaches a reviewer to stop reading the panel, which costs more than the rule gains.

---

## 19. No artificial pacing

`DEMO_PACING_MS` defaults to `0`. Staging fixture work with a sleep so it *looks* like
computation is exactly what §0 forbids — it manufactures an impression of live work.

Each row is a genuine request doing genuine generation and validation. When it finishes in
33ms the page says so: *"All 21 rows generated. Last row took 33ms — deterministic
templates, so it is fast. No artificial delay is applied."* That reads as competence rather
than as a stopwatch trick. If pacing is ever switched on, the provider bar shows a red
"artificial pacing on" chip for as long as it is.

---

## 20. Product names are disambiguated from the URL slug

Seven rows share the category `Smart Home` while pointing at smart-locks, smart-thermostat,
smart-appliances and so on. Identical names produce identical titles, which the uniqueness
validator correctly rejects — leaving a third of the batch unexportable for a reason the
input never actually forced.

Where a product name is duplicated across the batch, it is taken from the URL's last path
segment instead (`smart-locks.html` → `Smart Locks`). The slug is input data, so nothing is
invented. Rows whose URL yields no readable slug — an eshop `key-prod…` id — keep the
category name and stay genuinely ambiguous, which is then a data-quality finding for the team
rather than something papered over.

Brand casing cannot be derived algorithmically (`iPhone` and `AirPods` both break title-case;
`GPS` and `SE` both break `capitalize()`), so `CANONICAL_TOKENS` in `app/excel/reader.py` is
an explicit map. `category_raw` is always preserved untouched for display.

---

## 21. The interface was cut back to three pages

**Decision.** Upload → keywords and approve → copy, refresh and export. Explanatory copy
removed. The richer interface is preserved in `archive/full-ui/` with restore instructions.

**Why.** Requested, to get a simple journey agreed before any live APIs go in.

**Nothing in the backend was removed.** Every validator, the regeneration loop, the audit
trail, retention, the keyword registry, the ASO model and all five export sheets still run
and are still covered by tests. The workbook the simple UI produces is byte-for-byte the
same one the richer UI produced. What went is UI surface, not capability.

**Set aside, still working underneath:** the parsed-row preview, per-row unreachable
reasons, the unverified-keyword list, add/remove terms, per-field validation findings in
plain language, pixel/grapheme/byte measurements, the SERP preview with its truncation
mark, inline editing, the attempt diff, the ASO tab, and the diagnostics page.

**Kept despite the instruction to strip guiding elements:** one small chip per page naming
the keyword provider and the copy model, and marking the volumes as seeded. Brief §5 makes
that non-negotiable — "the UI must always display which provider produced the numbers on
screen, with a visible badge when isLiveData is false" — and without it the demo shows
seeded numbers with nothing saying so. It is now a single chip rather than a full bar.

**`/dev/` became JSON-only**, so brief §4's "purgeExpired invocable from a dev route" still
holds without adding a page to the journey.

### Two bugs the rebuild introduced, both caught in the browser

**Refresh was eroding the copy.** Compression was driven by the attempt number, so clicking
Refresh on a perfectly valid title walked it from `iPhone 18 Pro Max | Camera & battery | e&`
down towards the bare product name. That was defensible when the control was labelled
"Regenerate" inside a retry loop; labelled "Refresh" it is just wrong. `CopyRequest` now
carries `variant` and `shrink` separately: variant rotates the phrasing to offer a real
alternative, shrink only ever responds to an actual length failure.

**The export button stayed dead after streaming.** It was rendered outside any swappable
region, so a batch that streamed in clean still showed a disabled button until the page was
reloaded. The button and the blocked message now live in one out-of-band element, because
they depend on the same gate and must never disagree.

A third, quieter one: the settle response wrapped each field in another element carrying the
same `id`, producing duplicate ids that broke later out-of-band swaps for that cell.

---

## 22. Named Optimus, and the brand mark is a placeholder

**Name.** The tool is branded **Optimus**, shown alone in the masthead with no descriptor.
Chosen by the user. It reads naturally against "optimise", which suits a search tool.

*Worth a trademark check before this goes anywhere external.* Optimus is a well-known
Hasbro character mark, and — more relevant here — was a Portuguese mobile network brand, so
there is prior use in telecoms specifically. Not a blocker for an internal tool; it is a
blocker for anything customer-facing.

**The brand mark is deliberately NOT the official logo.** Brief §8 says: "Do not use
official e& logo files or brand assets." The masthead therefore carries the characters `e&`
set as text in the brand red (`#a81c30`), sitting top-right after the utility links behind a
divider rule. It is labelled as a placeholder in the markup and in its tooltip. Replacing
the `<span class="brand">` in `app/templates/base.html` with the approved asset is a
one-line change.

**On placement.** Top-right was requested, and it is the inverse of the usual convention —
a primary logo normally owns the top-left where the eye lands first. For an internal tool
the inversion is right: the product name should hold the left because that is what the user
is working in, and the company mark signs the page from the right without competing with it.
If this ever becomes customer-facing, swap them.

---

## 23. Live providers: Claude for everything except the numbers

**Decision.** Three seams, each with a fixture and a live implementation:

| Seam | Fixture (default) | Live | Credential |
|---|---|---|---|
| `providers/llm` | deterministic templates | **Claude** (`claude-opus-5`) | `ANTHROPIC_API_KEY` |
| `providers/keywords` | seeded from the reference workbook | **Semrush** Analytics API | `SEMRUSH_API_KEY` |
| `providers/pages` | no fetch | HTTP fetch + fact extraction | follows the model |

Claude does fact extraction, keyword ideation and copy drafting. Semrush supplies search
volumes and nothing else. That division is the whole point: a model cannot know how many
people searched for something, so it is never asked.

**Providers switch on by credential detection**, and an explicit `KEYWORD_PROVIDER` /
`LLM_PROVIDER` / `PAGE_PROVIDER` always overrides. So the tool still runs with no
environment variables at all (§11 intact), goes live the moment a key is added, and can be
forced back to fixture mode for an offline demo. The UI always names the provider actually
in use, so the convenience can never leave anyone unsure where a number came from.

### Semrush REST API, not the Semrush MCP

`phrase_these` (Batch Keyword Overview): up to 100 phrases per call, `database=ae`,
10 API units per keyword. ~250 candidates per 21-row batch is ~2,500 units.

**The MCP was rejected deliberately.** Semrush documents it as "designed for AI agents
rather than direct server-to-server calls", and its own disclaimer reads "AI responses may
be incomplete or inaccurate, so always verify them". Putting a language model between this
tool and a search volume reintroduces exactly the failure mode the design exists to
prevent. Both paths bill the same API units against the same subscription, so the REST call
costs no more and needs no extra access. The MCP remains a good way to explore Semrush data
interactively in Claude — just not as this tool's data path.

A Semrush error response **raises** rather than returning no rows. Silently returning
nothing would make an auth or billing failure indistinguishable from "nobody searches for
these terms", which would quietly turn a broken integration into a page full of legitimate-
looking gaps.

### Model configuration

`claude-opus-5` by default, overridable with `ANTHROPIC_MODEL`. Adaptive thinking, structured
output via `messages.parse` with Pydantic schemas so a malformed reply raises at the seam
instead of becoming a half-empty row. The system prompt is marked cacheable and is identical
for every row, so rows 2–21 of a batch read it from cache.

**No schema Claude fills in has a field for search demand**, the package cannot import the
volume providers, and `tests/test_no_llm_volumes.py` parses the source to prove the
identifier never appears. Enforced structurally, not by review.

---

## 24. eand.ae product pages are client-side rendered — grounding reads the page head

**What we found** by actually fetching the fixture's URLs:

| Page | Result |
|---|---|
| `www.eand.ae/en/c/...` (category) | HTTP 200, ~4.8KB of usable text |
| `www.eand.ae/eshop/...` (product) | HTTP 200, 888KB of HTML, **~1,000 characters of DOM text** |
| `preprodnew.eand.ae/...` | times out → `unreachable`, now genuinely established rather than inferred from the hostname |

The eshop pages are Angular and render client-side: 850KB of that 888KB is `<style>` and
`<script>`. The specifications (`6.3-inch display`, `48MP camera`, `A20 Pro chip`) appear
nowhere in the rendered markup — **only inside the page's existing `<meta name="description">`**.

**So the extractor reads head metadata as well as body text**, labelled by provenance.
Without that, 10 of 21 rows could not be grounded at all short of running a headless
browser.

**The uncomfortable part, stated plainly.** That meta description is verbatim the defective
copy from the reference workbook — em-dash glued to `Pro—ultimate`, `AED 225/month` and all.
The defects are live in production right now. Grounding new copy in it is therefore
circular, and it puts the old price claims directly in front of the extractor.

Two independent layers handle that:

1. The extraction prompt keeps durable product facts (screen size, camera, chip, battery,
   materials) and is told to discard every price, instalment, "pre-order" and "out of
   stock".
2. The banned-terms validator blocks any price that reaches indexed copy regardless of
   where it came from — tested explicitly against the real defective string.

**If specification accuracy ever becomes critical**, the honest options are a product API
(the eshop URL already carries a `productId`, so one likely exists) or a headless browser.
Reading the old meta description is a pragmatic floor, not a ceiling — and it is recorded
here so nobody later mistakes it for a validated data source.

---

## 25. DataForSEO and OpenAI wired as the live pair

**Decision.** The user has DataForSEO and OpenAI credentials, so those are the live
providers. Semrush and Claude remain implemented and selectable — they cost nothing to keep
and make a provider comparison possible.

| Seam | Default | Live (preferred) | Also available |
|---|---|---|---|
| volumes | fixture | **DataForSEO** | Semrush, Google Ads (stub) |
| model | fixture | **OpenAI** `gpt-6-astra` | Claude, Azure (stub) |
| pages | no fetch | HTTP + extraction | — |

Preference order matters only when several are configured; an explicit `KEYWORD_PROVIDER` /
`LLM_PROVIDER` always wins.

**DataForSEO:** Google Ads Search Volume live endpoint, Basic auth, up to 1,000 keywords per
task (capped at 700 here so one bad batch loses less), `location_code=2784` for the UAE.
A `null` search volume is preserved as `None` — Google reporting no data is not zero demand.
Phrases over 80 characters or 10 words are filtered out before sending, because one rejected
phrase fails the whole task and would turn a single over-long candidate into a batch with no
volumes at all. A non-20000 status raises rather than returning no rows, for the same reason
as Semrush: an auth or quota failure must not look like "nobody searches for these terms".

**OpenAI:** Responses API with `text_format` and a Pydantic schema, so replies are validated
at the seam. Refusals arrive as their own output item rather than as the schema, so they are
checked explicitly — reading `output_parsed` alone would report a refusal as "returned
nothing". `OPENAI_BASE_URL` points the same client at Azure OpenAI or an internal gateway,
which is what an in-region deployment needs.

### Prompts are shared, deliberately

`providers/llm/_prompts.py` holds the system prompts, the response schemas, the prompt
builders and the reply normalisation. Both model providers import them; neither owns a copy.

The rules in those prompts are editorial policy, not transport detail. Two copies would
drift the first time one was tightened, and a comparison between OpenAI and Claude would
stop being a fair test of the models. A test asserts both modules reference the *same
objects*, not merely equal strings.

### Credentials

`.env` (gitignored) loaded at startup, with real environment variables taking precedence.
`.env.example` is committed with placeholder names. This exists so nobody has to paste a key
into a terminal, a ticket or a chat transcript to get the tool running — a secret that
reaches any of those is a leaked secret.

---

## 26. An encoding incident worth not repeating

While renaming page titles I used PowerShell `Set-Content -Encoding utf8` to rewrite source
files. On Windows PowerShell 5.1 that **adds a UTF-8 BOM**, and round-tripping text through
it double-encoded two em-dashes into mojibake.

Caught by an audit of all 80 source files; BOMs stripped from five templates and the
mojibake repaired. A BOM before `{% extends %}` is not fatal but it leaks a zero-width
character into output and can trip template parsing.

**Rule for this repo: never rewrite a source file through PowerShell.** Use the editor
tooling, which writes UTF-8 without a BOM. `Set-Content`/`Out-File` are for throwaway
scratch output only.

---

## 27. Adding credentials must not, by itself, start spending money

Found the first time real keys were added, not by review — so both halves are now tests.

**The startup seed.** `ensure_demo_batch()` builds the demo batch by running the real
pipeline over every row of the reference file, deliberately, so nothing on screen is a
fixture pretending to be a result. On fixture providers that is instant, free and
deterministic. With live keys present it became 21 page fetches and dozens of model calls
executed *inside the app lifespan* — charged before the server accepted its first
connection, and holding the port closed for minutes while it ran. The first observation was
"the app won't start".

`should_seed()` now returns false when either the volume or the model provider is live. A
live configuration opens on the upload page, and the first paid batch is one someone chose
to run. `SEED_DEMO_BATCH=1` forces it for a rehearsal where the cost is intended, `=0`
suppresses it entirely.

The rejected alternative was to seed with fixture providers while the rest of the app runs
live. That keeps the demo batch on screen at zero cost, and it is the worst option
available: a seeded batch sitting under a header that says "DataForSEO / OpenAI" is
precisely the thing brief §0 and §1 rule 1 exist to prevent.

**The test suite.** `app.config` loads `.env` on import, which is correct for the
application and wrong for the tests: any test resolving a provider by credential detection
would have begun calling paid APIs the moment a developer added keys, with no diagnostic
beyond a slower suite and a bill. An autouse fixture in `conftest.py` now strips every
credential — collected from each provider's own `REQUIRED_ENV` rather than hand-listed, so
a new provider cannot leave a hole — and clears the settings cache around each test. A test
wanting a live path sets its own variables and stubs the transport.

The general rule this encodes: **detection may decide *which* provider, never *whether* to
spend.** Any code path that costs money is reached by a user action, not by a key existing.

A third case of the same rule surfaced while verifying the pivot: `PAGE_PROVIDER` was
derived from the presence of model credentials rather than from the resolved model, so
`LLM_PROVIDER=fixture` still fetched every page over HTTP — twelve seconds a row on a run
explicitly asked to stay offline, with nothing configured that could read the result. It
now follows the resolved provider.

---

## 28. The keyword-research pivot, and the SEO Copy Guidelines

Two changes arrived together on 2026-09-28: a new four-column input template, and the
content team's written **SEO Copy Guidelines**. Where the guidelines and the original
brief disagree, the guidelines win — they are the team's current standard and they are
newer. Each disagreement is listed below rather than absorbed silently.

### What the tool now does

The input is `Batch No/Name | Product Category | Brand | Product Name`, with an optional
`Price` and an optional `Product URL`. No URLs are required, which removes the build's
weakest link: eand.ae product pages render client-side, so grounding had been reading the
page's existing (defective) meta description. Product names in the template carry
verified specifications — `512GB`, `42MM`, `Ceramic` — supplied by the team rather than
scraped, which is strictly better evidence.

**The division of labour changed, and this is the heart of the pivot.** The model produces
*seeds* — it knows what the product is, who buys it and what they call it. DataForSEO's
`keywords_for_keywords` endpoint then expands up to 20 seeds into the real long tail, up
to 20,000 terms each carrying its own search volume, for one charge per request. So the
terms on screen are what UAE users demonstrably type, not a model's idea of what they
might. A model asked for the long tail directly would be inventing the phrasing and,
implicitly, the demand.

Six buckets, mirroring the six prompts the team runs by hand in ChatGPT today: brand,
product, device type, category, USP/intent, SmartPay. SmartPay is never priced — it is a
standing commercial requirement with no search demand, and showing it with a null volume
is the honest result rather than a failed lookup.

Per the team's instruction, volumes are looked up for product, brand and category terms
and **not** for specifications, colours or other attributes. One cost of that rule is
recorded rather than absorbed: storage is the single attribute that behaves like a product
term, because "iphone 17 512gb" is a real query. Under this rule its demand goes
unmeasured; moving storage out of `SPEC_TERM_PATTERNS` is the only change needed.

### Where the guidelines overrode the brief

| Rule | Brief / reference file | Guidelines | Now |
|---|---|---|---|
| Title length | `Character count (<60)` — under 60 | "60 characters or fewer" | ≤ 60 |
| Description length | `(<160)` — under 160 | "160 characters or fewer" | ≤ 160 |
| Price in descriptions | Defect #1; `AED` blocks export | Required in the second sentence | Allowed **only** when a human supplied that exact figure |

The length change reverses a headline demo point: the reference file's 160-character
description was the brief's named defect and is now compliant. The tests were rewritten to
assert the *measurement* rather than the verdict, because what deserves protecting is that
the tool counts the way Excel counts — the arithmetic did not move.

### The price rule

The guidelines mandate `Shop <Product Name> from AED <XXX> via SmartPay with e&.` as the
second sentence of every product description. The brief forbids prices outright. Both are
defensible: prices lift click-through, and they also go stale between crawls, which in the
UAE is a price-advertising accuracy problem and not only an SEO one.

The reconciliation is deliberately narrow. A figure may appear **only if a human supplied
exactly that figure**, from the input sheet or by typing it into the row. `FieldContext`
carries `allowed_price`; `no_banned_terms` redacts precisely that string before the rules
run, and everything else stays forbidden. So a different figure fails, a second figure
alongside the allowed one fails, `/month` fails regardless, and a price on a row where
nobody supplied one fails. The model cannot talk its way past it, because it has no way to
change `allowed_price`. There is no `PriceSource.model`, and that absence is the design.

Missing prices are a **warning**, not a block: the team asked for the price to be optional
per row, so a row without one still ships, visibly not meeting the second-sentence rule.
SmartPay is unconditional — it does not go stale.

### The pixel budget had to move

`DESCRIPTION_DESKTOP.total_px_budget` went from the brief's 920px to 1200px (container
600px x 2 lines). At 14px Arial, 920px is roughly 131 characters — so a description obeying
the team's own "160 or fewer" failed on pixels instead, and the tool rejected copy the
guidelines explicitly permit. **A limit that silently overrides a stated rule is worse than
no limit.** Pixel measurement still earns its place: it catches text that is wide for its
length, which a character count cannot see, and there is a test for exactly that.

### Defects the pivot introduced, found by running it

Worth recording because none came from review:

- **Expansion returns other models' keywords.** Asked to expand "iphone 18 pro", the API
  returns "iphone 18 pro max" — more demand, different phone. Unfiltered it outranked the
  correct term, became the primary keyword, and pointed the page at a product e& was not
  selling on it. `names_a_different_model` drops terms that add a model qualifier the
  product does not have, while keeping broader ones: "iphone 18" on a Pro Max page is the
  same phone described loosely.
- **Expanding a bare brand floods the row.** "apple" returns the whole Apple catalogue, so
  an Apple Watch page came back carrying iPhone keywords. Single-word brand seeds are now
  priced but never expanded.
- **A bare brand as primary keyword.** "apple" for an iPhone 17 page is unwinnable and
  collides with every other Apple row. `choose_primary` now returns *nothing* rather than
  something bad — "no keyword here is specific enough" is a finding a reviewer can act on;
  naming "apple" looks like an answer and is not one.
- **A guessed brand propagating.** Falling back to the product name's first word gave
  "Smart Appliances" the brand "Smart", which seeded a keyword that matched "smartphone",
  which became the primary keyword for a page about dishwashers. Unknown brands are now
  empty, and `BRAND_BY_LINE` resolves lines that name their maker ("iPhone 18 Pro Max" →
  Apple).
- **The fallback copy angle asserted features.** `DEFAULT_ANGLE` carried smart-home
  phrasing, so a PlayStation 5 was described as controlling your lighting and climate.
  Invisible while every row was an Apple device; wrong the moment the template arrived. The
  fallback now claims nothing about the product, which is the only safe thing a fallback
  can do.
- **The provider badge described the configuration, not the data.** A batch researched on
  seeded data and viewed after credentials were added showed "DataForSEO" above figures
  that came from a spreadsheet — exactly the failure this tool exists to prevent, sitting
  in the header. The badge now reports what actually produced the stored rows.

### The export

The team asked for the input sheet back with three columns added, and that is all it does:
`Meta Title`, `Meta Description`, `Keywords & Volumes`. No second sheet, no validation log,
no GEO or ASO tabs — those remain in `writer.py` for the legacy layout and are reachable,
but an export with five sheets when one was requested is not a more helpful export. The
price column comes back only when a price exists to put in it.

`Keywords & Volumes` lists only the terms that actually reached the copy, computed at
export time rather than stored so it cannot disagree with the copy beside it after an
edit. An unmeasured term renders as `(no data)`, never `0` — no data is not no demand.

Both input formats are still read; `read_any_workbook` decides from the headers, and
`Batch.input_layout` records which, because the export has to give back the shape the file
arrived in and the uploaded file may be long gone by the time someone re-downloads.

---

## 29. v1: seeded volumes are no longer reachable by accident

After the build was presented to leadership and accepted as v1, the instruction was to
remove seeded volumes from the running tool.

They were never presented as real — an amber "sample data" chip said otherwise on every
screen that showed them. But they were what the *absence* of credentials resolved to, so
a tool started without keys quietly served 29 numbers the team had collected once for one
Apple batch, against whatever products happened to be uploaded. Labelled, and still wrong.

**With no credentials, a provider now resolves to `UNCONFIGURED` and refuses.** Both
providers, not just volumes: a half-state with real numbers and templated copy is harder
to reason about than either extreme, and the rule is easier to explain as one rule.

Refusal happens **at the point of use**, not at startup. The app opens, the upload page
names what is missing and how to fix it, and the keywords step stops with the same
message. Someone can still open the tool to look at it, which matters more than a strict
fail-fast — and a missing key produces a sentence on screen rather than a crash at launch.

**Fixture mode survives as an explicit opt-in.** `KEYWORD_PROVIDER=fixture` still works
and is now the only route to seeded data. It costs nothing to keep once nothing reaches
it by default, and it is the difference between a working demo and no demo when a venue's
network fails. The warning chip stays on screen the entire time it is in use.

**`FixtureVolumeProvider` stays in the codebase**, and that is not reluctance to delete
code. Around 200 of the 504 tests drive the keyword pipeline end to end. Removing the
provider means either those tests call DataForSEO on every run — real money, real rate
limits, and a suite that fails whenever the network does — or roughly 200 tests are
deleted. Neither is a good trade. The suite now asks for fixtures **by name** in
`conftest.py` rather than relying on a default, which is the more honest arrangement
anyway.

### What this costs

**Brief §11's acceptance criterion no longer holds.** "The app runs end to end with no
environment variables set" was a real requirement and it is now deliberately false. It
was written when the tool was a clickable prototype whose job was to demonstrate a
workflow. v1 is a tool people will act on the output of, and for that, plausible numbers
attached to the wrong products are worse than no numbers. Recorded here rather than left
as a silent contradiction between the brief and the build.

---

## 30. Demand and publishability are two different questions

A projector row came back with this description, and a Tier 1 error under it:

> Shop a Philips projector for your smart home in the UAE. Explore the Philips projector
> **price** in UAE: AED 549 with SmartPay.

The flagged string was the word `price`, not the figure. `AED 549` was fine — a human had
supplied 549, and `_redact_sanctioned_price` removes exactly that string before the money
rules run (§28). What failed was `BANNED_PRICE_WORD`.

Three parts of the tool, each behaving correctly:

1. `candidates.py` generates `"{family} price in {market}"` for every product, and the
   research prompt asks for price-intent phrasings explicitly. Correct — people really do
   search them, and 1,900 a month on this row is a fact worth having.
2. Auto-tiering took the highest-volume terms as secondary. `projector price in uae`
   (1,900) came third on the row, ahead of `home projector` (590) and `philips projector`
   (170) — the two terms that actually belonged there.
3. The copy prompt asks the model to work the secondaries in. It did.

Then the validator rejected the result. Nothing was broken; the system simply had no
representation of the difference between *a term people search for* and *a term we may
publish*, so it computed the first and silently treated it as the second.

### The rule

A keyword's volume says how many people search it. It says nothing about whether it can
go on an indexed page. These are now separate properties:

- `validators.banned_in_copy(term)` returns the blocking rule for a term, or None. Same
  rule set as `no_banned_terms`, asked about a keyword instead of a finished field, and
  consulting only the rules that **block export** — a superlative is a warning a human may
  accept, so it is not grounds for withholding a term.
- Such a term is **never auto-tiered** (`keyword_service.auto_tier`) and **cannot be
  tiered by hand** (`set_keyword_tier` refuses). It is still researched, still measured,
  still shown with its volume, and still exported.
- `generation.supporting_tiers` filters both its paths as a backstop, which the
  approved-terms fallback genuinely needs: that path is *every* approved term on the row.
- `COPY_SYSTEM` rule 4 tells the model not to echo a price word even if a keyword contains
  one. A backstop only — the filtering is the mechanism.

### Why the chip is disabled rather than hidden

Dropping the term from the screen would have been less code. It would also have thrown
away the finding: *1,900 people a month search the price of this product* is something the
content team should see, and it is exactly the kind of signal they do this research for.
Leaving it clickable would have been worse — a control that cannot do what it offers.

So it renders with its volume, not interactive, labelled `research only`, with the reason
in the tooltip: "contains a price or discount claim, which must not be indexed."

### What this does not fix

`auto_tier` was extracted from `store_row_keywords` so an already-researched row can be
re-tiered without repeating the lookups, which cost money and would return the same
figures. Re-tiering batch 2 moved `home projector` up into the secondary slot the price
term had occupied, and the row regenerated clean.

It also confirmed a **separate, pre-existing defect it would have been easy to blame on
this change**: four of seven rows have no primary keyword at all, because their product
names arrive from the input sheet as unspaced slugs (`agongamingmonitor`, `airpodsmax2`),
and `shares_a_word_with_product` compares whole words. Verified by running
`choose_primary` with `banned_in_copy` stubbed out: identical result on all seven rows.
That one is input dirt and is recorded in the open questions, not quietly patched.

---

## 31. The keywords page becomes editable, and learns to carry claims

Three things the team asked for once the research was real, and they interact.

### Tiers graduated from the lab

Primary / secondary / tertiary selection was built on `/lab/step/2` to keep an unproven
feature away from a page leadership had been shown. It earned its place, so it moved into
`wizard.py` and onto `/step/2`, which is the path the lab exists to provide.

The lab page remains, for lazy loading only — and it now renders the **same**
`_keyword_row.html` partial and calls the **same** endpoints, so the only difference
between the two pages is which rows start immediately. `_lab_keyword_row.html` is gone
rather than left to drift.

One test inverted rather than deleted:
`test_the_simple_keyword_page_has_no_tier_controls` became
`test_the_keyword_page_now_has_the_graduated_tier_controls`. Same test, same job, opposite
direction — and it also asserts the page calls the wizard's route and not the lab's.

### Editing a keyword re-measures it. It has to.

This is the only part of the feature with a right and a wrong answer.

"home projector" measures 590 searches a month. Reword it to "home projectors" and 590 is
a figure for a query nobody asked about. Keeping it would attach a real measurement to the
wrong string, which is the same defect class as inventing one — brief §1 rule 1 does not
care whether a wrong number was fabricated or inherited.

So `edit_keyword_term` does a fresh lookup, and a term the provider has no data for comes
back **unverified with its figure cleared**. Two consequences, both stated in the UI
rather than discovered:

- an edit costs a provider call, so the button says "Save & re-measure";
- the open editor names the figure it is about to replace — "Its figure of 590 belongs to
  the old wording, so it is replaced, not carried over."

`is_expansion` also goes false: the term is no longer one the provider returned, it is one
a person wrote, and the provenance has to say so.

Removing is `reject_keyword`, which never deleted — but the record was unreachable from
the screen, so a mis-click was unrecoverable. There is now a "removed" disclosure and a
restore that reuses the **stored** figure rather than paying for the same lookup twice.

### USPs: the first time a model is asked to make a claim

Every other model output in this tool is either measured elsewhere (keywords) or
validated before it ships (copy). A USP is neither. It is an unverified assertion about a
product, shown to a writer who will put it in front of customers. That makes it the most
dangerous thing in the build, and it is governed by four rules:

1. **Nothing reaches copy unticked**, and ticking records a name and a time. "The model
   said so" is not an answer to who decided to claim it. Model-proposed USPs arrive
   **unselected** — unlike a keyword, which gets an opening tier, because a measured term
   is evidence and a claim is not.
2. **`is_grounded` is never set from the model's own say-so.** The model reports
   `from_page`, and `read_ideas` ANDs it with whether a page was actually read. A model
   mislabelling its recall as page-sourced is the one failure a reviewer cannot catch by
   reading, because the label is the whole basis on which they decide how hard to check.
3. **No figure slot exists.** `UspSchema` has two fields, `claim` and `from_page`. The
   rule against model-produced numbers is structural here too, not left to the prompt.
4. **Unpublishable claims are dropped, not locked.** This is where USPs differ from
   keywords: a locked keyword still carries information — its volume is a fact about the
   market — whereas an unusable USP carries nothing. "Cheapest price in Dubai" is refused
   at the box with the rule that refused it.

In the copy prompt they get the same standing as page facts, and the reason is spelled out
in `usp_block`: rule 13 permits a specification only from FACTS or the product name, so
without this an approved claim would be ignored or flagged. What makes it usable is not
the model's confidence — it is that a named person approved it.

### Why USPs ride on the ideation call

They come back from the **same** request as the keyword seeds. The model has to work out
what the product is either way, the keywords page is already the slowest in the tool, and
a second round trip for a second answer to the same question is latency nobody asked for.
`propose_keywords` now returns an `IdeationResult` instead of a tuple of terms.

Fixture mode returns USPs that are **true by construction** — "Available from e& in the
UAE", "Pay over time with SmartPay", "Genuine {brand} product". Returning none would make
the feature invisible offline and untestable; inventing product claims from a template
would be worse than either. None asserts a property of the product itself.

### Verified live

One fresh row (`Sony WH-1000XM6`) through the real providers returned five USPs, all
flagged `model recall`, all unticked, none carrying a figure or a price. Approving
"Wireless listening with no cable fuss" and generating produced:

> Headphones without cable fuss: Sony WH-1000XM6
> Shop Sony headphones for wireless listening with no cable fuss in the UAE. Explore the
> Sony WH-1000XM6 at e& with SmartPay.

No errors. The claim reached both fields because a person ticked it.

---

## 32. The lab closed, and what that leaves behind

The lab — a second pair of pages at `/batch/{id}/lab/step/2` and `/lab/step/3` — existed so
a feature could be tried on real data without risking a build that had been shown to
leadership. It did its job twice: keyword tiers graduated in §31, and row-at-a-time paging
graduated here.

Which left it with nothing to do, and a cost. Two sets of routes rendered the same
`_keyword_row.html` and called the same endpoints; the only difference was which rows
started immediately. That is two things to keep in step, one of them unvisited, and a
second copy of a page is exactly how two pages come to disagree about what a tool does.
So it is deleted, along with the `Lab` badge and its CSS.

The isolation tests were inverted rather than removed. `TestTheDemonstratedJourneyIsUntouched`
became `TestThereIsOneJourney`: where it asserted the real pages had no tier controls and
loaded every row at once, it now asserts the real pages HAVE the controls, DO paginate, the
lab routes return 404, and no page still wears the badge. Same tests, same job, opposite
direction — which is what should happen to an isolation test when the thing it isolated
gets adopted.

### Paging is invisible on a small batch, on purpose

`ROWS_PER_PAGE` is 8 and lives in `policy.py` with the other reviewable limits. A batch of
eight rows or fewer starts every row at once, exactly as it did before paging existed. So
the six-row demo batch behaves identically, and the feature only shows up on the twenty-row
batches it was built for.

### The gap this does not close

Worth recording plainly, because it is now the largest thing wrong with the build and it is
not a bug: **every row generates eleven copy fields and the page shows two.**

`h1`, `answer_block`, `benefits`, `faqs`, `faq_jsonld`, `geo_prompts`, `app_headline`,
`app_subhead` and `app_cta` are generated on every row, validated on length, and stored —
then shown nowhere and exported nowhere on the template layout. Brief §7 asked for them and
they were built; the three-page cut-back in §21 removed the surfaces that displayed them,
and the keyword-research pivot replaced the five-sheet export that carried them with a
single sheet that does not.

So the tool is paying for Tier 2 output on every row and throwing it away. Surfacing it is
the highest value-per-effort work left: the content already exists, so it is a disclosure
on the copy page and either extra columns or extra sheets in the export. Raised, not
actioned — it was not asked for, and adding it unasked to a build being presented today
would be the wrong call.

---

## 33. "None proposed" was a dead end, and a dishonest one

Three rows of a freshly researched seven-row batch showed **none proposed** under selling
points. Nothing was broken in the sense of an error, and nothing could be done about it.

### Why it could not be recovered

Three facts, each reasonable, combining into a trap:

1. USPs are written during research, inside `store_row_keywords`.
2. Research does not re-run for a row that already has keywords — correctly, because
   re-running costs money and returns the same volumes.
3. `propose_candidates` caught every exception and returned an empty result.

So a row that came back without selling points had no route to getting any, and the only
record that anything had gone differently was the absence itself.

### Why it happened

Not a failure. `IdeasSchema.usps` carries a default of `[]`, so a reply that omits the
field parses cleanly as "no selling points" — and the same product asked twice gives
different answers. Row 4 of that batch returned nothing on one attempt and three claims on
the next, which rules out anything product-specific.

The default stays. A model that cannot identify a product SHOULD return none rather than
invent claims about it, and the prompt says so in those words. "Return fewer, or none" is
the behaviour we asked for; what was missing was a way to ask again.

An honest note on the diagnosis: for the original three rows it is **not possible to tell**
whether the call raised or the model returned an empty list, because nothing recorded it.
That is the defect, not a detail of it — hence the logging below.

### The fix

- `POST /batch/{id}/rows/{n}/usps/propose` — one seed-model call, no volume lookup, outside
  the write lock like every other network call on that page. `add_proposed_usps` is
  additive and deduplicates case-insensitively, so a hand-typed claim survives a retry and
  asking twice cannot produce the same claim twice. The per-row cap still applies.
- The empty state states what it knows — "None came back for this product when it was
  researched" — and carries the button. If a retry also comes back empty it says the model
  proposed nothing usable and offers the typed box instead, rather than looking broken.
- The swallow in `propose_candidates` logs. Falling back to derived seeds remains the right
  behaviour — a row still gets measured keywords — but it silently costs the row its
  selling points, and that is worth a line in a log file.

### The pattern this is the fourth instance of

A thing the tool did once, could not be asked to do again, and reported as a property of
the data rather than as a gap:

| | |
|---|---|
| A removed keyword | kept in the database, unreachable from the screen → restore |
| A reopened batch | copy marked stale, no way to see what it had been |
| A blocked row | 500 on a revoked key, row left permanently failed → retryable |
| A row with no USPs | no route back to asking → this section |

Worth stating as a rule: **anything the tool does for a row, it should be possible to ask
it to do again for that row.** The cost of a retry button is small and the cost of its
absence is a user who concludes the tool is wrong about their product.

---

## 34. "In the UAE" was mine, and it was wrong

Asked where the phrase came from and whether it had ever been mandated. It had not. The
record, searched:

| Where "UAE" appears | What it is |
|---|---|
| BRIEF.md line 11 | describes whose team this is — "content team in the UAE" |
| BRIEF.md §1 rule 5 | the model must be hosted in-region: "Azure OpenAI UAE" |
| BRIEF.md §9 | the Google Ads geo target for keyword lookups |
| *SEO Copy Guidelines* | **nothing**. The rules are spelling, an action verb, SmartPay, the character limits, keyword placement, uniqueness, no stuffing |

So no mandate, no guideline. Three instructions were producing it and all three were mine:

1. `COPY_SYSTEM` opened by describing e& as "a telecommunications and electronics retailer
   **in the United Arab Emirates**".
2. Every request carried `Market: United Arab Emirates. Locale: en.` — the biggest cause.
   Stating the market as background context reads to a model as a thing worth saying.
3. Money rule 4, added two days earlier, said in as many words: for "<product> price in
   uae", *"write about the product in the UAE"*.

And the result was poor craft, which is the actual objection:

```
airpodsmax2 Apple Headphones in the UAE | e&          44/60
iPhone 17 Pro by Apple in the UAE | e&                38/60
apple airpods3 Earbuds | Explore Apple in the UAE | e& 54/60
```

The phrase typically landed in the **title and the description** — spending twice from a
60-character budget to tell a reader which country they are already shopping in. Worse, it
had become the model's default way of making titles unique across a batch, which is why
three of them read like the same template with the product swapped.

### The rule

A location may appear only where a **person** put one. Two routes, both human:

- a keyword they **tiered** contains one, so "projector in uae" is what the page targets;
- they **typed** it, which `FieldContext.human_edited` carries.

`no_unrequested_location` is an **error**, not a warning, so the regeneration loop removes
it. A warning would report the phrase and leave it in the copy, which is the opposite of
what was asked.

### Two details worth defending

**`requested_terms` is narrower than `secondary_keywords`.** The latter is every approved
term on the row; the former is only what carries a tier. Since `candidates.py` generates a
market-qualified term for every product, permitting the phrase whenever one was *available*
would mean the rule never fired. The question is not "is this term available" but "did a
human choose it".

**What is deliberately not caught:** "emirates" alone, which is a brand in this market, and
"gulf", which appears in product names. Both would flag copy making no geographic claim.

The offline templates were changed too. A rule enforced only when someone is paying for a
model is not a rule.

### The general lesson, since this is the second one of these

§30 was the tool contradicting itself about price keywords. This is the tool adding
something nobody asked for and then treating it as a requirement. Both came from the same
habit: **context I put in a prompt becomes an instruction the model follows**, and there is
no validator to catch it unless someone writes one. Worth re-reading the prompts for
anything else that is description masquerading as direction.

---

## 35. Three prompt-pass fixes, and what the audit was actually for

§34 ended with a suspicion: that context written into a prompt becomes an instruction, and
nothing catches it. A deliberate pass over every prompt found five more, three of which
were actively shaping copy.

### The length guide had become an instruction

The numbers are the team's — BRIEF.md line 204 has `50–60 chars` and `120–155 chars`,
labelled **"Character guide"**, **"all approximate and configurable"**. My first suspicion
was that I had invented them. I had not.

What I had done was turn a guide into a demand, twice over: the prompt said *"aim for
50-60 and 120-155"*, and `CHAR_SHORT` warned on anything under. So a 45-character title —
fully compliant with the actual rule, which is 60 or fewer — was told it was too short.

**This is the mechanism behind §34.** The model was being pressed for length on copy that
was already fine, and the cheapest way to add length without adding meaning is a filler
phrase. "in the UAE" was the filler nearest to hand. Removing the phrase without removing
the pressure would only have changed which filler appeared — and it did: the rows rewritten
under §34 came back with *"Discover SmartPay as you take the next step towards your
purchase"*.

So the ceiling stays an error, and the guide became what the brief called it: information.
"Uses 45 of the 60 characters available (guide: 50-60). Fine if the copy says what it needs
to — do not pad it."

### The filing category was being printed

`Category as supplied:` went into every prompt with nothing said about what it was for, so
the model used it: a **monitor** described as *"listed under Smart Home"*, products placed
*"in our Smart Home range"*. That second one is a claim about e&'s merchandising, generated
from a spreadsheet cell, on a page nobody checked.

The sheet files projectors and monitors under "Smart Home" and AirPods under "Devices".
Those are internal taxonomy labels, and nothing in the guidelines asks for them in copy.
The line is now `Internal filing category (NOT for the copy)` with an explicit prohibition.

### A guideline and a rule of ours disagreed

The guidelines name six action verbs: *"such as: Buy, Shop, Get, **Pre-order**, Explore,
Discover."* `WARN_AVAILABILITY` flagged `pre-?order`.

So following the guideline, using the guideline's own example, earned a warning from a rule
I wrote. Nothing had hit it because the model kept choosing "Shop". The team's document
wins; "coming soon" and "available now" still warn, because they date a page in a way
"pre-order" does not.

### What the pass also confirmed was fine

Worth recording, because an audit that only finds faults is not an audit. The ideation
prompt's UAE framing is correct and stays — geo-qualified keywords are real research, and
that prompt is about what people type, not what we print. It names amazon.ae, noon.com and
sharafdg.com as reference listings; every stored keyword across every batch was checked and
**no competitor retailer name has leaked into one**. The action-verb list, SmartPay in the
second sentence, the price rule and the character figures are all genuinely the team's.

### The two left undone, on purpose

`smartpay_mentioned` fires on every description regardless of page type, while the
guideline says "every **product** description" — a category page would be told to mention
an instalment plan. And the same judgement about shortening a long product name uses `> 45`
in the prompt and `TITLE_NAME_BUDGET = 42` in the fixture, neither of them in `policy.py`.
Both are tidying; neither changes what anyone reads today.

---

## 36. Keyword quality, and the limits of a blocklist

A Samsung Galaxy Fold row returned this, every figure real:

```
samsung galaxy       40,500   the page's own term
semsem galaxy        40,500   not a word, not a brand, not this product
samsung s24 ultra    33,100   a different phone — tiered SECOND, on volume
samsung a56          27,100   a different phone
samsung a17          18,100   a different phone
```

Three of those are genuine demand for products that are not this page, and the tool had
promoted one of them into the copy prompt. A page about a foldable was optimising for an
S24 Ultra.

### Why the existing filters missed all of it

| Filter | Why it did not fire |
|---|---|
| `names_a_different_model` | compares generations within a `(family, line)` pair, and returns False when the PRODUCT has no qualifier. "Galaxy Fold" has none, so every other Galaxy model was waved through |
| `names_another_brand` | only knows brands it has heard of. "semsem" is not a brand |
| `has_repeated_word` | catches ads-platform permutations, not foreign tokens |

Each was written against a specific defect seen in a specific batch. That is the failure
mode of a blocklist: it only ever knows the junk it has already met.

### The rule, inverted

`app/lib/quality.py` requires every word to be **accounted for** rather than listing what
is bad. A row's vocabulary is its product name, its brand, its filing category, and the
seeds it was researched with — plus a small set of words that sit next to any product
(intent, place, condition, audience).

The seeds are what make this work without a maintained word list. They are the model's and
the derivation's idea of what this product is called, so the gate adapts per product:
"foldable phone" is unaccounted-for in the abstract and fine on a row seeded with it. The
test asserts exactly that pair, because it is the property the design rests on.

On top of the accounting rule, two named reasons so a reviewer gets a useful one:
profanity, and brand misspelling by edit distance — "sasmung" is reported as *looks like a
misspelling of samsung*, not as unrecognised.

### Where the risk now sits

A gate that rejects good terms is worse than one that lets a few through, so the tests
spend more effort on what must survive than on what must not: eleven legitimate long-tail
projector terms, the product's own model code, market-qualified forms, price-intent forms.
If this is ever too aggressive, the symptom will be thin keyword lists, and the lever is
`GENERIC_VOCABULARY`.

---

## 37. The campaign name moved out of the sheet

"Batch number" is now **Campaign/File Name**, and the input template no longer needs a
batch column — all four columns of it were being retyped per row to carry one value.

It is typed once at upload and returned as the **first column of the export**, so the
delivered sheet records which run produced it without anyone maintaining a column for it.
The export header changed with it: reproducing "Batch No/Name" for a column that was never
supplied would be describing the file wrongly.

The stored field is still `Batch.batch_no`. Renaming a database column to match a
relabelled input is churn with no reader benefit, and the two places it surfaces — the
upload form and the export header — now both say what it is.

Sheets that still carry a batch column are read exactly as before. The team will have both
shapes in circulation for a while, and a tool that rejects last month's template is a tool
people stop using.

---

## 38. A cache for figures already bought

**There was none.** Every batch with a Samsung phone bought "samsung"; every projector row
bought "projector". Across seven test batches the same terms were purchased several times
over.

`VolumeCache` keys a figure on term + market + locale.

### Why caching a measurement is defensible — corrected

The first version of this section said: *"Google reports a twelve-month average and
updates it monthly, so a reading on the 1st and one on the 20th are the same number."*
Challenged, and it does not hold. The twelve-month-average part is right; the rest
overstated what we know.

**The reason the figures are stable is bucketing, not cadence.** Reported volumes come
back on a discrete ladder — 165,000 / 110,000 / 40,500 / 33,100 / 12,100 / 8,100 / 590 /
90 / 40 / 10 — so underlying demand can move by several percent without the published
number changing at all. Our own data shows the granularity plainly: `samsung galaxy` and
`semsem galaxy` both returned exactly **40,500**, and `apple`, `i phone 17` and
`iphone 17` all returned exactly **165,000**. Those are close variants grouped onto the
same rung. A number that coarse does not need a tight refresh window to stay correct, and
that — not a schedule — is what the cache rests on.

### Known limitations, recorded rather than implied

- **Google publishes no documented refresh cadence.** Monthly refresh is practitioner
  consensus, not policy. Any statement that a figure is "at most a month old" is an
  inference about someone else's pipeline.
- **The window rolls, so the oldest month drops out of the average.** For seasonal terms
  that is material, and a campaign named "Ramadan Smartphones" is precisely the case where
  it bites: the same keyword genuinely means something different in the twelve months to
  March than in the twelve months to September.
- **DataForSEO's own update cadence is unverified.** They are an intermediary between us
  and Google Ads, and we have never checked how quickly they pass a refresh through. An
  unchecked link in the provenance chain, stated as one.

### `data_date` was lying, and that was the worse problem

`_dataforseo.py` set `collected = datetime.now()` and stored it as `data_date` on every
figure. So the column recorded **the moment of the request**, dressed as the age of the
data, and the tool could not report the vintage of any number it held. For a build whose
whole argument is provenance — an LLM never produces a volume, a missing figure is never
interpolated, a price appears only if a human typed it — that was out of step.

It was also avoidable: the Google Ads endpoints return `monthly_searches`, the per-month
breakdown the average is taken over, and `parse_expansion` and `parse_response` were
discarding it.

Now parsed. `read_period()` returns the last month covered and how many months the average
spans; both are stored on `Keyword` and `VolumeCache`. A response with no breakdown yields
**None**, never today — "vintage unknown" is a fact, and substituting the clock is how the
original defect happened. A source-level test asserts `data_date` is never assigned from
`now()` in that module, because this is the kind of thing that creeps back.

The payoff is a claim that can be checked. The keywords page now says:

> Search volumes cover the 12 months to September 2026.
> Averages over a trailing window, reported on a rounded scale — treat them as orders of
> magnitude, not exact counts.

And when a row's figures span two published windows it says so rather than quoting only
the newest.

### Expiry is measured on the data, not on us

The cache used to expire on `fetched_at`, which has no relationship to the age of the
figure: a volume bought yesterday can already describe a window that closed months ago,
and one bought months ago can still be the newest published. Expiry now reads
`data_date`, so the question is "how old is this measurement" rather than "how long ago
did we ask".

That rule alone does not terminate, which is why there is a second one. If the published
window genuinely is old, re-fetching returns the same old window — still stale, so the
next row re-fetches, and every row after it. So `VOLUME_RECHECK_DAYS` (14) is a cost
guard: an entry whose data is out of date but which we asked about recently is served
anyway. It is the newest figure that exists; buying it again changes nothing but the bill.
`fetched_at` is the clock for that guard and nothing else, and a read does not move it —
a cache that renewed its own expiry on every read would never expire.

`VOLUME_MAX_VINTAGE_DAYS` defaults to **120**, and that number came from a measurement
rather than a guess — which is the point of having parsed the vintage at all.

On **8 October 2026**, a live lookup for `samsung galaxy` returned figures covering the
twelve months to **August 2026**. The published window was already **68 days** behind. The
first value here was 75 days, which would have declared that perfectly normal data stale
within a week and re-bought every term on a schedule set by our own threshold rather than
by anything actually changing.

Worth sitting with: under the old code that same figure was stamped "collected today".
Nobody would have known it described a window that closed in August.

120 days accommodates the observed lag with room for a refresh to arrive late. Still a
tolerance, still **not** an alignment to a cadence we cannot see.

**Entries with no recorded vintage are never served.** The rows written while the provider
was recording `now()` hold a value that is wrong under the column's new meaning, and
serving them would carry the error forward. `forget_undated()` clears them out.

### Three decisions inside it

**A measured absence is cached.** "We asked and Google had no data" costs the same to ask
again and gives the same answer. `volume` stays nullable and a cached NULL is meaningful.

**The expansion is not cached.** `expand()` answers "what else do people type around this
seed", and that answer set moves as search behaviour does. Caching it would freeze a row's
long tail to whenever its seed was first researched — a different kind of claim from
reusing one term's average.

**It is held to the provider boundary.** The module writes `volume=`, so
`tests/test_no_llm_volumes.py` requires it to import `app.providers.keywords`. That is the
right rule for it: a cache is somewhere a wrong figure could enter, so it answers to the
same test as the provider.

### Reads and writes sit on opposite sides of the lock

`read()` runs in the network phase and holds no write lock. `remember()` and
`record_hits()` run in the phase that persists the row, under the lock. Writing cache rows
during the slow phase would mean holding the lock across a network call, which is the
mistake that once turned nine rows into a ten-minute queue.

`/healthz` reports terms held, terms fresh, and lookups avoided — an unmeasurable saving is
an unverifiable claim.

---

## Open questions — raised, not guessed

Per brief §12, these need a decision from someone other than the engineer:

1. **App content limits** (screen headline ≤40, subhead ≤90, CTA ≤20) are placeholders from the
   brief. They ship in `app/lib/policy.py`, labelled unconfirmed in the UI, and must not be
   presented as agreed. **Needs the app team.**
2. **Arabic character limits** — character- or grapheme-based? See section 6. **Needs the content
   team**, before Arabic is added.
3. **Factual grounding** — the business should confirm decision 3 (no page fetching). It caps how
   specific generated copy can be, which is a content-quality trade-off, not a technical one.
4. **Arial metric licensing** — see section 7. **Needs legal** if this ever ships beyond a
   prototype.
