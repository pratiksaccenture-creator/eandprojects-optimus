# Optimus — v1.3

An internal SEO copy tool for e&'s UAE digital content team. It takes an Excel list of
products — batch, category, brand, product name — researches the keywords people actually
search for with real search volumes, lets a researcher tier and correct them, writes titles
and descriptions inside hard character *and* pixel limits, and hands the sheet back with the
copy added.

Built against [BRIEF.md](BRIEF.md) and the content team's *SEO Copy Guidelines*. Every
choice a reviewer might otherwise have to reverse-engineer is recorded in
[DECISIONS.md](DECISIONS.md), including the places where this build diverges from the brief
and why. What changed between builds is in [CHANGELOG.md](CHANGELOG.md); the walkthrough for
showing it to someone is [DEMO.md](DEMO.md).

The running build is shown in the masthead and by `/healthz`.

## Run it

```powershell
.\run.ps1 -Setup
```

Then `.\run.ps1` and open <http://127.0.0.1:8123>. On a machine where Windows blocks
PowerShell scripts, double-click `start.bat` instead.

**Credentials are required.** Copy `.env.example` to `.env`, fill in DataForSEO and
OpenAI, and run `.\run.ps1 -Keys` to check them — that check is free. Without them the
tool opens and says what is missing, then refuses at the keywords step. It does not
substitute sample figures for real ones. See "Going live" below, and DECISIONS.md §29 for
why this replaced the old fixture fallback.

For a demo with no network, set `KEYWORD_PROVIDER=fixture` and `LLM_PROVIDER=fixture`.
That is the only route to seeded data, nothing reaches it by default, and every screen
says the numbers are seeded while it is on.

```powershell
.\run.ps1 -Check    # pytest + mypy
```

## The journey

Three pages:

1. **Upload** — an `.xlsx` file. Four columns:
   `Batch No/Name | Product Category | Brand | Product Name`, plus an optional `Price` and
   an optional `Product URL`. `fixtures/product-template.xlsx` is the template.
2. **Keywords** — one row per product with its researched keywords and volumes, highest
   demand first. Click any term to make it the primary. Approve.
3. **Copy** — the title and description for each row, with a character count, a Refresh
   that offers a different phrasing, and a price box that rewrites the description around
   a figure you supply. Approve and export, or open History.

The export is the input sheet handed back with three columns added — `Meta Title`,
`Meta Description`, `Keywords & Volumes` — and nothing else.

## How the keywords are found

The model produces **seeds**; DataForSEO produces the **keywords**.

Given a product name, category and brand, the model works out what the thing is, who buys
it and what they call it, and proposes up to 20 short seed terms across the six buckets the
content team currently produces by hand in ChatGPT: brand, product, device type, category,
USP/intent, and SmartPay. DataForSEO's `keywords_for_keywords` endpoint then expands those
seeds into the real long tail — up to 20,000 terms, each carrying its own search volume,
for one charge per request.

That split is the point. The long tail is what UAE users demonstrably type, not a model's
idea of what they might; a model asked for it directly would be inventing the phrasing and,
implicitly, the demand. Volumes are looked up for product, brand and category terms and not
for colours, storage sizes or case sizes, because nobody searches "pearl white" and
measuring it wastes the budget.

Terms the provider has no data for stay on screen, marked `no data`. An empty bucket is a
finding about the market; a term that quietly vanished looks like one nobody tried.

## The SEO Copy Guidelines

Copy is written and validated against the content team's written guidelines
(*SEO Copy Guidelines, 21 Sep 2026 v2*), encoded as data in
[`app/lib/policy.py`](app/lib/policy.py) so a non-engineer can read what the tool enforces:
UK English except inside brand names, ≤60 and ≤160 characters, the primary keyword
front-loaded, an action verb, SmartPay in every description, uniqueness across the batch,
and no keyword stuffing.

**Prices are the one place the guidelines and the original brief collide.** The guidelines
require a starting price in the second sentence; the brief lists live prices in indexed
meta descriptions as defect #1. The resolution: a figure may appear **only if a human
supplied exactly that figure** — from the `Price` column, or typed into the row on the copy
page. A different figure, a second figure, anything with `/month`, or any price at all on a
row where nobody supplied one, all still block the export. The model can never produce one:
there is no field for it and no way for it to change the permission. Rows with no price
generate without one and carry a visible warning. DECISIONS.md §28.

A richer interface exists and is preserved in [`archive/full-ui/`](archive/full-ui/README.md):
SERP previews with the truncation point marked, per-field validation findings, inline
editing, attempt diffs, the app-store tab, and a diagnostics page. It was set aside to keep
the journey simple, not because it stopped working — **the backend is unchanged and the
exported workbook is identical**. That README lists exactly what is there and how to put any
of it back.

## What it does, and what it refuses to do

The tool exists to remove specific defects from the team's current output: live prices inside
indexed meta descriptions, a description at exactly 160 characters against a stated "under
160" limit, a brand suffix on one title in five, stale product generations in keyword cells,
a third of each keyword cell duplicated, and — worst — 16 of 21 input rows silently dropped.

Each of those is now structurally impossible rather than something a careful human catches:

- **An LLM never produces a search volume.** Volumes come only from a `KeywordVolumeProvider`.
  A term the provider has no data for is marked `unverified` and excluded, never estimated.
  `tests/test_no_llm_volumes.py` enforces this by parsing the source, not by review.
- **Every length limit is enforced in code**, with the failing cases from the reference file
  as tests. Characters are counted in UTF-16 code units so they mean the same thing as
  Excel's `LEN()`.
- **Pixel width is measured, not guessed**, from a font's own advance-width table, and the
  ±3% caveat is shown on screen rather than buried.
- **Nothing is truncated to fit.** A string that will not fit stays too long, fails, and
  blocks the export.
- **Every generated string is traceable**: which keywords fed it, which model, which prompt
  version, which attempt, and its validation result. Edits append a new attempt rather than
  overwriting one.
- **Failures are visible.** A row that cannot be processed keeps its place in the export with
  a stated reason.
- **Nothing is faked.** The provider badge says "seeded data, not live" and the model badge
  says "deterministic templates, not a model", on every screen that shows either.

## Stack

Python 3.12+, FastAPI + Jinja2, SQLAlchemy + SQLite, openpyxl, Pydantic, pytest, mypy.
Hand-written CSS and a ~150-line hand-rolled DOM swap layer — **no third-party JavaScript
runtime**, so the tool is provably offline.

The brief specifies Next.js, Prisma, ExcelJS and Vitest. Node is not installed on the build
machine, so the stack was rewritten in Python with the user's agreement; the architectural
requirements behind the original choice are all preserved. See DECISIONS.md §1.

## Layout

```
app/
  lib/         limits.py, validators.py, policy.py, surfaces.py, normalise.py
  excel/       reader.py, writer.py, determinism.py
  providers/   keywords/ and llm/ — the only seams to outside services
  services/    ingest, keyword_service, candidates, generation, validation,
               export_service, retention, seed
  routers/     wizard (the three pages), history, dev (JSON only)
  templates/   Jinja2, hand-built components only
  static/      css/simple.css, js/swap.js
tools/         extract_font_metrics.py  (build-time, output committed)
tests/         241 tests
fixtures/      the two reference workbooks
archive/       the richer UI, preserved with restore instructions
```

### Two seams worth knowing about

`app/providers/llm/` is the only place a model is called. Implementations are
underscore-private and reached through `get_llm()`, so repointing to Azure OpenAI UAE is one
file plus `LLM_PROVIDER=azure`, with **no call-site edits**.
`tests/test_provider_boundary.py` enforces that by walking the import graph.

`app/providers/keywords/` is the only place a search volume can originate — including the
spreadsheet reader for the seeded volumes, which lives there rather than in `app/excel` for
exactly that reason.

## Configuration

Every setting has a working default. The ones worth knowing:

### Going live

Copy the template and fill in what you have. Nothing else to configure — each provider
switches on by itself once its credentials are present:

```powershell
Copy-Item .env.example .env
```

```ini
DATAFORSEO_LOGIN=you@example.com
DATAFORSEO_PASSWORD=          # the API password, not your dashboard password
OPENAI_API_KEY=
```

`.env` is gitignored. Keep credentials there rather than in a terminal, a ticket or a chat
window. Real environment variables still win if both are set. **Edit `.env` in a text
editor, not with PowerShell `Set-Content`** — see DECISIONS.md §26.

Then confirm the credentials before spending anything on them:

```powershell
.\run.ps1 -Keys
```

That checks the DataForSEO login and balance and the OpenAI key and model id against
endpoints that are free on both accounts. It generates no copy and looks up no volumes.

`GET /healthz` reports which providers are actually in use, and every page names them.

| Variable | Default | Effect |
|---|---|---|
| `LLM_PROVIDER` | auto | `openai`, `anthropic`, `azure`, or `fixture` for an offline demo. Prefers OpenAI when both model keys are present. Unset with no keys = refuses. |
| `KEYWORD_PROVIDER` | auto | `dataforseo`, `semrush`, `google_ads`, or `fixture` for an offline demo. Prefers DataForSEO. Unset with no keys = refuses. |
| `PAGE_PROVIDER` | auto | `none` or `http`. Follows the model — no point reading a page if nothing can read facts off it. |
| `OPENAI_SEED_MODEL` | = `OPENAI_MODEL` | A faster model for keyword seeds only. The seed call is the slowest part of the keywords step. |
| `MAX_CONCURRENT_ROWS` | `3` | How many rows research at once. Capped because DataForSEO allows 12 requests a minute. |
| `OPENAI_MODEL` | `gpt-6-astra` | Any model your account can reach. |
| `OPENAI_BASE_URL` | — | Point at Azure OpenAI or an internal gateway. |
| `ANTHROPIC_MODEL` | `claude-opus-5` | Used only when `LLM_PROVIDER=anthropic`. |
| `DATAFORSEO_LOCATION_CODE` | `2784` (UAE) | Google location criteria ID. |
| `SEED_DEMO_BATCH` | auto | `1` forces the startup demo batch, `0` suppresses it. See below. |
| `DEMO_PACING_MS` | `0` | Artificial per-row delay. Off by design; when non-zero the UI shows a red chip. |
| `RETENTION_MONTHS` | `6` | Purge window. |

Setting a provider explicitly always wins, so `KEYWORD_PROVIDER=fixture` forces seeded
data even with live keys present. That is the only route to seeded volumes: nothing
resolves to them on its own, so they cannot appear by accident.

**Both model providers share one set of prompts** (`providers/llm/_prompts.py`). Swapping
`LLM_PROVIDER` changes who answers, never what was asked, so a comparison between OpenAI and
Claude is a fair one.

A live provider that is selected but missing credentials raises `NotConfiguredError`; it
never falls back to fixture data silently, because seeded numbers presented as live ones is
the one failure this tool must not have.

**Adding a key never starts spending on its own.** In fixture mode the app seeds a complete
demo batch at startup by running the real pipeline, so it opens with something to show; with
live providers that same seed would be 21 page fetches and dozens of model calls charged
before the server accepts a connection, so it is skipped and the tool opens on the upload
page. Detection decides *which* provider, never *whether* to spend. `SEED_DEMO_BATCH=1`
forces the seed when the cost is intended. DECISIONS.md §27.

**Division of labour, and why:** the model does fact extraction, keyword ideation and copy
drafting. DataForSEO supplies search volumes and nothing else. A language model cannot know
how many people searched for something — [tested against real Search Console data, LLM
volume estimates correlate weakly at best](https://dejan.ai/blog/llm-search-volume/) — so it
is never asked. No schema the model fills in has a field for search demand, and a test
parses the source to prove no path exists.

If you use Semrush instead, we call its **REST API**, not the Semrush MCP: Semrush documents
the MCP as "designed for AI agents rather than direct server-to-server calls" and warns its
responses "may be incomplete or inaccurate". Both bill the same API units. See DECISIONS.md
§23.

## The export

Five sheets. Sheet 1 reproduces the team's existing 8-column layout **verbatim**, including
the trailing space in the `Keywords ` header and the `Meta Decsription (EN)` spelling — those
are not tidied, because the file has to drop into an existing process. Character counts stay
live `=LEN()` formulas.

Two things are deliberately changed, because they are the defects being fixed: column C holds
the product URL on **every** row, and the product name gets its own new column J so nothing
existing shifts.

Exporting and then re-downloading from history yields a **byte-identical** workbook, because a
re-download regenerates from the stored records and replays the original version and
timestamp rather than serving a saved file. `tests/test_export_determinism.py` verifies this
across separate interpreters under different `PYTHONHASHSEED` values.

> **Open the export in desktop Excel.** openpyxl writes formulas without a cached value, so
> Excel Online, Outlook preview and LibreOffice may show the count columns blank until a
> recalculating client opens the file. The same numbers are also written as plain integers on
> the `Validation log` sheet.

## Known limits

- **English only.** The schema and measurement code are locale-aware and Arabic is not
  painful to add, but the Arabic columns were removed from the reference workbooks so nothing
  is generated for them. Pixel validation deliberately **refuses** to score Arabic rather
  than return a wrong number — per-character advance widths are invalid for a script that
  needs contextual shaping.
- **eand.ae product pages render client-side.** An eshop page returns 888KB of HTML and about
  1,000 characters of DOM text; the specifications live only in the page's existing
  `<meta name="description">`. The extractor therefore reads head metadata as well as body
  text. That metadata is the copy being replaced — prices and all — so the extraction prompt
  discards commercial language and the banned-terms validator blocks anything that slips
  through. For genuinely reliable specs you want a product API or a headless browser.
  DECISIONS.md §24.
- **In fixture mode pages are never fetched**, so no specification is ever invented and no row
  is reported as successfully fetched.
- **The three app-content limits are unconfirmed placeholders**, labelled as such in the UI.
  They need the app team.
