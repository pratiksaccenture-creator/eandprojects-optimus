# Setting up Optimus on the office Mac Studio

Written for the person at the Mac **and** for Claude Code helping them. The person may not
be technical, so:

> **Claude:** run the terminal steps yourself. Stop and hand over, in plain language, only
> at the steps marked **(by hand)**. Wait for the person to say they're done before
> carrying on.
>
> - **Never ask for API keys in chat**, and never read `.env` back out. Open it in TextEdit
>   for the person to paste into.
> - **Don't change the app's code** to get past an error. Stop, explain what failed in one
>   or two sentences, and ask the person to send a screenshot to Pratik.
> - **Don't run `tools/extract_font_metrics.py`.** The font table ships with the build;
>   regenerating it on a Mac fails or changes the pixel-width figures.

The finished result: Optimus runs in the background on this Mac, starts on its own when
the Mac is logged in, and anyone on the office network can open it in a browser.

---

## 1. Unpack into `~/optimus`

The build must live at `~/optimus`, **not** in Downloads, Desktop or Documents. macOS
blocks background services from reading those three folders, so the service in step 6
would fail to start with "Operation not permitted".

```bash
cd ~
unzip -q ~/Downloads/optimus-v1.5.0-mac-20261008.zip -d ~
mv ~/optimus-v1.5.0-mac-20261008 ~/optimus
chmod +x ~/optimus/run.sh        # a zip made on Windows does not carry this
cd ~/optimus
```

If `~/optimus` already exists, this is an update rather than a first install. Follow
**Updating later** at the bottom instead.

## 2. Python 3.14 **(by hand, if missing)**

```bash
python3 --version
```

Needs **3.12 or newer**; 3.14 matches the laptop build. Apple's own `python3` reports 3.9
or opens an "install developer tools" dialog. Neither will do. If so, ask the person to:

1. Go to https://www.python.org/downloads/macos/ and download the latest **Python 3.14**
   macOS installer.
2. Open the downloaded file and click Continue / Agree / Install, entering the Mac
   password when asked.
3. Close the Finder window that opens at the end.

Then open a **new** terminal and check again. If `python3` still reports the old version,
use the full path for the rest of setup:
`export PYTHON=/Library/Frameworks/Python.framework/Versions/3.14/bin/python3`.

## 3. Install

```bash
./run.sh --setup
```

Takes a minute or two. If `pip` fails with **SSL / certificate** errors, the office network
is inspecting secure traffic. That needs e& IT, not a code change. Stop and say so.

## 4. API keys **(by hand)**

```bash
cp .env.example .env
open -e .env
```

Tell the person: *"A file has opened in TextEdit. Paste the keys Pratik sent you after the
`=` signs on the lines `DATAFORSEO_LOGIN`, `DATAFORSEO_PASSWORD` and `OPENAI_API_KEY`, with
no spaces. Save with Cmd+S, close it, and tell me when that's done. Please don't paste the
keys here."*

Then check them. This is free and makes no paid calls:

```bash
./run.sh --keys
```

If a key is reported as rejected, ask the person to reopen `.env` (`open -e .env`) and
check it against what Pratik sent. Typos and stray spaces are the usual cause.

## 5. Health check

```bash
./run.sh --check
```

About three minutes. Expect roughly 650 passed, 1 skipped, then "All checks passed". Any
failure: stop and report it. Don't try to fix it.

## 6. Run it as a background service

Write `~/Library/LaunchAgents/ae.eand.optimus.plist`, with `YOUR_USER` replaced by the
output of `whoami` in all three places:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>                <string>ae.eand.optimus</string>
    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>/Users/YOUR_USER/optimus/run.sh</string>
    </array>
    <key>EnvironmentVariables</key>
    <dict>
        <key>HOST</key>             <string>0.0.0.0</string>
    </dict>
    <key>RunAtLoad</key>            <true/>
    <key>KeepAlive</key>            <true/>
    <key>StandardOutPath</key>      <string>/Users/YOUR_USER/optimus/logs/server.out.log</string>
    <key>StandardErrorPath</key>    <string>/Users/YOUR_USER/optimus/logs/server.err.log</string>
</dict>
</plist>
```

```bash
mkdir -p ~/optimus/logs
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/ae.eand.optimus.plist
sleep 5
curl -s http://127.0.0.1:8123/healthz
```

`/healthz` should report build **1.5.0**. If it doesn't answer, read
`~/optimus/logs/server.err.log`.

If a macOS dialog asks whether Python may **accept incoming network connections**, ask the
person to click **Allow**.

Restart the service: `launchctl kickstart -k gui/$(id -u)/ae.eand.optimus`
Stop it: `launchctl bootout gui/$(id -u)/ae.eand.optimus`

## 7. Keep the Mac awake **(by hand)**

Ask the person to open **System Settings → Energy** and turn on:

- **Prevent automatic sleeping when the display is off**
- **Start up automatically after a power failure**

The service starts when this user logs in. After a restart someone has to log in, but the
screen can then be locked.

## 8. Give the person the address

```bash
echo "http://$(scutil --get LocalHostName).local:8123"
```

Tell them that is the address for the team. Opening it in Safari should show **Optimus**
with **v1.5.0** at the top. Ask them to send it to Pratik.

---

## Bringing existing batches across (optional)

Without this the Mac starts with an empty history plus the demo batch. To carry the laptop's
history over, Pratik stops the server on the laptop and sends the whole `data` folder. The
database has `-wal` / `-shm` side files that must travel together, from a stopped server.
Then on the Mac:

```bash
launchctl bootout gui/$(id -u)/ae.eand.optimus
# copy the received data folder to ~/optimus/data, replacing the one there
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/ae.eand.optimus.plist
```

A database from an older build is upgraded in place on start (new columns are added,
nothing is dropped). Old export records keep their Windows file paths. That is harmless,
because re-download regenerates the workbook from the database rather than reading the file.

## Updating later

Pratik sends a new `optimus-vX.Y.Z-mac-*.zip`. Keep `.env`, `data/`, `.venv/` and `logs/`.
Replace everything else:

```bash
launchctl bootout gui/$(id -u)/ae.eand.optimus
rm -rf /tmp/optimus-update && mkdir /tmp/optimus-update
unzip -q ~/Downloads/optimus-vX.Y.Z-mac-*.zip -d /tmp/optimus-update
rsync -a --exclude .env --exclude data --exclude .venv --exclude logs \
    /tmp/optimus-update/*/ ~/optimus/
chmod +x ~/optimus/run.sh
cd ~/optimus && ./run.sh --setup && ./run.sh --check
launchctl bootstrap gui/$(id -u) ~/Library/LaunchAgents/ae.eand.optimus.plist
curl -s http://127.0.0.1:8123/healthz      # should report the new build
```

## Before it goes beyond the immediate team

See `HOSTING.md`. In short: there is **no login**, so anyone on the office network can
upload, spend the API budget and read every batch. Put a spend cap on the OpenAI key,
and get e& sign-off on product data being processed on this machine and on the six-month
retention period.
