# Hosting Optimus for a client test

Written for the question "can we put this somewhere the client can try it?". Short answer:
yes, in about half a day — but four things must be true first, and one of them is not a
technical task.

---

## What has to change before a URL exists

### 1. There is no login. This is the blocker.

Right now every request runs as a hard-coded `content.team@eand.ae` demo user. There is no
sign-in, no session, no roles. On localhost that is fine; it is one person on one laptop.

Put the same thing on a public URL and anyone who has the link — or finds it — can upload a
batch, spend your DataForSEO and OpenAI budget, read every batch anyone else uploaded, and
export it. A link shared in an email thread is a link that gets forwarded.

Three options, cheapest first:

| | Effort | Good for |
|---|---|---|
| **HTTP basic auth** on every route, one shared password | ~1 hour | A time-boxed client test, where everyone testing can share one credential |
| **A short-lived access list** — named users, password each, sessions | ~half a day | A pilot where you want to know who did what |
| **e& SSO / Entra ID** | Needs their IT | Anything that outlives the pilot |

For a client test I would do basic auth, with the password rotated after, and say plainly
in the handover that it is a test credential and not an access-control design.

### 2. The keys move out of `.env` and into the host's secret store

`.env` stays on your laptop and never goes near the repo or the archive. On the host they
become environment variables set in the dashboard:

```
DATAFORSEO_LOGIN        DATAFORSEO_PASSWORD
OPENAI_API_KEY          OPENAI_MODEL
OPENAI_SEED_MODEL       DATABASE_URL
```

Two things to do at the same time:

- **Separate keys for the hosted copy.** A key you can revoke without stopping your own
  work on the laptop.
- **A spend cap on the OpenAI key**, and a note of the DataForSEO balance before you hand
  the link over. One charge per request, not per keyword — but a client clicking
  "Add & measure" repeatedly is real money, and there is currently nothing stopping them.

**I will never need you to paste a key into this chat.** You set them in the host's
dashboard; I work against names, not values.

### 3. SQLite needs a disk, or it needs to become Postgres

The database is SQLite with WAL, which is a good fit for one writer and a handful of
readers — which is exactly what this is. But most hosts give you an **ephemeral**
filesystem: the container restarts, the file goes, and every batch with it.

- **Render:** attach a persistent disk, mount it at `/data`, set
  `DATABASE_URL=sqlite:////data/app.db`, and keep the service at **one instance**. SQLite
  does not survive two instances writing to one disk.
- **If they want more than one instance**, it has to be Postgres. That is a real but
  contained job — SQLAlchemy already abstracts it — and the only code that cares is the
  write-lock, which exists because of SQLite and would become redundant.

Also worth setting: the exports directory onto the same disk, or re-downloads will 404
after a restart.

### 4. Someone at e& says yes to the data leaving the laptop

Not a technical step, and the one most likely to be skipped. Uploading a batch sends
product names to DataForSEO and OpenAI, which already happens on your laptop — but a
hosted copy means **client staff** putting **e& product plans** into it, and unreleased
product names in a batch are commercially sensitive.

Two specific things to raise:

- **Region.** BRIEF §1 rule 5 asks for a governed, in-region deployment — Azure OpenAI UAE
  or an internal endpoint. Render has no UAE region; the nearest are Frankfurt and
  Singapore. For a throwaway test that is usually acceptable, but it should be a decision
  someone takes rather than a detail nobody noticed. The provider seam exists precisely so
  that repointing at Azure UAE is one file and one environment variable.
- **Retention.** Batches carry a six-month retention date and a purge route. Nobody has
  agreed that six months is right for client-uploaded data.

---

## What deploying to Render actually looks like

Assuming a persistent disk and basic auth:

1. **A `render.yaml`** in the repo, or the equivalent filled in through their dashboard:

   ```yaml
   services:
     - type: web
       name: optimus
       runtime: python
       plan: starter          # a free instance sleeps; it will be slow to wake mid-demo
       buildCommand: pip install -r requirements.txt && python tools/extract_font_metrics.py
       startCommand: uvicorn app.main:app --host 0.0.0.0 --port $PORT
       numInstances: 1        # SQLite. Not negotiable while the database is a file.
       disk:
         name: optimus-data
         mountPath: /data
         sizeGB: 1
       envVars:
         - key: DATABASE_URL
           value: sqlite:////data/app.db
         - key: EXPORTS_DIR
           value: /data/exports
         - key: DATAFORSEO_LOGIN
           sync: false        # set in the dashboard, never in the file
         - key: DATAFORSEO_PASSWORD
           sync: false
         - key: OPENAI_API_KEY
           sync: false
   ```

2. **Get the code there.** Render deploys from a git repository, and there is no git on
   this machine — so this is the step that needs doing first. Either install git and push
   to a private repo, or upload the snapshot in `builds/` into one from a machine that has
   git.

3. **Two small code changes**, neither of which exists yet:
   - read the port from `$PORT` in the start command (above — no code change needed);
   - the auth middleware from item 1.

4. **Run the font-metrics extraction in the build.** `lib/advance_widths.json` is
   generated from the local Arial file. A Linux container has no Arial, so either commit
   the generated file or switch to Liberation Sans, which was chosen as the metric-
   compatible fallback for exactly this reason (DECISIONS.md, Arial licensing note).

   This is the one thing most likely to break the first deploy.

5. **Check timeouts.** A keyword row takes 20–40 seconds and copy up to 70. Render's
   default request timeout is generous, but a proxy in front of it may not be — and a
   worker that gets killed mid-row leaves the row retryable rather than broken, which is
   at least the right failure.

### Rough timings

| | |
|---|---|
| Basic auth middleware + a test | 1 hour |
| Font metrics sorted for Linux | 30 minutes |
| `render.yaml`, disk, env vars | 1 hour |
| Getting the code into a git repo | depends on git access |
| First deploy and shake-out | 1–2 hours |

Half a day of work, plus however long the approval in item 4 takes.

---

## Answering the two questions directly

**"Can I host it on your server?"** No — I have no server to put it on, and nothing I run
persists between our sessions. The local server I start for you dies when the machine
sleeps or the process is killed. Anything client-facing needs real hosting that e& or the
client controls and can audit.

**"Should I get Render details from the client tomorrow?"** Yes, that is a sensible way in,
and Render is a reasonable choice for a time-boxed test. When you have it, what I need is:

- confirmation the service has a **persistent disk**, or a Postgres instance;
- the **region** they have picked, so it can be recorded against the in-region question;
- who is **allowed to see the data** — which decides whether basic auth is enough;
- a say-so on **spend limits** for the two API keys.

What I do **not** need, and will not accept in chat, is any key or password. Those go
straight into Render's environment settings.

One more thing worth deciding before the link goes out: whether the client should be able
to **upload their own batches** or only look at a prepared one. Read-only is a much smaller
security and cost surface, and for a first look it usually shows more than letting someone
loose on an empty upload form.
