"""Keyword tiers and row-at-a-time paging, on the one journey.

Both were built on a separate pair of lab pages so an unproven feature could not break a
demo. Both graduated, and the lab is gone — so these tests now drive `/step/2` and
`/step/3` directly, and `TestThereIsOneJourney` at the foot of the file asserts the second
copy did not quietly survive the move.
"""

from __future__ import annotations

import io
from pathlib import Path
from typing import Any, Iterator

import openpyxl
import pytest
from fastapi.testclient import TestClient

from app.lib.policy import ROWS_PER_PAGE as PAGE_SIZE
from app.models import KeywordTier

TEMPLATE = Path(__file__).resolve().parents[1] / "fixtures" / "product-template.xlsx"
PARTIAL = {"X-Partial": "1"}


@pytest.fixture()
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_path / 'test.db'}")
    monkeypatch.setenv("EXPORTS_DIR", str(tmp_path / "exports"))

    import app.config
    import app.db

    app.config.settings.cache_clear()
    app.db._engine = None
    app.db._session_factory = None

    from app.main import app as fastapi_app

    with TestClient(fastapi_app) as test_client:
        yield test_client

    app.config.settings.cache_clear()
    app.db._engine = None
    app.db._session_factory = None


def _workbook(count: int) -> io.BytesIO:
    """A sheet with `count` distinct products."""
    book = openpyxl.Workbook()
    sheet = book.active
    assert sheet is not None
    sheet.title = "Products"
    for column, header in enumerate(
        ("Batch No/Name", "Product Category", "Brand ", "Product Name"), start=1
    ):
        sheet.cell(1, column, header)
    # Row 1 is deliberately a product the seeded volume sheet covers, so the tests that
    # need a MEASURED term have one in fixture mode. The rest are arbitrary — they only
    # need to be distinct, which is what the pagination tests care about.
    names = [
        "Apple Watch Ultra 4", "Samsung Galaxy S25", "Xiaomi Redmi Note 14",
        "Sony PlayStation PS5", "Eufy Robot Vacuum S1", "Ring Video Doorbell Plus",
        "AOC Gaming Monitor AG276", "Apple Watch Series 12", "Motorola Razr 40",
        "Apple iPad Air 7", "Samsung Tab A11", "Google Pixel 10",
        "Sony Bravia 65", "Lenovo ThinkPad X1", "Dyson V16",
        "Bose QuietComfort 2", "JBL Charge 6", "Logitech MX Master 4",
        "Anker PowerCore 5", "Garmin Forerunner 9",
    ]
    for offset in range(count):
        sheet.cell(offset + 2, 1, "T1")
        sheet.cell(offset + 2, 2, "Electronics")
        sheet.cell(offset + 2, 4, names[offset % len(names)] + (
            f" v{offset // len(names)}" if offset >= len(names) else ""
        ))
    buffer = io.BytesIO()
    book.save(buffer)
    buffer.seek(0)
    return buffer


def _upload(client: TestClient, count: int) -> int:
    response = client.post(
        "/upload",
        data={"batch_no": "T1"},
        files={"file": ("products.xlsx", _workbook(count), "application/vnd.ms-excel")},
        follow_redirects=False,
    )
    assert response.status_code == 303, response.text
    return int(response.headers["location"].split("/")[2])


def _research(client: TestClient, batch_id: int, count: int) -> None:
    for index in range(1, count + 1):
        assert client.get(
            f"/batch/{batch_id}/rows/{index}/keywords", headers=PARTIAL
        ).status_code == 200


# ---------------------------------------------------------------- tiers


class TestKeywordTiers:
    """The guidelines ask for "the primary keyword and, where possible, secondary and
    tertiary keywords". The page used to model only a primary, so those three levels
    could not be expressed at all.

    Tried on the lab page, then graduated to the real keywords page at the team's
    request. These tests follow it there — the routes under test are the wizard's.
    """

    def _first_row_keywords(self, batch_id: int) -> list[Any]:
        from app.db import session_scope
        from app.models import Batch

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            return sorted(row.keywords, key=lambda k: k.id)

    def test_the_keywords_page_renders_with_a_legend(self, client: TestClient) -> None:
        batch_id = _upload(client, 3)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert "Primary" in page and "Secondary" in page and "Tertiary" in page
        assert "Click a keyword to cycle" in page

    def test_clicking_a_term_cycles_it_through_the_tiers(self, client: TestClient) -> None:
        from app.lib.validators import banned_in_copy

        batch_id = _upload(client, 1)
        _research(client, batch_id, 1)
        keyword = next(
            k for k in self._first_row_keywords(batch_id)
            # Tierable, so a research-only term is not picked — those refuse the cycle by
            # design and are covered in `TestResearchOnlyTerms`.
            if k.tier is KeywordTier.unranked and banned_in_copy(k.term_normalized) is None
        )

        seen = []
        for _ in range(4):
            client.post(
                f"/batch/{batch_id}/rows/1/cycle?keyword_id={keyword.id}",
                headers=PARTIAL,
            )
            current = next(
                k.tier for k in self._first_row_keywords(batch_id) if k.id == keyword.id
            )
            seen.append(current)

        assert seen == [
            KeywordTier.primary,
            KeywordTier.secondary,
            KeywordTier.tertiary,
            KeywordTier.unranked,
        ], "a term must cycle, so a mis-click is undone by clicking again"

    def test_only_one_term_can_be_primary(self, client: TestClient) -> None:
        batch_id = _upload(client, 1)
        _research(client, batch_id, 1)
        keywords = self._first_row_keywords(batch_id)
        first, second = keywords[0], keywords[1]

        from app.db import session_scope
        from app.models import Batch
        from app.services import keyword_service

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            keyword_service.set_keyword_tier(session, row, first.id, KeywordTier.primary)
            keyword_service.set_keyword_tier(session, row, second.id, KeywordTier.primary)

        after = {k.id: k.tier for k in self._first_row_keywords(batch_id)}
        assert after[second.id] is KeywordTier.primary
        # Demoted to secondary, not discarded — it was the best term a moment ago.
        assert after[first.id] is KeywordTier.secondary

    def test_is_primary_always_mirrors_the_tier(self, client: TestClient) -> None:
        # Both exist because a lot of code reads the boolean. They must not drift.
        batch_id = _upload(client, 1)
        _research(client, batch_id, 1)
        for keyword in self._first_row_keywords(batch_id):
            assert keyword.is_primary == (keyword.tier is KeywordTier.primary)

    def test_research_leaves_a_usable_starting_point(self, client: TestClient) -> None:
        # An untouched row should already have something to write from.
        batch_id = _upload(client, 1)
        _research(client, batch_id, 1)
        keywords = self._first_row_keywords(batch_id)
        if not any(k.volume is not None for k in keywords):
            pytest.skip("no measured terms for this row, so there is nothing to tier")

        tiers = [k.tier for k in keywords]
        assert tiers.count(KeywordTier.primary) == 1
        assert KeywordTier.secondary in tiers

    def test_a_row_with_nothing_measured_gets_no_primary(self, client: TestClient) -> None:
        """And that is correct, not a gap. A primary the page cannot win is worse than
        none — see `choose_primary`."""
        from app.db import session_scope
        from app.models import Batch, KeywordTier as Tier

        batch_id = _upload(client, 1)
        _research(client, batch_id, 1)
        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            if any(k.volume is not None for k in row.keywords):
                pytest.skip("this row has measured terms")
            assert all(k.tier is Tier.unranked for k in row.keywords)

    def test_an_unmeasured_term_can_still_be_tiered(self, client: TestClient) -> None:
        """No search figure is not the same as no value, and a writer who knows the
        market may want a term Google cannot price."""
        batch_id = _upload(client, 1)
        _research(client, batch_id, 1)
        unmeasured = [
            k for k in self._first_row_keywords(batch_id) if k.volume is None
        ]
        if not unmeasured:
            pytest.skip("every term for this row was measured")

        response = client.post(
            f"/batch/{batch_id}/rows/1/cycle?keyword_id={unmeasured[0].id}",
            headers=PARTIAL,
        )
        assert response.status_code == 200
        after = next(
            k.tier for k in self._first_row_keywords(batch_id) if k.id == unmeasured[0].id
        )
        assert after is KeywordTier.primary

    def test_the_tier_is_shown_as_text_not_only_as_colour(self, client: TestClient) -> None:
        # Colour alone fails a monochrome screen, a colour-blind reader and a screen
        # reader, so every selected chip also carries its rank as words.
        batch_id = _upload(client, 1)
        _research(client, batch_id, 1)
        keyword = self._first_row_keywords(batch_id)[0]
        client.post(
            f"/batch/{batch_id}/rows/1/cycle?keyword_id={keyword.id}",
            headers=PARTIAL,
        )
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert "1st" in page


class TestTiersReachTheCopyPrompt:
    def test_each_tier_gets_its_own_instruction(self) -> None:
        from app.providers.llm import CopyRequest
        from app.providers.llm._prompts import build_copy_prompt

        prompt = build_copy_prompt(
            CopyRequest(
                row_index=1,
                product_name="Apple iPhone 17",
                category_raw="Smartphones",
                primary_keyword="iphone 17",
                secondary_keywords=("apple iphone 17", "iphone 17 uae"),
                tertiary_keywords=("buy iphone 17 online",),
            )
        )
        assert "PRIMARY keyword" in prompt and "iphone 17" in prompt
        assert "SECONDARY keywords" in prompt and "iphone 17 uae" in prompt
        assert "TERTIARY keywords" in prompt and "buy iphone 17 online" in prompt
        # The three must mean different things, or the tiers are decoration.
        assert "must appear in the meta title" in prompt
        assert "work these into the description" in prompt
        assert "only if there is room" in prompt

    def test_the_prompt_forbids_forcing_a_term_in(self) -> None:
        from app.providers.llm import CopyRequest
        from app.providers.llm._prompts import build_copy_prompt

        prompt = build_copy_prompt(
            CopyRequest(row_index=1, product_name="x", category_raw="y")
        )
        assert "keyword stuffing" in prompt

    def test_an_untiered_row_still_gets_supporting_keywords(
        self, client: TestClient
    ) -> None:
        """Rows from the simple page have no tiers set. They must behave exactly as they
        did before tiers existed, or adding the feature would silently change the
        demonstrated journey."""
        from app.db import session_scope
        from app.lib.validators import banned_in_copy
        from app.models import Batch, KeywordStatus
        from app.services.generation import supporting_tiers

        batch_id = _upload(client, 1)
        _research(client, batch_id, 1)
        client.post(f"/batch/{batch_id}/approve", follow_redirects=False)

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            for keyword in row.keywords:
                keyword.tier = KeywordTier.unranked
                keyword.is_primary = False
            session.flush()
            # Every approved term the copy step is allowed to write. The unpublishable
            # ones are excluded here too, because handing the model a term it is
            # forbidden to use is not "support" — it is a guaranteed rejection.
            approved = [
                k for k in row.keywords
                if k.status is KeywordStatus.approved
                and k.volume is not None
                and banned_in_copy(k.term_normalized) is None
            ]
            secondary, tertiary = supporting_tiers(row, None)

        assert tertiary == ()
        assert len(secondary) == len(approved)


class TestResearchOnlyTerms:
    """A term can be real demand and still be unpublishable.

    Research measured "projector price in uae" at 1,900 searches a month, auto-tiering
    promoted it to secondary on volume alone, the prompt asked the model to work the
    secondaries in, and `no_banned_terms` then failed the row for containing "price" —
    three parts each behaving correctly, producing a guaranteed failure. Volume says how
    many people search a term; it says nothing about whether we may publish it.
    """

    def test_a_price_term_is_flagged_and_an_ordinary_one_is_not(self) -> None:
        from app.lib.validators import banned_in_copy

        assert banned_in_copy("projector price in uae") is not None
        assert banned_in_copy("apple watch discount") is not None
        assert banned_in_copy("iphone 17 aed") is not None
        assert banned_in_copy("home projector") is None
        assert banned_in_copy("philips projector") is None

    def test_a_warning_rule_does_not_make_a_term_research_only(self) -> None:
        """Only the rules that block export are grounds for keeping a term from the
        prompt. A superlative is a warning a human may still choose to accept."""
        from app.lib.validators import banned_in_copy

        assert banned_in_copy("best projector uae") is None

    def test_a_price_term_is_never_auto_tiered(self, client: TestClient) -> None:
        from app.db import session_scope
        from app.lib.validators import banned_in_copy
        from app.models import Batch

        batch_id = _upload(client, 4)
        for index in range(1, 5):
            _research(client, batch_id, index)

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            tiered = [
                k
                for row in batch.rows
                for k in row.keywords
                if k.tier is not KeywordTier.unranked
            ]
            assert tiered, "the fixture must produce some tiers, or this proves nothing"
            offenders = [k.term for k in tiered if banned_in_copy(k.term_normalized)]
            assert offenders == [], f"unpublishable terms were tiered: {offenders}"

    def test_a_price_term_cannot_be_tiered_by_hand(self, client: TestClient) -> None:
        from app.db import session_scope
        from app.lib.validators import banned_in_copy
        from app.models import Batch

        batch_id = _upload(client, 1)
        _research(client, batch_id, 1)

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            target = next(
                (k for k in row.keywords if banned_in_copy(k.term_normalized)), None
            )
            if target is None:
                pytest.skip("this fixture row produced no price-intent term")
            target_id = target.id

        client.post(
            f"/batch/{batch_id}/rows/1/cycle?keyword_id={target_id}", headers=PARTIAL
        )

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            chosen = next(k for k in row.keywords if k.id == target_id)
            assert chosen.tier is KeywordTier.unranked
            assert chosen.is_primary is False

    def test_the_chip_says_why_rather_than_being_a_dead_control(
        self, client: TestClient
    ) -> None:
        """Hiding the term would lose a fact about the market. Leaving it clickable would
        offer a choice that cannot be honoured."""
        batch_id = _upload(client, 1)
        _research(client, batch_id, 1)
        page = client.get(f"/batch/{batch_id}/step/2").text
        if "price" not in page:
            pytest.skip("this fixture row produced no price-intent term")
        assert "research only" in page
        assert "must not be indexed" in page

    def test_a_price_term_never_reaches_the_prompt(self, client: TestClient) -> None:
        """The seam that matters: whatever the tiers say, the model is not handed a term
        it is forbidden to write."""
        from app.db import session_scope
        from app.lib.validators import banned_in_copy
        from app.models import Batch
        from app.services.generation import supporting_tiers

        batch_id = _upload(client, 1)
        _research(client, batch_id, 1)
        client.post(f"/batch/{batch_id}/approve", follow_redirects=False)

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            # Force the bad state the pre-fix rows are already in, so the filter is
            # proved rather than the tiering that now prevents it.
            for keyword in row.keywords:
                if banned_in_copy(keyword.term_normalized):
                    keyword.tier = KeywordTier.secondary
            session.flush()
            secondary, tertiary = supporting_tiers(row, None)

        for term in secondary + tertiary:
            assert banned_in_copy(term) is None, f"{term!r} was handed to the model"

    def test_the_prompt_forbids_echoing_a_price_word_from_a_keyword(self) -> None:
        """A backstop, not the mechanism. Filtering is what stops this; the rule catches
        the case where a price word arrives some other way — a product name, say."""
        from app.providers.llm._prompts import COPY_SYSTEM

        assert 'Never write the words "price", "cost" or "discount"' in COPY_SYSTEM
        assert "not even when a keyword you were given contains one" in COPY_SYSTEM


# ---------------------------------------------------------------- lazy loading


class TestLazyLoading:
    """Twenty products used to fire twenty requests at once. The server caps concurrency
    at three, so the last rows queued behind the first eight regardless, and the screen
    showed twenty shimmering skeletons with no sense of progress."""

    def test_only_the_first_page_starts_immediately(self, client: TestClient) -> None:
        batch_id = _upload(client, 20)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert page.count('data-trigger="load"') == PAGE_SIZE
        assert page.count("data-lazy-url") == 20 - PAGE_SIZE

    def test_the_rest_carry_their_url_ready_to_be_released(
        self, client: TestClient
    ) -> None:
        batch_id = _upload(client, 20)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert f"/batch/{batch_id}/rows/20/keywords" in page
        # ...but not as something that fires on load.
        queued = page.split('data-lazy-url="', 1)[1]
        assert 'data-trigger="load"' not in queued.split("</tr>", 1)[0]

    def test_a_short_batch_has_no_load_more_control(self, client: TestClient) -> None:
        # Nothing to release, so no dead button.
        batch_id = _upload(client, 3)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert "data-lazy-more" not in page
        assert page.count('data-trigger="load"') == 3

    def test_a_long_batch_offers_a_real_button_not_only_a_scroll_trigger(
        self, client: TestClient
    ) -> None:
        """Scrolling releases the next batch automatically, but the button is what makes
        it work for a keyboard, a screen reader, and anywhere IntersectionObserver is
        unavailable."""
        batch_id = _upload(client, 20)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert "data-lazy-more" in page
        assert f"Load the next {PAGE_SIZE}" in page

    def test_a_queued_row_says_so_rather_than_shimmering(self, client: TestClient) -> None:
        # A shimmer claims work is happening. Nothing is happening yet.
        batch_id = _upload(client, 20)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert 'data-s="queued"' in page
        assert "loads when you scroll down" in page

    def test_the_copy_page_paginates_the_same_way(self, client: TestClient) -> None:
        batch_id = _upload(client, 20)
        _research(client, batch_id, 20)
        client.post(f"/batch/{batch_id}/approve", follow_redirects=False)
        page = client.get(f"/batch/{batch_id}/step/3").text
        assert page.count('data-trigger="load"') == PAGE_SIZE
        assert page.count("data-lazy-url") == 20 - PAGE_SIZE
        assert f"Write the next {PAGE_SIZE}" in page

    def test_a_queued_copy_row_carries_the_ordinary_generate_url(
        self, client: TestClient
    ) -> None:
        # Releasing a row is a client-side act; the endpoint it calls is the same one an
        # eager row calls. A separate "paginated generate" path would be two code paths
        # that could disagree about what writing a row means.
        batch_id = _upload(client, 20)
        page = client.get(f"/batch/{batch_id}/step/3").text
        assert f'data-lazy-url="/batch/{batch_id}/rows/20/generate"' in page
        assert f'data-get="/batch/{batch_id}/rows/1/generate"' in page

    def test_the_eager_budget_goes_to_rows_that_still_need_work(
        self, client: TestClient
    ) -> None:
        """A reload mid-run must resume, not stall.

        The budget used to be "the first eight rows in the table". Once eight rows had
        finished, a reload left every remaining row queued and nothing running — the
        reader had to click to restart a page that was working a moment earlier.
        """
        batch_id = _upload(client, 20)
        _research(client, batch_id, 8)

        page = client.get(f"/batch/{batch_id}/step/2").text
        assert page.count('data-trigger="load"') == PAGE_SIZE, (
            "the next eight unfinished rows should start on their own"
        )
        assert page.count("data-lazy-url") == 20 - (8 + PAGE_SIZE)

    def test_a_released_row_researches_normally(self, client: TestClient) -> None:
        # Releasing is a client-side act; the endpoint it calls is the ordinary one.
        batch_id = _upload(client, 20)
        response = client.get(
            f"/batch/{batch_id}/rows/20/keywords", headers=PARTIAL
        )
        assert response.status_code == 200
        assert "kw-20" in response.text


# ---------------------------------------------------------------- one journey


class TestThereIsOneJourney:
    """Both features graduated, so the lab is gone. These assert it stayed gone.

    Tiers and lazy loading were built on a second pair of pages at `/batch/{id}/lab/...`
    so an unproven feature could not break a demo. Both earned their place, which left two
    sets of routes rendering the same partials — two things to keep in step, one of them
    unused. This class is what is left of the isolation tests: the features are on the real
    pages, and there is no second copy of them anywhere.
    """

    def test_the_keywords_page_has_the_graduated_tier_controls(
        self, client: TestClient
    ) -> None:
        batch_id = _upload(client, 3)
        _research(client, batch_id, 3)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert "/cycle?" in page
        assert "Click a keyword to cycle" in page

    def test_the_keywords_page_paginates(self, client: TestClient) -> None:
        batch_id = _upload(client, 20)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert page.count('data-trigger="load"') == PAGE_SIZE
        assert page.count("data-lazy-url") == 20 - PAGE_SIZE

    def test_the_lab_routes_are_gone(self, client: TestClient) -> None:
        batch_id = _upload(client, 3)
        for path in (
            f"/batch/{batch_id}/lab/step/2",
            f"/batch/{batch_id}/lab/step/3",
            f"/batch/{batch_id}/lab/rows/1/keywords",
            f"/batch/{batch_id}/lab/rows/1/cycle",
        ):
            assert client.get(path).status_code == 404, f"{path} still answers"

    def test_no_page_still_wears_a_lab_badge(self, client: TestClient) -> None:
        batch_id = _upload(client, 3)
        for step in (2, 3):
            page = client.get(f"/batch/{batch_id}/step/{step}").text
            assert "source--lab" not in page
            assert ">Lab<" not in page

    def test_making_a_term_primary_means_the_same_thing_as_cycling_to_it(
        self, client: TestClient
    ) -> None:
        """The "make primary" control and the tier cycle must agree, or the page would
        disagree with itself about what "primary" does to a row."""
        from app.db import session_scope
        from app.lib.validators import banned_in_copy
        from app.models import Batch

        batch_id = _upload(client, 1)
        _research(client, batch_id, 1)
        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            target = next(
                k for k in row.keywords
                if k.tier is KeywordTier.unranked
                and banned_in_copy(k.term_normalized) is None
            )
            target_id = target.id

        client.post(f"/batch/{batch_id}/rows/1/primary?keyword_id={target_id}", headers=PARTIAL)

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            chosen = next(k for k in row.keywords if k.id == target_id)
            assert chosen.tier is KeywordTier.primary
            assert chosen.is_primary is True
            assert sum(1 for k in row.keywords if k.is_primary) == 1
