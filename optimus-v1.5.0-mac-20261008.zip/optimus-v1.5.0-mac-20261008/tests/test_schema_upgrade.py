"""Adding a column to a table that already holds data.

`create_all()` creates missing TABLES and silently ignores missing COLUMNS. That was fine
until the first column was added to a populated table: adding `months_covered` to
`keywords` and `volume_cache` broke every query against them — "no such column" on a
database that looked perfectly healthy, and on the live one, not just in tests.

There is no Alembic in this build, so `add_missing_columns` is the smallest thing that
closes the gap. These tests pin what it will and will not do, because a startup hook that
edits the schema needs a tighter contract than one that creates it.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from sqlalchemy import Column, Integer, MetaData, String, Table, create_engine, inspect, text


def _engine(tmp_path: Path):  # type: ignore[no-untyped-def]
    return create_engine(f"sqlite:///{tmp_path / 'upgrade.db'}", future=True)


class TestItAddsWhatIsMissing:
    def test_a_new_nullable_column_is_added_to_a_populated_table(
        self, tmp_path: Path
    ) -> None:
        from app.db import add_missing_columns
        from app.models import Base

        engine = _engine(tmp_path)

        # The real upgrade, reproduced: a populated v1.4 database, which is the current
        # schema minus the column v1.5 added. Built by removing the column rather than by
        # hand-writing an old table, so the test stays honest as the model grows.
        Base.metadata.create_all(engine)
        with engine.begin() as connection:
            connection.execute(
                text(
                    "INSERT INTO volume_cache (term_normalized, geo, locale, volume, "
                    "source, fetched_at, hits) VALUES "
                    "('samsung', 'AE', 'en', 110000, 'DataForSEOProvider', "
                    "'2026-10-07 00:00:00', 0)"
                )
            )
            connection.execute(text("ALTER TABLE volume_cache DROP COLUMN months_covered"))

        assert "months_covered" not in {
            c["name"] for c in inspect(engine).get_columns("volume_cache")
        }

        added = add_missing_columns(engine)
        assert "volume_cache.months_covered" in added

        # And the row that predates the column survives, with NULL in it.
        with engine.begin() as connection:
            row = connection.execute(
                text("SELECT term_normalized, volume, months_covered FROM volume_cache")
            ).one()
        assert row[0] == "samsung"
        assert row[1] == 110_000
        assert row[2] is None

    def test_it_is_idempotent(self, tmp_path: Path) -> None:
        # It runs on every start, so a second run must be a no-op rather than an error.
        from app.db import add_missing_columns
        from app.models import Base

        engine = _engine(tmp_path)
        Base.metadata.create_all(engine)
        add_missing_columns(engine)
        assert add_missing_columns(engine) == []

    def test_a_fresh_database_needs_nothing_added(self, tmp_path: Path) -> None:
        from app.db import add_missing_columns
        from app.models import Base

        engine = _engine(tmp_path)
        Base.metadata.create_all(engine)
        assert add_missing_columns(engine) == []


class TestItRefusesWhatItCannotDecide:
    def test_a_required_column_raises_rather_than_guessing(self, tmp_path: Path) -> None:
        """A column that needs a value for existing rows is a decision about data.

        Picking one in a startup hook is how a database quietly fills with defaults nobody
        chose. It raises instead, naming the column, so the answer gets written down.
        """
        from app.db import add_missing_columns

        engine = _engine(tmp_path)

        old = MetaData()
        Table("widgets", old, Column("id", Integer, primary_key=True))
        old.create_all(engine)

        new = MetaData()
        Table(
            "widgets",
            new,
            Column("id", Integer, primary_key=True),
            Column("owner", String, nullable=False),
        )

        import app.db as db_module
        from app.models import Base

        original = Base.metadata
        try:
            db_module.Base.metadata = new  # type: ignore[misc]
            with pytest.raises(RuntimeError, match="widgets.owner"):
                add_missing_columns(engine)
        finally:
            db_module.Base.metadata = original  # type: ignore[misc]

    def test_it_never_drops_a_column_the_models_no_longer_declare(
        self, tmp_path: Path
    ) -> None:
        """Forward-only and additive. Dropping is destructive and irreversible, and a
        column the models stopped declaring may still hold the only copy of something."""
        from app.db import add_missing_columns
        from app.models import Base

        engine = _engine(tmp_path)
        Base.metadata.create_all(engine)
        with engine.begin() as connection:
            connection.execute(text("ALTER TABLE volume_cache ADD COLUMN legacy TEXT"))

        add_missing_columns(engine)

        columns = {c["name"] for c in inspect(engine).get_columns("volume_cache")}
        assert "legacy" in columns
