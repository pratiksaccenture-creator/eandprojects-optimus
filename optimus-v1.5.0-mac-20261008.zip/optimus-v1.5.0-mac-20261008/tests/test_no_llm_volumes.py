"""No code path can populate a search volume from model output — brief §1 rule 1, §11.

"An LLM never produces a search volume. Not as an estimate, not as a fallback, not
'approximately'. Volumes come only from a KeywordVolumeProvider implementation. If a
provider returns no data for a term, that term is marked unverified and excluded. Never
inferred, never interpolated."

This is the rule that makes the tool defensible, so it is enforced by parsing the source
rather than by reviewer vigilance. Four independent properties are asserted, because any
one of them alone could be worked around by accident.
"""

from __future__ import annotations

import ast
import dataclasses
from pathlib import Path

APP = Path(__file__).resolve().parents[1] / "app"
LLM_PACKAGE = APP / "providers" / "llm"
KEYWORDS_PACKAGE = APP / "providers" / "keywords"


def _modules(root: Path) -> list[Path]:
    return sorted(p for p in root.rglob("*.py") if "__pycache__" not in p.parts)


def _tree(path: Path) -> ast.Module:
    return ast.parse(path.read_text(encoding="utf-8"), filename=str(path))


def test_the_llm_package_never_mentions_a_volume() -> None:
    """The strongest available static guarantee: the identifier does not occur there."""
    offenders: list[str] = []
    for path in _modules(LLM_PACKAGE):
        for node in ast.walk(_tree(path)):
            name: str | None = None
            if isinstance(node, ast.Name):
                name = node.id
            elif isinstance(node, ast.Attribute):
                name = node.attr
            elif isinstance(node, ast.keyword):
                name = node.arg
            if name and "volume" in name.casefold():
                offenders.append(f"{path.relative_to(APP.parent)}:{node.lineno} -> {name}")
    assert not offenders, (
        "The copy provider must not touch volumes at all:\n  " + "\n  ".join(offenders)
    )


def test_the_llm_package_cannot_reach_the_volume_providers_or_the_orm() -> None:
    forbidden = ("app.providers.keywords", "app.models", "app.db")
    offenders: list[str] = []
    for path in _modules(LLM_PACKAGE):
        for node in ast.walk(_tree(path)):
            modules: list[str] = []
            if isinstance(node, ast.Import):
                modules = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                modules = [node.module]
            for module in modules:
                if any(module == f or module.startswith(f + ".") for f in forbidden):
                    offenders.append(f"{path.relative_to(APP.parent)} imports {module}")
    assert not offenders, (
        "The copy provider has no legitimate reason to reach volumes or the database:\n  "
        + "\n  ".join(offenders)
    )


def test_model_output_types_expose_no_volume_field() -> None:
    from app.providers.llm import CopyDraft, CopyResult

    for cls in (CopyDraft, CopyResult):
        fields = {f.name for f in dataclasses.fields(cls)}
        assert not any("volume" in name.casefold() for name in fields), (
            f"{cls.__name__} exposes a volume-shaped field: {sorted(fields)}"
        )


def test_every_volume_assignment_comes_from_the_keyword_provider() -> None:
    """Locate every place a volume is written and prove it is fed by a volume provider.

    A module may only assign `volume=` or `.volume` if it also imports
    `app.providers.keywords` — the only sanctioned source. This is what stops a well-meaning
    change from wiring model output into `Keyword.volume`.
    """
    sanctioned_roots = (KEYWORDS_PACKAGE, APP / "models.py")
    offenders: list[str] = []

    for path in _modules(APP):
        if any(path == root or root in path.parents for root in sanctioned_roots):
            continue

        tree = _tree(path)
        imports_provider = any(
            isinstance(node, ast.ImportFrom)
            and node.module
            and node.module.startswith("app.providers.keywords")
            for node in ast.walk(tree)
        )

        writes: list[int] = []
        for node in ast.walk(tree):
            if isinstance(node, ast.keyword) and node.arg == "volume":
                writes.append(node.lineno)
            elif (
                isinstance(node, ast.Assign)
                and any(
                    isinstance(t, ast.Attribute) and t.attr == "volume" for t in node.targets
                )
            ):
                writes.append(node.lineno)

        if writes and not imports_provider:
            offenders.append(
                f"{path.relative_to(APP.parent)} writes a volume at line(s) "
                f"{writes} without importing app.providers.keywords"
            )

    assert not offenders, (
        "A volume was written outside the sanctioned path:\n  " + "\n  ".join(offenders)
    )


def test_a_provider_with_no_data_yields_none_rather_than_a_number() -> None:
    import anyio

    from app.providers.keywords import get_keyword_provider

    async def run() -> None:
        provider = get_keyword_provider("fixture")
        results = await provider.lookup(
            ["apple watch", "a term nobody has ever searched for"], geo="AE", locale="en"
        )
        by_term = {r.term: r for r in results}
        assert by_term["apple watch"].volume == 33100
        missing = by_term["a term nobody has ever searched for"]
        assert missing.volume is None
        assert not missing.is_verified
        # No date either: a date would imply a measurement that never happened.
        assert missing.data_date is None

    anyio.run(run)
