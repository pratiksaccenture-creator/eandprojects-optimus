"""Keyword volume and copy providers — brief §5 and §1 rule 5."""

from __future__ import annotations

from pathlib import Path

import anyio
import pytest

from app.providers.keywords import (
    NotConfiguredError,
    available_providers,
    get_keyword_provider,
)
from app.providers.keywords._dataforseo import DataForSeoProvider
from app.providers.keywords._fixture import FixtureVolumeProvider, read_keyword_seed, seed_terms
from app.providers.keywords._google_ads import (
    GEO_TARGET_UAE,
    LANGUAGE_ARABIC,
    LANGUAGE_ENGLISH,
    GoogleAdsKeywordPlannerProvider,
)
from app.providers.keywords._google_ads import build_request as ads_request
from app.providers.llm import CopyRequest, ModelNotConfiguredError, get_llm
from app.providers.llm._azure import AzureOpenAIProvider, build_messages
from app.providers.llm._fixture import FixtureCopyProvider


# ---------------------------------------------------------------- keyword seed


class TestKeywordSeed:
    def test_deduplicates_case_insensitively(self, output_path: Path) -> None:
        # The sheet has 30 rows with `apple watch ` repeated at rows 15 and 21.
        terms = read_keyword_seed(output_path)
        assert len(terms) == 29
        normalized = [t.term_normalized for t in terms]
        assert len(normalized) == len(set(normalized))

    def test_every_seed_term_has_a_real_volume(self, output_path: Path) -> None:
        terms = read_keyword_seed(output_path)
        assert all(t.volume is not None and t.volume > 0 for t in terms)

    def test_whitespace_only_cells_are_not_treated_as_terms(self, output_path: Path) -> None:
        # `keywords!F15` holds a single space.
        terms = read_keyword_seed(output_path)
        assert all(t.term.strip() == t.term and t.term for t in terms)

    def test_seed_is_sorted_deterministically(self) -> None:
        # Export bytes must be reproducible, so the seed order cannot depend on dict order.
        assert seed_terms() == seed_terms()
        volumes = [v for _, v in seed_terms()]
        assert volumes == sorted(volumes, reverse=True)

    def test_highest_volume_term_matches_the_source_sheet(self) -> None:
        assert seed_terms()[0] == ("apple", 165000)


# ---------------------------------------------------------------- fixture provider


class TestFixtureVolumeProvider:
    def test_is_labelled_as_not_live_data(self) -> None:
        provider = FixtureVolumeProvider()
        assert provider.is_live_data is False
        assert provider.name == "FixtureVolumeProvider"

    def test_returns_a_result_for_every_term_asked_for(self) -> None:
        async def go() -> None:
            provider = FixtureVolumeProvider()
            terms = ["apple watch", "unknown one", "AirPods "]
            results = await provider.lookup(terms, geo="AE", locale="en")
            assert [r.term for r in results] == terms

        anyio.run(go)

    def test_matches_terms_despite_case_and_trailing_space(self) -> None:
        async def go() -> None:
            provider = FixtureVolumeProvider()
            results = await provider.lookup(
                ["APPLE WATCH", "apple watch ", "  apple   watch  "], geo="AE", locale="en"
            )
            assert {r.volume for r in results} == {33100}

        anyio.run(go)

    def test_unknown_terms_yield_none_and_no_date(self) -> None:
        async def go() -> None:
            provider = FixtureVolumeProvider()
            (result,) = await provider.lookup(["nothing like this"], geo="AE", locale="en")
            assert result.volume is None
            assert result.data_date is None
            assert not result.is_verified

        anyio.run(go)

    def test_data_date_is_not_now(self) -> None:
        # Presenting collected-on-a-past-date volumes as fresh would misrepresent them.
        import datetime as dt

        async def go() -> None:
            provider = FixtureVolumeProvider()
            (result,) = await provider.lookup(["apple watch"], geo="AE", locale="en")
            assert result.data_date is not None
            assert result.data_date < dt.datetime.now()

        anyio.run(go)


# ---------------------------------------------------------------- live provider stubs


class TestGoogleAdsProvider:
    def test_declares_itself_live(self) -> None:
        assert GoogleAdsKeywordPlannerProvider().is_live_data is True

    def test_raises_rather_than_falling_back_when_unconfigured(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        for name in ("GOOGLE_ADS_DEVELOPER_TOKEN", "GOOGLE_ADS_CLIENT_ID"):
            monkeypatch.delenv(name, raising=False)

        async def go() -> None:
            with pytest.raises(NotConfiguredError) as excinfo:
                await GoogleAdsKeywordPlannerProvider().lookup(
                    ["apple watch"], geo="AE", locale="en"
                )
            # The message must not suggest the tool silently used seeded data.
            assert "not configured" in str(excinfo.value).lower()

        anyio.run(go)

    def test_request_targets_the_uae(self) -> None:
        body = ads_request(["apple watch", "airpods"], geo="AE", locale="en")
        assert body["geoTargetConstants"] == [GEO_TARGET_UAE]
        assert body["language"] == LANGUAGE_ENGLISH

    def test_arabic_locale_selects_the_arabic_language_constant(self) -> None:
        body = ads_request(["apple watch"], geo="AE", locale="ar")
        assert body["language"] == LANGUAGE_ARABIC

    def test_request_terms_are_sorted_and_deduplicated(self) -> None:
        body = ads_request(["b", "a", "b"], geo="AE", locale="en")
        assert body["keywordSeed"] == {"keywords": ["a", "b"]}

    def test_unsupported_geo_is_refused(self) -> None:
        with pytest.raises(NotConfiguredError):
            ads_request(["apple watch"], geo="SA", locale="en")


class TestDataForSeoProvider:
    def test_raises_when_unconfigured(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("DATAFORSEO_LOGIN", raising=False)
        monkeypatch.delenv("DATAFORSEO_PASSWORD", raising=False)

        async def go() -> None:
            with pytest.raises(NotConfiguredError):
                await DataForSeoProvider().lookup(["apple watch"], geo="AE", locale="en")

        anyio.run(go)


class TestProviderSelection:
    def test_default_is_the_fixture_provider(self) -> None:
        assert isinstance(get_keyword_provider(), FixtureVolumeProvider)

    def test_each_named_provider_resolves(self) -> None:
        assert isinstance(get_keyword_provider("google_ads"), GoogleAdsKeywordPlannerProvider)
        assert isinstance(get_keyword_provider("dataforseo"), DataForSeoProvider)

    def test_unknown_provider_is_refused_loudly(self) -> None:
        with pytest.raises(NotConfiguredError):
            get_keyword_provider("made_up")

    def test_advertised_providers_all_resolve(self) -> None:
        for name in available_providers():
            assert get_keyword_provider(name) is not None


# ---------------------------------------------------------------- copy provider


def _request(**kw: object) -> CopyRequest:
    base: dict[str, object] = {
        "row_index": 1,
        "product_name": "Apple Watch Ultra 4",
        "category_raw": "Apple WATCH ULTRA 4",
        "product_url": "https://www.eand.ae/eshop/x",
        "page_type": "product",
        "primary_keyword": "apple watch",
    }
    base.update(kw)
    return CopyRequest(**base)  # type: ignore[arg-type]


class TestFixtureCopyProvider:
    def test_is_labelled_as_not_a_live_model(self) -> None:
        provider = FixtureCopyProvider()
        assert provider.is_live_model is False
        assert provider.model == "fixture-templates"

    def test_is_deterministic(self) -> None:
        async def go() -> None:
            provider = FixtureCopyProvider()
            first = await provider.generate(_request())
            second = await provider.generate(_request())
            assert first.draft == second.draft

        anyio.run(go)

    def test_later_attempts_shorten_the_title(self) -> None:
        async def go() -> None:
            provider = FixtureCopyProvider()
            lengths = []
            for attempt in (1, 2, 3):
                result = await provider.generate(
                    _request(
                        product_name="Apple Watch Series 12 GPS + Cellular Aluminium",
                        attempt=attempt,
                        feedback=("CHAR_LIMIT",) if attempt > 1 else (),
                    )
                )
                lengths.append(len(result.draft.meta_title))
            assert lengths[0] > lengths[-1], lengths

        anyio.run(go)

    def test_brand_suffix_is_applied_when_asked(self) -> None:
        async def go() -> None:
            provider = FixtureCopyProvider()
            result = await provider.generate(_request(brand_suffix=True))
            assert result.draft.meta_title.endswith("| e&")

        anyio.run(go)

    def test_generated_copy_contains_no_price_language(self) -> None:
        # Generating text designed to fail the banned-terms validator would waste attempts.
        from app.lib.validators import FieldContext, no_banned_terms

        async def go() -> None:
            provider = FixtureCopyProvider()
            for name in (
                "Apple Watch Ultra 4", "iPhone 18 Pro", "AirPods 5", "Smart Home",
            ):
                result = await provider.generate(_request(product_name=name))
                for field, text in result.draft.tier1().items():
                    findings = no_banned_terms(
                        text, FieldContext(field=field, row_index=1)
                    )
                    blocking = [f for f in findings if f.severity == "error"]
                    assert not blocking, f"{name} / {field}: {blocking}"

        anyio.run(go)

    def test_answer_block_is_forty_to_sixty_words(self) -> None:
        async def go() -> None:
            provider = FixtureCopyProvider()
            result = await provider.generate(_request())
            words = len(result.draft.answer_block.split())
            assert 40 <= words <= 60, words

        anyio.run(go)

    def test_produces_three_benefits_and_three_faqs(self) -> None:
        async def go() -> None:
            result = await FixtureCopyProvider().generate(_request())
            assert len(result.draft.benefits) == 3
            assert len(result.draft.faqs) == 3
            assert all(q and a for q, a in result.draft.faqs)

        anyio.run(go)

    def test_produces_between_eight_and_twelve_tracked_prompts(self) -> None:
        async def go() -> None:
            result = await FixtureCopyProvider().generate(_request())
            assert 8 <= len(result.draft.geo_prompts) <= 12

        anyio.run(go)

    def test_jsonld_is_parseable_faqpage(self) -> None:
        import json

        async def go() -> None:
            result = await FixtureCopyProvider().generate(_request())
            payload = json.loads(result.draft.jsonld)
            assert payload["@type"] == "FAQPage"
            assert len(payload["mainEntity"]) == 3

        anyio.run(go)

    def test_a_shortened_name_never_drops_the_generation_number(self) -> None:
        # Dropping it would create the stale-generation defect the validators exist to catch.
        async def go() -> None:
            provider = FixtureCopyProvider()
            for attempt in (1, 2, 3):
                result = await provider.generate(
                    _request(
                        product_name="Apple Watch Series 12 GPS + Cellular Aluminium",
                        attempt=attempt,
                        feedback=("CHAR_LIMIT",),
                    )
                )
                assert "12" in result.draft.meta_title, result.draft.meta_title

        anyio.run(go)


class TestAzureProvider:
    def test_declares_itself_live(self) -> None:
        assert AzureOpenAIProvider().is_live_model is True

    def test_raises_rather_than_falling_back_when_unconfigured(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        for name in ("AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_DEPLOYMENT"):
            monkeypatch.delenv(name, raising=False)

        async def go() -> None:
            with pytest.raises(ModelNotConfiguredError):
                await AzureOpenAIProvider().generate(_request())

        anyio.run(go)

    def test_refuses_an_endpoint_outside_a_uae_region(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://x.westeurope.openai.azure.com")
        monkeypatch.setenv("AZURE_OPENAI_API_KEY", "k")
        monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT", "d")

        async def go() -> None:
            with pytest.raises(ModelNotConfiguredError) as excinfo:
                await AzureOpenAIProvider().generate(_request())
            assert "region" in str(excinfo.value).lower()

        anyio.run(go)

    def test_system_prompt_forbids_inventing_volumes_and_prices(self) -> None:
        messages = build_messages(_request())
        system = messages[0]["content"].lower()
        assert "never state a price" in system
        assert "search volume" in system

    def test_feedback_is_passed_to_the_model(self) -> None:
        messages = build_messages(_request(attempt=2, feedback=("CHAR_LIMIT", "GLUED_DASH")))
        user = messages[1]["content"]
        assert "CHAR_LIMIT" in user and "GLUED_DASH" in user
        assert "Attempt 2" in user


class TestLlmSelection:
    def test_default_is_the_fixture_provider(self) -> None:
        assert isinstance(get_llm(), FixtureCopyProvider)

    def test_azure_resolves(self) -> None:
        assert isinstance(get_llm("azure"), AzureOpenAIProvider)

    def test_unknown_provider_is_refused(self) -> None:
        with pytest.raises(ModelNotConfiguredError):
            get_llm("made_up")
