"""What period a search volume covers, and how the cache expires on it.

The tool used to record `datetime.now()` as a figure's `data_date`. That is the time of the
request, not the age of the data, so the column said nothing — and the cache expired on it,
which meant expiry was measured against our own behaviour rather than against the figures.

The provider does report the real window. `search_volume` is an average over a trailing
window and the response returns it month by month in `monthly_searches`; the parser threw
that away. These tests cover reading it, storing it, expiring on it, and saying it.

Why a cache is defensible at all, stated here because the reasoning is the point:

  * Reported volumes sit on a **rounded scale** — 165,000 / 110,000 / 40,500 / 33,100 /
    8,100 / 590 / 90 / 40 / 10 — so underlying demand can move by several percent without
    the published number changing at all. In our own data `samsung galaxy` and
    `semsem galaxy` both returned exactly 40,500, and `apple`, `i phone 17` and `iphone 17`
    all returned exactly 165,000. That is the stability the cache relies on.
  * NOT because of a refresh schedule. Google publishes no documented cadence; monthly
    refresh is practitioner consensus. See DECISIONS.md §38 for the limitations this
    leaves, including rolling-window seasonality and DataForSEO's own unverified cadence.
"""

from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Any, Iterator

import pytest

from app.providers.keywords import VolumeResult


def _row(term: str, volume: int, months: list[tuple[int, int]]) -> dict[str, Any]:
    return {
        "keyword": term,
        "search_volume": volume,
        "cpc": 1.2,
        "competition": "LOW",
        "competition_index": 30,
        "monthly_searches": [
            {"year": year, "month": month, "search_volume": volume}
            for year, month in months
        ],
    }


def _twelve_months_to(year: int, month: int) -> list[tuple[int, int]]:
    out: list[tuple[int, int]] = []
    for offset in range(12):
        m = month - offset
        y = year
        while m <= 0:
            m += 12
            y -= 1
        out.append((y, m))
    return list(reversed(out))


class TestReadingThePeriod:
    def test_the_window_is_read_from_the_monthly_breakdown(self) -> None:
        from app.providers.keywords._dataforseo import read_period

        period_end, months = read_period(
            _row("samsung", 110_000, _twelve_months_to(2026, 9))
        )
        assert period_end == dt.date(2026, 9, 1)
        assert months == 12

    def test_a_missing_breakdown_yields_no_date_rather_than_today(self) -> None:
        """The defect this replaces. "We asked today" is not the age of the data, and
        filling it in with today is what made the column meaningless."""
        from app.providers.keywords._dataforseo import read_period

        assert read_period({"keyword": "x", "search_volume": 10}) == (None, None)
        assert read_period({"monthly_searches": []}) == (None, None)
        assert read_period({"monthly_searches": "nonsense"}) == (None, None)

    def test_malformed_months_are_skipped_not_guessed(self) -> None:
        from app.providers.keywords._dataforseo import read_period

        period_end, months = read_period(
            {
                "monthly_searches": [
                    {"year": 2026, "month": 8, "search_volume": 10},
                    {"year": "twenty-six", "month": 9},
                    {"year": 2026, "month": 13},
                    {"not": "a month"},
                ]
            }
        )
        assert period_end == dt.date(2026, 8, 1)
        assert months == 1

    def test_the_lookup_parser_carries_it_through(self) -> None:
        from app.providers.keywords._dataforseo import parse_response

        parsed = parse_response(
            {
                "status_code": 20000,
                "tasks": [
                    {
                        "status_code": 20000,
                        "result": [_row("apple", 165_000, _twelve_months_to(2026, 9))],
                    }
                ],
            }
        )
        assert parsed["apple"].period_end == dt.date(2026, 9, 1)
        assert parsed["apple"].months_covered == 12

    def test_the_expansion_parser_carries_it_through(self) -> None:
        from app.providers.keywords._dataforseo import parse_expansion

        rows = parse_expansion(
            {
                "status_code": 20000,
                "tasks": [
                    {
                        "status_code": 20000,
                        "result": [_row("iphone 17", 165_000, _twelve_months_to(2026, 8))],
                    }
                ],
            }
        )
        assert rows[0].period_end == dt.date(2026, 8, 1)
        assert rows[0].months_covered == 12


class TestTheProviderNeverFabricatesADate:
    def test_now_is_not_used_as_a_data_date(self) -> None:
        """A source-level check, because this is the kind of thing that creeps back.

        `datetime.now()` is legitimate for measuring how long a request took. It is not
        legitimate as the date a figure describes, and the two sat on the same line.
        """
        import re

        source = Path("app/providers/keywords/_dataforseo.py").read_text(encoding="utf-8")
        for match in re.finditer(r"data_date\s*=\s*([^,\n]+)", source):
            expression = match.group(1)
            assert "now()" not in expression, (
                f"data_date is being set from the clock: {expression.strip()}"
            )


class TestSayingIt:
    def test_a_figure_can_state_its_own_period(self) -> None:
        result = VolumeResult(
            term="samsung",
            volume=110_000,
            source="DataForSEOProvider",
            data_date=dt.datetime(2026, 9, 1),
            months_covered=12,
        )
        assert result.period_note == "covers 12 months to September 2026"

    def test_an_unknown_period_says_so(self) -> None:
        result = VolumeResult(term="x", volume=10, source="s")
        assert result.period_note == "period not reported"

    def test_the_page_note_names_the_window(self) -> None:
        from app.models import Keyword
        from app.services.keyword_service import data_date_note

        keywords = [
            Keyword(
                term="samsung",
                term_normalized="samsung",
                source="s",
                data_date=dt.datetime(2026, 9, 1),
                months_covered=12,
            )
        ]
        # Plural verb: this describes a set of figures. "Search volumes covers..." was
        # what the page rendered the first time.
        assert data_date_note(keywords) == "cover the 12 months to September 2026"

    def test_a_row_spanning_two_windows_admits_it(self) -> None:
        from app.models import Keyword
        from app.services.keyword_service import data_date_note

        keywords = [
            Keyword(
                term=t,
                term_normalized=t,
                source="s",
                data_date=dt.datetime(2026, month, 1),
                months_covered=12,
            )
            for t, month in (("a", 9), ("b", 6))
        ]
        note = data_date_note(keywords)
        assert "September 2026" in note and "June 2026" in note

    def test_no_dated_figures_does_not_invent_a_period(self) -> None:
        from app.models import Keyword
        from app.services.keyword_service import data_date_note

        assert data_date_note(
            [Keyword(term="a", term_normalized="a", source="s")]
        ) == "period not reported"


@pytest.fixture()
def db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_path / 'vintage.db'}")
    monkeypatch.setenv("VOLUME_MAX_VINTAGE_DAYS", "120")
    monkeypatch.setenv("VOLUME_RECHECK_DAYS", "14")

    import app.config
    import app.db

    app.config.settings.cache_clear()
    app.db._engine = None
    app.db._session_factory = None
    app.db.create_all()
    yield
    app.config.settings.cache_clear()
    app.db._engine = None
    app.db._session_factory = None


def _stored(volume: int, *, period: dt.datetime | None) -> VolumeResult:
    return VolumeResult(
        term="samsung",
        volume=volume,
        source="DataForSEOProvider",
        data_date=period,
        months_covered=12 if period else None,
    )


class TestExpiryIsMeasuredOnTheData:
    def test_a_current_window_is_served(self, db: None) -> None:
        from app.db import session_scope
        from app.models import utcnow
        from app.services import volume_cache

        recent = utcnow() - dt.timedelta(days=20)
        with session_scope() as session:
            volume_cache.remember(session, [_stored(110_000, period=recent)], geo="AE", locale="en")

        assert volume_cache.read(["samsung"], geo="AE", locale="en")

    def test_an_old_window_is_not_served_once_the_recheck_guard_lapses(
        self, db: None
    ) -> None:
        """The point of the change. A figure fetched yesterday can already describe a
        window that closed months ago, and fetch time cannot tell you that."""
        from app.db import session_scope
        from app.models import VolumeCache, utcnow
        from app.services import volume_cache

        stale_window = utcnow() - dt.timedelta(days=200)
        with session_scope() as session:
            volume_cache.remember(
                session, [_stored(110_000, period=stale_window)], geo="AE", locale="en"
            )
        # Fetched long enough ago that the cost guard no longer applies.
        with session_scope() as session:
            session.query(VolumeCache).one().fetched_at = utcnow() - dt.timedelta(days=30)

        assert not volume_cache.read(["samsung"], geo="AE", locale="en")

    def test_an_old_window_we_checked_recently_is_still_served(self, db: None) -> None:
        """The cost guard, and it is load-bearing: without it the vintage rule does not
        terminate. If the published window really is old, re-fetching returns the same old
        window, which is still stale, which would re-fetch on every row."""
        from app.db import session_scope
        from app.models import utcnow
        from app.services import volume_cache

        stale_window = utcnow() - dt.timedelta(days=200)
        with session_scope() as session:
            volume_cache.remember(
                session, [_stored(110_000, period=stale_window)], geo="AE", locale="en"
            )

        held = volume_cache.read(["samsung"], geo="AE", locale="en")
        assert held, "it is the newest figure that exists; buying it again changes nothing"

    def test_a_figure_with_no_recorded_period_is_never_served(self, db: None) -> None:
        """Rows written before the provider reported a window hold the time of the
        request in that column. Serving them would carry that error forward under a
        column that now means something else."""
        from app.db import session_scope
        from app.services import volume_cache

        with session_scope() as session:
            volume_cache.remember(session, [_stored(110_000, period=None)], geo="AE", locale="en")

        assert not volume_cache.read(["samsung"], geo="AE", locale="en")

    def test_undated_entries_can_be_cleared_out(self, db: None) -> None:
        from app.db import session_scope
        from app.models import VolumeCache
        from app.services import volume_cache

        with session_scope() as session:
            volume_cache.remember(session, [_stored(1, period=None)], geo="AE", locale="en")
        with session_scope() as session:
            assert volume_cache.forget_undated(session) == 1
        with session_scope() as session:
            assert session.query(VolumeCache).count() == 0

    def test_the_statistics_report_the_vintages_held(self, db: None) -> None:
        from app.db import session_scope
        from app.models import utcnow
        from app.services import volume_cache

        with session_scope() as session:
            volume_cache.remember(
                session,
                [_stored(1, period=utcnow() - dt.timedelta(days=10))],
                geo="AE",
                locale="en",
            )

        stats = volume_cache.statistics()
        assert stats["terms_within_vintage"] == 1
        assert stats["newest_period"] is not None
        assert "max_vintage_days" in stats
