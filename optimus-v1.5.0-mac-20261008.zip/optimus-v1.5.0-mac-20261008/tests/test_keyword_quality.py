"""The quality gate on what the volume provider returns.

A Samsung Galaxy Fold row came back with this, all of it real demand Google reported:

    samsung galaxy       40,500   the page's own term
    semsem galaxy        40,500   not a word, not a brand, not this product
    samsung s24 ultra    33,100   a different phone — and it was tiered SECOND
    samsung a56          27,100   a different phone
    samsung a17          18,100   a different phone

The old filters missed all four. `names_a_different_model` returns False when the PRODUCT
has no numeric qualifier, and "Samsung Galaxy Fold" has none, so every other Samsung model
sailed past it; `names_another_brand` only knows brands it has heard of, and "semsem" is
not one.

So the rule runs the other way round: every word must be accounted for by the row's own
vocabulary — its name, brand, filing category, and the seeds it was researched with.
"""

from __future__ import annotations

import pytest

from app.lib.quality import (
    is_profane,
    misspelled_brand,
    rejection_reason,
)

FOLD = {
    "product_name": "Samsung Galaxy Fold",
    "brand": "Samsung",
    "category": "Smartphones",
    "seeds": ("samsung galaxy", "samsung galaxy fold", "foldable phone", "samsung"),
}


class TestTheRowFromTheScreenshot:
    """Every term that should not have been on that row, and the one that should."""

    def test_the_pages_own_term_survives(self) -> None:
        assert rejection_reason("samsung galaxy", **FOLD) is None
        assert rejection_reason("samsung galaxy fold", **FOLD) is None
        assert rejection_reason("foldable phone", **FOLD) is None

    def test_a_word_from_nowhere_is_rejected(self) -> None:
        reason = rejection_reason("semsem galaxy", **FOLD)
        assert reason is not None
        assert "semsem" in reason

    @pytest.mark.parametrize(
        "term", ["samsung s24 ultra", "samsung a56", "samsung a17", "samsung s23 ultra"]
    )
    def test_another_phone_in_the_same_family_is_rejected(self, term: str) -> None:
        """The case the old check could not see.

        It compared generation numbers within a `(family, line)` pair, and a product with
        no generation number had nothing to compare — so a Fold page happily collected
        every other Galaxy model, sorted by volume, and tiered the biggest.
        """
        reason = rejection_reason(term, **FOLD)
        assert reason is not None, f"{term} should not reach a Galaxy Fold row"
        assert "model code" in reason or "accounts for" in reason

    def test_the_bare_brand_is_still_allowed_through(self) -> None:
        # Poor as a primary — `choose_primary` refuses it — but a real term, and the
        # quality gate is not where that judgement belongs.
        assert rejection_reason("samsung", **FOLD) is None


class TestProfanity:
    def test_a_profane_term_is_rejected(self) -> None:
        assert rejection_reason("shit projector", product_name="Philips Projector")
        assert is_profane("best porn projector")

    def test_ordinary_copy_is_not_flagged(self) -> None:
        for clean in ("projector for home", "analysis of sound", "classic design"):
            assert not is_profane(clean), clean

    def test_the_reason_is_named(self) -> None:
        assert rejection_reason(
            "xxx headphones", product_name="Sony Headphones", brand="Sony"
        ) == "profanity"


class TestMisspelledBrands:
    @pytest.mark.parametrize(
        ("token", "expected"),
        [("sasmung", "samsung"), ("samsnug", "samsung"), ("philps", "philips")],
    )
    def test_a_near_miss_is_identified(self, token: str, expected: str) -> None:
        assert misspelled_brand(token) == expected

    def test_a_real_brand_is_not_a_misspelling_of_itself(self) -> None:
        assert misspelled_brand("samsung") is None
        assert misspelled_brand("philips") is None

    def test_a_short_token_is_not_judged(self) -> None:
        # Four letters is not enough evidence. "sony" vs "pony" is one edit.
        assert misspelled_brand("pony") is None

    def test_the_reason_names_the_brand_it_resembles(self) -> None:
        reason = rejection_reason(
            "sasmung galaxy fold",
            product_name="Samsung Galaxy Fold",
            brand="Samsung",
            seeds=("samsung galaxy",),
        )
        assert reason is not None
        assert "misspelling of 'samsung'" in reason


class TestItDoesNotOverreach:
    """A gate that rejects good terms is worse than one that lets a few through."""

    PROJECTOR = {
        "product_name": "Philips NeoPix Home Projector",
        "brand": "Philips",
        "category": "Smart Home",
        "seeds": ("philips projector", "home projector", "projector", "neopix"),
    }

    @pytest.mark.parametrize(
        "term",
        [
            "philips projector",
            "home projector",
            "projector uae",
            "projector dubai",
            "buy projector online",
            "best home projector",
            "projector price in uae",
            "philips neopix",
            "smart home projector",
            "projector for bedroom",
            "portable projector",
        ],
    )
    def test_a_legitimate_long_tail_term_survives(self, term: str) -> None:
        assert rejection_reason(term, **self.PROJECTOR) is None, term

    def test_the_products_own_model_code_survives(self) -> None:
        assert rejection_reason(
            "neopix n130",
            product_name="Philips NeoPix N130 Home Projector",
            brand="Philips",
            seeds=("philips neopix",),
        ) is None

    def test_a_term_is_judged_against_the_seeds_it_was_researched_with(self) -> None:
        """The seeds are the row's vocabulary, so the gate adapts per product without
        anyone maintaining a word list."""
        without = rejection_reason(
            "foldable phone", product_name="Samsung Galaxy Fold", brand="Samsung"
        )
        with_seed = rejection_reason(
            "foldable phone",
            product_name="Samsung Galaxy Fold",
            brand="Samsung",
            seeds=("foldable phone",),
        )
        assert without is not None, "'foldable' is accounted for by nothing here"
        assert with_seed is None, "...but it is once it is one of the row's seeds"


class TestItIsWiredIntoResearch:
    def test_the_expansion_filter_calls_the_gate(self) -> None:
        import inspect

        from app.services import keyword_service

        source = inspect.getsource(keyword_service.research_row_keywords)
        assert "rejection_reason(" in source
