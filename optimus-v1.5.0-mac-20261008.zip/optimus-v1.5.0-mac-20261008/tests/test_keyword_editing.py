"""Editing the research: adding, rewording and removing keywords, and approving USPs.

Three features the content team asked for once the keywords were real:

  add / edit     the research is a starting point, and a researcher who knows the market
                 needs to be able to correct it without re-running the batch.
  USPs           something to write the copy FROM. Keywords say what people search for;
                 they do not say why anyone buys the thing.
  tiers          moved onto the real keywords page. Covered in `test_lab.py`.

The rule running through all of it: a figure comes from the volume provider or it does
not exist. Editing a term therefore re-measures it, and no claim reaches the copy without
a person putting their name to it.
"""

from __future__ import annotations

import io
from pathlib import Path
from typing import Any, Iterator

import openpyxl
import pytest
from fastapi.testclient import TestClient

PARTIAL = {"X-Partial": "1"}


@pytest.fixture()
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_path / 'test.db'}")
    monkeypatch.setenv("EXPORTS_DIR", str(tmp_path / "exports"))

    import app.config
    import app.db

    app.config.settings.cache_clear()
    app.db._engine = None
    app.db._session_factory = None

    from app.main import app as fastapi_app

    with TestClient(fastapi_app) as test_client:
        yield test_client

    app.config.settings.cache_clear()
    app.db._engine = None
    app.db._session_factory = None


def _upload(client: TestClient) -> int:
    book = openpyxl.Workbook()
    sheet = book.active
    assert sheet is not None
    sheet.title = "Products"
    for index, header in enumerate(
        ("Batch No/Name", "Product Category", "Brand ", "Product Name"), start=1
    ):
        sheet.cell(1, index, header)
    sheet.cell(2, 1, "E1")
    sheet.cell(2, 2, "Smart Home")
    sheet.cell(2, 3, "Apple")
    sheet.cell(2, 4, "Apple Watch Ultra 4")

    buffer = io.BytesIO()
    book.save(buffer)
    buffer.seek(0)

    response = client.post(
        "/upload",
        data={"batch_no": "E1"},
        files={"file": ("products.xlsx", buffer, "application/vnd.ms-excel")},
        follow_redirects=False,
    )
    assert response.status_code == 303, response.text
    return int(response.headers["location"].split("/")[2])


def _researched(client: TestClient) -> int:
    batch_id = _upload(client)
    assert client.get(
        f"/batch/{batch_id}/rows/1/keywords", headers=PARTIAL
    ).status_code == 200
    return batch_id


def _a_measured_term_absent_from(row: Any) -> str:
    """A term the fixture provider has a volume for, that this row does not already hold.

    Read out of the seed the provider itself uses, rather than hard-coded, so the test
    cannot drift from the fixture data.
    """
    from app.config import settings
    from app.lib.validators import banned_in_copy
    from app.providers.keywords._fixture import read_keyword_seed

    held = {k.term_normalized for k in row.keywords}
    for seeded in read_keyword_seed(settings().fixtures_dir / "output.xlsx"):
        if seeded.volume is None or seeded.term_normalized in held:
            continue
        if banned_in_copy(seeded.term_normalized) is not None:
            continue
        return seeded.term_normalized
    raise AssertionError("the seed has no measured term this row is missing")


def _row(batch_id: int) -> Any:
    """Row 1, with its collections already loaded so it survives the session closing."""
    from app.db import session_scope
    from app.models import Batch

    with session_scope() as session:
        batch = session.get(Batch, batch_id)
        assert batch is not None
        row = next(r for r in batch.rows if r.row_index == 1)
        # Touched inside the session on purpose: the factory sets expire_on_commit=False,
        # so an attribute read here stays readable after the session closes, while a
        # lazy load attempted afterwards raises DetachedInstanceError.
        list(row.keywords)
        list(row.usps)
        session.expunge_all()
        return row


# ---------------------------------------------------------------- adding


class TestAddingAKeyword:
    def test_a_typed_term_is_measured_by_the_provider(self, client: TestClient) -> None:
        """Not accepted on trust. A hand-added term goes through the same lookup as a
        derived one, and if the provider has no figure it stays visibly unmeasured."""
        from app.models import KeywordStatus

        batch_id = _researched(client)
        response = client.post(
            f"/batch/{batch_id}/rows/1/keywords/add",
            data={"term": "apple watch"},
            headers=PARTIAL,
        )
        assert response.status_code == 200

        added = next(k for k in _row(batch_id).keywords if k.term == "apple watch")
        # The seeded sheet covers this term, so in fixture mode it comes back measured.
        assert added.volume is not None
        assert added.status is not KeywordStatus.unverified
        assert added.is_expansion is False

    def test_a_term_with_no_data_is_kept_as_an_unmeasured_gap(
        self, client: TestClient
    ) -> None:
        from app.models import KeywordStatus

        batch_id = _researched(client)
        client.post(
            f"/batch/{batch_id}/rows/1/keywords/add",
            data={"term": "nobody searches for this at all"},
            headers=PARTIAL,
        )
        added = next(
            k for k in _row(batch_id).keywords
            if k.term == "nobody searches for this at all"
        )
        assert added.volume is None
        assert added.status is KeywordStatus.unverified

    def test_an_empty_box_says_so_rather_than_doing_nothing(
        self, client: TestClient
    ) -> None:
        batch_id = _researched(client)
        before = len(_row(batch_id).keywords)
        response = client.post(
            f"/batch/{batch_id}/rows/1/keywords/add", data={"term": "   "}, headers=PARTIAL
        )
        assert "Type a keyword first" in response.text
        assert len(_row(batch_id).keywords) == before

    def test_a_duplicate_is_not_added_twice(self, client: TestClient) -> None:
        batch_id = _researched(client)
        existing = _row(batch_id).keywords[0].term
        before = len(_row(batch_id).keywords)
        client.post(
            f"/batch/{batch_id}/rows/1/keywords/add",
            data={"term": existing},
            headers=PARTIAL,
        )
        assert len(_row(batch_id).keywords) == before


# ---------------------------------------------------------------- editing


class TestEditingAKeyword:
    def test_the_old_volume_does_not_survive_the_edit(self, client: TestClient) -> None:
        """The defect this guards against is a fabricated number.

        "apple watch" measures 33,100. Reworded to something nobody searches, the figure
        has to go — carrying 33,100 across would attach a real measurement to a query it
        was never measured for, which is the one thing the tool must never do.
        """
        batch_id = _researched(client)
        client.post(
            f"/batch/{batch_id}/rows/1/keywords/add",
            data={"term": "apple watch"},
            headers=PARTIAL,
        )
        target = next(k for k in _row(batch_id).keywords if k.term == "apple watch")
        assert target.volume is not None
        measured = target.volume

        client.post(
            f"/batch/{batch_id}/rows/1/keywords/{target.id}/edit",
            data={"term": "apple watch for absolutely nobody"},
            headers=PARTIAL,
        )

        after = next(k for k in _row(batch_id).keywords if k.id == target.id)
        assert after.term == "apple watch for absolutely nobody"
        assert after.volume is None, f"the old figure of {measured} survived the edit"

    def test_a_re_measured_term_keeps_a_figure_the_provider_still_has(
        self, client: TestClient
    ) -> None:
        batch_id = _researched(client)
        row = _row(batch_id)
        target = row.keywords[0]
        # A term the provider has a figure for AND the row does not already carry.
        # Renaming onto an existing term is refused, which is correct and is covered
        # below — picking one blindly made this test assert the refusal by accident.
        replacement = _a_measured_term_absent_from(row)
        client.post(
            f"/batch/{batch_id}/rows/1/keywords/{target.id}/edit",
            data={"term": replacement},
            headers=PARTIAL,
        )
        after = next(k for k in _row(batch_id).keywords if k.id == target.id)
        assert after.term == replacement
        assert after.volume is not None

    def test_the_editor_warns_that_saving_re_measures(self, client: TestClient) -> None:
        # The warning is the feature. A reader who expects the number to follow the text
        # would otherwise be surprised by a blank, or not notice it at all.
        batch_id = _researched(client)
        target = _row(batch_id).keywords[0]
        response = client.post(
            f"/batch/{batch_id}/rows/1/keywords/{target.id}/edit",
            data={"open_editor": "1"},
            headers=PARTIAL,
        )
        assert "looks the term up again" in response.text
        assert "replaced, not carried over" in response.text

    def test_renaming_onto_an_existing_term_is_refused_with_a_reason(
        self, client: TestClient
    ) -> None:
        batch_id = _researched(client)
        keywords = _row(batch_id).keywords
        first, second = keywords[0], keywords[1]

        response = client.post(
            f"/batch/{batch_id}/rows/1/keywords/{first.id}/edit",
            data={"term": second.term},
            headers=PARTIAL,
        )
        assert "already on this row" in response.text
        after = next(k for k in _row(batch_id).keywords if k.id == first.id)
        assert after.term == first.term

    def test_an_edit_into_an_unpublishable_term_loses_its_tier(
        self, client: TestClient
    ) -> None:
        """Editing "projector" into "projector price" makes it a term the copy step is
        forbidden to write, so it must not keep a tier the prompt would then ignore."""
        from app.models import KeywordTier

        batch_id = _researched(client)
        row = _row(batch_id)
        target = next(k for k in row.keywords if k.tier is not KeywordTier.unranked)
        # Not "... price in uae": the research already generates that shape for every
        # product, so the edit would be refused as a duplicate and the test would pass
        # for the wrong reason.
        unpublishable = "apple watch cashback deal"
        assert not any(k.term_normalized == unpublishable for k in row.keywords)

        client.post(
            f"/batch/{batch_id}/rows/1/keywords/{target.id}/edit",
            data={"term": unpublishable},
            headers=PARTIAL,
        )
        after = next(k for k in _row(batch_id).keywords if k.id == target.id)
        assert after.term == unpublishable, "the edit itself must have gone through"
        assert after.tier is KeywordTier.unranked
        assert after.is_primary is False


# ---------------------------------------------------------------- removing


class TestRemovingAKeyword:
    def test_a_removed_term_is_hidden_but_not_destroyed(self, client: TestClient) -> None:
        from app.models import KeywordStatus

        batch_id = _researched(client)
        target = _row(batch_id).keywords[0]
        response = client.post(
            f"/batch/{batch_id}/rows/1/keywords/{target.id}/remove", headers=PARTIAL
        )
        assert response.status_code == 200

        after = next(k for k in _row(batch_id).keywords if k.id == target.id)
        assert after.status is KeywordStatus.rejected, "the record must survive"
        assert "1 removed" in response.text, "and stay reachable to undo"

    def test_a_removal_can_be_undone_without_paying_for_another_lookup(
        self, client: TestClient
    ) -> None:
        from app.models import KeywordStatus

        batch_id = _researched(client)
        target = next(k for k in _row(batch_id).keywords if k.volume is not None)
        volume = target.volume

        client.post(f"/batch/{batch_id}/rows/1/keywords/{target.id}/remove", headers=PARTIAL)
        client.post(f"/batch/{batch_id}/rows/1/keywords/{target.id}/restore", headers=PARTIAL)

        after = next(k for k in _row(batch_id).keywords if k.id == target.id)
        assert after.status is not KeywordStatus.rejected
        assert after.volume == volume, "the stored figure should not have been re-fetched"


# ---------------------------------------------------------------- USPs


class TestSellingPoints:
    def test_a_row_is_offered_usps_and_none_are_pre_approved(
        self, client: TestClient
    ) -> None:
        """Unticked on purpose. A keyword gets an opening tier because a measured term is
        evidence; a USP is an unverified claim, and pre-ticking one would put a claim in
        a writer's mouth that nobody chose to make."""
        batch_id = _researched(client)
        usps = _row(batch_id).usps
        assert usps, "the row should be offered something to write from"
        assert not any(u.is_selected for u in usps)

    def test_ticking_one_records_who_approved_it(self, client: TestClient) -> None:
        batch_id = _researched(client)
        target = _row(batch_id).usps[0]

        client.post(
            f"/batch/{batch_id}/rows/1/usps/{target.id}/toggle", headers=PARTIAL
        )
        after = next(u for u in _row(batch_id).usps if u.id == target.id)
        assert after.is_selected is True
        assert after.selected_by, "an approved claim needs an owner"
        assert after.selected_at is not None

    def test_unticking_clears_the_owner_rather_than_leaving_a_stale_one(
        self, client: TestClient
    ) -> None:
        batch_id = _researched(client)
        target = _row(batch_id).usps[0]
        for _ in range(2):
            client.post(
                f"/batch/{batch_id}/rows/1/usps/{target.id}/toggle", headers=PARTIAL
            )
        after = next(u for u in _row(batch_id).usps if u.id == target.id)
        assert after.is_selected is False
        assert after.selected_by is None
        assert after.selected_at is None

    def test_only_ticked_claims_reach_the_prompt(self, client: TestClient) -> None:
        from app.providers.llm._prompts import usp_block
        from app.services.generation import approved_usps

        batch_id = _researched(client)
        target = _row(batch_id).usps[0]
        client.post(f"/batch/{batch_id}/rows/1/usps/{target.id}/toggle", headers=PARTIAL)

        claims = approved_usps(_row(batch_id))
        assert claims == (target.claim,)

        from app.providers.llm import CopyRequest

        block = usp_block(CopyRequest(row_index=1, product_name="x", category_raw="y", usps=claims))
        assert target.claim in block
        assert "a person reviewed and approved these" in block

    def test_a_row_with_nothing_approved_tells_the_model_to_claim_nothing(self) -> None:
        # The silent case stated outright, for the same reason the price block does it:
        # "use them if there are any" invites a model with none to invent one.
        from app.providers.llm import CopyRequest
        from app.providers.llm._prompts import usp_block

        block = usp_block(CopyRequest(row_index=1, product_name="x", category_raw="y"))
        assert "none approved" in block
        assert "Say nothing about what this product is good at" in block

    def test_a_typed_claim_is_approved_by_the_act_of_typing_it(
        self, client: TestClient
    ) -> None:
        from app.models import UspSource

        batch_id = _researched(client)
        client.post(
            f"/batch/{batch_id}/rows/1/usps/add",
            data={"claim": "Titanium case, built for open water"},
            headers=PARTIAL,
        )
        added = next(
            u for u in _row(batch_id).usps
            if u.claim == "Titanium case, built for open water"
        )
        assert added.source is UspSource.entered
        assert added.is_selected is True
        assert added.selected_by
        assert added.is_grounded is False

    def test_a_claim_about_price_is_refused_with_its_reason(
        self, client: TestClient
    ) -> None:
        """The same rule the keywords learned. Accepting it would offer a claim the copy
        step is forbidden to write, and the failure would surface two pages later."""
        batch_id = _researched(client)
        response = client.post(
            f"/batch/{batch_id}/rows/1/usps/add",
            data={"claim": "Cheapest price in the UAE"},
            headers=PARTIAL,
        )
        assert "Cannot be used" in response.text
        assert not any("Cheapest" in u.claim for u in _row(batch_id).usps)

    def test_an_over_long_claim_is_refused_with_the_limit(
        self, client: TestClient
    ) -> None:
        from app.lib.policy import MAX_USP_CHARS

        batch_id = _researched(client)
        response = client.post(
            f"/batch/{batch_id}/rows/1/usps/add",
            data={"claim": "a" * (MAX_USP_CHARS + 20)},
            headers=PARTIAL,
        )
        assert str(MAX_USP_CHARS) in response.text
        assert "160-character description" in response.text

    def test_a_model_claim_not_read_off_a_page_is_flagged_for_checking(
        self, client: TestClient
    ) -> None:
        """The flag is the whole basis on which a reviewer decides how hard to check a
        claim, so it must never come from the model's own say-so."""
        batch_id = _researched(client)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert "check" in page
        assert "model's own knowledge" in page

    def test_the_model_cannot_mark_its_own_recall_as_page_sourced(self) -> None:
        from app.providers.llm._prompts import IdeasSchema, UspSchema, read_ideas

        parsed = IdeasSchema(
            terms=[], usps=[UspSchema(claim="Waterproof to 100m", from_page=True)]
        )
        # No page was read for this row, so the claim cannot be grounded whatever the
        # model asserted about it.
        result = read_ideas(parsed, max_terms=20, grounded_allowed=False)
        assert result.usps[0].grounded is False

        allowed = read_ideas(parsed, max_terms=20, grounded_allowed=True)
        assert allowed.usps[0].grounded is True

    def test_a_row_with_no_usps_offers_a_retry_rather_than_a_dead_end(
        self, client: TestClient
    ) -> None:
        """Three rows of a seven-row batch lost their selling points to a swallowed
        ideation failure, and there was no way back: USPs are written during research,
        research does not re-run for a row that already has keywords, and the screen said
        "none proposed" as though the product had none."""
        from app.db import session_scope
        from app.models import Batch

        batch_id = _researched(client)

        # The state a failed ideation call leaves behind.
        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            for usp in list(row.usps):
                session.delete(usp)
            session.flush()

        page = client.get(f"/batch/{batch_id}/step/2").text
        assert "Propose selling points" in page
        assert "None came back for this product" in page

        response = client.post(
            f"/batch/{batch_id}/rows/1/usps/propose", headers=PARTIAL
        )
        assert response.status_code == 200
        assert _row(batch_id).usps, "the retry must actually fetch something"

    def test_a_retry_does_not_discard_a_claim_someone_typed(
        self, client: TestClient
    ) -> None:
        batch_id = _researched(client)

        from app.db import session_scope
        from app.models import Batch

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            for usp in list(row.usps):
                session.delete(usp)
            session.flush()

        client.post(
            f"/batch/{batch_id}/rows/1/usps/add",
            data={"claim": "Titanium case, built for open water"},
            headers=PARTIAL,
        )
        client.post(f"/batch/{batch_id}/rows/1/usps/propose", headers=PARTIAL)

        claims = [u.claim for u in _row(batch_id).usps]
        assert "Titanium case, built for open water" in claims
        assert len(claims) == len(set(claims)), "asking twice must not duplicate a claim"

    def test_a_retry_respects_the_per_row_limit(self, client: TestClient) -> None:
        from app.lib.policy import MAX_USPS

        batch_id = _researched(client)
        for _ in range(3):
            client.post(f"/batch/{batch_id}/rows/1/usps/propose", headers=PARTIAL)
        assert len(_row(batch_id).usps) <= MAX_USPS

    def test_a_usp_carries_no_figure_slot_at_all(self) -> None:
        # The structural half of "an LLM never produces a volume": there is nowhere in the
        # USP schema to put a number, so the rule is not left to the prompt alone.
        from app.providers.llm import ProposedUsp
        from app.providers.llm._prompts import UspSchema

        assert set(UspSchema.model_fields) == {"claim", "from_page"}
        assert set(ProposedUsp.__dataclass_fields__) == {"claim", "grounded"}
