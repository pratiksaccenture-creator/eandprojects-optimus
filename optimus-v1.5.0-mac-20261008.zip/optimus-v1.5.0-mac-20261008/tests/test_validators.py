"""Tests for the validator set — brief §6, and the failing tests §3 and §11 mandate.

The reference-defect tests read the real workbook, so each one is evidence about the file
the team actually produced rather than a restatement of a transcription of it.
"""

from __future__ import annotations

from dataclasses import replace

import pytest

from app.lib import normalise
from app.lib.policy import BRAND_SUFFIX
from app.lib.surfaces import DESCRIPTION_DESKTOP, TITLE_DESKTOP
from app.lib.validators import (
    BatchSnapshot,
    FieldContext,
    Finding,
    ProductIdentity,
    RowSnapshot,
    apple_keyword_overlap,
    cannibalisation,
    decide_brand_suffix,
    has_errors,
    no_banned_terms,
    no_banned_terms_in_keywords,
    no_double_space,
    no_glued_em_dash,
    no_stale_generation,
    no_trailing_whitespace,
    parse_identity,
    primary_keyword_present,
    unique_titles,
    validate_field,
    validate_keyword_cell,
    validate_store_field,
)

ARABIC = "مرحبا"  # مرحبا, 2 bytes per character


def codes(findings: list[Finding]) -> set[str]:
    return {f.code for f in findings}


def title_ctx(**kw: object) -> FieldContext:
    base: dict[str, object] = {
        "field": "meta_title_en",
        "row_index": 1,
        "surface": TITLE_DESKTOP,
    }
    base.update(kw)
    return FieldContext(**base)  # type: ignore[arg-type]


def desc_ctx(**kw: object) -> FieldContext:
    base: dict[str, object] = {
        "field": "meta_description_en",
        "row_index": 1,
        "surface": DESCRIPTION_DESKTOP,
    }
    base.update(kw)
    return FieldContext(**base)  # type: ignore[arg-type]


# ---------------------------------------------------------------- product identity


class TestParseIdentity:
    @pytest.mark.parametrize(
        ("name", "family", "line", "generation"),
        [
            ("Apple Watch Ultra 4", "watch", "ultra", 4),
            ("Apple WATCH ULTRA 4", "watch", "ultra", 4),
            ("Apple Watch Series 12", "watch", "series", 12),
            ("Apple Watch SE 3 (2026)", "watch", "se", 3),
            ("iPhone 18 Pro", "iphone", "pro", 18),
            ("iPhone 18 pro Max", "iphone", "pro max", 18),
            ("Airpods 5", "airpods", None, 5),
        ],
    )
    def test_parses_real_product_names(
        self, name: str, family: str, line: str | None, generation: int
    ) -> None:
        identity = parse_identity(name)
        assert identity.family == family
        assert identity.line == line
        assert identity.generation == generation

    def test_strips_parenthesised_year_before_finding_a_generation(self) -> None:
        # Without stripping, "(2026)" would be read as the generation.
        assert parse_identity("Apple Watch SE 3 (2026)").generation == 3

    @pytest.mark.parametrize(
        "name",
        ["iPhone 128GB", "Apple Watch 45mm", "Router 5G", "Hub Wi-Fi 7"],
    )
    def test_does_not_mistake_units_for_generations(self, name: str) -> None:
        # Capacities, sizes and radio standards contain integers that are not generations.
        assert parse_identity(name).generation is None

    def test_unknown_input_yields_nothing_rather_than_a_guess(self) -> None:
        identity = parse_identity("Smart Home")
        assert identity == ProductIdentity(None, None, None)
        assert not identity.is_known

    def test_non_numeric_generations_are_not_invented(self) -> None:
        # A documented limitation: "SE" and "XS" are generations without a number.
        assert parse_identity("Apple Watch SE").generation is None

    def test_arabic_indic_digits_fold_to_ascii(self) -> None:
        assert parse_identity("Apple Watch Ultra ٤").generation == 4


# ---------------------------------------------------------------- stale generation


class TestNoStaleGeneration:
    def test_flags_an_older_generation_of_the_same_line(self) -> None:
        ctx = title_ctx(
            product_name="Apple Watch Ultra 4", identity=parse_identity("Apple Watch Ultra 4")
        )
        findings = no_stale_generation("apple watch ultra 3 strap", ctx)
        assert codes(findings) == {"STALE_GENERATION"}
        assert has_errors(findings)

    def test_accepts_the_rows_own_generation(self) -> None:
        ctx = title_ctx(
            product_name="Apple Watch Ultra 4", identity=parse_identity("Apple Watch Ultra 4")
        )
        assert no_stale_generation("Apple Watch Ultra 4 review", ctx) == []

    def test_does_not_compare_across_model_lines(self) -> None:
        # An Ultra 2 is newer than a Series 9, so "lower number" is meaningless across
        # lines. Comparing them would produce a confident, wrong error.
        ctx = title_ctx(
            product_name="Apple Watch Ultra 4", identity=parse_identity("Apple Watch Ultra 4")
        )
        assert no_stale_generation("apple watch series 12", ctx) == []

    def test_warns_when_no_product_name_is_known(self) -> None:
        findings = no_stale_generation("anything", title_ctx(product_name=""))
        assert codes(findings) == {"STALE_GEN_NOT_CHECKED"}
        assert not has_errors(findings)

    def test_newer_generation_mention_is_not_flagged(self) -> None:
        ctx = title_ctx(
            product_name="Apple Watch Ultra 4", identity=parse_identity("Apple Watch Ultra 4")
        )
        assert no_stale_generation("apple watch ultra 5 rumours", ctx) == []


# ---------------------------------------------------------------- banned terms


class TestNoBannedTerms:
    @pytest.mark.parametrize(
        "text",
        [
            "Pre-order via SmartPay starting AED 225/month on e&.",
            "Pre-order starting AED 549 on e&.",
            "Just AED 70/month",
        ],
    )
    def test_prices_are_errors(self, text: str) -> None:
        findings = no_banned_terms(text, desc_ctx())
        assert has_errors(findings)
        assert "BANNED_CURRENCY" in codes(findings)

    def test_recurring_price_is_caught_without_a_currency(self) -> None:
        findings = no_banned_terms("Only 99/month", desc_ctx())
        assert "BANNED_RECURRING_PRICE" in codes(findings)
        assert has_errors(findings)

    def test_stock_claims_are_errors(self) -> None:
        findings = no_banned_terms("While stocks last", desc_ctx())
        assert "BANNED_STOCK" in codes(findings)
        assert has_errors(findings)

    def test_competitor_marks_are_errors(self) -> None:
        findings = no_banned_terms("Better than Vodafone", desc_ctx())
        assert "BANNED_COMPETITOR" in codes(findings)

    def test_superlatives_warn_but_do_not_block(self) -> None:
        # "Best smartphone UAE" is in the reference titles. It is weak, unproven copy, but
        # it is not a false factual claim about money or stock, so a human decides.
        findings = no_banned_terms("Best smartphone UAE", title_ctx())
        assert "WARN_SUPERLATIVE" in codes(findings)
        assert not has_errors(findings)

    def test_availability_language_warns_but_does_not_block(self) -> None:
        findings = no_banned_terms("Coming soon to e&", desc_ctx())
        assert "WARN_AVAILABILITY" in codes(findings)
        assert not has_errors(findings)

    def test_pre_order_is_not_flagged_because_the_guidelines_ask_for_it(self) -> None:
        """It used to be in this pattern, and it is ALSO one of the six action verbs the
        guidelines name: "such as: Buy, Shop, Get, Pre-order, Explore, Discover".

        So following the guideline, using the guideline's own example, earned a warning
        from a rule of ours. The team's document wins. "Coming soon" and "available now"
        still warn, because they date a page in a way "pre-order" does not.
        """
        assert no_banned_terms("Pre-order the Apple Watch Ultra 4 today", desc_ctx()) == []

    def test_clean_copy_passes(self) -> None:
        findings = no_banned_terms(
            "Apple Watch Series 12 with GPS and health sensing.", desc_ctx()
        )
        assert findings == []

    def test_unindexed_fields_are_not_checked(self) -> None:
        # Apple's description is not indexed; price copy there is a business choice.
        assert no_banned_terms("AED 549", desc_ctx(is_indexed=False)) == []


class TestBannedTermsInKeywords:
    """Keyword research is a record of real demand, not copy, so it is judged differently."""

    def test_a_real_price_query_is_allowed_as_a_keyword(self) -> None:
        # "apple watch price in uae" is in the seed data at 1,600 searches a month.
        ctx = FieldContext(field="keywords", row_index=1)
        assert no_banned_terms_in_keywords("apple watch price in uae", ctx) == []

    def test_the_same_phrase_is_still_blocked_in_indexed_copy(self) -> None:
        findings = no_banned_terms("apple watch price in uae", desc_ctx())
        assert has_errors(findings)

    def test_competitor_marks_are_still_blocked_in_keywords(self) -> None:
        ctx = FieldContext(field="keywords", row_index=1)
        findings = no_banned_terms_in_keywords("vodafone watch deal", ctx)
        assert "BANNED_COMPETITOR" in codes(findings)

    def test_the_real_seed_keywords_all_pass_the_keyword_gate(self) -> None:
        from app.providers.keywords._fixture import seed_terms

        ctx = FieldContext(field="keywords", row_index=1)
        for term, _ in seed_terms():
            assert no_banned_terms_in_keywords(term, ctx) == [], term


# ---------------------------------------------------------------- hygiene


class TestHygiene:
    def test_glued_em_dash_is_an_error(self) -> None:
        findings = no_glued_em_dash("iPhone 18 Pro—ultimate smartphone", title_ctx())
        assert codes(findings) == {"GLUED_DASH"}

    def test_spaced_em_dash_is_fine(self) -> None:
        assert no_glued_em_dash("iPhone 18 Pro — ultimate smartphone", title_ctx()) == []

    def test_trailing_space_is_an_error(self) -> None:
        assert codes(no_trailing_whitespace("Apple Watch ", title_ctx())) == {"EDGE_WHITESPACE"}

    def test_double_space_is_an_error(self) -> None:
        assert codes(no_double_space("Apple  Watch", title_ctx())) == {"DOUBLE_SPACE"}


# ---------------------------------------------------------------- limits


class TestCharAndPixelLimits:
    def test_exactly_at_the_limit_passes_under_the_guidelines(self) -> None:
        """The SEO Copy Guidelines say "160 characters or fewer", so 160 is compliant.

        This reverses the earlier reading, which came from the team's own column header
        `Character count (<160)` and made the reference file's 160-character description a
        defect. The guidelines are the newer and more authoritative statement of the same
        rule. DECISIONS.md §28.
        """
        assert "CHAR_LIMIT" not in codes(validate_field("x" * 160, desc_ctx()))

    def test_one_over_the_limit_fails(self) -> None:
        findings = validate_field("x" * 161, desc_ctx())
        assert "CHAR_LIMIT" in codes(findings)
        assert has_errors(findings)

    def test_the_stricter_exclusive_reading_is_still_available(self) -> None:
        # `char_limit_inclusive=False` restores "under 160", for anyone who wants the
        # one-character safety margin back.
        strict = replace(desc_ctx(), char_limit_inclusive=False)
        assert "CHAR_LIMIT" in codes(validate_field("x" * 160, strict))

    def test_a_wide_title_can_fail_pixels_while_passing_characters(self) -> None:
        # The reason §6 insists on measuring width as well as counting characters.
        wide = "WM" * 27  # 54 characters, all wide capitals
        findings = validate_field(wide, title_ctx())
        assert "CHAR_LIMIT" not in codes(findings)
        assert "PIXEL_LIMIT" in codes(findings)

    def test_arabic_skips_pixel_checks_with_a_visible_warning(self) -> None:
        findings = validate_field(ARABIC, title_ctx(locale="ar"))
        assert "PIXEL_UNSUPPORTED_LOCALE" in codes(findings)
        assert "PIXEL_LIMIT" not in codes(findings)


class TestPrimaryKeyword:
    def test_missing_primary_is_an_error(self) -> None:
        findings = primary_keyword_present("Apple Watch", title_ctx(primary_keyword="airpods"))
        assert codes(findings) == {"PRIMARY_KEYWORD_MISSING"}

    def test_primary_early_passes(self) -> None:
        ctx = title_ctx(primary_keyword="apple watch")
        assert primary_keyword_present("Apple Watch Series 12 with GPS", ctx) == []

    def test_primary_late_warns(self) -> None:
        ctx = title_ctx(primary_keyword="apple watch")
        findings = primary_keyword_present("Fitness tracking and health for Apple Watch", ctx)
        assert codes(findings) == {"PRIMARY_KEYWORD_LATE"}
        assert not has_errors(findings)


# ---------------------------------------------------------------- store fields


class TestStoreFields:
    def test_apple_keyword_field_is_measured_in_bytes(self) -> None:
        # Brief §11: 100 Arabic characters must fail a 100-byte limit.
        arabic_100 = ARABIC[0] * 100
        findings = validate_store_field(arabic_100, "apple_keywords")
        assert "BYTE_LIMIT" in codes(findings)
        assert has_errors(findings)

    def test_one_hundred_latin_characters_fit_the_same_field(self) -> None:
        assert "BYTE_LIMIT" not in codes(validate_store_field("a" * 100, "apple_keywords"))

    def test_apple_keyword_field_rejects_spaces_after_commas(self) -> None:
        findings = validate_store_field("watch, fitness, gps", "apple_keywords")
        assert "APPLE_KEYWORD_SPACES" in codes(findings)

    def test_apple_keyword_field_accepts_tight_commas(self) -> None:
        findings = validate_store_field("watch,fitness,gps", "apple_keywords")
        assert "APPLE_KEYWORD_SPACES" not in codes(findings)

    def test_apple_name_over_thirty_chars_fails(self) -> None:
        assert "CHAR_LIMIT" in codes(validate_store_field("x" * 31, "apple_name"))

    def test_apple_limits_are_inclusive(self) -> None:
        # Apple accepts a 30-character subtitle, so failing one would invent a rule the
        # store does not have. The SEO fields now read the same way — "60 or fewer", "160
        # or fewer" — so the two no longer disagree. They did until the guidelines arrived.
        assert "CHAR_LIMIT" not in codes(validate_store_field("x" * 30, "apple_subtitle"))
        assert "CHAR_LIMIT" in codes(validate_store_field("x" * 31, "apple_subtitle"))

    def test_apple_keyword_field_accepts_exactly_one_hundred_bytes(self) -> None:
        assert "BYTE_LIMIT" not in codes(validate_store_field("a" * 100, "apple_keywords"))
        assert "BYTE_LIMIT" in codes(validate_store_field("a" * 101, "apple_keywords"))

    def test_keyword_overlap_with_name_and_subtitle_is_an_error(self) -> None:
        findings = apple_keyword_overlap(
            "smart,watch,fitness", app_name="e& Smart", subtitle="Watch your home"
        )
        assert codes(findings) == {"APPLE_KEYWORD_OVERLAP"}

    def test_no_overlap_passes(self) -> None:
        assert apple_keyword_overlap("fitness,gps", "e& Home", "Control everything") == []

    def test_unknown_store_field_raises(self) -> None:
        with pytest.raises(KeyError):
            validate_store_field("x", "not_a_field")


# ---------------------------------------------------------------- brand suffix


def _row(index: int, title: str) -> RowSnapshot:
    return RowSnapshot(
        row_index=index,
        category_norm="devices apple watch",
        category_raw="Devices - Apple Watch",
        url=f"https://www.eand.ae/{index}",
        product_name="Apple Watch Series 12",
        title=title,
    )


class TestBrandSuffixPolicy:
    def test_applied_when_every_title_has_room(self) -> None:
        snapshot = BatchSnapshot(rows=(_row(1, "Apple Watch"), _row(2, "Apple AirPods")))
        decision = decide_brand_suffix(snapshot, TITLE_DESKTOP)
        assert decision.applied
        assert decision.blocking_row is None

    def test_one_long_title_switches_it_off_for_the_whole_batch(self) -> None:
        # Brief §6 requires one decision across the batch, not per row.
        snapshot = BatchSnapshot(rows=(_row(1, "Apple Watch"), _row(2, "W" * 58)))
        decision = decide_brand_suffix(snapshot, TITLE_DESKTOP)
        assert not decision.applied
        assert decision.blocking_row == 2

    def test_the_blocking_row_is_named_so_the_ui_can_explain_itself(self) -> None:
        snapshot = BatchSnapshot(rows=(_row(7, "W" * 58),))
        decision = decide_brand_suffix(snapshot, TITLE_DESKTOP)
        assert "row 7" in decision.reason

    def test_no_titles_yet_is_not_an_application(self) -> None:
        assert not decide_brand_suffix(BatchSnapshot(rows=()), TITLE_DESKTOP).applied

    def test_row_missing_the_agreed_suffix_is_an_error(self) -> None:
        findings = validate_field("Apple Watch Series 12", title_ctx(brand_suffix_applied=True))
        assert "BRAND_SUFFIX_MISSING" in codes(findings)

    def test_row_carrying_a_switched_off_suffix_is_an_error(self) -> None:
        findings = validate_field(
            "Apple Watch Series 12" + BRAND_SUFFIX, title_ctx(brand_suffix_applied=False)
        )
        assert "BRAND_SUFFIX_UNEXPECTED" in codes(findings)

    def test_consistent_row_passes(self) -> None:
        findings = validate_field(
            "Apple Watch Series 12" + BRAND_SUFFIX, title_ctx(brand_suffix_applied=True)
        )
        assert "BRAND_SUFFIX_MISSING" not in codes(findings)
        assert "BRAND_SUFFIX_UNEXPECTED" not in codes(findings)


# ---------------------------------------------------------------- batch tier


class TestBatchValidators:
    def test_duplicate_titles_are_errors(self) -> None:
        snapshot = BatchSnapshot(rows=(_row(1, "Apple Watch"), _row(2, "Apple Watch")))
        findings = unique_titles(snapshot)
        assert codes(findings) == {"DUPLICATE_TITLE"}
        assert findings[0].field == "row2.meta_title_en"

    def test_distinct_titles_pass(self) -> None:
        snapshot = BatchSnapshot(rows=(_row(1, "Apple Watch"), _row(2, "Apple AirPods")))
        assert unique_titles(snapshot) == []

    def test_case_and_space_variants_count_as_duplicates(self) -> None:
        snapshot = BatchSnapshot(rows=(_row(1, "Apple Watch"), _row(2, "apple  watch ")))
        assert codes(unique_titles(snapshot)) == {"DUPLICATE_TITLE"}

    def test_cannibalisation_within_a_category_warns(self) -> None:
        rows = (
            RowSnapshot(1, "devices apple watch", "Devices - Apple Watch", "u1", "Watch 12",
                        primary_keyword="apple watch"),
            RowSnapshot(2, "devices apple watch", "Devices - Apple Watch", "u2", "Ultra 4",
                        primary_keyword="apple watch"),
        )
        findings = cannibalisation(BatchSnapshot(rows=rows))
        assert codes(findings) == {"CANNIBALISATION"}
        assert not has_errors(findings)

    def test_same_primary_across_categories_is_reported_separately(self) -> None:
        # Reported under its own code rather than ignored. The spreadsheet's categories are
        # per-variant, so six Apple Watch rows compete for one term under six different
        # category labels — a same-category-only check sees none of it.
        rows = (
            RowSnapshot(1, "cat a", "Cat A", "u1", "P1", primary_keyword="apple watch"),
            RowSnapshot(2, "cat b", "Cat B", "u2", "P2", primary_keyword="apple watch"),
        )
        findings = cannibalisation(BatchSnapshot(rows=rows))
        assert codes(findings) == {"CANNIBALISATION_BATCH"}
        assert not has_errors(findings)

    def test_distinct_primaries_produce_no_cannibalisation_findings(self) -> None:
        rows = (
            RowSnapshot(1, "cat a", "Cat A", "u1", "P1", primary_keyword="apple watch"),
            RowSnapshot(2, "cat b", "Cat B", "u2", "P2", primary_keyword="airpods"),
        )
        assert cannibalisation(BatchSnapshot(rows=rows)) == []

    def test_same_category_duplicate_is_not_also_reported_as_cross_category(self) -> None:
        # One overlap should produce one finding, not two for the same pair.
        rows = (
            RowSnapshot(1, "cat a", "Cat A", "u1", "P1", primary_keyword="apple watch"),
            RowSnapshot(2, "cat a", "Cat A", "u2", "P2", primary_keyword="apple watch"),
        )
        assert codes(cannibalisation(BatchSnapshot(rows=rows))) == {"CANNIBALISATION"}

    def test_registry_claim_from_an_earlier_batch_is_caught(self) -> None:
        rows = (
            RowSnapshot(5, "devices apple watch", "Devices - Apple Watch", "u", "Ultra 4",
                        primary_keyword="apple watch"),
        )
        snapshot = BatchSnapshot(rows=rows, registry={("devices apple watch", "apple watch"): 2})
        assert codes(cannibalisation(snapshot)) == {"CANNIBALISATION_REGISTRY"}

    def test_skipped_rows_are_excluded_from_batch_checks(self) -> None:
        rows = (
            _row(1, "Apple Watch"),
            RowSnapshot(2, "c", "C", "u", "P", title="Apple Watch",
                        skipped_reason="unreachable"),
        )
        assert unique_titles(BatchSnapshot(rows=rows)) == []


# ---------------------------------------------------------------- reference defects


class TestReferenceFileDefects:
    """One test per known defect in the workbook the team actually produced."""

    def test_every_generated_description_contains_a_price(
        self, reference_descriptions: dict[int, str]
    ) -> None:
        for row, text in reference_descriptions.items():
            findings = no_banned_terms(text, desc_ctx())
            assert has_errors(findings), f"row {row} unexpectedly clean"
            assert "BANNED_CURRENCY" in codes(findings), f"row {row}"

    def test_row_12_description_sits_exactly_on_the_160_character_limit(
        self, reference_descriptions: dict[int, str]
    ) -> None:
        """Measured at exactly 160, which the guidelines permit and the column header did not.

        This was the brief's headline defect and it is no longer one: "160 characters or
        fewer" includes 160. The measurement is still asserted, because the thing worth
        protecting is that the tool counts the way Excel counts — the *verdict* moved, the
        arithmetic did not. DECISIONS.md §28.
        """
        from app.lib import limits

        assert limits.char_count(reference_descriptions[12]) == 160
        assert "CHAR_LIMIT" not in codes(validate_field(reference_descriptions[12], desc_ctx()))
        # One character more and it fails, so the ceiling is real rather than absent.
        assert "CHAR_LIMIT" in codes(
            validate_field(reference_descriptions[12] + "x", desc_ctx())
        )

    def test_row_10_description_has_a_glued_em_dash(
        self, reference_descriptions: dict[int, str]
    ) -> None:
        assert "GLUED_DASH" in codes(no_glued_em_dash(reference_descriptions[10], desc_ctx()))

    def test_rows_10_and_13_descriptions_have_trailing_whitespace(
        self, reference_descriptions: dict[int, str]
    ) -> None:
        for row in (10, 13):
            findings = no_trailing_whitespace(reference_descriptions[row], desc_ctx())
            assert "EDGE_WHITESPACE" in codes(findings), f"row {row}"

    def test_brand_suffix_is_inconsistent_across_the_reference_titles(
        self, reference_titles: dict[int, str]
    ) -> None:
        # Brief §3 says 2 of 5. It is 1 of 5 — only the Series 12 title carries it.
        with_suffix = {
            row for row, text in reference_titles.items()
            if text.rstrip().endswith(BRAND_SUFFIX.strip())
        }
        assert with_suffix == {12}
        assert len(reference_titles) == 5

    def test_row_13_keyword_cell_names_a_superseded_generation(
        self, reference_keyword_cells: dict[int, str], reference_product_names: dict[int, str]
    ) -> None:
        # The defect brief §3 names: "apple watch ultra 3" on an Ultra 4 row.
        name = reference_product_names[13]
        assert name == "Apple Watch Ultra 4"
        findings = validate_keyword_cell(
            reference_keyword_cells[13],
            FieldContext(
                field="keywords", row_index=13,
                product_name=name, identity=parse_identity(name),
            ),
        )
        assert "STALE_GENERATION" in codes(findings)
        assert has_errors(findings)

    def test_row_14_keyword_cell_also_names_a_superseded_generation(
        self, reference_keyword_cells: dict[int, str], reference_product_names: dict[int, str]
    ) -> None:
        # Not mentioned in the brief: the AirPods 5 row carries "airpods 3".
        name = reference_product_names[14]
        findings = validate_keyword_cell(
            reference_keyword_cells[14],
            FieldContext(
                field="keywords", row_index=14,
                product_name=name, identity=parse_identity(name),
            ),
        )
        assert "STALE_GENERATION" in codes(findings)

    def test_row_12_keyword_cell_is_heavily_duplicated(
        self, reference_keyword_cells: dict[int, str]
    ) -> None:
        # Brief §3 says "apple watch x4". The real shape is broader: 22 terms, 8 of which
        # occur twice each, so a third of the cell is redundant.
        terms = normalise.split_keyword_cell(reference_keyword_cells[12])
        duplicates = normalise.duplicate_terms(terms)
        assert len(terms) == 22
        assert len(duplicates) == 8
        assert duplicates["apple watch"] == 2

        findings = validate_keyword_cell(
            reference_keyword_cells[12], FieldContext(field="keywords", row_index=12)
        )
        assert "KEYWORD_DUPLICATES" in codes(findings)
        assert has_errors(findings)

    def test_row_12_keyword_cell_names_a_different_model_line(
        self, reference_keyword_cells: dict[int, str], reference_product_names: dict[int, str]
    ) -> None:
        # "apple watch ultra 3" on a Series 12 row is not a stale generation of that row's
        # line, it is a different product. Reported separately, as a warning.
        name = reference_product_names[12]
        findings = validate_keyword_cell(
            reference_keyword_cells[12],
            FieldContext(
                field="keywords", row_index=12,
                product_name=name, identity=parse_identity(name),
            ),
        )
        assert "KEYWORD_CROSS_LINE" in codes(findings)
        assert "STALE_GENERATION" not in codes(findings)

    def test_keyword_cells_carry_trailing_whitespace(
        self, reference_keyword_cells: dict[int, str]
    ) -> None:
        dirty = [r for r, c in reference_keyword_cells.items() if c != c.strip()]
        assert dirty, "expected at least one keyword cell with edge whitespace"

    def test_no_reference_row_would_pass_export_unchanged(
        self, reference_descriptions: dict[int, str], reference_titles: dict[int, str]
    ) -> None:
        # The summary claim behind the build: every generated row in the current file has
        # at least one blocking defect, so none of it would survive this tool's export gate.
        for row in reference_titles:
            findings = [
                *validate_field(reference_titles[row], title_ctx(row_index=row)),
                *validate_field(reference_descriptions[row], desc_ctx(row_index=row)),
            ]
            assert has_errors(findings), f"row {row} would have passed"
