"""Copy must not add a place nobody asked for.

The tool wrote "in the UAE" into nearly every title and description — "airpodsmax2 Apple
Headphones in the UAE", "iPhone 17 Pro by Apple in the UAE" — and it was the tool's own
idea. Nothing in the brief or the SEO Copy Guidelines asks for it. The brief names the UAE
to say whose team this is and which region the model must be hosted in; the guidelines
cover spelling, an action verb, SmartPay, the limits, keyword placement and uniqueness.

Three instructions were producing it, all of them mine:

  * `COPY_SYSTEM` described e& as a retailer "in the United Arab Emirates";
  * every prompt carried a "Market: United Arab Emirates" line;
  * a money rule told the model that for "<product> price in uae" it should "write about
    the product in the UAE".

It is also simply worse copy, and it cost characters twice because the phrase usually
landed in the title AND the description.
"""

from __future__ import annotations

import pytest

from app.lib.validators import FieldContext, no_unrequested_location


def _ctx(**kwargs: object) -> FieldContext:
    base: dict[str, object] = {"field": "meta_title_en", "row_index": 1}
    base.update(kwargs)
    return FieldContext(**base)  # type: ignore[arg-type]


class TestTheRule:
    @pytest.mark.parametrize(
        "text",
        [
            "Apple iPhone 17 Pro by Apple in the UAE | e&",
            "airpodsmax2 Apple Headphones in the UAE | e&",
            "Explore the Philips projector in the United Arab Emirates.",
            "Shop the AOC monitor in Dubai with SmartPay.",
            "Available across the U.A.E. with SmartPay.",
            "Order in Abu Dhabi today with SmartPay.",
        ],
    )
    def test_an_added_location_is_an_error(self, text: str) -> None:
        findings = no_unrequested_location(text, _ctx())
        assert len(findings) == 1
        assert findings[0].code == "UNREQUESTED_LOCATION"
        assert findings[0].severity == "error", (
            "a warning would report the phrase and leave it in the copy, which is the "
            "opposite of the ask"
        )

    @pytest.mark.parametrize(
        "text",
        [
            "Apple iPhone 17 Pro: the latest iPhone design | e&",
            "Shop Sony headphones and explore SmartPay with e&.",
            "Philips home projector for your smart home | e&",
            # Not a location rule: these must not be caught.
            "Emirates-ready eSIM from e&",
            "Gulf Edition console from e&",
        ],
    )
    def test_copy_without_a_location_passes(self, text: str) -> None:
        assert no_unrequested_location(text, _ctx()) == []


class TestTheTwoWaysItIsAllowed:
    """Both are a person's decision. That is the whole rule."""

    def test_a_tiered_keyword_that_names_a_place_permits_it(self) -> None:
        ctx = _ctx(requested_terms=("projector in uae", "philips"))
        assert no_unrequested_location("Philips projector in uae | e&", ctx) == []

    def test_an_untiered_term_does_not_permit_it(self) -> None:
        """`requested_terms` is what carries a tier, not every term on the row.

        Market-qualified keywords are generated for every product, so letting any
        available term license the phrase would mean the rule never fired.
        """
        ctx = _ctx(secondary_keywords=("projector in uae",), requested_terms=("philips",))
        findings = no_unrequested_location("Philips projector in the UAE | e&", ctx)
        assert len(findings) == 1

    def test_a_human_edit_is_never_refused(self) -> None:
        # The rule exists to stop the MODEL adding a place. Refusing the same words from
        # the person it defers to would be the rule outliving its reason.
        ctx = _ctx(human_edited=True)
        assert no_unrequested_location("iPhone 17 Pro in the UAE | e&", ctx) == []

    def test_a_non_indexed_field_is_out_of_scope(self) -> None:
        # Tier 2 drafts and store copy are validated on length only.
        ctx = _ctx(is_indexed=False)
        assert no_unrequested_location("Buy in Dubai", ctx) == []


class TestItIsWiredIn:
    def test_the_validator_runs_in_the_field_set(self) -> None:
        from app.lib.validators import FIELD_VALIDATORS

        assert no_unrequested_location in FIELD_VALIDATORS

    def test_the_prompt_no_longer_states_the_market_as_context(self) -> None:
        """The single biggest cause. Stating the market as background reads to a model as
        a thing worth mentioning."""
        from app.providers.llm import CopyRequest
        from app.providers.llm._prompts import COPY_SYSTEM, build_copy_prompt

        prompt = build_copy_prompt(
            CopyRequest(row_index=1, product_name="x", category_raw="y")
        )
        assert "Market: United Arab Emirates" not in prompt
        assert "United Arab Emirates" not in COPY_SYSTEM.split("PLACE.")[0], (
            "the system prompt should not describe e& by its country before the rule that "
            "forbids saying so"
        )

    def test_the_prompt_forbids_adding_a_place_and_names_the_exception(self) -> None:
        from app.providers.llm._prompts import COPY_SYSTEM

        assert "Never add a location" in COPY_SYSTEM
        assert "if a keyword you were given contains a place" in COPY_SYSTEM

    def test_the_offline_templates_obey_the_same_rule(self) -> None:
        """Otherwise the rule is only enforced when someone is paying for a model."""
        import pathlib

        source = pathlib.Path("app/providers/llm/_fixture.py").read_text(encoding="utf-8")
        assert "UAE" not in source
        assert "United Arab Emirates" not in source
