"""Structural enforcement of the provider boundary — brief §1 rule 5.

"The model provider is behind one module. The prototype may default to fixture mode, but
repointing must be a single file change with no call-site edits."

A docstring asking people not to import `_azure` directly is a convention. These tests make
it a rule, by parsing the import graph rather than trusting it.
"""

from __future__ import annotations

import ast
from pathlib import Path

import pytest

APP = Path(__file__).resolve().parents[1] / "app"
PROVIDERS = APP / "providers"

# Vendor SDKs and HTTP clients belong inside a provider implementation and nowhere else.
FORBIDDEN_OUTSIDE_PROVIDERS = (
    "openai", "azure", "httpx", "requests", "aiohttp", "google.ads", "boto3",
)


def _modules(root: Path) -> list[Path]:
    return sorted(p for p in root.rglob("*.py") if "__pycache__" not in p.parts)


def _imported_names(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            names.add(node.module)
            names.update(f"{node.module}.{alias.name}" for alias in node.names)
    return names


def _outside_providers() -> list[Path]:
    return [p for p in _modules(APP) if PROVIDERS not in p.parents and p.parent != PROVIDERS]


def test_no_module_outside_providers_imports_a_private_implementation() -> None:
    offenders: list[str] = []
    for path in _outside_providers():
        for name in _imported_names(path):
            parts = name.split(".")
            if "providers" in parts and any(
                part.startswith("_") and part != "__init__" for part in parts
            ):
                offenders.append(f"{path.relative_to(APP.parent)} imports {name}")
    assert not offenders, (
        "Private provider modules must be reached through get_llm() / "
        "get_keyword_provider():\n  " + "\n  ".join(offenders)
    )


def test_no_module_outside_providers_imports_a_vendor_sdk() -> None:
    offenders: list[str] = []
    for path in _outside_providers():
        for name in _imported_names(path):
            for forbidden in FORBIDDEN_OUTSIDE_PROVIDERS:
                if name == forbidden or name.startswith(f"{forbidden}."):
                    offenders.append(f"{path.relative_to(APP.parent)} imports {name}")
    assert not offenders, (
        "Vendor SDKs and HTTP clients belong inside a provider implementation:\n  "
        + "\n  ".join(offenders)
    )


def test_llm_package_exports_only_the_seam() -> None:
    from app.providers import llm

    assert set(llm.__all__) == {
        "CopyDraft", "CopyRequest", "CopyResult", "IdeationRequest", "IdeationResult",
        "KeywordIdea", "LLMProvider", "ModelNotConfiguredError", "PageFacts",
        "ProposedUsp", "get_llm",
    }


def test_pages_package_exports_only_the_seam() -> None:
    from app.providers import pages

    assert set(pages.__all__) == {"PageProvider", "PageResult", "get_page_provider"}


def test_keyword_package_exports_only_the_seam() -> None:
    from app.providers import keywords

    assert set(keywords.__all__) == {
        "ExpansionResult", "KeywordVolumeProvider", "NotConfiguredError", "VolumeResult",
        "available_providers", "get_keyword_provider",
    }


def test_every_provider_implementation_is_private() -> None:
    for package in ("llm", "keywords", "pages"):
        for path in _modules(PROVIDERS / package):
            assert path.name == "__init__.py" or path.name.startswith("_"), (
                f"{path.name} is a public module inside providers/{package}; "
                "implementations must be underscore-private"
            )


@pytest.mark.parametrize("package", ["llm", "keywords", "pages"])
def test_switching_provider_needs_no_call_site_change(package: str) -> None:
    # The factory is the only public entry point, so a call site names a provider by
    # string and never by import.
    init = (PROVIDERS / package / "__init__.py").read_text(encoding="utf-8")
    assert "def get_" in init
    tree = ast.parse(init)
    factories = [
        n.name for n in ast.walk(tree)
        if isinstance(n, ast.FunctionDef) and n.name.startswith("get_")
    ]
    assert factories, f"providers/{package} has no factory function"
