"""End-to-end tests for the three-page journey.

Upload, keywords and approve, copy and export. Drives the real app against a throwaway
database.

The route tests for the richer interface are kept at
`archive/full-ui/tests/test_web_full_ui.py` — they exercise pages this version does not
serve (the row preview, the ASO tab, inline editing, the diagnostics page), so they are not
collected here.
"""

from __future__ import annotations

import hashlib
import io
from collections.abc import Iterator
from pathlib import Path

import openpyxl
import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
PARTIAL = {"X-Partial": "1"}


@pytest.fixture()
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """A fresh app on a throwaway database, with nothing configured — brief §11 requires the
    tool to run with no environment variables set."""
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_path / 'test.db'}")
    monkeypatch.setenv("EXPORTS_DIR", str(tmp_path / "exports"))
    monkeypatch.delenv("DEMO_PACING_MS", raising=False)
    # Asked for by name. Deleting these used to be enough, because the absence of
    # credentials resolved to fixtures; since it resolves to "unconfigured" instead
    # (DECISIONS.md §29), a test that deletes them gets a tool that refuses.
    monkeypatch.setenv("KEYWORD_PROVIDER", "fixture")
    monkeypatch.setenv("LLM_PROVIDER", "fixture")

    import app.config
    import app.db

    app.config.settings.cache_clear()
    app.db._engine = None
    app.db._session_factory = None

    from app.main import app as fastapi_app

    with TestClient(fastapi_app) as test_client:
        yield test_client

    app.config.settings.cache_clear()
    app.db._engine = None
    app.db._session_factory = None


def _upload(client: TestClient, batch_no: str = "Batch 9") -> int:
    response = client.post("/upload", data={"batch_no": batch_no}, follow_redirects=False)
    assert response.status_code == 303
    location = response.headers["location"]
    assert "/step/2" in location, "upload should land on the keyword page"
    return int(location.split("/")[2])


def _keywords(client: TestClient, batch_id: int) -> None:
    for row_index in range(1, 22):
        got = client.get(f"/batch/{batch_id}/rows/{row_index}/keywords", headers=PARTIAL)
        assert got.status_code == 200, row_index


def _generate(client: TestClient, batch_id: int) -> None:
    for row_index in range(1, 22):
        got = client.get(f"/batch/{batch_id}/rows/{row_index}/generate", headers=PARTIAL)
        assert got.status_code == 200, row_index
    assert client.get(f"/batch/{batch_id}/settle", headers=PARTIAL).status_code == 200


def _full_batch(client: TestClient, batch_no: str = "Batch 9") -> int:
    batch_id = _upload(client, batch_no)
    _keywords(client, batch_id)
    assert client.post(f"/batch/{batch_id}/approve", follow_redirects=False).status_code == 303
    _generate(client, batch_id)
    return batch_id


# ---------------------------------------------------------------- shape of the journey


class TestJourney:
    def test_only_three_steps_are_offered(self, client: TestClient) -> None:
        batch_id = _full_batch(client)
        page = client.get(f"/batch/{batch_id}/step/2")
        assert page.text.count('class="dot"') == 3
        for label in ("Upload", "Keywords", "Copy"):
            assert label in page.text

    def test_pages_the_simple_journey_does_not_serve_are_gone(self, client: TestClient) -> None:
        batch_id = _full_batch(client)
        for path in (f"/batch/{batch_id}/step/1", f"/batch/{batch_id}/step/4", "/aso"):
            assert client.get(path).status_code == 404, path

    def test_root_lands_on_the_right_step(self, client: TestClient) -> None:
        response = client.get("/", follow_redirects=False)
        assert response.status_code == 303
        assert "/step/" in response.headers["location"]

    def test_no_explanatory_prose_on_the_pages(self, client: TestClient) -> None:
        # The guiding text the earlier version carried has gone.
        batch_id = _full_batch(client)
        for step in (2, 3):
            text = client.get(f"/batch/{batch_id}/step/{step}").text
            for phrase in (
                "Candidate terms are derived",
                "Each row generates, validates",
                "gap is real, not an error",
                "Nothing is truncated to fit",
            ):
                assert phrase not in text, f"step {step} still carries: {phrase}"

    def test_healthz_reports_fixture_mode_and_no_pacing(self, client: TestClient) -> None:
        payload = client.get("/healthz").json()
        assert payload["keyword_provider"] == "fixture"
        assert payload["demo_pacing_ms"] == 0


# ---------------------------------------------------------------- 1. upload


class TestUpload:
    def test_upload_goes_straight_to_keywords(self, client: TestClient) -> None:
        batch_id = _upload(client)
        assert client.get(f"/batch/{batch_id}/step/2").status_code == 200

    def test_all_twenty_one_rows_are_ingested(self, client: TestClient) -> None:
        batch_id = _upload(client)
        page = client.get(f"/batch/{batch_id}/step/2")
        # One table row per input URL, skeleton or filled.
        assert page.text.count('id="kw-') == 21

    def test_a_non_xlsx_upload_is_refused(self, client: TestClient) -> None:
        response = client.post(
            "/upload",
            data={"batch_no": "Batch 9"},
            files={"file": ("notes.txt", b"hello", "text/plain")},
        )
        assert response.status_code == 400
        assert "not an .xlsx workbook" in response.text


# ---------------------------------------------------------------- 2. keywords


class TestKeywords:
    def test_volumes_appear_per_row(self, client: TestClient) -> None:
        batch_id = _upload(client)
        page = client.get(f"/batch/{batch_id}/rows/9/keywords", headers=PARTIAL)
        assert page.status_code == 200
        assert "3,600" in page.text  # iphone 18 pro

    def test_a_row_with_no_data_shows_no_number(self, client: TestClient) -> None:
        # Brief §1 rule 1: a missing volume is never invented or interpolated.
        batch_id = _upload(client)
        page = client.get(f"/batch/{batch_id}/rows/1/keywords", headers=PARTIAL)
        assert "no volume data" in page.text
        assert "0" not in page.text.split("no volume data")[0][-40:]

    def test_the_primary_is_specific_not_the_biggest_number(self, client: TestClient) -> None:
        batch_id = _upload(client)
        client.get(f"/batch/{batch_id}/rows/10/keywords", headers=PARTIAL)

        # Asserted against the database rather than by slicing the HTML. The old version
        # split on a `<td class="vol">` marker, and when the volume column was replaced by
        # the targeting column the split stopped matching — so the assertion ran against
        # the whole page and could no longer fail.
        from app.db import session_scope
        from app.models import Batch, KeywordTier

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 10)
            primary = next(k for k in row.keywords if k.tier is KeywordTier.primary)
            offered = {k.term for k in row.keywords}

        # `apple` at 165,000 is offered but must not hold the primary slot.
        assert "apple" in offered
        assert primary.term == "iphone 18 pro max"

    def test_clicking_a_term_makes_it_primary(self, client: TestClient) -> None:
        batch_id = _upload(client)
        client.get(f"/batch/{batch_id}/rows/10/keywords", headers=PARTIAL)

        from app.db import session_scope
        from app.models import Batch

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 10)
            other = next(k for k in row.keywords if not k.is_primary and k.volume)
            target_id, target_term = other.id, other.term

        response = client.post(
            f"/batch/{batch_id}/rows/10/primary?keyword_id={target_id}", headers=PARTIAL
        )
        assert response.status_code == 200

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 10)
            primary = next(k for k in row.keywords if k.is_primary)
            assert primary.term == target_term

    def test_seeded_data_is_disclosed_as_not_live(self, client: TestClient) -> None:
        """Brief §5 requires this even in the stripped-back UI.

        The supplier's NAME was removed from the screen; the claim about the data was
        not, and must not be. Those are different things: "who gave us this figure" is
        operational detail, "is this figure real" is the disclosure.
        """
        batch_id = _upload(client)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert "Sample data" in page
        assert "not live" in page
        assert "FixtureVolumeProvider" not in page

    def test_approve_moves_to_the_copy_page(self, client: TestClient) -> None:
        batch_id = _upload(client)
        _keywords(client, batch_id)
        response = client.post(f"/batch/{batch_id}/approve", follow_redirects=False)
        assert response.status_code == 303
        assert response.headers["location"].endswith("/step/3")

    def test_approval_is_recorded(self, client: TestClient) -> None:
        batch_id = _full_batch(client)

        from app.db import session_scope
        from app.models import AuditEvent

        with session_scope() as session:
            actions = {e.action for e in session.query(AuditEvent).all()}
            assert "batch_uploaded" in actions
            assert "keywords_approved" in actions


# ---------------------------------------------------------------- 3. copy


class TestCopy:
    def test_every_row_gets_a_title_and_a_description(self, client: TestClient) -> None:
        batch_id = _full_batch(client)
        page = client.get(f"/batch/{batch_id}/step/3")
        assert page.text.count('id="f-') == 42  # 21 rows x 2 fields
        assert page.text.count("Refresh") == 42

    def test_the_export_control_enables_itself_when_the_last_row_lands(
        self, client: TestClient
    ) -> None:
        """The button must not stay disabled after streaming finishes.

        It began life outside any swappable region, so a clean batch still showed a dead
        export button until the page was reloaded.
        """
        batch_id = _upload(client)
        _keywords(client, batch_id)
        client.post(f"/batch/{batch_id}/approve", follow_redirects=False)

        # Before generating, the control is correctly disabled.
        assert "disabled" in client.get(f"/batch/{batch_id}/step/3").text

        for row_index in range(1, 22):
            last = client.get(
                f"/batch/{batch_id}/rows/{row_index}/generate", headers=PARTIAL
            )
        settled = client.get(f"/batch/{batch_id}/settle", headers=PARTIAL)

        # The final row or the settle step must hand back a refreshed, enabled control.
        combined = last.text + settled.text
        assert 'id="export-state"' in combined
        assert 'data-swap-oob="true"' in combined
        assert "disabled" not in settled.text

        assert "disabled" not in client.get(f"/batch/{batch_id}/step/3").text

    def test_fields_are_not_duplicated_after_the_settle_step(
        self, client: TestClient
    ) -> None:
        # The settle response used to wrap each field in another element carrying the same
        # id, which broke every later out-of-band swap for that cell.
        batch_id = _full_batch(client)
        page = client.get(f"/batch/{batch_id}/step/3").text
        assert page.count('id="f-10-meta_title_en"') == 1
        assert page.count('id="export-state"') == 1

    def test_character_counts_are_shown_against_their_limits(self, client: TestClient) -> None:
        batch_id = _full_batch(client)
        page = client.get(f"/batch/{batch_id}/step/3")
        assert "/60" in page.text
        assert "/160" in page.text

    def test_refresh_offers_an_alternative_rather_than_eroding_the_copy(
        self, client: TestClient
    ) -> None:
        """Refreshing a valid field must not just shorten it.

        The first implementation drove compression off the attempt number, so clicking
        Refresh on perfectly good copy walked it down to the bare product name. Variants
        now rotate instead.
        """
        batch_id = _full_batch(client)

        from app.db import session_scope
        from app.models import Batch
        from app.services.validation import current_text

        def title() -> str:
            with session_scope() as session:
                batch = session.get(Batch, batch_id)
                assert batch is not None
                row = next(r for r in batch.rows if r.row_index == 10)
                return current_text(row, "meta_title_en")

        seen = {title()}
        for _ in range(4):
            response = client.post(
                f"/batch/{batch_id}/rows/10/fields/meta_title_en/regenerate",
                headers=PARTIAL,
            )
            assert response.status_code == 200
            seen.add(title())

        assert len(seen) > 1, "refresh produced no alternatives at all"
        shortest = min(len(t) for t in seen)
        assert shortest > 20, (
            f"refresh eroded the copy down to {shortest} characters: {sorted(seen, key=len)[0]!r}"
        )
        # The product name survives every variant.
        for text in seen:
            assert "iPhone 18 Pro Max" in text or "iPhone 18 Pro" in text

    def test_refreshed_copy_is_still_validated(self, client: TestClient) -> None:
        batch_id = _full_batch(client)
        for _ in range(3):
            client.post(
                f"/batch/{batch_id}/rows/10/fields/meta_title_en/regenerate", headers=PARTIAL
            )

        from app.db import session_scope
        from app.models import Batch
        from app.services.validation import current_field

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 10)
            field = current_field(row, "meta_title_en")
            assert field is not None
            assert field.char_count > 0
            assert field.pixel_width > 0

    def test_brand_suffix_is_uniform_across_every_row(self, client: TestClient) -> None:
        # The reference file carried ` | e&` on one title in five. That is the defect.
        batch_id = _full_batch(client)

        from app.db import session_scope
        from app.models import Batch
        from app.services.validation import current_text

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            titles = [current_text(r, "meta_title_en") for r in batch.rows]
            with_suffix = [t for t in titles if t.rstrip().endswith("| e&")]
            assert len(with_suffix) == len(titles)

    def test_every_attempt_is_retained(self, client: TestClient) -> None:
        # Brief §1 rule 4: nothing is overwritten.
        batch_id = _full_batch(client)
        client.post(
            f"/batch/{batch_id}/rows/10/fields/meta_title_en/regenerate", headers=PARTIAL
        )

        from app.db import session_scope
        from app.models import Batch

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 10)
            attempts = [c for c in row.copy_fields if c.field == "meta_title_en"]
            assert len(attempts) > 1
            assert sum(1 for c in attempts if c.is_current) == 1


# ---------------------------------------------------------------- export


class TestExport:
    def test_export_returns_a_workbook_as_a_download(self, client: TestClient) -> None:
        batch_id = _full_batch(client)
        response = client.post(f"/batch/{batch_id}/export")
        assert response.status_code == 200
        assert response.headers["content-type"].startswith(
            "application/vnd.openxmlformats"
        )
        assert ".xlsx" in response.headers["content-disposition"]
        assert response.content[:2] == b"PK"

    def test_export_is_blocked_while_an_error_stands(self, client: TestClient) -> None:
        batch_id = _full_batch(client)

        # Editing is not in this UI, so the error is introduced through the service the UI
        # would have used. The gate itself is what is under test.
        from app.db import session_scope
        from app.models import Batch
        from app.services import generation

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 10)
            generation.edit_field(
                session, row, "meta_title_en", "iPhone from AED 225/month",
                locale=batch.locale, brand_suffix_applied=batch.brand_suffix_applied,
            )

        blocked = client.post(f"/batch/{batch_id}/export")
        assert blocked.status_code == 409

        page = client.get(f"/batch/{batch_id}/step/3")
        assert "need attention" in page.text
        assert "disabled" in page.text

    def test_the_workbook_reproduces_the_reference_layout(self, client: TestClient) -> None:
        batch_id = _full_batch(client)
        content = client.post(f"/batch/{batch_id}/export").content

        book = openpyxl.load_workbook(io.BytesIO(content))
        assert book.sheetnames == [
            "SEO Batch 6 Product List", "keywords ", "GEO", "ASO", "Validation log",
        ]
        sheet = book["SEO Batch 6 Product List"]
        assert sheet.cell(row=1, column=4).value == "Keywords "
        assert sheet.cell(row=1, column=7).value == "Meta Decsription (EN)"
        assert sheet["I1"].value is None and sheet["I1"].font.b is True

        for row in range(2, 23):
            assert str(sheet.cell(row=row, column=3).value).startswith("https://"), row
            assert sheet.cell(row=row, column=6).value == f"=LEN(E{row})"
            assert sheet.cell(row=row, column=8).value == f"=LEN(G{row})"
            assert sheet.cell(row=row, column=10).value
        assert sheet.cell(row=23, column=3).value is None

    def test_twenty_one_rows_in_yields_twenty_one_rows_out(self, client: TestClient) -> None:
        batch_id = _full_batch(client)
        content = client.post(f"/batch/{batch_id}/export").content
        sheet = openpyxl.load_workbook(io.BytesIO(content))["SEO Batch 6 Product List"]
        urls = [
            sheet.cell(row=r, column=3).value
            for r in range(2, sheet.max_row + 1)
            if sheet.cell(row=r, column=3).value
        ]
        assert len(urls) == 21 and len(set(urls)) == 21

    def test_redownload_from_history_is_byte_identical(self, client: TestClient) -> None:
        batch_id = _full_batch(client)
        first = client.post(f"/batch/{batch_id}/export").content

        again = client.get("/exports/1/download")
        assert again.status_code == 200
        assert hashlib.sha256(again.content).hexdigest() == (
            hashlib.sha256(first).hexdigest()
        )
        assert again.content == first

    def test_the_geo_and_aso_sheets_are_still_populated(self, client: TestClient) -> None:
        # The tabs that showed these are gone from the UI; the data has not gone anywhere.
        batch_id = _full_batch(client)
        content = client.post(f"/batch/{batch_id}/export").content
        book = openpyxl.load_workbook(io.BytesIO(content))
        assert book["GEO"].max_row > 1
        assert book["ASO"].max_row > 1
        assert book["Validation log"].max_row > 1


# ---------------------------------------------------------------- history


class TestHistory:
    def test_history_lists_the_batch_with_its_retention_date(self, client: TestClient) -> None:
        batch_id = _full_batch(client)
        client.post(f"/batch/{batch_id}/export")
        page = client.get("/history")
        assert page.status_code == 200
        assert "Batch 9" in page.text
        assert "Download" in page.text

    def test_history_offers_a_download_per_batch(self, client: TestClient) -> None:
        batch_id = _full_batch(client)
        client.post(f"/batch/{batch_id}/export")
        assert "/exports/1/download" in client.get("/history").text

    def test_empty_history_says_so(self, client: TestClient) -> None:
        # The seeded demo batch is created on startup, so clear it first.
        from app.db import session_scope
        from app.models import Batch

        with session_scope() as session:
            for batch in session.query(Batch).all():
                session.delete(batch)
        assert "Nothing yet" in client.get("/history").text


# ---------------------------------------------------------------- maintenance


class TestMaintenance:
    def test_dev_status_is_json_with_metric_provenance(self, client: TestClient) -> None:
        payload = client.get("/dev/").json()
        assert "batches" in payload
        assert payload["pixel_metrics"]["sha256"]

    def test_purge_leaves_unexpired_batches_alone(self, client: TestClient) -> None:
        _full_batch(client)
        assert client.post("/dev/purge").json()["purged"] == 0

    def test_simulated_purge_removes_expired_batches(self, client: TestClient) -> None:
        _full_batch(client)
        assert client.post("/dev/purge-simulated").json()["purged"] >= 1


# ---------------------------------------------------------------- failures


class TestFailuresAreVisible:
    def test_a_missing_batch_is_a_stated_error(self, client: TestClient) -> None:
        response = client.get("/batch/999/step/2")
        assert response.status_code == 404
        assert "999" in response.text

    def test_a_missing_row_is_a_stated_error(self, client: TestClient) -> None:
        batch_id = _upload(client)
        response = client.get(f"/batch/{batch_id}/rows/999/keywords", headers=PARTIAL)
        assert response.status_code == 404
