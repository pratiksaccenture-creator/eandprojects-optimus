"""Tests for measurement — brief §6.

The four counts in `measure()` exist because they disagree. These tests pin the
disagreements, because every one of them is a place a naive implementation silently
reports the wrong number.
"""

from __future__ import annotations

import pytest

from app.lib import limits
from app.lib.surfaces import (
    DESCRIPTION_DESKTOP,
    DESCRIPTION_MOBILE,
    TITLE_DESKTOP,
)

UAE_FLAG = "\U0001f1e6\U0001f1ea"
ARABIC_PLAIN = "مرحبا"  # مرحبا
ARABIC_HARAKAT = "مَرْحَبًا"  # مَرْحَبًا


class TestCharCount:
    def test_matches_excel_len_on_ascii(self) -> None:
        assert limits.char_count("hello") == 5

    def test_counts_utf16_units_not_code_points(self) -> None:
        # Excel's LEN() reports 4 for this, because it counts UTF-16 units.
        # Python's len() reports 2. Using len() would understate the count by half.
        assert len(UAE_FLAG) == 2
        assert limits.char_count(UAE_FLAG) == 4

    def test_arabic_is_bmp_so_chars_equal_code_points(self) -> None:
        assert limits.char_count(ARABIC_PLAIN) == len(ARABIC_PLAIN) == 5

    def test_empty(self) -> None:
        assert limits.char_count("") == 0


class TestGraphemeCount:
    def test_flag_is_one_grapheme(self) -> None:
        assert limits.grapheme_count(UAE_FLAG) == 1

    def test_harakat_do_not_add_graphemes(self) -> None:
        # This is why a char-based <60 limit becomes meaningless for Arabic: the four
        # invisible vowel marks cost four characters against the limit and zero graphemes.
        assert limits.char_count(ARABIC_HARAKAT) == 9
        assert limits.grapheme_count(ARABIC_HARAKAT) == 5
        assert limits.grapheme_count(ARABIC_HARAKAT) == limits.grapheme_count(ARABIC_PLAIN)

    def test_precomposed_and_decomposed_agree(self) -> None:
        assert limits.grapheme_count("café") == limits.grapheme_count("café") == 4


class TestByteCount:
    def test_ascii_is_one_byte_per_char(self) -> None:
        assert limits.byte_count("hello") == 5

    def test_arabic_is_two_bytes_per_char(self) -> None:
        assert limits.byte_count(ARABIC_PLAIN) == 10

    def test_normalises_before_counting(self) -> None:
        # Decomposed input must not be charged for its combining mark.
        assert limits.byte_count("café") == limits.byte_count("café") == 5


class TestAdvanceWidth:
    def test_narrow_char_is_narrower_than_wide_char(self) -> None:
        narrow, _ = limits.advance_width("i", 20)
        wide, _ = limits.advance_width("W", 20)
        assert narrow < wide

    def test_scales_linearly_with_font_size(self) -> None:
        at_10, _ = limits.advance_width("Apple Watch", 10)
        at_20, _ = limits.advance_width("Apple Watch", 20)
        assert at_20 == pytest.approx(at_10 * 2)

    def test_capitals_are_wider_than_lowercase_at_equal_char_count(self) -> None:
        # The premise of gating on pixels as well as characters.
        upper, _ = limits.advance_width("MMMMMMMMMM", 20)
        lower, _ = limits.advance_width("iiiiiiiiii", 20)
        assert limits.char_count("MMMMMMMMMM") == limits.char_count("iiiiiiiiii")
        assert upper > lower * 3

    def test_unknown_glyphs_are_counted_not_silently_zeroed(self) -> None:
        width, missing = limits.advance_width("\U000f0000", 20)
        assert missing == 1
        assert width > 0

    def test_known_text_reports_no_missing_glyphs(self) -> None:
        _, missing = limits.advance_width("Apple iPhone 18 Pro | Best smartphone UAE", 20)
        assert missing == 0


class TestTruncation:
    def test_visible_and_clipped_reconstruct_the_input(self) -> None:
        text = "Apple Watch Series 12 " * 12
        for surface in (TITLE_DESKTOP, DESCRIPTION_DESKTOP, DESCRIPTION_MOBILE):
            result = limits.truncate(text, surface)
            assert result.visible + result.clipped == text, surface.key

    def test_short_text_is_not_truncated(self) -> None:
        result = limits.truncate("Apple AirPods 5", TITLE_DESKTOP)
        assert not result.truncated
        assert result.clipped == ""

    def test_long_title_truncates_on_one_line(self) -> None:
        result = limits.truncate("Apple Watch Ultra 4 " * 6, TITLE_DESKTOP)
        assert result.truncated
        assert len(result.lines) == 1
        assert result.used_px <= TITLE_DESKTOP.container_px

    def test_description_wraps_to_its_line_allowance(self) -> None:
        result = limits.truncate("Apple Watch Series 12 " * 30, DESCRIPTION_DESKTOP)
        assert result.truncated
        assert len(result.lines) == DESCRIPTION_DESKTOP.max_lines

    def test_mobile_description_clips_earlier_than_desktop(self) -> None:
        text = "Apple Watch Series 12 " * 30
        desktop = limits.truncate(text, DESCRIPTION_DESKTOP)
        mobile = limits.truncate(text, DESCRIPTION_MOBILE)
        assert len(mobile.visible) < len(desktop.visible)

    def test_wrapped_lines_respect_container_width(self) -> None:
        lines = limits.wrap_lines(
            "Stay active with Apple Watch Series 12 and track everything you do all day",
            DESCRIPTION_DESKTOP.font_px,
            DESCRIPTION_DESKTOP.container_px,
        )
        for line in lines:
            width, _ = limits.advance_width(line.rstrip(), DESCRIPTION_DESKTOP.font_px)
            assert width <= DESCRIPTION_DESKTOP.container_px

    def test_empty_text(self) -> None:
        result = limits.truncate("", TITLE_DESKTOP)
        assert result.visible == "" and result.clipped == ""


class TestProvenance:
    def test_metrics_are_attributable(self) -> None:
        # Brief §0: every number on screen must be traceable to a source.
        prov = limits.metrics_provenance()
        for key in ("font_family", "sha256", "units_per_em", "accuracy_note"):
            assert prov.get(key), f"missing provenance: {key}"

    def test_units_per_em_is_sane(self) -> None:
        assert limits.font_metrics().units_per_em in (1000, 2048)


class TestReferenceFileMeasurements:
    """Measurements taken against the real reference workbook."""

    def test_description_char_counts_match_the_excel_len_column(
        self, reference_sheet: object, reference_descriptions: dict[int, str]
    ) -> None:
        # The reference file's H column holds Excel's own cached LEN() results. Our
        # char_count must agree with Excel exactly, or the <160 column means nothing.
        import openpyxl

        from tests.conftest import FIXTURES, REFERENCE_SHEET

        cached = openpyxl.load_workbook(FIXTURES / "output.xlsx", data_only=True)[
            REFERENCE_SHEET
        ]
        for row, text in reference_descriptions.items():
            assert limits.char_count(text) == cached[f"H{row}"].value, f"row {row}"

    def test_title_char_counts_match_the_excel_len_column(
        self, reference_titles: dict[int, str]
    ) -> None:
        import openpyxl

        from tests.conftest import FIXTURES, REFERENCE_SHEET

        cached = openpyxl.load_workbook(FIXTURES / "output.xlsx", data_only=True)[
            REFERENCE_SHEET
        ]
        for row, text in reference_titles.items():
            assert limits.char_count(text) == cached[f"F{row}"].value, f"row {row}"

    def test_row_12_description_is_exactly_160_chars(
        self, reference_descriptions: dict[int, str]
    ) -> None:
        # The defect named in brief §11 (as M12; the column moved to H in the current
        # fixture). A stated limit of "under 160" is not satisfied by exactly 160.
        assert limits.char_count(reference_descriptions[12]) == 160

    def test_a_160_character_description_fits_the_wrapped_pixel_budget(
        self, reference_descriptions: dict[int, str]
    ) -> None:
        """The two gates have to agree about what fits, and now they do.

        This used to assert the opposite, against the brief's single-line 920px figure —
        which made a 160-character description fail on pixels even though the team's own
        guideline permits exactly 160. A pixel budget that silently overrides the stated
        character rule is a bug, not a stricter check. DECISIONS.md §28.
        """
        px, _ = limits.advance_width(
            reference_descriptions[12], DESCRIPTION_DESKTOP.font_px
        )
        assert limits.char_count(reference_descriptions[12]) == 160
        assert px <= DESCRIPTION_DESKTOP.total_px_budget

    def test_pixels_still_catch_text_that_is_wide_for_its_length(self) -> None:
        # The reason to measure width at all: same character count, very different width.
        wide, _ = limits.advance_width("W" * 160, DESCRIPTION_DESKTOP.font_px)
        narrow, _ = limits.advance_width("i" * 160, DESCRIPTION_DESKTOP.font_px)
        assert wide > DESCRIPTION_DESKTOP.total_px_budget
        assert narrow <= DESCRIPTION_DESKTOP.total_px_budget

    def test_reference_titles_all_fit_the_title_pixel_budget(
        self, reference_titles: dict[int, str]
    ) -> None:
        for row, text in reference_titles.items():
            px, _ = limits.advance_width(text, TITLE_DESKTOP.font_px)
            assert px <= TITLE_DESKTOP.total_px_budget, f"row {row}"
