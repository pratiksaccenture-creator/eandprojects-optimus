"""Cross-process export determinism — brief §11.

"Exporting, then re-downloading from history, yields a byte-identical workbook" is easy to
satisfy accidentally within one process and easy to break in ways a single-process test
cannot see. Iterating a `set` of strings varies with `PYTHONHASHSEED`, so an unsorted
collection anywhere in the export path would reorder `sharedStrings.xml` between two runs
of the server without any code changing.

These tests build the same workbook in separate interpreters under different hash seeds and
compare digests, which is the only way to catch that class of bug.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]

BUILD_SCRIPT = """
import datetime as dt, hashlib, sys
from pathlib import Path
sys.path.insert(0, %(root)r)
from app.excel.reader import read_input_workbook
from app.excel.writer import ExportKeyword, ExportPayload, ExportRow, build_workbook

created = dt.datetime(2026, 9, 17, 11, 30, 0)
parsed = read_input_workbook(Path(%(root)r) / "fixtures" / "input.xlsx")
rows = tuple(
    ExportRow(
        row_index=r.row_index,
        category_raw=r.category_raw,
        product_url=r.product_url,
        product_name=r.product_name,
        keywords_joined="apple watch, smart watch, fitness tracker",
        meta_title=r.product_name + " in the UAE",
        meta_description="Everything about " + r.product_name + " on e&.",
        date_value=r.date_value,
        date_serial=r.date_serial,
        date_number_format=r.date_number_format,
        fetch_status=r.fetch_status.value,
        fetch_note=r.fetch_note,
    )
    for r in parsed.rows
)
keywords = tuple(
    ExportKeyword(
        row_index=r.row_index, term=t, type="category", volume=v,
        source="FixtureVolumeProvider", is_live_data=False, data_date=created,
        locale="en", geo="AE", status="approved", product_url=r.product_url,
    )
    for r in parsed.rows
    for t, v in (("apple watch", 33100), ("smart watch", None), ("fitness tracker", 1300))
)
payload = ExportPayload(
    batch_no="Batch 6", source_file_name="input.xlsx", created_at=created, version=1,
    locale="en", geo="AE", provider_name="FixtureVolumeProvider", provider_is_live=False,
    model_name="fixture-deterministic", prompt_version="v1",
    brand_suffix_note="Applied to all rows.", rows=rows, keywords=keywords,
)
print(hashlib.sha256(build_workbook(payload)).hexdigest())
""" % {"root": str(ROOT)}


def _build_with_seed(seed: str) -> str:
    result = subprocess.run(
        [sys.executable, "-c", BUILD_SCRIPT],
        capture_output=True,
        text=True,
        env={"PYTHONHASHSEED": seed, "SYSTEMROOT": "C:\\Windows", "PATH": ""},
        cwd=ROOT,
        timeout=180,
    )
    if result.returncode != 0:
        pytest.fail(f"build failed under PYTHONHASHSEED={seed}:\n{result.stderr}")
    return result.stdout.strip()


@pytest.mark.slow
def test_export_is_identical_under_different_hash_seeds() -> None:
    first = _build_with_seed("1")
    second = _build_with_seed("99999")
    assert first and second
    assert first == second, (
        "export bytes changed with PYTHONHASHSEED, which means something in the export "
        "path iterates an unordered collection"
    )


@pytest.mark.slow
def test_export_is_identical_across_repeated_runs() -> None:
    assert _build_with_seed("7") == _build_with_seed("7")
