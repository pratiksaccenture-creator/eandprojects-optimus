"""Shared test fixtures.

The reference-defect tests read the real workbooks rather than hard-coded copies of their
strings, so a test can never silently pass against a stale transcription of the fixture.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterator

import openpyxl
import pytest

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"


def _credential_vars() -> tuple[str, ...]:
    """Every environment variable that could switch a provider to a live service.

    Collected from each provider's own `REQUIRED_ENV` rather than hand-listed, so adding a
    provider cannot quietly leave a hole here.
    """
    from app.providers.keywords import _dataforseo, _google_ads, _semrush
    from app.providers.llm import _anthropic, _azure, _openai

    names: set[str] = set()
    for module in (_dataforseo, _google_ads, _semrush, _anthropic, _azure, _openai):
        names.update(module.REQUIRED_ENV)
    names.update(
        {
            # Secondary credentials and tuning knobs that are not in REQUIRED_ENV.
            "ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_MODEL", "OPENAI_MODEL", "OPENAI_BASE_URL",
            "DATAFORSEO_LOCATION_CODE", "DATAFORSEO_LANGUAGE_CODE", "SEMRUSH_DATABASE",
            # Explicit selection beats detection, so these matter just as much.
            "KEYWORD_PROVIDER", "LLM_PROVIDER", "PAGE_PROVIDER", "SEED_DEMO_BATCH",
        }
    )
    return tuple(sorted(names))


@pytest.fixture(autouse=True)
def isolate_credentials(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    """Hide real credentials from every test.

    `app.config` loads `.env` on import, which is right for the application and wrong for
    the suite: once a developer adds live keys, tests that resolve a provider by detection
    would start calling paid APIs. The suite must cost nothing and must not depend on who
    is running it, so every credential is removed and each test starts from "nothing
    configured" — the same state brief §11 requires the app itself to run in.

    A test that wants a live code path sets the variables it needs itself, and stubs the
    transport. Nothing in `tests/` should ever open a socket to a vendor.

    Fixture mode is now requested EXPLICITLY. It used to be what the absence of
    credentials resolved to, so stripping the environment was enough; since seeded
    volumes stopped being reachable by accident (DECISIONS.md §29), a suite that strips
    the environment gets an unconfigured tool that refuses. Asking for fixtures by name
    is also the more honest arrangement: the tests say which providers they want instead
    of relying on a default.
    """
    import app.config

    for name in _credential_vars():
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setenv("KEYWORD_PROVIDER", "fixture")
    monkeypatch.setenv("LLM_PROVIDER", "fixture")
    app.config.settings.cache_clear()
    yield
    app.config.settings.cache_clear()

REFERENCE_SHEET = "SEO Batch 6 Product List"
KEYWORDS_SHEET = "keywords "  # trailing space is real

# Rows 10-14 are the only rows in the reference output that carry generated copy.
GENERATED_ROWS = range(10, 15)


@pytest.fixture(scope="session")
def input_path() -> Path:
    return FIXTURES / "input.xlsx"


@pytest.fixture(scope="session")
def output_path() -> Path:
    return FIXTURES / "output.xlsx"


@pytest.fixture(scope="session")
def reference_wb(output_path: Path) -> Any:
    return openpyxl.load_workbook(output_path)


@pytest.fixture(scope="session")
def reference_sheet(reference_wb: Any) -> Any:
    return reference_wb[REFERENCE_SHEET]


@pytest.fixture(scope="session")
def reference_titles(reference_sheet: Any) -> dict[int, str]:
    return {r: reference_sheet[f"E{r}"].value for r in GENERATED_ROWS}


@pytest.fixture(scope="session")
def reference_descriptions(reference_sheet: Any) -> dict[int, str]:
    return {r: reference_sheet[f"G{r}"].value for r in GENERATED_ROWS}


@pytest.fixture(scope="session")
def reference_keyword_cells(reference_sheet: Any) -> dict[int, str]:
    return {r: reference_sheet[f"D{r}"].value for r in GENERATED_ROWS}


@pytest.fixture(scope="session")
def reference_product_names(reference_sheet: Any) -> dict[int, str]:
    """Column C in the reference file — the defect. It holds product names on rows 10-14
    where it should hold the URL."""
    return {r: reference_sheet[f"C{r}"].value for r in GENERATED_ROWS}
