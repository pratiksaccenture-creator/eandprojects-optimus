"""Reuse of search volumes already paid for.

DataForSEO bills per request and the tool repeats itself: every batch with a Samsung phone
asks for "samsung", every projector row asks for "projector". Across the batches run during
testing the same terms were bought several times over.

What makes it safe is that the figure is a twelve-month average which Google updates
monthly — a reading taken on the 1st and one taken on the 20th are the same number. So the
TTL is the honest part of this: a cache with no expiry would serve a figure nobody could
date, which is the same class of problem as inventing one.
"""

from __future__ import annotations

import datetime as dt
from pathlib import Path
from typing import Iterator

import pytest

from app.providers.keywords import VolumeResult


@pytest.fixture()
def db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_path / 'cache.db'}")
    monkeypatch.setenv("VOLUME_MAX_VINTAGE_DAYS", "120")
    monkeypatch.setenv("VOLUME_RECHECK_DAYS", "14")

    import app.config
    import app.db

    app.config.settings.cache_clear()
    app.db._engine = None
    app.db._session_factory = None
    app.db.create_all()
    yield
    app.config.settings.cache_clear()
    app.db._engine = None
    app.db._session_factory = None


def _result(term: str, volume: int | None) -> VolumeResult:
    """A figure with a CURRENT data window.

    The window matters now: expiry is measured on the age of the data rather than on when
    we fetched it, so a fixture with a hard-coded date would start failing the day it aged
    past the threshold. Covered in detail in `test_volume_vintage.py`.
    """
    from app.models import utcnow

    return VolumeResult(
        term=term,
        volume=volume,
        cpc=1.5,
        competition="LOW",
        source="DataForSEOProvider",
        data_date=utcnow() - dt.timedelta(days=20),
        months_covered=12,
    )


class TestReuse:
    def test_a_stored_figure_is_served_without_a_provider_call(self, db: None) -> None:
        from app.db import session_scope
        from app.services import volume_cache

        with session_scope() as session:
            volume_cache.remember(
                session, [_result("samsung", 110_000)], geo="AE", locale="en"
            )

        held = volume_cache.read(["samsung"], geo="AE", locale="en")
        assert held["samsung"].volume == 110_000
        assert held["samsung"].source == "DataForSEOProvider", (
            "a cached figure keeps its provenance; it must be as auditable as a live one"
        )

    def test_a_measured_absence_is_remembered_too(self, db: None) -> None:
        """"We asked and Google had no data" is worth caching: asking again costs the
        same as asking the first time, and the answer is the same."""
        from app.db import session_scope
        from app.services import volume_cache

        with session_scope() as session:
            volume_cache.remember(
                session, [_result("nobody searches this", None)], geo="AE", locale="en"
            )

        held = volume_cache.read(["nobody searches this"], geo="AE", locale="en")
        assert "nobody searches this" in held
        assert held["nobody searches this"].volume is None

    def test_the_key_includes_the_market(self, db: None) -> None:
        # The same term has different demand in different markets, so a figure bought for
        # the UAE must not be served for Saudi Arabia.
        from app.db import session_scope
        from app.services import volume_cache

        with session_scope() as session:
            volume_cache.remember(session, [_result("iphone", 135_000)], geo="AE", locale="en")

        assert volume_cache.read(["iphone"], geo="AE", locale="en")
        assert not volume_cache.read(["iphone"], geo="SA", locale="en")

    def test_a_term_is_matched_on_its_normalised_form(self, db: None) -> None:
        from app.db import session_scope
        from app.services import volume_cache

        with session_scope() as session:
            volume_cache.remember(session, [_result("Apple  Watch ", 33_100)], geo="AE", locale="en")

        assert volume_cache.read(["apple watch"], geo="AE", locale="en")


class TestExpiry:
    """Expiry is measured on the age of the DATA, not on when we asked for it.

    The two are unrelated, which is the whole correction: a figure fetched yesterday can
    already describe a window that closed months ago. The vintage rules live in
    `test_volume_vintage.py`; what remains here is the behaviour of the fetch clock, which
    is now only a cost guard.
    """

    def test_an_old_fetch_alone_does_not_expire_a_current_figure(self, db: None) -> None:
        """This test used to assert the opposite, and the opposite was the bug.

        Ageing `fetched_at` to 45 days once removed the entry. But the figure's window is
        current, so it is still the right number — and re-buying it would have changed
        nothing except the bill.
        """
        from app.db import session_scope
        from app.models import VolumeCache, utcnow
        from app.services import volume_cache

        with session_scope() as session:
            volume_cache.remember(session, [_result("projector", 8_100)], geo="AE", locale="en")

        with session_scope() as session:
            entry = session.query(VolumeCache).one()
            entry.fetched_at = utcnow() - dt.timedelta(days=45)

        assert volume_cache.read(["projector"], geo="AE", locale="en")

    def test_a_read_does_not_move_the_fetch_clock(self, db: None) -> None:
        """The re-check guard reads it, so a read that renewed it would mean the guard
        never lapses and a genuinely stale window is never refreshed."""
        from app.db import session_scope
        from app.models import VolumeCache, utcnow
        from app.services import volume_cache

        with session_scope() as session:
            volume_cache.remember(session, [_result("projector", 8_100)], geo="AE", locale="en")
        with session_scope() as session:
            aged = utcnow() - dt.timedelta(days=20)
            session.query(VolumeCache).one().fetched_at = aged

        volume_cache.read(["projector"], geo="AE", locale="en")

        with session_scope() as session:
            entry = session.query(VolumeCache).one()
            assert (utcnow() - entry.fetched_at).days >= 19

    def test_a_refresh_from_the_network_does_move_it(self, db: None) -> None:
        from app.db import session_scope
        from app.models import VolumeCache, utcnow
        from app.services import volume_cache

        with session_scope() as session:
            volume_cache.remember(session, [_result("projector", 8_100)], geo="AE", locale="en")
        with session_scope() as session:
            session.query(VolumeCache).one().fetched_at = utcnow() - dt.timedelta(days=40)
        with session_scope() as session:
            volume_cache.remember(session, [_result("projector", 9_900)], geo="AE", locale="en")

        held = volume_cache.read(["projector"], geo="AE", locale="en")
        assert held["projector"].volume == 9_900


class TestItCanBeTurnedOff:
    def test_zero_days_is_a_real_bypass(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_path / 'off.db'}")
        monkeypatch.setenv("VOLUME_MAX_VINTAGE_DAYS", "0")

        import app.config
        import app.db

        app.config.settings.cache_clear()
        app.db._engine = None
        app.db._session_factory = None
        app.db.create_all()

        from app.db import session_scope
        from app.services import volume_cache

        with session_scope() as session:
            written = volume_cache.remember(
                session, [_result("samsung", 110_000)], geo="AE", locale="en"
            )
        assert written == 0, "nothing should be stored when the cache is off"
        assert not volume_cache.read(["samsung"], geo="AE", locale="en")

        app.config.settings.cache_clear()
        app.db._engine = None
        app.db._session_factory = None


class TestItIsWiredIn:
    def test_research_consults_the_cache_before_paying(self) -> None:
        import inspect

        from app.services import keyword_service

        source = inspect.getsource(keyword_service.research_row_keywords)
        assert "volume_cache.read(" in source
        # And only buys what the cache did not have.
        assert "to_buy" in source

    def test_adding_and_editing_a_term_also_consult_it(self) -> None:
        import inspect

        from app.services import keyword_service

        for function in (keyword_service.add_manual_term, keyword_service.edit_keyword_term):
            assert "_measure_one(" in inspect.getsource(function), function.__name__

    def test_the_expansion_itself_is_not_cached(self) -> None:
        """Only the figure for a specific term is reused. `expand()` answers "what else do
        people type", and that answer set moves as search behaviour does — caching it
        would freeze a row's long tail to whenever the seed was first researched."""
        import inspect

        from app.services import volume_cache

        source = inspect.getsource(volume_cache)
        assert "expand" not in source.split('"""', 2)[2], (
            "the cache must not store expansion results, only per-term figures"
        )

    def test_the_cache_is_held_to_the_provider_boundary_rule(self) -> None:
        # It writes `volume=`, so `tests/test_no_llm_volumes.py` requires it to import the
        # sanctioned source. A cache is a place a wrong figure could enter.
        import ast
        import pathlib

        tree = ast.parse(
            pathlib.Path("app/services/volume_cache.py").read_text(encoding="utf-8")
        )
        imports = {
            node.module
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module
        }
        assert any(m.startswith("app.providers.keywords") for m in imports)
