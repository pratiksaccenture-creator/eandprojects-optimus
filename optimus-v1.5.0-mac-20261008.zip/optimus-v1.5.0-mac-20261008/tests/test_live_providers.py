"""The live providers: DataForSEO and Semrush volumes, HTTP page fetching, OpenAI and
Claude copy.

Every test here runs offline. Nothing calls a real API — the parsing, prompt construction
and response mapping are pure functions, and the end-to-end paths run through stubbed
transports. A test suite that needed credentials, or that cost money to run, would stop
being run.
"""

from __future__ import annotations

from typing import Any

import anyio
import pytest

from app.providers.keywords import NotConfiguredError, get_keyword_provider
from app.providers.keywords._semrush import (
    EXPORT_COLUMNS,
    MAX_PHRASES_PER_REQUEST,
    REPORT_TYPE,
    SemrushVolumeProvider,
    build_params,
    chunk,
    database_for,
    missing_env,
    parse_response,
    units_for,
)
from app.providers.llm import CopyRequest, IdeationRequest, ModelNotConfiguredError, PageFacts
from app.providers.llm._anthropic import DEFAULT_MODEL, ClaudeProvider, model_name
from app.providers.llm._prompts import (
    CopySchema,
    build_copy_prompt,
    build_ideation_prompt,
    facts_block,
)
from app.providers.pages import get_page_provider
from app.providers.pages._http import HttpPageProvider, extract_text
from app.providers.pages._none import NoFetchProvider

# A realistic `phrase_these` response: `;`-delimited, header line first.
SEMRUSH_BODY = (
    "Keyword;Search Volume;CPC;Competition;Number of Results;"
    "Keyword Difficulty Index;Intent\r\n"
    "apple watch;33100;1.25;0.08;1250000000;78;0\r\n"
    "iphone 18 pro;3600;2.10;0.15;890000000;65;1\r\n"
    "airpods;27100;0.95;0.11;450000000;71;0\r\n"
)


# ---------------------------------------------------------------- Semrush


class TestSemrushRequest:
    def test_targets_the_uae_database(self) -> None:
        assert database_for("AE") == "ae"
        assert database_for("uae") == "ae"

    def test_unmapped_geo_is_refused_rather_than_guessed(self) -> None:
        with pytest.raises(NotConfiguredError):
            database_for("ZZ")

    def test_request_uses_the_batch_endpoint_and_semicolon_separator(self) -> None:
        params = build_params(["apple watch", "airpods"], api_key="k", database="ae")
        assert params["type"] == REPORT_TYPE
        assert params["phrase"] == "apple watch;airpods"
        assert params["database"] == "ae"
        assert params["export_columns"] == EXPORT_COLUMNS

    def test_a_batch_over_the_limit_is_refused(self) -> None:
        # Semrush caps this at 100; silently truncating would lose terms.
        with pytest.raises(ValueError):
            build_params(["x"] * (MAX_PHRASES_PER_REQUEST + 1), api_key="k", database="ae")

    def test_chunking_respects_the_hundred_phrase_cap(self) -> None:
        batches = chunk([f"term {i}" for i in range(250)])
        assert [len(b) for b in batches] == [100, 100, 50]

    def test_unit_cost_is_ten_per_term(self) -> None:
        assert units_for(250) == 2500


class TestSemrushParsing:
    def test_reads_volumes_for_every_returned_row(self) -> None:
        rows = parse_response(SEMRUSH_BODY)
        assert rows["apple watch"].search_volume == 33100
        assert rows["iphone 18 pro"].search_volume == 3600
        assert rows["airpods"].search_volume == 27100

    def test_reads_the_supporting_columns(self) -> None:
        row = parse_response(SEMRUSH_BODY)["apple watch"]
        assert row.cpc == pytest.approx(1.25)
        assert row.competition == "0.08"
        assert row.difficulty == "78"

    def test_an_error_response_raises_rather_than_looking_like_no_data(self) -> None:
        # Silently returning nothing would turn an auth or billing failure into missing
        # volumes, which is indistinguishable from "nobody searches for this".
        with pytest.raises(NotConfiguredError):
            parse_response("ERROR 50 :: NOTHING FOUND")
        with pytest.raises(NotConfiguredError):
            parse_response("ERROR 120 :: WRONG KEY")

    def test_an_empty_body_is_no_rows_not_an_error(self) -> None:
        assert parse_response("") == {}
        assert parse_response("   \n") == {}

    def test_a_blank_volume_yields_none_not_zero(self) -> None:
        body = "Keyword;Search Volume;CPC\r\nsome term;;0.00\r\n"
        assert parse_response(body)["some term"].search_volume is None

    def test_rows_are_keyed_on_the_normalised_term(self) -> None:
        body = "Keyword;Search Volume\r\n  Apple   WATCH ;33100\r\n"
        assert parse_response(body)["apple watch"].search_volume == 33100


class TestSemrushLookup:
    def test_unconfigured_raises_and_does_not_fall_back(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("SEMRUSH_API_KEY", raising=False)
        assert missing_env() == ("SEMRUSH_API_KEY",)

        async def go() -> None:
            with pytest.raises(NotConfiguredError) as excinfo:
                await SemrushVolumeProvider().lookup(["apple watch"], geo="AE", locale="en")
            assert "not configured" in str(excinfo.value).lower()

        anyio.run(go)

    def test_declares_itself_live(self) -> None:
        provider = SemrushVolumeProvider()
        assert provider.is_live_data is True
        assert provider.name == "Semrush"

    def test_resolves_from_the_provider_factory(self) -> None:
        assert isinstance(get_keyword_provider("semrush"), SemrushVolumeProvider)

    def test_a_term_semrush_omits_comes_back_unverified(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The headline guarantee: no data means None, never a substituted figure."""
        monkeypatch.setenv("SEMRUSH_API_KEY", "test-key")
        monkeypatch.setenv("SEMRUSH_DATABASE", "ae")
        _stub_httpx(monkeypatch, SEMRUSH_BODY)

        async def go() -> None:
            results = await SemrushVolumeProvider().lookup(
                ["apple watch", "a term nobody searches"], geo="AE", locale="en"
            )
            by_term = {r.term: r for r in results}
            assert by_term["apple watch"].volume == 33100
            assert by_term["apple watch"].source.startswith("Semrush")

            missing = by_term["a term nobody searches"]
            assert missing.volume is None
            assert not missing.is_verified
            # No date either — a date would imply a measurement that never happened.
            assert missing.data_date is None

        anyio.run(go)

    def test_returns_one_result_per_requested_term_in_order(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("SEMRUSH_API_KEY", "test-key")
        _stub_httpx(monkeypatch, SEMRUSH_BODY)
        asked = ["airpods", "apple watch", "unknown one"]

        async def go() -> None:
            results = await SemrushVolumeProvider().lookup(asked, geo="AE", locale="en")
            assert [r.term for r in results] == asked

        anyio.run(go)


def _stub_httpx(monkeypatch: pytest.MonkeyPatch, body: str) -> None:
    """Replace httpx.AsyncClient with a stub returning `body`. No network."""

    class StubResponse:
        text = body

        def raise_for_status(self) -> None:
            return None

    class StubClient:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        async def __aenter__(self) -> "StubClient":
            return self

        async def __aexit__(self, *args: Any) -> None:
            return None

        async def get(self, *args: Any, **kwargs: Any) -> StubResponse:
            return StubResponse()

    import app.providers.keywords._semrush as module

    monkeypatch.setattr(module.httpx, "AsyncClient", StubClient)


# ---------------------------------------------------------------- pages


class TestTextExtraction:
    def test_pulls_the_title_and_body_text(self) -> None:
        title, text = extract_text(
            "<html><head><title> Apple Watch Ultra 4 </title></head>"
            "<body><main><h1>Apple Watch Ultra 4</h1>"
            "<p>45 hour battery.</p></main></body></html>"
        )
        assert title == "Apple Watch Ultra 4"
        assert "45 hour battery." in text

    def test_drops_scripts_navigation_and_footers(self) -> None:
        _, text = extract_text(
            "<html><body>"
            "<nav>Home Shop Support</nav>"
            "<script>var price = 225;</script>"
            "<style>.a{color:red}</style>"
            "<main><p>Real content here.</p></main>"
            "<footer>Terms and conditions</footer>"
            "</body></html>"
        )
        assert "Real content here." in text
        assert "Home Shop Support" not in text
        assert "225" not in text
        assert "Terms and conditions" not in text

    def test_malformed_html_does_not_raise(self) -> None:
        title, text = extract_text("<html><body><p>unclosed")
        assert title == ""
        assert "unclosed" in text

    def test_empty_document(self) -> None:
        assert extract_text("") == ("", "")

    def test_reads_head_metadata_because_product_pages_render_client_side(self) -> None:
        """The eshop pages carry ~1,000 characters of DOM text and put the specifications
        only in the existing meta description. Without reading the head, a product row
        cannot be grounded at all."""
        _, text = extract_text(
            '<html><head><title>Apple iPhone 18 Pro</title>'
            '<meta name="description" content="6.3-inch display, 48MP camera &amp; A20 Pro chip.">'
            '<meta name="keywords" content="iphone 18 pro, apple iphone">'
            '<meta property="og:title" content="Apple iPhone 18 Pro">'
            "</head><body><div>Cart</div></body></html>"
        )
        assert "PAGE METADATA" in text
        assert "6.3-inch display" in text
        assert "48MP camera" in text
        assert "og:title: Apple iPhone 18 Pro" in text

    def test_metadata_is_labelled_as_the_pages_current_copy(self) -> None:
        # The label matters: the facts come from copy that is itself being replaced, so the
        # extractor has to know to keep the specs and drop the commercial language.
        _, text = extract_text(
            '<html><head><meta name="description" content="A chip and AED 225/month.">'
            "</head><body><p>x</p></body></html>"
        )
        assert "the page's current copy" in text

    def test_headings_are_captured(self) -> None:
        _, text = extract_text(
            "<html><body><h1>Smart Locks</h1><h2>What they do</h2></body></html>"
        )
        assert "heading: Smart Locks" in text

    def test_body_text_is_kept_separate_from_metadata(self) -> None:
        _, text = extract_text(
            '<html><head><meta name="description" content="Meta line."></head>'
            "<body><main><p>Body line.</p></main></body></html>"
        )
        assert text.index("PAGE METADATA") < text.index("PAGE TEXT")
        assert "Meta line." in text and "Body line." in text


class TestFactExtractionPrompt:
    def test_extractor_is_told_to_keep_specs_but_drop_commercial_language(self) -> None:
        """Two layers stand between the old defective copy and the new copy: this
        instruction, and the banned-terms validator. This asserts the first."""
        from app.providers.llm._anthropic import FACTS_SYSTEM

        lowered = FACTS_SYSTEM.lower()
        assert "page metadata" in lowered
        assert "discard everything commercial" in lowered
        for banned in ("price", "instalment", "pre-order", "out of stock", "superlative"):
            assert banned in lowered, banned
        assert "screen size" in lowered  # the facts it should keep

    def test_a_price_in_the_source_still_cannot_reach_indexed_copy(self) -> None:
        # The second layer, independent of the model: even if extraction leaked the price
        # from the page's own meta description, the validator blocks it.
        from app.lib.validators import FieldContext, has_errors, no_banned_terms

        findings = no_banned_terms(
            "Own the latest Apple iPhone 18 Pro with 6.3-inch display. "
            "Pre-order via SmartPay starting AED 225/month on e&.",
            FieldContext(field="meta_description_en", row_index=10),
        )
        assert has_errors(findings)


class TestNoFetchProvider:
    def test_never_claims_a_successful_fetch(self) -> None:
        async def go() -> None:
            provider = NoFetchProvider()
            assert provider.fetches is False
            for url in (
                "https://www.eand.ae/en/c/home/smart-locks.html",
                "https://www.eand.ae/eshop/devices/configuration/k?productId=p",
            ):
                result = await provider.fetch(url)
                assert result.status == "not_attempted"
                assert not result.has_content

        anyio.run(go)

    def test_preprod_host_is_unreachable_on_the_hostname_alone(self) -> None:
        async def go() -> None:
            result = await NoFetchProvider().fetch(
                "https://preprodnew.eand.ae/en/c/x/y.html"
            )
            assert result.status == "unreachable"
            assert result.note and "preprodnew.eand.ae" in result.note

        anyio.run(go)

    def test_is_the_default_provider(self) -> None:
        assert isinstance(get_page_provider(), NoFetchProvider)

    def test_http_provider_resolves_and_declares_itself_fetching(self) -> None:
        provider = get_page_provider("http")
        assert isinstance(provider, HttpPageProvider)
        assert provider.fetches is True

    def test_unknown_provider_is_refused(self) -> None:
        with pytest.raises(ValueError):
            get_page_provider("made_up")

    def test_empty_url_is_blocked_not_crashed(self) -> None:
        async def go() -> None:
            assert (await NoFetchProvider().fetch("")).status == "blocked"

        anyio.run(go)


# ---------------------------------------------------------------- Claude


def _copy_request(**kw: Any) -> CopyRequest:
    base: dict[str, Any] = {
        "row_index": 10,
        "product_name": "Apple Watch Ultra 4",
        "category_raw": "Apple WATCH ULTRA 4",
        "product_url": "https://www.eand.ae/eshop/x",
        "page_type": "product",
        "primary_keyword": "apple watch",
    }
    base.update(kw)
    return CopyRequest(**base)


class TestClaudeConfiguration:
    def test_default_model_is_opus_five(self) -> None:
        assert DEFAULT_MODEL == "claude-opus-5"

    def test_model_is_overridable(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("ANTHROPIC_MODEL", "claude-sonnet-5")
        assert model_name() == "claude-sonnet-5"

    def test_declares_itself_a_live_model(self) -> None:
        assert ClaudeProvider().is_live_model is True


class TestClaudePrompts:
    def test_system_prompt_forbids_stock_and_invented_specs(self) -> None:
        from app.providers.llm._anthropic import COPY_SYSTEM

        lowered = COPY_SYSTEM.lower()
        assert "stock" in lowered
        assert "never invent a specification" in lowered

    def test_the_model_may_never_produce_a_price_of_its_own(self) -> None:
        """The guidelines require a price; the prompt still forbids the model inventing one.

        Both statements have to be in there at once, which is the delicate part: the
        instruction is "use the figure you were handed, and never any other". A prompt that
        only said "include the price" would invite a recalled or plausible one.
        """
        from app.providers.llm._anthropic import COPY_SYSTEM

        lowered = COPY_SYSTEM.lower()
        assert "never produce a price" in lowered
        assert "you do not know what anything costs" in lowered
        assert "only if" in lowered  # the figure is conditional on being supplied

    def test_ideation_prompt_forbids_the_model_producing_figures(self) -> None:
        from app.providers.llm._anthropic import IDEATION_SYSTEM

        assert "never figures" in IDEATION_SYSTEM.lower()

    def test_facts_block_says_so_plainly_when_there_are_none(self) -> None:
        block = facts_block(None)
        assert "none available" in block
        assert "do not state any specification" in block

    def test_facts_block_lists_only_what_the_page_said(self) -> None:
        facts = PageFacts(
            summary="Smart watch page.",
            specifications=("45 hour battery", "49mm case"),
            features=("water resistant",),
            source_url="https://www.eand.ae/x",
            grounded=True,
        )
        block = facts_block(facts)
        assert "45 hour battery" in block
        assert "water resistant" in block
        assert "https://www.eand.ae/x" in block

    def test_copy_prompt_carries_the_primary_keyword_and_limits(self) -> None:
        prompt = build_copy_prompt(_copy_request())
        assert "apple watch" in prompt
        # "or fewer", not "under" — the guidelines' wording, and the validator agrees.
        assert "60 characters or fewer" in prompt
        assert "160 or fewer" in prompt

    def test_the_copy_prompt_asks_for_substance_rather_than_length(self) -> None:
        """The guide is a target for CONTENT, not a quota to fill.

        It read "aim for 120-155" with nothing said about what should be in those
        characters, and `CHAR_SHORT` warned below it — so the model was pressed for length
        on copy that was already compliant, and filler is what length pressure buys.
        DECISIONS.md §35.
        """
        prompt = build_copy_prompt(_copy_request())
        assert "120-155" in prompt
        assert "not" in prompt and "place" in prompt
        assert "would fit any product" in prompt

    def test_a_row_with_no_price_is_told_the_price_is_unknown(self) -> None:
        prompt = build_copy_prompt(_copy_request())
        assert "PRICE: none supplied" in prompt
        assert "unknown to you" in prompt
        assert "SmartPay" in prompt

    def test_a_supplied_price_is_passed_through_exactly(self) -> None:
        prompt = build_copy_prompt(_copy_request(price="3,499"))
        assert "PRICE: 3,499" in prompt
        assert "AED 3,499" in prompt
        assert "Do not round it" in prompt

    def test_an_over_long_product_name_is_flagged_for_the_title(self) -> None:
        # 75 characters against a 60-character title: the model has to be told to drop
        # attributes rather than truncate mid-name.
        prompt = build_copy_prompt(
            _copy_request(
                product_name=(
                    "Apple Watch Series 12 GPS + Cellular Ceramic | Pearl White "
                    "| Case Size 42MM"
                )
            )
        )
        assert "longer than a meta title allows" in prompt
        assert "colour, case size and storage" in prompt

    def test_copy_prompt_passes_validator_failures_back(self) -> None:
        prompt = build_copy_prompt(
            _copy_request(attempt=2, feedback=("CHAR_LIMIT", "BANNED_CURRENCY"))
        )
        assert "CHAR_LIMIT" in prompt
        assert "BANNED_CURRENCY" in prompt
        assert "Attempt 2" in prompt

    def test_a_refresh_asks_for_a_different_angle_not_a_shorter_one(self) -> None:
        prompt = build_copy_prompt(_copy_request(variant=2))
        assert "genuinely" in prompt and "different angle" in prompt
        assert "not the same sentence shortened" in prompt

    def test_compression_keeps_the_generation_number(self) -> None:
        prompt = build_copy_prompt(_copy_request(shrink=2))
        assert "keep the product name complete including any generation number" in prompt

    def test_ideation_prompt_names_the_market(self) -> None:
        prompt = build_ideation_prompt(
            IdeationRequest(
                row_index=1,
                product_name="AirPods 5",
                category_raw="Airpods 5",
                product_url="https://www.eand.ae/x",
                page_type="product",
                geo="AE",
            )
        )
        assert "AirPods 5" in prompt
        assert "AE" in prompt


class TestClaudeResponseMapping:
    """The model is stubbed; what is under test is how its reply becomes a CopyDraft."""

    def test_maps_a_reply_onto_the_draft(self, monkeypatch: pytest.MonkeyPatch) -> None:
        reply = CopySchema(
            meta_title="Apple Watch Ultra 4 | Health tracking",
            meta_description="Explore the Apple Watch Ultra 4 at e&. Built-in GPS and 45 hour battery.",
            h1="Apple Watch Ultra 4",
            answer_block="  The Apple Watch Ultra 4   is available from e&.  ",
            benefits=["GPS built in", "45 hour battery", "Water resistant", "Extra one"],
            faqs=[["What is it?", "A smart watch."], ["Where?", "From e&."], ["bad pair"]],
            app_headline="Track everything",
            app_subhead="Health and fitness on your wrist",
            app_cta="See models",
            geo_prompts=["What is the Apple Watch Ultra 4?", "Where can I buy it in the UAE?"],
        )

        async def fake_parse(self: Any, **kwargs: Any) -> Any:
            return reply

        monkeypatch.setattr(ClaudeProvider, "_parse", fake_parse)

        async def go() -> None:
            result = await ClaudeProvider().generate(_copy_request())
            draft = result.draft
            assert draft.meta_title == "Apple Watch Ultra 4 | Health tracking"
            # Whitespace in the answer block is collapsed.
            assert draft.answer_block == "The Apple Watch Ultra 4 is available from e&."
            # Exactly three benefits, even though four came back.
            assert len(draft.benefits) == 3
            # The malformed FAQ pair is dropped rather than half-stored.
            assert len(draft.faqs) == 2
            assert result.is_live_model is True
            assert result.model == model_name()

        anyio.run(go)

    def test_faq_jsonld_is_parseable(self, monkeypatch: pytest.MonkeyPatch) -> None:
        import json

        reply = CopySchema(
            meta_title="t", meta_description="d", h1="h", answer_block="a",
            benefits=["a", "b", "c"],
            faqs=[["Q1", "A1"], ["Q2", "A2"], ["Q3", "A3"]],
            app_headline="x", app_subhead="y", app_cta="z",
            geo_prompts=["p"],
        )

        async def fake_parse(self: Any, **kwargs: Any) -> Any:
            return reply

        monkeypatch.setattr(ClaudeProvider, "_parse", fake_parse)

        async def go() -> None:
            result = await ClaudeProvider().generate(_copy_request())
            payload = json.loads(result.draft.jsonld)
            assert payload["@type"] == "FAQPage"
            assert len(payload["mainEntity"]) == 3

        anyio.run(go)

    def test_extract_facts_short_circuits_on_empty_page_text(self) -> None:
        async def go() -> None:
            facts = await ClaudeProvider().extract_facts(
                product_name="X", url="https://x", page_title="", page_text="   "
            )
            assert not facts.grounded
            assert facts.is_empty

        anyio.run(go)


# ---------------------------------------------------------------- DataForSEO

DFS_OK = {
    "status_code": 20000,
    "status_message": "Ok.",
    "cost": 0.0075,
    "tasks": [
        {
            "status_code": 20000,
            "result": [
                {
                    "keyword": "apple watch",
                    "search_volume": 33100,
                    "cpc": 1.25,
                    "competition": "LOW",
                    "competition_index": 8,
                },
                {
                    "keyword": "iphone 18 pro",
                    "search_volume": 3600,
                    "cpc": 2.1,
                    "competition": "MEDIUM",
                    "competition_index": 42,
                },
                # Google has no data for this one. `null`, not zero.
                {
                    "keyword": "a term nobody searches",
                    "search_volume": None,
                    "cpc": None,
                    "competition": None,
                    "competition_index": None,
                },
            ],
        }
    ],
}


class TestDataForSeoRequest:
    def test_uae_location_code(self) -> None:
        from app.providers.keywords._dataforseo import location_code_for

        assert location_code_for("AE") == 2784
        assert location_code_for("uae") == 2784

    def test_location_code_is_overridable(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from app.providers.keywords._dataforseo import location_code_for

        monkeypatch.setenv("DATAFORSEO_LOCATION_CODE", "2840")
        assert location_code_for("AE") == 2840

    def test_unmapped_geo_is_refused_rather_than_guessed(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.providers.keywords._dataforseo import location_code_for

        monkeypatch.delenv("DATAFORSEO_LOCATION_CODE", raising=False)
        with pytest.raises(NotConfiguredError):
            location_code_for("ZZ")

    def test_arabic_locale_selects_arabic(self) -> None:
        from app.providers.keywords._dataforseo import language_code_for

        assert language_code_for("ar") == "ar"
        assert language_code_for("en") == "en"

    def test_task_shape(self) -> None:
        from app.providers.keywords._dataforseo import build_task

        task = build_task(["apple watch"], location_code=2784, language_code="en")
        assert task["keywords"] == ["apple watch"]
        assert task["location_code"] == 2784
        assert task["search_partners"] is False

    def test_over_long_phrases_are_filtered_not_sent(self) -> None:
        """One rejected phrase fails the whole task, which would turn a single bad
        candidate into a batch with no volumes at all."""
        from app.providers.keywords._dataforseo import acceptable

        assert acceptable("apple watch ultra 4")
        assert not acceptable("x" * 81)
        assert not acceptable(" ".join(["word"] * 11))
        assert not acceptable("")

    def test_chunking(self) -> None:
        from app.providers.keywords._dataforseo import MAX_KEYWORDS_PER_TASK, chunk

        batches = chunk([f"t{i}" for i in range(1500)])
        assert [len(b) for b in batches] == [MAX_KEYWORDS_PER_TASK, MAX_KEYWORDS_PER_TASK, 100]
        assert sum(len(b) for b in batches) == 1500


class TestDataForSeoParsing:
    def test_reads_volumes(self) -> None:
        from app.providers.keywords._dataforseo import parse_response

        rows = parse_response(DFS_OK)
        assert rows["apple watch"].search_volume == 33100
        assert rows["apple watch"].competition == "LOW"
        assert rows["iphone 18 pro"].cpc == pytest.approx(2.1)

    def test_a_null_volume_stays_none(self) -> None:
        from app.providers.keywords._dataforseo import parse_response

        assert parse_response(DFS_OK)["a term nobody searches"].search_volume is None

    def test_a_failed_request_raises(self) -> None:
        # Returning no rows would make an auth or quota failure look like "no search data".
        from app.providers.keywords._dataforseo import parse_response

        with pytest.raises(NotConfiguredError):
            parse_response({"status_code": 40101, "status_message": "Auth error."})

    def test_a_failed_task_raises_even_when_the_request_succeeded(self) -> None:
        from app.providers.keywords._dataforseo import parse_response

        with pytest.raises(NotConfiguredError):
            parse_response(
                {
                    "status_code": 20000,
                    "tasks": [{"status_code": 40501, "status_message": "Invalid field."}],
                }
            )

    def test_cost_is_reported_from_the_response(self) -> None:
        from app.providers.keywords._dataforseo import cost_of

        assert cost_of(DFS_OK) == pytest.approx(0.0075)
        assert cost_of({}) == 0.0


class TestDataForSeoLookup:
    def test_unconfigured_raises_and_names_what_is_missing(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.providers.keywords._dataforseo import DataForSeoProvider

        monkeypatch.delenv("DATAFORSEO_LOGIN", raising=False)
        monkeypatch.delenv("DATAFORSEO_PASSWORD", raising=False)

        async def go() -> None:
            with pytest.raises(NotConfiguredError) as excinfo:
                await DataForSeoProvider().lookup(["apple watch"], geo="AE", locale="en")
            message = str(excinfo.value)
            assert "DATAFORSEO_LOGIN" in message
            assert "DATAFORSEO_PASSWORD" in message

        anyio.run(go)

    def test_half_configured_still_raises_rather_than_falling_back(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.providers.keywords._dataforseo import DataForSeoProvider

        monkeypatch.setenv("DATAFORSEO_LOGIN", "you@example.com")
        monkeypatch.delenv("DATAFORSEO_PASSWORD", raising=False)

        async def go() -> None:
            with pytest.raises(NotConfiguredError) as excinfo:
                await DataForSeoProvider().lookup(["apple watch"], geo="AE", locale="en")
            assert "DATAFORSEO_PASSWORD" in str(excinfo.value)

        anyio.run(go)

    def test_an_unknown_term_comes_back_unverified(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.providers.keywords._dataforseo import DataForSeoProvider

        monkeypatch.setenv("DATAFORSEO_LOGIN", "you@example.com")
        monkeypatch.setenv("DATAFORSEO_PASSWORD", "secret")
        _stub_dfs(monkeypatch, DFS_OK)

        async def go() -> None:
            results = await DataForSeoProvider().lookup(
                ["apple watch", "a term nobody searches"], geo="AE", locale="en"
            )
            by_term = {r.term: r for r in results}
            assert by_term["apple watch"].volume == 33100
            assert "DataForSEO" in by_term["apple watch"].source

            missing = by_term["a term nobody searches"]
            assert missing.volume is None
            assert not missing.is_verified
            assert missing.data_date is None

        anyio.run(go)

    def test_resolves_from_the_factory(self) -> None:
        from app.providers.keywords._dataforseo import DataForSeoProvider

        assert isinstance(get_keyword_provider("dataforseo"), DataForSeoProvider)


def _stub_dfs(monkeypatch: pytest.MonkeyPatch, payload: dict[str, Any]) -> None:
    class StubResponse:
        def raise_for_status(self) -> None:
            return None

        def json(self) -> dict[str, Any]:
            return payload

    class StubClient:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        async def __aenter__(self) -> "StubClient":
            return self

        async def __aexit__(self, *args: Any) -> None:
            return None

        async def post(self, *args: Any, **kwargs: Any) -> StubResponse:
            return StubResponse()

    import app.providers.keywords._dataforseo as module

    monkeypatch.setattr(module.httpx, "AsyncClient", StubClient)


# ---------------------------------------------------------------- OpenAI


class TestOpenAIProvider:
    def test_default_model_and_override(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from app.providers.llm._openai import DEFAULT_MODEL, model_name

        monkeypatch.delenv("OPENAI_MODEL", raising=False)
        assert model_name() == DEFAULT_MODEL
        monkeypatch.setenv("OPENAI_MODEL", "gpt-5.2")
        assert model_name() == "gpt-5.2"

    def test_declares_itself_live(self) -> None:
        from app.providers.llm._openai import OpenAIProvider

        assert OpenAIProvider().is_live_model is True

    def test_unconfigured_raises_and_does_not_fall_back(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.providers.llm._openai import OpenAIProvider

        monkeypatch.delenv("OPENAI_API_KEY", raising=False)

        async def go() -> None:
            with pytest.raises(ModelNotConfiguredError) as excinfo:
                await OpenAIProvider().generate(_copy_request())
            assert "not configured" in str(excinfo.value).lower()

        anyio.run(go)

    def test_resolves_from_the_factory(self) -> None:
        from app.providers.llm import get_llm
        from app.providers.llm._openai import OpenAIProvider

        assert isinstance(get_llm("openai"), OpenAIProvider)

    def test_maps_a_reply_onto_the_draft(self, monkeypatch: pytest.MonkeyPatch) -> None:
        from app.providers.llm._openai import OpenAIProvider

        reply = CopySchema(
            meta_title="Apple Watch Ultra 4 | Health tracking",
            meta_description="Explore the Apple Watch Ultra 4 at e&.",
            h1="Apple Watch Ultra 4",
            answer_block="  The   Apple Watch Ultra 4 is at e&.  ",
            benefits=["GPS", "Battery", "Water resistant", "Fourth one"],
            faqs=[["Q1", "A1"], ["Q2", "A2"], ["malformed"]],
            app_headline="Track everything",
            app_subhead="Health on your wrist",
            app_cta="See models",
            geo_prompts=["What is it?"],
        )

        async def fake_parse(self: Any, **kwargs: Any) -> Any:
            return reply

        monkeypatch.setattr(OpenAIProvider, "_parse", fake_parse)

        async def go() -> None:
            result = await OpenAIProvider().generate(_copy_request())
            assert result.draft.answer_block == "The Apple Watch Ultra 4 is at e&."
            assert len(result.draft.benefits) == 3
            assert len(result.draft.faqs) == 2  # malformed pair dropped
            assert result.is_live_model is True

        anyio.run(go)

    def test_empty_page_text_short_circuits_without_calling_the_api(self) -> None:
        from app.providers.llm._openai import OpenAIProvider

        async def go() -> None:
            facts = await OpenAIProvider().extract_facts(
                product_name="X", url="https://x", page_title="", page_text="  "
            )
            assert not facts.grounded

        anyio.run(go)


class TestBothModelsAskTheSameQuestion:
    """The two providers must stay behaviourally identical apart from transport.

    If each carried its own prompts they would drift the first time one was tightened, and
    a comparison between the models would stop being a fair test of the models.
    """

    def test_prompts_and_schemas_come_from_one_place(self) -> None:
        from app.providers.llm import _anthropic, _openai, _prompts

        for module in (_anthropic, _openai):
            assert module.COPY_SYSTEM is _prompts.COPY_SYSTEM
            assert module.FACTS_SYSTEM is _prompts.FACTS_SYSTEM
            assert module.IDEATION_SYSTEM is _prompts.IDEATION_SYSTEM
            assert module.CopySchema is _prompts.CopySchema
            assert module.build_copy_prompt is _prompts.build_copy_prompt

    def test_both_report_the_same_prompt_version(self) -> None:
        from app.providers.llm._anthropic import ClaudeProvider
        from app.providers.llm._openai import OpenAIProvider

        assert ClaudeProvider().prompt_version == OpenAIProvider().prompt_version


class TestNoFigureCanComeFromTheModel:
    def test_the_copy_schema_has_no_field_for_search_demand(self) -> None:
        # Structural: the model is never given a slot to put a figure in.
        fields = set(CopySchema.model_fields)
        assert not any("volume" in f or "search_count" in f for f in fields)

    def test_keyword_ideas_carry_no_figures(self) -> None:
        import dataclasses

        from app.providers.llm import KeywordIdea

        names = {f.name for f in dataclasses.fields(KeywordIdea)}
        assert names == {"term", "kind", "rationale"}


# ---------------------------------------------------------------- cost safety


class TestNothingLiveHappensWithoutBeingAskedTo:
    """Adding credentials must not, by itself, start spending money."""

    def test_the_suite_cannot_see_live_credentials(self) -> None:
        # Guards the autouse fixture in conftest. If credential isolation breaks, this
        # fails rather than a bill arriving.
        import os

        from app.config import settings

        for name in ("DATAFORSEO_PASSWORD", "OPENAI_API_KEY", "ANTHROPIC_API_KEY"):
            assert not os.environ.get(name), f"{name} leaked into the test environment"
        config = settings()
        assert config.keyword_provider == "fixture"
        assert config.llm_provider == "fixture"
        assert config.page_provider == "none"

    def test_the_demo_batch_is_seeded_when_nothing_is_configured(self) -> None:
        from app.services.seed import should_seed

        assert should_seed() is True

    def test_live_credentials_suppress_the_startup_seed(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The seed runs the real pipeline over every row of the reference file. On live
        providers that is 21 page fetches and dozens of model calls, charged before the
        server accepts its first connection — so it does not run."""
        import app.config
        from app.services.seed import should_seed

        # The suite pins both providers to fixture; detection only gets a say once the
        # explicit settings are out of the way.
        monkeypatch.delenv("KEYWORD_PROVIDER", raising=False)
        monkeypatch.delenv("LLM_PROVIDER", raising=False)
        monkeypatch.setenv("DATAFORSEO_LOGIN", "you@example.com")
        monkeypatch.setenv("DATAFORSEO_PASSWORD", "secret")
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        app.config.settings.cache_clear()

        assert should_seed() is False

    def test_one_live_provider_is_enough_to_suppress_it(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # A live model with fixture volumes still costs money per row.
        import app.config
        from app.services.seed import should_seed

        monkeypatch.delenv("LLM_PROVIDER", raising=False)
        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        app.config.settings.cache_clear()

        assert should_seed() is False

    def test_the_seed_can_be_forced_for_a_rehearsal(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import app.config
        from app.services.seed import should_seed

        monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
        monkeypatch.setenv("SEED_DEMO_BATCH", "1")
        app.config.settings.cache_clear()

        assert should_seed() is True

    def test_the_seed_can_be_suppressed_even_in_fixture_mode(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import app.config
        from app.services.seed import should_seed

        monkeypatch.setenv("SEED_DEMO_BATCH", "0")
        app.config.settings.cache_clear()

        assert should_seed() is False
