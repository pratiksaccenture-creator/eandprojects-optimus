"""Excel read and write — brief §3, §9 and §10 step 3.

The round-trip test proves the reference layout reproduces. It asserts on semantics, not on
xlsx encoding: the reference file stores its `LEN()` formulas as shared formulas
(`t="shared"`, `si=...`), which openpyxl expands on read and cannot reproduce on write. That
encoding is not a requirement — the formula being live is.
"""

from __future__ import annotations

import datetime as dt
import io
from pathlib import Path

import openpyxl
import pytest

from app.excel import writer
from app.excel.determinism import FIXED_TIMESTAMP, sha256
from app.excel.reader import (
    classify_url,
    derive_product_name,
    read_input_workbook,
)
from app.excel.writer import (
    ExportAsoField,
    ExportFinding,
    ExportGeoRow,
    ExportKeyword,
    ExportPayload,
    ExportRow,
    build_workbook,
)
from app.models import FetchStatus, PageType

CREATED = dt.datetime(2026, 9, 17, 11, 30, 0)


# ---------------------------------------------------------------- reader


class TestClassifyUrl:
    def test_eshop_deep_link_is_a_product(self) -> None:
        result = classify_url(
            "https://www.eand.ae/eshop/devices/configuration/key-prod1t178?productId=prod1T178&locale=EN"
        )
        assert result.page_type is PageType.product
        assert result.product_id == "prod1T178"

    def test_category_page(self) -> None:
        result = classify_url("https://www.eand.ae/en/c/home/smart-locks.html")
        assert result.page_type is PageType.category
        assert result.fetch_status is FetchStatus.not_attempted

    def test_help_guide_is_content_not_a_category(self) -> None:
        result = classify_url(
            "https://preprodnew.eand.ae/en/c/smart-home-simplification/help-guide.html"
        )
        assert result.page_type is PageType.content

    def test_preprod_host_is_unreachable_with_a_reason(self) -> None:
        result = classify_url("https://preprodnew.eand.ae/en/c/x/y.html")
        assert result.fetch_status is FetchStatus.unreachable
        assert result.note and "preprodnew.eand.ae" in result.note

    def test_no_row_is_ever_reported_as_ok(self) -> None:
        # The tool never fetches, so claiming a successful fetch would be a lie.
        for url in (
            "https://www.eand.ae/en/c/home/smart-locks.html",
            "https://www.eand.ae/eshop/devices/configuration/k?productId=p",
        ):
            assert classify_url(url).fetch_status is not FetchStatus.ok

    def test_empty_and_malformed_urls_do_not_raise(self) -> None:
        assert classify_url("").fetch_status is FetchStatus.blocked
        assert classify_url("not a url").fetch_status is FetchStatus.blocked


class TestDeriveProductName:
    @pytest.mark.parametrize(
        ("category", "expected"),
        [
            ("Apple WATCH ULTRA 4", "Apple Watch Ultra 4"),
            ("Devices - Iphone Family", "iPhone Family"),
            ("Devices - iPhone 18 pro", "iPhone 18 Pro"),
            ("Devices - iPhone 18 pro Max", "iPhone 18 Pro Max"),
            ("Airpods 5", "AirPods 5"),
            ("Apple Watch SE 3 (2026)", "Apple Watch SE 3 (2026)"),
            ("Apple Watch Series 12 GPS Aluminium", "Apple Watch Series 12 GPS Aluminium"),
            ("Apple AirPods 5 with Wireless Charging Case",
             "Apple AirPods 5 with Wireless Charging Case"),
            ("Smart Home", "Smart Home"),
            ("", ""),
        ],
    )
    def test_brand_casing_is_normalised(self, category: str, expected: str) -> None:
        assert derive_product_name(category) == expected


class TestReadInputWorkbook:
    def test_reads_all_twenty_one_rows(self, input_path: Path) -> None:
        parsed = read_input_workbook(input_path)
        assert len(parsed.rows) == 21
        assert parsed.sheet_name == "SEO Batch 6 Product List"

    def test_headers_match_the_expected_schema(self, input_path: Path) -> None:
        parsed = read_input_workbook(input_path)
        assert parsed.headers == ("Date", "Category", "Product URL")
        assert parsed.header_warnings == ()

    def test_exactly_three_rows_are_unreachable(self, input_path: Path) -> None:
        parsed = read_input_workbook(input_path)
        unreachable = [r for r in parsed.rows if r.fetch_status is FetchStatus.unreachable]
        assert len(unreachable) == 3
        assert all("preprodnew" in r.product_url for r in unreachable)
        assert all(r.fetch_note for r in unreachable)

    def test_no_row_is_silently_dropped(self, input_path: Path) -> None:
        parsed = read_input_workbook(input_path)
        assert all(r.product_url for r in parsed.rows)
        assert parsed.skipped_count == 0

    def test_both_date_formats_survive(self, input_path: Path) -> None:
        parsed = read_input_workbook(input_path)
        formats = {r.date_number_format for r in parsed.rows}
        assert len(formats) == 2, f"expected two coexisting date formats, got {formats}"
        dates = {r.date_value for r in parsed.rows if r.date_value}
        assert dates == {dt.datetime(2026, 7, 9), dt.datetime(2026, 9, 14)}

    def test_dirty_data_never_raises(self, input_path: Path) -> None:
        # Brief §8 step 1: never reject a file for dirty data, classify and continue.
        parsed = read_input_workbook(input_path)
        assert parsed.rows


# Reading the keyword seed is tested in tests/test_providers.py — it lives inside the
# keyword provider package, because that package owns where volumes come from.


# ---------------------------------------------------------------- writer


def _payload_from_input(path: Path, version: int = 1) -> ExportPayload:
    parsed = read_input_workbook(path)
    rows = tuple(
        ExportRow(
            row_index=r.row_index,
            category_raw=r.category_raw,
            product_url=r.product_url,
            product_name=r.product_name,
            keywords_joined="apple watch, smart watch",
            meta_title=f"{r.product_name} in the UAE",
            meta_description=f"Everything about {r.product_name} on e&.",
            date_value=r.date_value,
            date_serial=r.date_serial,
            date_number_format=r.date_number_format,
            fetch_status=r.fetch_status.value,
            fetch_note=r.fetch_note,
        )
        for r in parsed.rows
    )
    return ExportPayload(
        batch_no="Batch 6",
        source_file_name=path.name,
        created_at=CREATED,
        version=version,
        locale="en",
        geo="AE",
        provider_name="FixtureVolumeProvider",
        provider_is_live=False,
        model_name="fixture-deterministic",
        prompt_version="v1",
        brand_suffix_note="Applied to all rows.",
        rows=rows,
        keywords=(
            ExportKeyword(1, "apple watch", "category", 33100, "FixtureVolumeProvider",
                          False, CREATED, "en", "AE", "approved", rows[0].product_url, True),
            ExportKeyword(1, "nonexistent term", "benefit", None, "FixtureVolumeProvider",
                          False, None, "en", "AE", "unverified", rows[0].product_url),
        ),
        geo_rows=(
            ExportGeoRow(1, rows[0].product_url, rows[0].product_name,
                         ("What is it?", "How much does it cost?"), "An answer.", "{}"),
        ),
        aso_fields=(
            ExportAsoField("apple_name", "apple", "Apple app name", "e& Smart",
                           30, "chars", 8, 8, True, True, "Highest weight."),
        ),
        findings=(
            ExportFinding(1, "meta_title_en", "WARN_SUPERLATIVE", "warning", "Unproven claim."),
        ),
    )


@pytest.fixture(scope="module")
def built(input_path: Path) -> bytes:
    return build_workbook(_payload_from_input(input_path))


@pytest.fixture(scope="module")
def built_sheet(built: bytes) -> openpyxl.worksheet.worksheet.Worksheet:
    return openpyxl.load_workbook(io.BytesIO(built))[writer.SHEET_MAIN]


class TestWorkbookLayout:
    def test_sheet_names_are_exact(self, built: bytes) -> None:
        book = openpyxl.load_workbook(io.BytesIO(built))
        assert book.sheetnames == [
            "SEO Batch 6 Product List",
            "keywords ",  # trailing space preserved
            "GEO",
            "ASO",
            "Validation log",
        ]

    def test_headers_are_reproduced_verbatim_including_the_defects(
        self, built_sheet: openpyxl.worksheet.worksheet.Worksheet
    ) -> None:
        headers = tuple(built_sheet.cell(row=1, column=c).value for c in range(1, 11))
        assert headers == (
            "Date",
            "Category",
            "Product URL",
            "Keywords ",              # trailing space is real
            "Meta Title (EN)",
            "Character count (<60)",
            "Meta Decsription (EN)",  # typo is real
            "Character count (<160)",
            None,                     # reserved column I
            "Product Name",           # new column J
        )

    def test_headers_match_the_reference_file_exactly(
        self, built_sheet: openpyxl.worksheet.worksheet.Worksheet, reference_sheet: object
    ) -> None:
        for column in range(1, 9):
            ours = built_sheet.cell(row=1, column=column).value
            theirs = reference_sheet[f"{openpyxl.utils.get_column_letter(column)}1"].value  # type: ignore[index]
            assert ours == theirs, f"column {column}"

    def test_reserved_column_keeps_its_style_and_width(
        self, built_sheet: openpyxl.worksheet.worksheet.Worksheet
    ) -> None:
        assert built_sheet["I1"].value is None
        assert built_sheet["I1"].font.b is True
        assert built_sheet.column_dimensions["I"].width == pytest.approx(18.36328125)

    def test_len_formulas_are_live_not_computed(
        self, built_sheet: openpyxl.worksheet.worksheet.Worksheet
    ) -> None:
        for row in range(2, 23):
            title_count = built_sheet.cell(row=row, column=6)
            desc_count = built_sheet.cell(row=row, column=8)
            assert title_count.value == f"=LEN(E{row})"
            assert title_count.data_type == "f"
            assert desc_count.value == f"=LEN(G{row})"
            assert desc_count.data_type == "f"

    def test_formulas_recalculate_on_open(self, built: bytes) -> None:
        # openpyxl writes no cached value, so this flag is what makes Excel fill them in.
        book = openpyxl.load_workbook(io.BytesIO(built))
        assert book.calculation.fullCalcOnLoad is True

    def test_twenty_one_rows_in_yields_twenty_one_rows_out(
        self, built_sheet: openpyxl.worksheet.worksheet.Worksheet
    ) -> None:
        urls = [built_sheet.cell(row=r, column=3).value for r in range(2, 23)]
        assert len(urls) == 21
        assert built_sheet.cell(row=23, column=3).value is None

    def test_column_c_holds_a_url_on_every_row(
        self, built_sheet: openpyxl.worksheet.worksheet.Worksheet
    ) -> None:
        # The reference file's defect: rows 10-14 held the product name here instead.
        for row in range(2, 23):
            value = built_sheet.cell(row=row, column=3).value
            assert isinstance(value, str) and value.startswith("https://"), f"row {row}"

    def test_product_name_lives_only_in_column_j(
        self, built_sheet: openpyxl.worksheet.worksheet.Worksheet
    ) -> None:
        for row in range(2, 23):
            assert built_sheet.cell(row=row, column=10).value
            assert built_sheet.cell(row=row, column=9).value is None

    def test_both_date_formats_are_preserved_in_the_export(
        self, built_sheet: openpyxl.worksheet.worksheet.Worksheet
    ) -> None:
        formats = {built_sheet.cell(row=r, column=1).number_format for r in range(2, 23)}
        assert len(formats) == 2

    def test_unverified_keyword_volume_is_blank_not_zero(self, built: bytes) -> None:
        # A zero would read as a measured volume of zero.
        sheet = openpyxl.load_workbook(io.BytesIO(built))[writer.SHEET_KEYWORDS]
        by_term = {sheet.cell(row=r, column=1).value: r for r in range(2, 4)}
        row = by_term["nonexistent term"]
        assert sheet.cell(row=row, column=3).value is None
        assert sheet.cell(row=row, column=9).value == "unverified"

    def test_validation_log_carries_readable_character_counts(self, built: bytes) -> None:
        # Sheet 1's counts are formulas with no cached value; these integers are the
        # guaranteed-readable copy.
        sheet = openpyxl.load_workbook(io.BytesIO(built))[writer.SHEET_VALIDATION]
        counts = [
            sheet.cell(row=r, column=7).value
            for r in range(2, sheet.max_row + 1)
            if isinstance(sheet.cell(row=r, column=7).value, int)
        ]
        assert counts and all(c > 0 for c in counts)

    def test_validation_log_records_provenance(self, built: bytes) -> None:
        sheet = openpyxl.load_workbook(io.BytesIO(built))[writer.SHEET_VALIDATION]
        labels = {
            sheet.cell(row=r, column=1).value
            for r in range(1, sheet.max_row + 1)
        }
        for expected in ("Keyword volume provider", "Volumes are live data", "Copy model"):
            assert expected in labels


class TestFileName:
    def test_matches_the_required_pattern(self, input_path: Path) -> None:
        payload = _payload_from_input(input_path, version=3)
        assert payload.file_name == "Output_File_-_SEO_Batch_6_20260917_v3.xlsx"


class TestDeterminism:
    def test_two_builds_of_the_same_payload_are_byte_identical(self, input_path: Path) -> None:
        first = build_workbook(_payload_from_input(input_path))
        second = build_workbook(_payload_from_input(input_path))
        assert sha256(first) == sha256(second)
        assert first == second

    def test_zip_entry_timestamps_are_frozen(self, built: bytes) -> None:
        archive = openpyxl.load_workbook  # keep import local intent clear
        del archive
        import zipfile

        with zipfile.ZipFile(io.BytesIO(built)) as zf:
            assert zf.namelist() == sorted(zf.namelist())
            for info in zf.infolist():
                assert info.date_time == FIXED_TIMESTAMP, info.filename

    def test_document_timestamps_come_from_the_payload_not_the_clock(self, built: bytes) -> None:
        book = openpyxl.load_workbook(io.BytesIO(built))
        assert book.properties.created == CREATED
        assert book.properties.modified == CREATED

    def test_a_different_version_changes_the_bytes(self, input_path: Path) -> None:
        first = build_workbook(_payload_from_input(input_path, version=1))
        second = build_workbook(_payload_from_input(input_path, version=2))
        assert first != second
