"""The keyword-research pivot: four-column template in, researched keywords and copy out.

Covers the parts the earlier suite could not, because they did not exist: reading the
product template, deciding which terms are worth measuring, expanding seeds into the long
tail, and the SEO Copy Guidelines as enforced rules.

Everything here runs offline. Nothing calls a paid API.
"""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Any

import anyio
import pytest

from app.excel.reader import (
    BRAND_BY_LINE,
    derive_brand,
    looks_like_template,
    read_any_workbook,
    read_price,
)
from app.excel.template_writer import KeywordUsage, TemplatePayload, TemplateRow
from app.excel.template_writer import build_workbook as build_template_workbook
from app.lib.policy import KEYWORD_BUCKETS, PRICED_BUCKETS, format_price
from app.lib.terms import (
    category_phrases,
    display_name,
    has_repeated_word,
    is_attribute_term,
    names_a_different_model,
    names_another_brand,
    shares_a_word_with_product,
    strip_attributes,
)
from app.lib.validators import (
    FieldContext,
    has_errors,
    no_banned_terms,
    price_sentence,
    smartpay_mentioned,
    uk_english,
    validate_field,
)
from app.models import KeywordType
from app.services.candidates import derive_seeds
from app.services.export_service import keywords_used_in

TEMPLATE = Path(__file__).resolve().parents[1] / "fixtures" / "product-template.xlsx"


def codes(findings: Any) -> set[str]:
    return {f.code for f in findings}


def desc_ctx(**kw: Any) -> FieldContext:
    base: dict[str, Any] = {
        "field": "meta_description_en",
        "row_index": 10,
        "product_name": "Apple iPhone 17",
        "brand": "Apple",
    }
    base.update(kw)
    return FieldContext(**base)


# ---------------------------------------------------------------- the input template


class TestTemplateReader:
    def test_the_template_is_recognised_without_being_told(self) -> None:
        # Both formats will be in circulation for a while, and asking the user which one
        # they have is a question the headers already answer.
        assert looks_like_template(["Batch No/Name", "Product Category", "Brand ", "Product Name"])
        assert not looks_like_template(["Date", "Category", "Product URL"])

    def test_reads_the_four_columns(self) -> None:
        book = read_any_workbook(TEMPLATE)
        assert book.layout == "template"
        assert book.sheet_name == "Products"
        assert len(book.rows) == 9

    def test_the_trailing_space_in_the_brand_header_is_tolerated(self) -> None:
        # The supplied template has `Brand `, exactly as the output workbook has
        # `Keywords `. Matching has to trim; writing it back must not.
        book = read_any_workbook(TEMPLATE)
        assert any(r.brand for r in book.rows)

    def test_formatting_only_rows_are_not_ingested_as_products(self) -> None:
        # The sheet is formatted down to row 101 with nine rows of data.
        book = read_any_workbook(TEMPLATE)
        assert all(r.product_name for r in book.rows)

    def test_the_batch_number_comes_from_the_file(self) -> None:
        assert read_any_workbook(TEMPLATE).batch_numbers == ("T1",)

    def test_rows_carry_their_own_row_index_in_order(self) -> None:
        book = read_any_workbook(TEMPLATE)
        assert [r.row_index for r in book.rows] == list(range(1, 10))


class TestBrandDerivation:
    def test_a_supplied_brand_is_taken_as_given(self) -> None:
        # The fixture has the column filled, so nothing is derived and nothing is
        # flagged. Derivation is covered separately below, for the sheets that leave it
        # blank — which the shipped template does.
        book = read_any_workbook(TEMPLATE)
        assert all(r.brand for r in book.rows)
        assert not any(r.brand_derived for r in book.rows)

    def test_an_empty_brand_column_is_filled_in_and_flagged(self, tmp_path: Path) -> None:
        import openpyxl

        book = openpyxl.Workbook()
        sheet = book.active
        assert sheet is not None
        sheet.title = "Products"
        for column, header in enumerate(
            ("Batch No/Name", "Product Category", "Brand ", "Product Name"), start=1
        ):
            sheet.cell(1, column, header)
        sheet.cell(2, 1, "T1")
        sheet.cell(2, 2, "Smart Home")
        sheet.cell(2, 4, "Eufy Robot Vacuum Omni S1 Pro")
        target = tmp_path / "blank-brand.xlsx"
        book.save(target)

        parsed = read_any_workbook(target)
        assert parsed.rows[0].brand == "Eufy"
        assert parsed.rows[0].brand_derived is True

    @pytest.mark.parametrize(
        ("name", "expected"),
        [
            ("Eufy Robot Vacuum Omni S1 Pro", "Eufy"),
            ("Samsung Tab A11 Plus Storage 128GB", "Samsung"),
            ("Apple Watch Series 12 GPS + Cellular Ceramic", "Apple"),
            ("Xiaomi Redmi Note 14 Pro", "Xiaomi"),
            ("Motorola Razr 40 Ultra", "Motorola"),
            ("Ring Wired Video Doorbell Plus", "Ring"),
            ("AOC AGON Gaming Monitor Series AG276FK/89", "AOC"),
        ],
    )
    def test_derives_the_brand_from_the_product_name(self, name: str, expected: str) -> None:
        assert derive_brand(name) == expected

    def test_the_manufacturer_beats_its_own_product_line(self) -> None:
        # Both "Sony" and "PlayStation" are known names. Earliest wins, because a product
        # line trails its maker. Sorting by length picked PlayStation.
        assert derive_brand("Sony PlayStation PS5 Digital Console") == "Sony"

    def test_a_line_that_names_its_maker_is_resolved(self) -> None:
        # The legacy file names rows "iPhone 18 Pro Max" with no "Apple" anywhere.
        assert derive_brand("iPhone 18 Pro Max") == "Apple"
        assert derive_brand("Galaxy Z Fold 7") == "Samsung"

    def test_every_mapped_line_points_at_a_known_brand(self) -> None:
        from app.excel.reader import KNOWN_BRANDS

        for _, brand in BRAND_BY_LINE:
            assert brand in KNOWN_BRANDS

    def test_an_unknown_product_yields_no_brand_rather_than_a_guess(self) -> None:
        """The first word is the brand often enough to be tempting and wrong often enough
        to matter.

        On a row named "Smart Appliances" the guess was "Smart", which became a keyword
        seed, which matched "smartphone", which became the primary keyword for a page
        about dishwashers. An empty brand is a visible gap; a wrong one propagates.
        """
        assert derive_brand("Smart Appliances") == ""
        assert derive_brand("") == ""


class TestPriceColumn:
    @pytest.mark.parametrize(
        ("raw", "expected"),
        [
            (3499, 3499.0),
            (3499.0, 3499.0),
            ("3,499", 3499.0),
            ("AED 3,499", 3499.0),
            ("3499.50", 3499.5),
            ("", None),
            ("   ", None),
            ("not a price", None),
            (0, None),
            (None, None),
        ],
    )
    def test_reads_a_price_however_it_was_typed(self, raw: Any, expected: float | None) -> None:
        assert read_price(raw) == expected

    def test_formats_for_copy_without_pointless_decimals(self) -> None:
        assert format_price(3499.0) == "3,499"
        assert format_price(99.5) == "99.50"

    def test_the_template_carries_prices_on_some_rows_only(self) -> None:
        book = read_any_workbook(TEMPLATE)
        assert 0 < book.priced_count < len(book.rows)


# ---------------------------------------------------------------- what is worth measuring


class TestAttributeFiltering:
    @pytest.mark.parametrize(
        "term",
        ["512gb", "128 gb", "42mm", "case size", "2k", "ag276fk", "pearl white", "ceramic"],
    )
    def test_attributes_are_not_worth_measuring(self, term: str) -> None:
        assert is_attribute_term(term)

    @pytest.mark.parametrize(
        "term",
        ["apple watch", "iphone 17", "robot vacuum", "gaming monitor", "smartphones"],
    )
    def test_products_and_categories_are(self, term: str) -> None:
        assert not is_attribute_term(term)

    def test_a_colour_attached_to_a_product_keeps_its_product(self) -> None:
        # "pearl white" is an attribute; "white iphone 17" is a query someone types.
        assert is_attribute_term("pearl white")
        assert not is_attribute_term("white iphone 17")

    def test_strip_attributes_leaves_the_searchable_core(self) -> None:
        assert strip_attributes(
            "Apple Watch Series 12 GPS + Cellular Ceramic | Pearl White | Case Size 42MM"
        ) == "apple watch series 12 gps cellular"
        assert strip_attributes("Apple iPhone 17 | 512GB") == "apple iphone 17"


class TestDisplayName:
    def test_keeps_the_material_that_distinguishes_sibling_rows(self) -> None:
        """Three rows in the reference batch differ only by Aluminium, Titanium, Ceramic.

        Dropping the material gives them identical titles, which the uniqueness validator
        rejects — so the copy rule and the keyword rule have to differ here, and they do.
        """
        names = [
            "Apple Watch Series 12 GPS + Cellular Aluminium",
            "Apple Watch Series 12 GPS + Cellular Titanium",
            "Apple Watch Series 12 GPS + Cellular Ceramic",
        ]
        rendered = [display_name(n) for n in names]
        assert len(set(rendered)) == 3
        # ...while the keyword core drops the material, because nobody searches it.
        assert len({strip_attributes(n) for n in names}) == 1

    def test_drops_specifications_and_trailing_attribute_segments(self) -> None:
        assert display_name("Apple iPhone 17 | 512GB") == "Apple iPhone 17"
        assert display_name("Sony PlayStation PS5 Digital Console | White | 825GB") == (
            "Sony PlayStation PS5 Digital Console"
        )

    def test_a_seventy_five_character_name_comes_under_the_title_limit(self) -> None:
        name = (
            "Apple Watch Series 12 GPS + Cellular Ceramic | Pearl White | Case Size 42MM"
        )
        assert len(name) > 60
        assert len(display_name(name)) <= 60


class TestTermsAboutTheRightProduct:
    @pytest.mark.parametrize(
        ("term", "product"),
        [
            ("iphone 18 pro max", "iPhone 18 Pro"),
            ("apple watch series 12", "Apple Watch Ultra 4"),
            ("iphone 17", "iPhone 18 Pro"),
        ],
    )
    def test_a_term_naming_another_model_is_rejected(self, term: str, product: str) -> None:
        """Expansion does not know which SKU it is working for.

        Asked to expand "iphone 18 pro" the API returns "iphone 18 pro max" — more demand,
        different phone. Unfiltered it outranks the correct term and becomes the primary
        keyword, pointing the page at a product it is not selling.
        """
        assert names_a_different_model(term, product)

    @pytest.mark.parametrize(
        ("term", "product"),
        [
            ("iphone 18", "iPhone 18 Pro Max"),
            ("apple watch", "Apple Watch Ultra 4"),
            ("smart watch", "Apple Watch Ultra 4"),
            ("robot vacuum", "Eufy Robot Vacuum Omni S1 Pro"),
        ],
    )
    def test_a_broader_term_is_kept(self, term: str, product: str) -> None:
        # Broader is fine — that is how customers describe things. Only ADDING a model
        # qualifier the product does not have is disqualifying.
        assert not names_a_different_model(term, product)

    def test_a_generation_welded_into_a_token_still_counts(self) -> None:
        """"PS5" carries its generation inside the token, so reading only standalone
        digits left that product with no generation at all — and "playstation 5", the
        single most correct term for it, was rejected as a different model."""
        ps5 = "Sony PlayStation PS5 Digital Console | White | 825GB"
        assert not names_a_different_model("playstation 5", ps5)
        assert not names_a_different_model("ps5 price", ps5)
        # A different console is still rejected.
        assert names_a_different_model("playstation 6", ps5)
        assert names_a_different_model("ps5 pro", ps5)

    def test_a_product_with_no_model_markers_filters_nothing(self) -> None:
        # No baseline to compare against. Rejecting every numbered term on that basis
        # threw away good ones.
        assert not names_a_different_model("smart plug 2 pack", "Smart Appliances")

    def test_a_term_with_nothing_in_common_cannot_be_the_primary(self) -> None:
        assert not shares_a_word_with_product("apple", "iPhone Family")
        assert not shares_a_word_with_product("smartphone", "Smart Appliances")

    def test_market_words_alone_do_not_count_as_overlap(self) -> None:
        assert not shares_a_word_with_product("buy online in uae", "Apple Watch Ultra 4")

    def test_a_generic_description_of_the_product_does_count(self) -> None:
        assert shares_a_word_with_product("smart watch", "Apple Watch Ultra 4")


class TestCompetitorTerms:
    """Expansion does not know whose page it is working on.

    Seeded with "robot vacuum" for a Eufy product it returned "dyson vacuum" and "dyson
    sweeper"; seeded from a Samsung tablet it returned "ipad", "apple ipad" and "lenovo
    tablet". Those reached the screen and would have been handed to the copy model as
    supporting keywords — a competitor's brand written into e&'s own product page.
    """

    @pytest.mark.parametrize(
        ("term", "brand"),
        [
            ("dyson vacuum", "Eufy"),
            ("dyson sweeper", "Eufy"),
            ("ipad", "Samsung"),
            ("apple ipad", "Samsung"),
            ("lenovo tablet", "Samsung"),
        ],
    )
    def test_another_manufacturers_term_is_rejected(self, term: str, brand: str) -> None:
        assert names_another_brand(term, brand)

    @pytest.mark.parametrize(
        ("term", "brand"),
        [
            ("robot vacuum", "Eufy"),
            ("automatic vacuum cleaner", "Eufy"),
            ("eufy robot vacuum", "Eufy"),
            ("tablet", "Samsung"),
            ("samsung galaxy tab", "Samsung"),
        ],
    )
    def test_generic_and_own_brand_terms_are_kept(self, term: str, brand: str) -> None:
        # Generic terms name no manufacturer and are exactly what the page should target.
        assert not names_another_brand(term, brand)

    def test_nothing_is_filtered_when_the_brand_is_unknown(self) -> None:
        # No evidence to filter on. Better to show a term than to drop it on a guess.
        assert not names_another_brand("dyson vacuum", "")

    def test_a_product_line_counts_as_its_maker(self) -> None:
        # "ipad" contains no brand word, but it is unambiguously Apple.
        assert derive_brand("ipad") == "Apple"
        assert derive_brand("galaxy tab") == "Samsung"


class TestJunkExpansions:
    @pytest.mark.parametrize(
        "term",
        ["robot vacuum robot", "robot robot vacuum cleaner", "robot vacuum cleaner robot"],
    )
    def test_permuted_duplicates_are_rejected(self, term: str) -> None:
        """All three came back for one product at the same 3,600 volume, and one became
        its primary keyword. They are artefacts of how the ads platform permutes terms,
        not phrases anybody types."""
        assert has_repeated_word(term)

    @pytest.mark.parametrize(
        "term",
        ["robot vacuum", "apple watch series 12", "automatic vacuum cleaner", "buy iphone 17 online"],
    )
    def test_real_phrases_survive(self, term: str) -> None:
        assert not has_repeated_word(term)

    def test_a_long_phrase_may_legitimately_repeat(self) -> None:
        assert not has_repeated_word("best robot vacuum for pet hair and robot mop")


class TestBareBrandIsNeverPrimary:
    def test_the_manufacturer_alone_cannot_be_the_primary_keyword(self) -> None:
        """"samsung" at 110,000 outranked every real candidate on a Samsung tablet row.

        It was meant to be blocked by a scoring penalty, but the penalty only fired for
        products matching one of the four Apple families that had a family phrase — so
        every other product in the catalogue skipped it, and the defect appeared the
        moment the input stopped being Apple devices.
        """
        from app.models import Keyword, KeywordType
        from app.services.keyword_service import choose_primary

        def term(text: str, volume: int) -> Keyword:
            return Keyword(
                term=text, term_normalized=text, type=KeywordType.product,
                volume=volume, source="test", locale="en", geo="AE",
            )

        keywords = [term("samsung", 110000), term("samsung tab", 8100)]
        chosen = choose_primary(keywords, "Samsung Tab A11 Plus", "Samsung")
        assert chosen is not None
        assert chosen.term == "samsung tab"

    def test_with_nothing_else_available_there_is_no_primary(self) -> None:
        # Better an honest gap than a keyword the page cannot win.
        from app.models import Keyword, KeywordType
        from app.services.keyword_service import choose_primary

        only_brand = [
            Keyword(
                term="samsung", term_normalized="samsung", type=KeywordType.brand,
                volume=110000, source="test", locale="en", geo="AE",
            )
        ]
        assert choose_primary(only_brand, "Samsung Tab A11 Plus", "Samsung") is None


class TestCategoryPhrases:
    def test_a_compound_category_yields_both_halves(self) -> None:
        # "wearables" and "apple watches" are different queries with different demand.
        assert category_phrases("Wearables | Apple Watches") == ("apple watches", "wearables")

    def test_a_simple_category_yields_itself(self) -> None:
        assert category_phrases("Smartphones") == ("smartphones",)

    def test_the_sources_typo_is_preserved_not_corrected(self) -> None:
        # "Monitorting" is in the supplied file. Silently fixing input data would make the
        # export disagree with the sheet it came from.
        assert "monitorting" in category_phrases("Smart Home & Monitorting")


# ---------------------------------------------------------------- seeds


class TestSeeds:
    def test_seeds_cover_the_buckets_the_team_uses_by_hand(self) -> None:
        seeds = derive_seeds(
            "Apple Watch Series 12 GPS + Cellular Ceramic | Pearl White",
            brand="Apple",
            category_raw="Wearables | Apple Watches",
        )
        buckets = {s.type for s in seeds}
        assert KeywordType.brand in buckets
        assert KeywordType.product in buckets
        assert KeywordType.category in buckets
        assert KeywordType.smartpay in buckets

    def test_no_seed_is_an_attribute(self) -> None:
        seeds = derive_seeds(
            "Apple Watch Series 12 GPS + Cellular Ceramic | Pearl White | Case Size 42MM",
            brand="Apple",
            category_raw="Wearables",
        )
        for seed in seeds:
            if seed.type is KeywordType.smartpay:
                continue
            assert not is_attribute_term(seed.term), seed.term

    def test_seeds_stay_short_enough_to_expand(self) -> None:
        # A seed carrying every attribute expands into nothing, because nobody types it.
        seeds = derive_seeds(
            "AOC AGON Gaming Monitor Series AG276FK/89 | 27 inch",
            brand="AOC",
            category_raw="Gaming",
        )
        assert all(len(s.term.split()) <= 6 for s in seeds), [s.term for s in seeds]

    def test_smartpay_is_always_present_and_never_priced(self) -> None:
        seeds = derive_seeds("Apple iPhone 17", brand="Apple", category_raw="Smartphones")
        assert any(s.type is KeywordType.smartpay for s in seeds)
        assert "smartpay" not in PRICED_BUCKETS

    def test_every_bucket_declares_whether_it_is_priced(self) -> None:
        assert {b.key for b in KEYWORD_BUCKETS if b.priced} == set(PRICED_BUCKETS)

    def test_seeds_are_deduplicated_and_ordered_reproducibly(self) -> None:
        args = dict(brand="Apple", category_raw="Smartphones")
        first = derive_seeds("Apple iPhone 17 | 512GB", **args)
        second = derive_seeds("Apple iPhone 17 | 512GB", **args)
        assert [s.term for s in first] == [s.term for s in second]
        assert len({s.term for s in first}) == len(first)


# ---------------------------------------------------------------- expansion


DFS_EXPANSION = {
    "status_code": 20000,
    "tasks": [
        {
            "status_code": 20000,
            "result": [
                {"keyword": "apple watch", "search_volume": 33100, "cpc": 1.2,
                 "competition": "LOW", "competition_index": 8},
                {"keyword": "apple watch series 12", "search_volume": 9900, "cpc": 1.4,
                 "competition": "LOW", "competition_index": 11},
                {"keyword": "apple watch uae", "search_volume": None, "cpc": None,
                 "competition": None, "competition_index": None},
                # Duplicated by the API; kept once.
                {"keyword": "Apple Watch", "search_volume": 33100, "cpc": 1.2,
                 "competition": "LOW", "competition_index": 8},
            ],
        }
    ],
}


class TestDataForSeoExpansion:
    def test_the_task_asks_for_the_highest_volume_ideas(self) -> None:
        from app.providers.keywords._dataforseo import build_expansion_task

        task = build_expansion_task(
            ["apple watch"], location_code=2784, language_code="en", limit=50
        )
        assert task["keywords"] == ["apple watch"]
        assert task["location_code"] == 2784
        assert task["sort_by"] == "search_volume"
        assert task["limit"] == 50

    def test_more_than_twenty_seeds_is_refused(self) -> None:
        # DataForSEO's cap, not ours. Sending 21 fails the whole request.
        from app.providers.keywords._dataforseo import build_expansion_task

        with pytest.raises(ValueError):
            build_expansion_task(
                [f"t{i}" for i in range(21)],
                location_code=2784, language_code="en", limit=50,
            )

    def test_parses_ideas_with_their_own_volumes(self) -> None:
        from app.providers.keywords._dataforseo import parse_expansion

        rows = parse_expansion(DFS_EXPANSION)
        by_term = {r.term.lower(): r for r in rows}
        assert by_term["apple watch"].search_volume == 33100
        assert by_term["apple watch series 12"].search_volume == 9900

    def test_a_null_volume_stays_none(self) -> None:
        from app.providers.keywords._dataforseo import parse_expansion

        rows = {r.term: r for r in parse_expansion(DFS_EXPANSION)}
        assert rows["apple watch uae"].search_volume is None

    def test_duplicates_are_collapsed_on_the_normalised_term(self) -> None:
        from app.providers.keywords._dataforseo import parse_expansion

        assert len(parse_expansion(DFS_EXPANSION)) == 3

    def test_a_failed_expansion_raises_rather_than_returning_nothing(self) -> None:
        from app.providers.keywords import NotConfiguredError
        from app.providers.keywords._dataforseo import parse_expansion

        with pytest.raises(NotConfiguredError):
            parse_expansion({"status_code": 40101, "status_message": "Auth error."})

    def test_expansion_credits_the_longest_matching_seed(self) -> None:
        from app.providers.keywords._dataforseo import DataForSeoProvider

        async def go() -> None:
            provider = DataForSeoProvider()
            results = await provider.expand(
                ["apple", "apple watch"], geo="AE", locale="en"
            )
            by_term = {r.term: r for r in results}
            # "apple watch series 12" contains both seeds; the more specific one is the
            # honest attribution.
            assert by_term["apple watch series 12"].seed == "apple watch"

        _with_dfs_stub(go, DFS_EXPANSION)

    def test_declares_that_it_can_expand(self) -> None:
        from app.providers.keywords._dataforseo import DataForSeoProvider

        assert DataForSeoProvider().can_expand is True

    def test_a_provider_that_cannot_expand_says_so_rather_than_faking_it(self) -> None:
        from app.providers.keywords._semrush import SemrushVolumeProvider

        assert SemrushVolumeProvider().can_expand is False


def _with_dfs_stub(coro: Any, payload: dict[str, Any]) -> None:
    """Run `coro` with DataForSEO's transport replaced. No network, no credentials."""
    import os

    import app.providers.keywords._dataforseo as module

    class StubResponse:
        def raise_for_status(self) -> None:
            return None

        def json(self) -> dict[str, Any]:
            return payload

    class StubClient:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        async def __aenter__(self) -> "StubClient":
            return self

        async def __aexit__(self, *args: Any) -> None:
            return None

        async def post(self, *args: Any, **kwargs: Any) -> StubResponse:
            return StubResponse()

    real_client = module.httpx.AsyncClient
    os.environ["DATAFORSEO_LOGIN"] = "you@example.com"
    os.environ["DATAFORSEO_PASSWORD"] = "secret"
    module.httpx.AsyncClient = StubClient  # type: ignore[misc]
    try:
        anyio.run(coro)
    finally:
        module.httpx.AsyncClient = real_client  # type: ignore[misc]
        os.environ.pop("DATAFORSEO_LOGIN", None)
        os.environ.pop("DATAFORSEO_PASSWORD", None)


class TestFixtureExpansion:
    def test_matches_whole_words_only(self) -> None:
        """A bare `in` test matched the seed "smart" against the seeded term "smartphone",
        which handed a page about smart appliances a primary keyword of "smartphone"."""
        from app.providers.keywords._fixture import FixtureVolumeProvider

        async def go() -> None:
            results = await FixtureVolumeProvider().expand(
                ["smart"], geo="AE", locale="en"
            )
            assert all("smartphone" not in r.term for r in results)

        anyio.run(go)

    def test_stays_marked_as_seeded_data(self) -> None:
        from app.providers.keywords._fixture import FixtureVolumeProvider

        assert FixtureVolumeProvider().is_live_data is False


# ---------------------------------------------------------------- the guidelines


class TestPriceRule:
    """The reconciliation between the guidelines, which require a price, and the brief,
    which forbids one. A figure appears only if a human supplied exactly that figure."""

    GOOD = "Explore the Apple iPhone 17. Shop it from AED 3,499 via SmartPay with e&."

    def test_the_supplied_price_is_allowed(self) -> None:
        assert "BANNED_CURRENCY" not in codes(
            no_banned_terms(self.GOOD, desc_ctx(allowed_price="3,499"))
        )

    def test_a_different_figure_is_still_blocked(self) -> None:
        wrong = self.GOOD.replace("3,499", "3,299")
        findings = no_banned_terms(wrong, desc_ctx(allowed_price="3,499"))
        assert "BANNED_CURRENCY" in codes(findings)
        assert has_errors(findings)

    def test_a_price_on_a_row_with_none_supplied_is_blocked(self) -> None:
        findings = no_banned_terms(self.GOOD, desc_ctx(allowed_price=None))
        assert has_errors(findings)

    def test_a_second_figure_alongside_the_allowed_one_is_blocked(self) -> None:
        # The allowance is for one exact string, not for currency in general.
        text = self.GOOD.replace("with e&.", "or AED 99 per month with e&.")
        assert has_errors(no_banned_terms(text, desc_ctx(allowed_price="3,499")))

    def test_monthly_pricing_is_blocked_even_with_the_right_figure(self) -> None:
        text = "Shop the Apple iPhone 17 from AED 3,499/month via SmartPay with e&."
        assert has_errors(no_banned_terms(text, desc_ctx(allowed_price="3,499")))

    def test_a_row_with_no_price_is_warned_not_blocked(self) -> None:
        findings = price_sentence("Explore the iPhone 17.", desc_ctx(allowed_price=None))
        assert codes(findings) == {"NO_PRICE_SUPPLIED"}
        assert not has_errors(findings)

    def test_a_supplied_price_the_copy_ignored_is_reported(self) -> None:
        findings = price_sentence(
            "Explore the iPhone 17. Shop via SmartPay with e&.",
            desc_ctx(allowed_price="3,499"),
        )
        assert codes(findings) == {"PRICE_NOT_USED"}

    def test_the_price_rule_does_not_apply_to_titles(self) -> None:
        assert price_sentence("Apple iPhone 17 | e&", desc_ctx(field="meta_title_en")) == []


class TestSmartPayRule:
    def test_a_description_without_smartpay_is_flagged(self) -> None:
        assert "NO_SMARTPAY" in codes(
            smartpay_mentioned("Explore the Apple iPhone 17 at e&.", desc_ctx())
        )

    def test_smartpay_is_required_even_when_no_price_was_supplied(self) -> None:
        # It is a standing commercial requirement, not part of the price sentence.
        findings = smartpay_mentioned("Explore the iPhone 17.", desc_ctx(allowed_price=None))
        assert "NO_SMARTPAY" in codes(findings)

    def test_a_compliant_description_passes(self) -> None:
        assert smartpay_mentioned(
            "Explore the iPhone 17. Shop via SmartPay with e&.", desc_ctx()
        ) == []


class TestUkEnglish:
    def test_american_spelling_is_flagged(self) -> None:
        findings = uk_english("Personalize the color of your favorite watch.", desc_ctx())
        assert codes(findings) == {"US_SPELLING"}
        assert len(findings) == 3

    def test_uk_spelling_passes(self) -> None:
        assert uk_english("Personalise the colour of your favourite watch.", desc_ctx()) == []

    def test_a_brand_spelled_the_american_way_is_left_alone(self) -> None:
        """The guidelines' own exception: "except where a brand name or product name is
        officially written in US spelling". Oppo ships ColorOS; correcting it would
        introduce an error rather than remove one."""
        ctx = desc_ctx(product_name="Oppo Find X9 with ColorOS", brand="Oppo")
        assert uk_english("The Oppo Find X9 with ColorOS is available.", ctx) == []

    def test_it_is_a_warning_not_a_blocker(self) -> None:
        assert not has_errors(uk_english("Customize your color.", desc_ctx()))


class TestActionVerbs:
    def test_a_description_with_no_verb_is_flagged(self) -> None:
        findings = validate_field("The Apple iPhone 17 is a phone.", desc_ctx())
        assert "NO_ACTION_VERB" in codes(findings)

    def test_any_of_the_listed_verbs_satisfies_it(self) -> None:
        for verb in ("Shop", "Buy", "Explore", "Discover"):
            text = f"{verb} the Apple iPhone 17 at e&. Order via SmartPay."
            assert "NO_ACTION_VERB" not in codes(validate_field(text, desc_ctx()))

    def test_titles_are_exempt(self) -> None:
        # A 60-character title often cannot afford a verb without losing the keyword.
        findings = validate_field(
            "Apple iPhone 17 | Camera & battery", desc_ctx(field="meta_title_en")
        )
        assert "NO_ACTION_VERB" not in codes(findings)


class TestLengthUnderTheGuidelines:
    def test_exactly_sixty_is_a_valid_title(self) -> None:
        ctx = FieldContext(field="meta_title_en", row_index=1, char_limit=60)
        assert "CHAR_LIMIT" not in codes(validate_field("x" * 60, ctx))

    def test_sixty_one_is_not(self) -> None:
        ctx = FieldContext(field="meta_title_en", row_index=1, char_limit=60)
        assert "CHAR_LIMIT" in codes(validate_field("x" * 61, ctx))

    def test_the_stricter_reading_remains_one_flag_away(self) -> None:
        ctx = FieldContext(
            field="meta_title_en", row_index=1, char_limit=60, char_limit_inclusive=False
        )
        assert "CHAR_LIMIT" in codes(validate_field("x" * 60, ctx))


# ---------------------------------------------------------------- the export


class TestTemplateExport:
    def _payload(self, **kw: Any) -> TemplatePayload:
        import datetime as dt

        base: dict[str, Any] = {
            "batch_no": "T1",
            "created_at": dt.datetime(2026, 9, 28, 12, 0, 0),
            "version": 1,
            "rows": (
                TemplateRow(
                    row_index=1,
                    batch_no="T1",
                    category_raw="Smartphones",
                    brand="Apple",
                    product_name="Apple iPhone 17 | 512GB",
                    meta_title="Apple iPhone 17 | Camera & battery | e&",
                    meta_description="Explore the Apple iPhone 17. Shop via SmartPay with e&.",
                    keywords_used=(KeywordUsage("apple iphone 17", 12100),),
                ),
            ),
        }
        base.update(kw)
        return TemplatePayload(**base)

    def _sheet(self, payload: TemplatePayload) -> Any:
        import io

        import openpyxl

        return openpyxl.load_workbook(io.BytesIO(build_template_workbook(payload)))["Products"]

    def test_the_input_columns_come_back_in_their_original_order_and_spelling(self) -> None:
        """`Brand ` keeps its trailing space — a column renamed on the way out is a column
        some downstream lookup stops finding.

        The first column is the deliberate exception. It used to be "Batch No/Name", read
        from a column in the input sheet; the sheet no longer carries one, because the name
        is typed once on the upload page. Reproducing a header for a column that was never
        supplied would be the dishonest option, so it comes back as what it is.
        """
        sheet = self._sheet(self._payload())
        headers = [sheet.cell(1, c).value for c in range(1, sheet.max_column + 1)]
        assert headers[:4] == [
            "Campaign/File Name",
            "Product Category",
            "Brand ",
            "Product Name",
        ]

    def test_the_campaign_column_carries_what_was_typed_at_upload(self) -> None:
        # The record the delivered sheet keeps of which run produced it, without anyone
        # maintaining a column for it.
        payload = self._payload()
        sheet = self._sheet(payload)
        assert sheet.cell(2, 1).value == payload.rows[0].batch_no

    def test_exactly_three_columns_are_added(self) -> None:
        sheet = self._sheet(self._payload())
        headers = [sheet.cell(1, c).value for c in range(1, sheet.max_column + 1)]
        assert headers[4:] == ["Meta Title", "Meta Description", "Keywords & Volumes"]

    def test_the_price_column_appears_only_when_a_price_exists(self) -> None:
        # An empty column on every row implies the tool failed to fill something in.
        without = self._sheet(self._payload())
        assert "Price (AED)" not in [
            without.cell(1, c).value for c in range(1, without.max_column + 1)
        ]

        priced_rows = (replace(self._payload().rows[0], price_aed=3499.0),)
        with_price = self._sheet(self._payload(rows=priced_rows, include_price=True))
        assert with_price.cell(1, 5).value == "Price (AED)"
        assert with_price.cell(2, 5).value == 3499.0

    def test_a_row_that_could_not_be_processed_keeps_its_place_and_says_why(self) -> None:
        rows = (
            replace(
                self._payload().rows[0],
                meta_title="", meta_description="", skip_reason="No product name in this row.",
            ),
        )
        sheet = self._sheet(self._payload(rows=rows))
        assert "NOT GENERATED" in str(sheet.cell(2, 5).value)

    def test_re_rendering_the_same_payload_is_byte_identical(self) -> None:
        payload = self._payload()
        assert build_template_workbook(payload) == build_template_workbook(payload)


class TestKeywordsUsedColumn:
    TERMS = (("apple iphone 17", 12100), ("iphone 17", 33100), ("android phone", 5000))

    def test_only_terms_that_reached_the_copy_are_listed(self) -> None:
        used = keywords_used_in("Explore the Apple iPhone 17 at e&.", self.TERMS)
        assert [k.term for k in used] == ["iphone 17", "apple iphone 17"]

    def test_listed_highest_demand_first(self) -> None:
        used = keywords_used_in("Apple iPhone 17", self.TERMS)
        assert [k.volume for k in used] == [33100, 12100]

    def test_an_unmeasured_term_says_so_rather_than_showing_zero(self) -> None:
        # No data is not no demand, and "0" would assert something nobody measured.
        assert KeywordUsage("smartpay", None).render() == "smartpay (no data)"
        assert KeywordUsage("iphone 17", 33100).render() == "iphone 17 (33,100)"

    def test_empty_copy_yields_no_keywords(self) -> None:
        assert keywords_used_in("", self.TERMS) == ()


# ---------------------------------------------------------------- the whole journey


@pytest.fixture()
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Any:
    from fastapi.testclient import TestClient

    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_path / 'test.db'}")
    monkeypatch.setenv("EXPORTS_DIR", str(tmp_path / "exports"))

    import app.config
    import app.db

    app.config.settings.cache_clear()
    app.db._engine = None
    app.db._session_factory = None

    from app.main import app as fastapi_app

    with TestClient(fastapi_app) as test_client:
        yield test_client

    app.config.settings.cache_clear()
    app.db._engine = None
    app.db._session_factory = None


class TestTheTemplateJourney:
    """Upload the real template, research, approve, generate, export — over HTTP."""

    PARTIAL = {"X-Partial": "1"}
    ROWS = 9

    def _run(self, client: Any) -> int:
        with TEMPLATE.open("rb") as handle:
            response = client.post(
                "/upload",
                data={"batch_no": "ignored"},
                files={"file": (TEMPLATE.name, handle, "application/vnd.ms-excel")},
                follow_redirects=False,
            )
        assert response.status_code == 303, response.text
        batch_id = int(response.headers["location"].split("/")[2])

        for index in range(1, self.ROWS + 1):
            assert client.get(
                f"/batch/{batch_id}/rows/{index}/keywords", headers=self.PARTIAL
            ).status_code == 200
        assert client.post(
            f"/batch/{batch_id}/approve", follow_redirects=False
        ).status_code == 303
        for index in range(1, self.ROWS + 1):
            assert client.get(
                f"/batch/{batch_id}/rows/{index}/generate", headers=self.PARTIAL
            ).status_code == 200
        client.get(f"/batch/{batch_id}/settle", headers=self.PARTIAL)
        return batch_id

    def test_the_batch_is_named_by_the_file_not_the_form(self, client: Any) -> None:
        # The template carries a Batch No/Name column, so taking the form value would
        # quietly rename what the team labelled.
        batch_id = self._run(client)
        assert "T1" in client.get("/history").text

    def test_nine_rows_in_yields_nine_rows_out(self, client: Any) -> None:
        import io

        import openpyxl

        batch_id = self._run(client)
        response = client.post(f"/batch/{batch_id}/export")
        assert response.status_code == 200, response.text
        sheet = openpyxl.load_workbook(io.BytesIO(response.content))["Products"]
        assert sheet.max_row == self.ROWS + 1

    def test_every_row_gets_a_title_and_a_description_inside_the_limits(
        self, client: Any
    ) -> None:
        import io

        import openpyxl

        from app.lib import limits

        batch_id = self._run(client)
        content = client.post(f"/batch/{batch_id}/export").content
        sheet = openpyxl.load_workbook(io.BytesIO(content))["Products"]
        title_col = sheet.max_column - 2
        for row in range(2, sheet.max_row + 1):
            title = str(sheet.cell(row, title_col).value or "")
            description = str(sheet.cell(row, title_col + 1).value or "")
            assert title and description, f"row {row}"
            assert limits.char_count(title) <= 60, title
            assert limits.char_count(description) <= 160, description

    def test_titles_are_unique_across_the_batch(self, client: Any) -> None:
        import io

        import openpyxl

        batch_id = self._run(client)
        content = client.post(f"/batch/{batch_id}/export").content
        sheet = openpyxl.load_workbook(io.BytesIO(content))["Products"]
        title_col = sheet.max_column - 2
        titles = [sheet.cell(r, title_col).value for r in range(2, sheet.max_row + 1)]
        assert len(set(titles)) == len(titles), titles

    def test_a_price_typed_into_a_row_reaches_the_copy(self, client: Any) -> None:
        """The whole point of the price control: a human types a figure, and only then
        may it appear in an indexed field."""
        batch_id = self._run(client)
        response = client.post(
            f"/batch/{batch_id}/rows/1/price", data={"price": "1,299"},
            headers=self.PARTIAL,
        )
        assert response.status_code == 200
        assert "AED 1,299" in response.text

    def test_clearing_the_price_removes_it_again(self, client: Any) -> None:
        batch_id = self._run(client)
        client.post(
            f"/batch/{batch_id}/rows/1/price", data={"price": "1,299"}, headers=self.PARTIAL
        )
        response = client.post(
            f"/batch/{batch_id}/rows/1/price", data={"price": ""}, headers=self.PARTIAL
        )
        assert "AED 1,299" not in response.text

    def test_an_unreadable_price_does_not_wipe_the_stored_one(self, client: Any) -> None:
        # A typo should not silently delete a correct figure.
        batch_id = self._run(client)
        client.post(
            f"/batch/{batch_id}/rows/1/price", data={"price": "1,299"}, headers=self.PARTIAL
        )
        response = client.post(
            f"/batch/{batch_id}/rows/1/price", data={"price": "about a grand"},
            headers=self.PARTIAL,
        )
        assert response.status_code == 200

        from app.db import session_scope
        from app.models import Batch

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            assert row.price_aed == 1299.0

    def test_redownload_from_history_is_byte_identical(self, client: Any) -> None:
        batch_id = self._run(client)
        first = client.post(f"/batch/{batch_id}/export")
        assert first.status_code == 200
        again = client.get("/exports/1/download")
        assert again.status_code == 200
        assert again.content == first.content

    def test_a_confidently_derived_brand_is_not_flagged(self, client: Any) -> None:
        """Only the absence of a brand is worth marking.

        Every derived brand used to be tagged "Eufy?", "Samsung?" — and since the
        template has no Brand column, that fired on every row of every batch. A marker
        that is always on carries no information, and a question mark after a word reads
        as doubt about the word rather than about where it came from.
        """
        batch_id = self._run(client)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert "brand--unknown" not in page, "every row in this file has a known brand"
        assert "Eufy?" not in page and "Samsung?" not in page

    def test_a_row_with_no_readable_brand_is_flagged(self) -> None:
        # The actionable case: without a brand, competitor terms cannot be filtered out
        # of that row's keywords.
        from app.lib.terms import derive_brand

        assert derive_brand("Smart Appliances") == ""


class TestSeededVolumesAreNotReachableByAccident:
    """After v1 went to leadership, the decision was that seeded volumes must never be
    served unless someone asks for them by name.

    They used to be what the absence of credentials resolved to, so a tool with no keys
    quietly served 29 numbers collected once for an Apple batch — labelled, but served.
    DECISIONS.md §29.
    """

    def _unconfigured(self, monkeypatch: pytest.MonkeyPatch) -> None:
        import app.config

        for name in (
            "KEYWORD_PROVIDER", "LLM_PROVIDER", "PAGE_PROVIDER",
            "DATAFORSEO_LOGIN", "DATAFORSEO_PASSWORD", "SEMRUSH_API_KEY",
            "OPENAI_API_KEY", "ANTHROPIC_API_KEY",
        ):
            monkeypatch.delenv(name, raising=False)
        app.config.settings.cache_clear()

    def test_no_credentials_resolves_to_unconfigured_not_to_fixtures(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.config import UNCONFIGURED, settings

        self._unconfigured(monkeypatch)
        assert settings().keyword_provider == UNCONFIGURED
        assert settings().llm_provider == UNCONFIGURED
        assert settings().configured is False

    def test_asking_for_a_volume_provider_raises_rather_than_seeding(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        from app.providers.keywords import NotConfiguredError, get_keyword_provider

        self._unconfigured(monkeypatch)
        with pytest.raises(NotConfiguredError) as excinfo:
            get_keyword_provider()
        message = str(excinfo.value)
        assert "will not invent or substitute" in message
        assert "DATAFORSEO_LOGIN" in message

    def test_the_copy_model_is_treated_the_same_way(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # One rule for both, so there is no half-state with real numbers and templated
        # copy.
        from app.providers.llm import ModelNotConfiguredError, get_llm

        self._unconfigured(monkeypatch)
        with pytest.raises(ModelNotConfiguredError) as excinfo:
            get_llm()
        assert "OPENAI_API_KEY" in str(excinfo.value)

    def test_pages_are_not_fetched_either(self, monkeypatch: pytest.MonkeyPatch) -> None:
        # Nothing to read a page with means nothing to read a page for.
        from app.config import settings

        self._unconfigured(monkeypatch)
        assert settings().page_provider == "none"

    def test_the_offline_demo_mode_still_works_when_asked_for(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """The break-glass: a venue with no network should not mean no demo. It cannot
        happen by itself — someone has to name it."""
        import app.config
        from app.providers.keywords import get_keyword_provider
        from app.providers.keywords._fixture import FixtureVolumeProvider

        self._unconfigured(monkeypatch)
        monkeypatch.setenv("KEYWORD_PROVIDER", "fixture")
        app.config.settings.cache_clear()

        provider = get_keyword_provider()
        assert isinstance(provider, FixtureVolumeProvider)
        # And it still announces itself as seeded.
        assert provider.is_live_data is False

    def test_the_upload_page_says_what_is_missing_rather_than_failing(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Refusing at the point of use means the tool still opens. Someone can look at
        the interface and be told what to add, instead of meeting a stack trace."""
        import app.config
        import app.db
        from fastapi.testclient import TestClient

        self._unconfigured(monkeypatch)
        app.db._engine = None
        app.db._session_factory = None
        from app.main import app as fastapi_app

        with TestClient(fastapi_app) as unconfigured_client:
            page = unconfigured_client.get("/upload")
            assert page.status_code == 200
            assert "Not configured for" in page.text
            assert "search volumes" in page.text
            assert "does not substitute sample figures" in page.text

        app.db._engine = None
        app.db._session_factory = None

    def test_healthz_reports_the_gap(self, monkeypatch: pytest.MonkeyPatch) -> None:
        import app.config
        import app.db
        from fastapi.testclient import TestClient

        self._unconfigured(monkeypatch)
        app.db._engine = None
        app.db._session_factory = None
        from app.main import app as fastapi_app

        with TestClient(fastapi_app) as unconfigured_client:
            health = unconfigured_client.get("/healthz").json()
            assert health["keyword_provider"] == "unconfigured"
            assert health["fully_live"] is False

        app.db._engine = None
        app.db._session_factory = None


class TestNoErrorIsInvisible:
    """An error that blocks the export must be findable on the page.

    A duplicate title blocked an export while the only thing on screen was
    "1 field need attention." — no row named, no cell flagged, nothing to click.
    Batch-level findings are about a relationship BETWEEN rows, so no cell owns them,
    and the banner threw away the row number they carry.
    """

    def test_a_batch_level_error_names_its_row_and_states_itself(self) -> None:
        from app.lib.validators import Finding
        from app.services.validation import batch_finding_row

        finding = Finding(
            code="DUPLICATE_TITLE",
            severity="error",
            message="Same title as row 2. Two pages competing on one title split their own ranking.",
            field="row5.meta_title_en",
        )
        assert batch_finding_row(finding) == 5

    def test_a_finding_with_no_row_is_handled(self) -> None:
        from app.lib.validators import Finding
        from app.services.validation import batch_finding_row

        assert batch_finding_row(
            Finding(code="X", severity="error", message="m", field="batch")
        ) is None

    def test_the_banner_spells_out_an_error_that_belongs_to_no_cell(
        self, client: Any
    ) -> None:
        from app.web import templates

        rendered = templates.get_template("_export_state.html").render(
            batch=type("B", (), {"id": 1})(),
            can_export=False,
            error_count=1,
            blocking_rows=[5],
            batch_errors=[
                {"row": 5, "message": "Same title as row 2. Two pages competing."}
            ],
        )
        assert "Row 5" in rendered
        assert "Same title as row 2" in rendered
        # ...and the count reads as English.
        assert "1 problem needs attention" in rendered
        assert "field need attention" not in rendered

    def test_the_plural_reads_correctly_too(self, client: Any) -> None:
        from app.web import templates

        rendered = templates.get_template("_export_state.html").render(
            batch=type("B", (), {"id": 1})(),
            can_export=False,
            error_count=3,
            blocking_rows=[2, 5],
            batch_errors=[],
        )
        assert "3 problems need attention" in rendered
        assert "rows 2, 5" in rendered

    def test_a_duplicate_title_is_reported_end_to_end(self, client: Any) -> None:
        """The whole path: two rows given the same title, export blocked, and the reason
        visible on the page rather than only in the count."""
        import io

        import openpyxl

        from app.db import session_scope
        from app.models import Batch

        book = openpyxl.Workbook()
        sheet = book.active
        assert sheet is not None
        sheet.title = "Products"
        for column, header in enumerate(
            ("Batch No/Name", "Product Category", "Brand ", "Product Name"), start=1
        ):
            sheet.cell(1, column, header)
        for offset, name in enumerate(["Apple iPhone 17", "Apple iPhone 17"], start=2):
            sheet.cell(offset, 1, "T1")
            sheet.cell(offset, 2, "Smartphones")
            sheet.cell(offset, 4, name)
        buffer = io.BytesIO()
        book.save(buffer)
        buffer.seek(0)

        response = client.post(
            "/upload",
            data={"batch_no": "T1"},
            files={"file": ("dupes.xlsx", buffer, "application/vnd.ms-excel")},
            follow_redirects=False,
        )
        batch_id = int(response.headers["location"].split("/")[2])
        for index in (1, 2):
            client.get(f"/batch/{batch_id}/rows/{index}/keywords", headers={"X-Partial": "1"})
        client.post(f"/batch/{batch_id}/approve", follow_redirects=False)
        for index in (1, 2):
            client.get(f"/batch/{batch_id}/rows/{index}/generate", headers={"X-Partial": "1"})
        client.get(f"/batch/{batch_id}/settle", headers={"X-Partial": "1"})

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            titles = {
                c.text for row in batch.rows for c in row.copy_fields
                if c.field == "meta_title_en" and c.is_current
            }
        if len(titles) > 1:
            pytest.skip("the generator disambiguated these rows; nothing to report")

        page = client.get(f"/batch/{batch_id}/step/3").text
        assert "Same title as row" in page, "the blocking reason must be on the page"


class TestEmptyUpload:
    def _blank_template(self, tmp_path: Path) -> Path:
        """The supplied template with its headers and no products — what someone sends
        when they download the template and upload it before filling it in."""
        import openpyxl

        book = openpyxl.Workbook()
        sheet = book.active
        assert sheet is not None
        sheet.title = "Products"
        for column, header in enumerate(
            ("Batch No/Name", "Product Category", "Product Name"), start=1
        ):
            sheet.cell(1, column, header)
        # Formatted down to row 101 with nothing in it, exactly as the real one is.
        sheet.cell(101, 3, None)
        target = tmp_path / "Product_Input_Template.xlsx"
        book.save(target)
        return target

    def test_a_file_with_no_products_is_refused_with_a_reason(
        self, client: Any, tmp_path: Path
    ) -> None:
        """Uploading the blank template used to create a batch of zero rows and land on
        a keyword page with nothing on it — indistinguishable from one still loading, and
        reported as "the keywords page is stuck". The tool had read the file correctly
        and simply never said it was empty."""
        blank = self._blank_template(tmp_path)
        with blank.open("rb") as handle:
            response = client.post(
                "/upload",
                data={"batch_no": "Batch 1"},
                files={"file": (blank.name, handle, "application/vnd.ms-excel")},
                follow_redirects=False,
            )
        assert response.status_code == 400
        assert "has no products in it" in response.text
        assert "every row below them is empty" in response.text

    def test_the_refusal_names_the_headers_it_found(
        self, client: Any, tmp_path: Path
    ) -> None:
        # So a file whose headers are wrong is diagnosable from the message, rather than
        # needing someone to open the sheet and compare by eye.
        blank = self._blank_template(tmp_path)
        with blank.open("rb") as handle:
            response = client.post(
                "/upload",
                data={"batch_no": "Batch 1"},
                files={"file": (blank.name, handle, "application/vnd.ms-excel")},
                follow_redirects=False,
            )
        assert "Product Name" in response.text
        assert "Products" in response.text

    def test_no_empty_batch_is_created(self, client: Any, tmp_path: Path) -> None:
        blank = self._blank_template(tmp_path)
        with blank.open("rb") as handle:
            client.post(
                "/upload",
                data={"batch_no": "Batch 1"},
                files={"file": (blank.name, handle, "application/vnd.ms-excel")},
                follow_redirects=False,
            )
        from app.db import session_scope
        from app.models import Batch

        with session_scope() as session:
            # Asserted on the file rather than on the total, because fixture mode seeds a
            # demo batch at startup and that one is supposed to be there.
            from_this_file = [
                b for b in session.query(Batch).all()
                if b.source_file_name == blank.name
            ]
            assert from_this_file == []


class TestEditing:
    """A human edit has to reach the export, survive validation, and stay auditable."""

    PARTIAL = {"X-Partial": "1"}

    def _generated(self, client: Any) -> int:
        with TEMPLATE.open("rb") as handle:
            response = client.post(
                "/upload",
                data={"batch_no": "ignored"},
                files={"file": (TEMPLATE.name, handle, "application/vnd.ms-excel")},
                follow_redirects=False,
            )
        batch_id = int(response.headers["location"].split("/")[2])
        for index in range(1, 10):
            client.get(f"/batch/{batch_id}/rows/{index}/keywords", headers=self.PARTIAL)
        client.post(f"/batch/{batch_id}/approve", follow_redirects=False)
        for index in range(1, 10):
            client.get(f"/batch/{batch_id}/rows/{index}/generate", headers=self.PARTIAL)
        client.get(f"/batch/{batch_id}/settle", headers=self.PARTIAL)
        return batch_id

    def test_the_copy_page_offers_an_edit_control(self, client: Any) -> None:
        batch_id = self._generated(client)
        page = client.get(f"/batch/{batch_id}/step/3").text
        assert page.count(">Edit<") >= 18  # both fields on all nine rows

    def test_the_editor_opens_with_the_current_text(self, client: Any) -> None:
        batch_id = self._generated(client)
        current = self._current(batch_id, "meta_title_en")
        editor = client.get(
            f"/batch/{batch_id}/rows/1/fields/meta_title_en/editor", headers=self.PARTIAL
        )
        assert editor.status_code == 200
        assert current in editor.text
        assert 'name="text"' in editor.text

    def _current(self, batch_id: int, field: str) -> str:
        from app.db import session_scope
        from app.models import Batch
        from app.services.validation import current_text

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            return current_text(row, field)

    def test_a_saved_edit_becomes_the_shown_text(self, client: Any) -> None:
        batch_id = self._generated(client)
        response = client.post(
            f"/batch/{batch_id}/rows/1/fields/meta_title_en/edit",
            data={"text": "Eufy Robot Vacuum Omni S1 Pro | e&"},
            headers=self.PARTIAL,
        )
        assert response.status_code == 200
        assert "Eufy Robot Vacuum Omni S1 Pro | e&" in response.text

    def test_a_saved_edit_is_what_gets_exported(self, client: Any) -> None:
        """The whole point. If the export still carried the generated text, editing
        would be theatre."""
        import io

        import openpyxl

        batch_id = self._generated(client)
        edited = "Eufy Robot Vacuum Omni S1 Pro | e&"
        client.post(
            f"/batch/{batch_id}/rows/1/fields/meta_title_en/edit",
            data={"text": edited},
            headers=self.PARTIAL,
        )
        content = client.post(f"/batch/{batch_id}/export").content
        sheet = openpyxl.load_workbook(io.BytesIO(content))["Products"]
        title_col = sheet.max_column - 2
        assert sheet.cell(2, title_col).value == edited

    def test_the_generated_original_is_kept_not_overwritten(self, client: Any) -> None:
        from app.db import session_scope
        from app.models import Batch

        batch_id = self._generated(client)
        original = self._current(batch_id, "meta_title_en")
        client.post(
            f"/batch/{batch_id}/rows/1/fields/meta_title_en/edit",
            data={"text": "Something else entirely | e&"},
            headers=self.PARTIAL,
        )
        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            titles = [c for c in row.copy_fields if c.field == "meta_title_en"]
            assert original in [c.text for c in titles], "the original attempt was lost"
            current = [c for c in titles if c.is_current]
            assert len(current) == 1
            assert current[0].edited_by_user is True

    def test_an_edit_is_validated_like_generated_copy(self, client: Any) -> None:
        # The rules are about what gets published, not about who typed it.
        batch_id = self._generated(client)
        response = client.post(
            f"/batch/{batch_id}/rows/1/fields/meta_title_en/edit",
            data={"text": "x" * 120},
            headers=self.PARTIAL,
        )
        assert "Too long" in response.text

    def test_an_edit_that_breaks_a_rule_blocks_the_export(self, client: Any) -> None:
        batch_id = self._generated(client)
        client.post(
            f"/batch/{batch_id}/rows/1/fields/meta_title_en/edit",
            data={"text": "x" * 120},
            headers=self.PARTIAL,
        )
        assert client.post(f"/batch/{batch_id}/export").status_code == 409

    def test_a_price_nobody_supplied_cannot_be_typed_in_either(self, client: Any) -> None:
        """Editing is not a way around the price rule. Row 1 has no price in the sheet,
        so a figure in its description is still a blocking error."""
        batch_id = self._generated(client)
        client.post(
            f"/batch/{batch_id}/rows/1/fields/meta_description_en/edit",
            data={"text": "Shop the Eufy Robot Vacuum from AED 1,299 via SmartPay with e&."},
            headers=self.PARTIAL,
        )
        assert client.post(f"/batch/{batch_id}/export").status_code == 409

    def test_cancel_restores_the_stored_text(self, client: Any) -> None:
        batch_id = self._generated(client)
        current = self._current(batch_id, "meta_title_en")
        cell = client.get(
            f"/batch/{batch_id}/rows/1/fields/meta_title_en/cell", headers=self.PARTIAL
        )
        assert cell.status_code == 200
        assert current in cell.text
        assert 'name="text"' not in cell.text

    def test_edited_copy_is_marked_as_edited(self, client: Any) -> None:
        batch_id = self._generated(client)
        response = client.post(
            f"/batch/{batch_id}/rows/1/fields/meta_title_en/edit",
            data={"text": "Eufy Robot Vacuum Omni S1 Pro | e&"},
            headers=self.PARTIAL,
        )
        assert "badge-edited" in response.text


class TestLoadingFeedback:
    """A row waiting on two APIs must look like it is working, and say what for."""

    def _pending_batch(self, client: Any) -> int:
        with TEMPLATE.open("rb") as handle:
            response = client.post(
                "/upload",
                data={"batch_no": "ignored"},
                files={"file": (TEMPLATE.name, handle, "application/vnd.ms-excel")},
                follow_redirects=False,
            )
        return int(response.headers["location"].split("/")[2])

    def test_a_row_that_is_working_shows_a_skeleton_and_a_spinner(
        self, client: Any
    ) -> None:
        """Only the rows actually working, which since paging landed is not all of them.

        The fixture has nine rows and eight start on load, so the ninth is queued. It must
        NOT shimmer: a skeleton and a spinner claim work is in progress, and claiming it
        for a row the server has not been asked about yet is the same dishonesty as a
        progress bar that advances on a timer.
        """
        from app.lib.policy import ROWS_PER_PAGE

        batch_id = self._pending_batch(client)
        page = client.get(f"/batch/{batch_id}/step/2").text

        assert page.count('class="working"') == ROWS_PER_PAGE
        assert page.count('class="skel') >= ROWS_PER_PAGE
        assert page.count('data-s="queued"') == 9 - ROWS_PER_PAGE
        assert "loads when you scroll down" in page

    def test_the_wait_says_what_is_happening(self, client: Any) -> None:
        # A five-second pause is easier to sit through when the screen says what is
        # going on — in the reader's terms, not the supplier's.
        batch_id = self._pending_batch(client)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert 'data-verb="Researching"' in page
        assert 'data-label="sample data"' in page

    def test_no_vendor_name_reaches_the_screen(self, client: Any) -> None:
        """Which supplier produced a number is an operational fact, not something a
        content writer can act on, and it read as leaked plumbing on a screen meant for
        senior leadership. It stays in /healthz, the audit trail and each keyword's
        stored `source`."""
        batch_id = self._pending_batch(client)
        for page in (
            client.get(f"/batch/{batch_id}/step/2").text,
            client.get(f"/batch/{batch_id}/step/3").text,
        ):
            for vendor in ("DataForSEO", "OpenAI", "gpt-", "claude-", "Semrush", "Fixture"):
                assert vendor not in page, vendor

    def test_the_operational_detail_is_still_available_off_screen(
        self, client: Any
    ) -> None:
        # Removed from the UI, not from the record — otherwise "which provider gave us
        # this number" becomes unanswerable.
        health = client.get("/healthz").json()
        assert "keyword_provider" in health and "llm_provider" in health

    @pytest.mark.parametrize(
        ("volumes", "model", "expected"),
        [
            (False, False, "sample data"),
            (True, True, "finding keywords and writing copy"),
            (True, False, "finding keywords"),
            (False, True, "writing copy"),
        ],
    )
    def test_the_label_describes_the_work_not_the_supplier(
        self, volumes: bool, model: bool, expected: str
    ) -> None:
        from app.routers.wizard import _waiting_label

        assert _waiting_label(volumes, model) == expected

    def test_the_progress_element_is_present_and_starts_hidden(self, client: Any) -> None:
        # Hidden until the script counts a real pending row, so a fully-loaded page
        # never shows a progress bar for work that is not happening.
        batch_id = self._pending_batch(client)
        page = client.get(f"/batch/{batch_id}/step/2").text
        assert "data-progress" in page
        assert "hidden" in page.split("data-progress", 1)[1][:400]

    def test_a_revoked_key_explains_itself_instead_of_returning_a_500(
        self, client: Any, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """What a revoked OpenAI key actually did: nine HTTP 500s and "Could not load
        this", while the sentence that mattered sat in a log file.

        A provider being unusable is a configuration problem, not a row failure. It has to
        name the service, quote what the service said, and state the fix.
        """
        from app.providers.llm import ModelNotConfiguredError

        batch_id = self._pending_batch(client)
        for index in range(1, 10):
            client.get(f"/batch/{batch_id}/rows/{index}/keywords", headers={"X-Partial": "1"})
        client.post(f"/batch/{batch_id}/approve", follow_redirects=False)

        async def rejected(*args: Any, **kwargs: Any) -> Any:
            raise ModelNotConfiguredError(
                "OpenAI rejected the credentials: Error code: 401 - "
                "Your API key has been invalidated."
            )

        monkeypatch.setattr("app.services.generation.generate_row", rejected)

        response = client.get(
            f"/batch/{batch_id}/rows/1/generate", headers={"X-Partial": "1"}
        )
        assert response.status_code == 200, "a bad key is not a server error"
        assert "The copy model could not be used" in response.text
        assert "Your API key has been invalidated" in response.text
        assert "OPENAI_API_KEY" in response.text
        assert "run.ps1 -Keys" in response.text

    def test_a_blocked_row_stays_retryable(
        self, client: Any, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        # Fixing the credentials and reloading must pick the row up, so it must not be
        # marked failed on the way out.
        from app.db import session_scope
        from app.models import Batch, RowStage
        from app.providers.llm import ModelNotConfiguredError

        batch_id = self._pending_batch(client)
        for index in range(1, 10):
            client.get(f"/batch/{batch_id}/rows/{index}/keywords", headers={"X-Partial": "1"})
        client.post(f"/batch/{batch_id}/approve", follow_redirects=False)

        async def rejected(*args: Any, **kwargs: Any) -> Any:
            raise ModelNotConfiguredError("nope")

        monkeypatch.setattr("app.services.generation.generate_row", rejected)
        client.get(f"/batch/{batch_id}/rows/1/generate", headers={"X-Partial": "1"})

        with session_scope() as session:
            batch = session.get(Batch, batch_id)
            assert batch is not None
            row = next(r for r in batch.rows if r.row_index == 1)
            assert row.stage is not RowStage.failed

    def test_the_copy_page_has_its_own_label(self, client: Any) -> None:
        batch_id = self._pending_batch(client)
        for index in range(1, 10):
            client.get(f"/batch/{batch_id}/rows/{index}/keywords", headers={"X-Partial": "1"})
        client.post(f"/batch/{batch_id}/approve", follow_redirects=False)
        page = client.get(f"/batch/{batch_id}/step/3").text
        assert 'data-verb="Writing"' in page
        assert 'data-row-prefix="cp-"' in page
