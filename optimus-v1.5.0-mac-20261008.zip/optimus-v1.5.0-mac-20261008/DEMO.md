# Optimus — showcase walkthrough

Six products, researched live against Google's own volume data, copy written to the e& SEO
Copy Guidelines. Everything below is real: no staged data, no pacing, no pre-recorded
numbers.

## The link

```
http://127.0.0.1:8123/batch/6/step/2
```

That is the prepared **Demo** batch: researched, tiered, selling points proposed, copy
written, ready to export. Two of the three steps are below it in the stepper, so you can
walk the whole journey from there.

Build **v1.3.0**, shown in the masthead. One journey — there are no longer any "lab" pages
to avoid or explain.

If the server is not answering, start it:

```bash
.\start.bat
```

### What is already in it

| | |
|---|---|
| Products | 6 — iPhone 17 Pro, Galaxy S25 Ultra, Watch Ultra 3, Sony WH-1000XM6, Eufy X10, Philips NeoPix |
| Keywords measured | 72 across the batch, every figure from Google Ads |
| Prices from the sheet | 3 of 6, so the priced and unpriced paths sit side by side |
| `research only` chips | 9 — real demand the copy is not allowed to use |
| Selling points proposed | 27, of which 2 are already approved |
| Tier 1 errors | **0** |
| Export | verified: 6 rows in, 6 rows out |

Timings, measured on this build: **171s** to research all six rows, **230s** to write the
copy. Worth quoting if anyone asks — and worth saying that almost all of it is time spent
waiting on Google and the model, not on this laptop.

---

## The one-line version

> It turns a four-column product list into guideline-compliant meta titles and
> descriptions, with real search volumes attached — and it makes the specific mistakes in
> our current output structurally impossible rather than something a careful human has to
> catch.

---

## 1. Upload — what the team actually has to provide

Show the input sheet: **Batch No/Name, Product Category, Brand, Product Name**, plus an
optional **Price**. That is all.

Worth saying out loud: everything else — the keywords, their volumes, the copy — is
produced from those four columns. There is no spreadsheet of research to maintain.

---

## 2. Keywords — the page that does the work

### Real volumes, and visible gaps

Every number on this page came from Google Ads via DataForSEO. None was produced by a
model, and that is enforced structurally, not by convention — there is a test that walks
the import graph and fails if a code path could ever carry a model's output into a volume
field.

Point at **"terms with no search data"**. Those are terms we asked about and got nothing
back for. They are kept on purpose: *"we asked and there is no data"* and *"we never
asked"* look identical once a term disappears, and only one of them is a finding.

Good numbers to point at: `apple` at **165,000** a month, `iphone 17 pro` at **90,500**,
`projector` at **8,100**. And note that `apple` is *not* the primary on any Apple row —
the bare manufacturer is a term no single product page can win, and one every other Apple
row would compete with. The tool refuses to pick it even though it is the biggest number
on the page.

### Tiering — primary, secondary, tertiary

**Row 1 already shows all three**, so you can point at them before touching anything:
`iphone 17 pro` primary, `apple` / `iphone17 pro` secondary, `i phone 17 pro` tertiary.

Click any keyword. It cycles **primary → secondary → tertiary → clear**.

- **Primary** goes in the title. One per product.
- **Secondary** is worked into the description.
- **Tertiary** is used only if there is room.

Each tier reaches the model as a genuinely different instruction, which implements a line
from the guidelines the tool previously only half-honoured: *"Include the primary keyword
and, where possible, secondary and tertiary keywords."*

Note the **1st / 2nd / 3rd** labels. Colour is never the only signal, so the state
survives a projector that washes out the ambers, a colour-blind viewer and a screen
reader.

### The chip marked `research only`

This is the best thing to linger on, because it shows the tool reasoning about publishing
rules rather than just fetching numbers. There are **nine** of them in this batch; row 1
has five, including:

> `iphone 17 pro price in uae` — **research only**

Real demand. People search it. But e& cannot put the word "price" in an indexed meta
description, because promotional pricing goes stale on a page that outlives the promotion.
So the tool reports the demand and refuses to let that term into the copy. The chip cannot
be tiered, and it says why when you hover it.

The honest framing: **search volume tells you how many people want something. It tells you
nothing about whether you are allowed to say it.** Those are two different questions and
the tool now models both.

### Editing the research

Click **edit** on any keyword. Note the warning:

> Saving looks the term up again. Its figure of 590 belongs to the old wording, so it is
> replaced, not carried over.

This is the rule that matters. Reword "home projector" to "home projectors" and 590 is a
figure for a query nobody measured. Carrying it across would attach a real number to the
wrong term — exactly as wrong as inventing one. So an edit re-measures, and if Google has
no data for the new wording the figure is cleared rather than inherited.

**Add & measure** adds a term the researcher knows the market for. It goes through the same
lookup as everything else; a hand-typed term cannot acquire a volume the provider did not
supply.

**×** removes a term — and it is recoverable. Open **"removed"** and restore it. Nothing on
this page is destroyed, which is also what makes the audit trail complete.

---

## 3. Selling points — what the writer needs that keywords cannot give

Keywords tell you what people type. They never tell you **why anyone buys the thing**.

The right-hand column proposes USPs per product — 27 across this batch. **Rows 1 and 2
each have one already approved** (`Latest iPhone design`, `Premium Samsung flagship
experience`), so you can show both states next to each other. Rows 3 to 6 have theirs
untouched, ready to tick live.

Three things to show:

**Nothing is pre-ticked.** A keyword gets a starting tier because a measured term is
evidence. A USP is an unverified claim, so pre-ticking one would put words in a writer's
mouth that nobody chose. Ticking is a person taking responsibility — it records who and
when.

**The `check` flag.** It marks a claim that came from the model's own knowledge rather than
off a product page. That flag is never set from the model's own say-so; it is checked
against whether a page was actually read. The label is the whole basis on which a reviewer
decides how hard to verify something, so it is not left to the thing being reviewed.

**Try typing a price claim.** Put *"Cheapest price in Dubai"* in the box and submit:

> Cannot be used: contains a price or discount claim. Promotional pricing must not be
> indexed.

Same rule as the keywords, same reason, refused at the point of entry rather than
discovered two pages later.

---

## 4. Copy — the limits are the product

Approve, and move to the copy page.

### Every limit is measured, not estimated

- **Characters** are counted the way Excel's `LEN()` counts them, so the number on screen
  matches the number in the exported workbook.
- **Pixels** are measured from real Arial advance widths, because Google truncates on
  width, not on character count. Labelled as an estimate, ±3%, because it is one.

### The guidelines are enforced, each one named

UK spelling. An action verb. SmartPay in the second sentence. No keyword stuffing. No
invented specification. No earlier product generation. No competitor named. Each is a
validator with a name a content person can read against their own document — the prompt
asks, but only the validator decides.

### The approved claim, in the copy

Row 1's description, written after a person ticked *"Latest iPhone design"*:

> Shop Apple iPhone 17 Pro for the **latest iPhone design** and a fresh look for your next
> smartphone. Get it for AED 4,299 with SmartPay.

It is there because someone approved it. Untick it, hit **Refresh**, and it goes.

### What is *not* in it

Worth pointing at, because it was there until this build: **no "in the UAE".** Not in a
single title or description across the batch.

The tool used to add it almost everywhere — `iPhone 17 Pro by Apple in the UAE | e&` — and
it was never a requirement. Nothing in the brief or the guidelines asks for it; it came
from three lines in the prompts that described the market as context, which a model reads
as a thing worth saying. It spent a 38-character title telling a reader which country they
were already shopping in, usually spent it twice by repeating the phrase in the
description, and had become the model's laziest way of making two titles differ.

A location now appears only where a person put one: in a keyword they tiered, or in text
they typed. Enforced as a blocking error, so the regeneration loop removes it rather than
reporting it and leaving it in place.

### Price — the one place a figure may enter copy

Rows **1, 3 and 5** have a price from the sheet (AED 4,299 / 3,199 / 1,499); the others do
not, and they carry a warning saying the description cannot meet the second-sentence price
rule.

Show the **price box** on an unpriced row. Type a figure, hit **Update price**, and the
description is rewritten around it.

The rule underneath: a model is never asked what something costs. It is handed a figure a
person supplied, and the validator forgives **exactly that string and nothing else**. A
model inventing "AED 2,999" fails. The same figure, typed by a human, passes. That is the
whole mechanism.

### Edit, and the export

**Edit** any field. The revised text is what reaches the export — and every attempt is
retained, so the history of what was generated, rejected and corrected stays complete.

Export gives back **the input sheet** with three columns added: Meta Title, Meta
Description, and the keywords used with their volumes. Same rows, same order, nothing
dropped. Already verified for this batch:

```
Batch No/Name | Product Category | Brand | Product Name | Price (AED) |
Meta Title | Meta Description | Keywords & Volumes
```

...and the keywords column holds only terms that actually appear in the copy, with the
figure beside each: `apple (165,000), iphone 17 pro (90,500)`.

That last point is worth saying plainly: **21 rows in, 21 rows out.** In the current
process, 16 of 21 rows were silently lost. That cannot happen here — there is a test that
fails if it does.

---

## If someone asks

**"How fast is it?"** About 20–40 seconds a row for research, three rows at a time, then a
few seconds a row for copy. Almost all of it is spent waiting on Google and the model, so
more compute does not help much — overlapping the calls and caching repeated terms do.

**"What does it cost to run?"** One DataForSEO charge per request, not per keyword, plus
the model calls. A six-row batch is pennies. The expensive mistake would be re-researching
the same terms, which is the next thing worth caching.

**"Can it do Arabic?"** The schema is locale-aware and the byte-length rules are already in
place for it. Not switched on: a character limit means something different when invisible
tashkeel marks count toward it, and that is a decision for the content team, not a default
I should pick.

**"Is this the model writing whatever it likes?"** No. The model proposes; validators
decide. A failing field is regenerated with the actual failure fed back, up to three times,
and then it goes to a queue for a human — it is never truncated to fit and never shipped
invalid.

---

## Known limitations — say these before someone finds them

- **Product names must have spaces.** A name like `airpodsmax2` cannot be matched against
  search terms, so those rows get no primary keyword. It is input dirt, and it shows.
- **Copy rows are written one at a time.** Research overlaps; generation does not yet.
- **Nothing is cached between batches.** The same term researched twice is paid for twice.
- **Pixel widths are an estimate.** No kerning, no font shaping. Gated on characters too.
