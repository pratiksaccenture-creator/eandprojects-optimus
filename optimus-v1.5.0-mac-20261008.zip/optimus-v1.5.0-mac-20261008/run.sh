#!/usr/bin/env bash
# Start the tool on macOS. The equivalent of run.ps1 for the office Mac Studio.
#
#   ./run.sh            start on http://127.0.0.1:8123 (this machine only)
#   ./run.sh --setup    create the virtualenv and install dependencies, then exit
#   ./run.sh --check    run the tests and the type checker, then exit
#   ./run.sh --keys     verify the live API credentials, then exit (costs nothing)
#
#   HOST=0.0.0.0 ./run.sh    also reachable from the office network. There is no login
#                            yet — anyone on that network can use it. See MAC_SETUP.md.
#
# Unlike run.ps1, --setup exits rather than going on to start the server, so a setup run
# from Claude Code finishes instead of sitting on a server that never returns.

set -euo pipefail
cd "$(dirname "$0")"

HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-8123}"
# The python.org installer's python3, not Apple's /usr/bin/python3 (3.9, too old). Set
# PYTHON to a full path if `python3` on this Mac resolves to the wrong one.
PYTHON="${PYTHON:-python3}"
PY=".venv/bin/python"
MODE="${1:-}"

if [[ "$MODE" == "--setup" || ! -x "$PY" ]]; then
    echo "Creating virtualenv and installing dependencies..."
    "$PYTHON" -m venv .venv
    "$PY" -m pip install --upgrade pip --quiet
    "$PY" -m pip install -r requirements.txt
    # app/lib/advance_widths.json ships with the build and is deliberately not
    # regenerated here. The extractor only knows Windows and Linux font paths, and a
    # different Arial revision would shift every pixel-width figure from the laptop's.
    if [[ "$MODE" == "--setup" ]]; then
        echo "Setup complete. Start the tool with ./run.sh"
        exit 0
    fi
fi

if [[ "$MODE" == "--keys" ]]; then
    exec "$PY" tools/check_credentials.py
fi

if [[ "$MODE" == "--check" ]]; then
    echo; echo "Running tests..."
    "$PY" -m pytest
    echo; echo "Type checking..."
    "$PY" -m mypy
    echo; echo "All checks passed."
    exit 0
fi

echo "Starting on http://$HOST:$PORT"
echo "Credentials come from .env. Run './run.sh --keys' to check them (free)."
exec "$PY" -m uvicorn app.main:app --host "$HOST" --port "$PORT"
