"""Extract per-character advance widths from a TrueType font into a vendored JSON table.

Run once at build time; the output is committed so the app never needs fontTools at runtime:

    python tools/extract_font_metrics.py

Brief §6 forbids node-canvas and there is no browser, so pixel width is computed from the
font's own hmtx table. The output records provenance so the numbers on screen are traceable
to a specific font binary rather than being unattributable constants.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import sys
from pathlib import Path

from fontTools.ttLib import TTFont

# Arial is used for measurement only, never redistributed or rendered by this tool.
# Liberation Sans is a metrically compatible OFL substitute if licensing objects.
CANDIDATES = [
    Path(r"C:\Windows\Fonts\arial.ttf"),
    Path(r"C:\Windows\Fonts\LiberationSans-Regular.ttf"),
    Path("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"),
]

OUT = Path(__file__).resolve().parents[1] / "app" / "lib" / "advance_widths.json"


def main() -> int:
    src = next((p for p in CANDIDATES if p.exists()), None)
    if src is None:
        print("No candidate font found. Looked in:", file=sys.stderr)
        for p in CANDIDATES:
            print(f"  {p}", file=sys.stderr)
        return 1

    raw = src.read_bytes()
    font = TTFont(src, fontNumber=0)
    upm: int = font["head"].unitsPerEm
    cmap = font.getBestCmap()
    hmtx = font["hmtx"]

    widths: dict[str, int] = {}
    for codepoint, glyph_name in cmap.items():
        metrics = hmtx.metrics.get(glyph_name)
        if metrics is None:
            continue
        widths[str(codepoint)] = int(metrics[0])

    # Fallback for characters the font does not cover. Mean of the printable ASCII
    # range is a better guess than zero, and misses are counted at measure time so
    # they surface in the UI rather than silently scoring nothing.
    ascii_widths = [widths[str(c)] for c in range(0x20, 0x7F) if str(c) in widths]
    fallback = round(sum(ascii_widths) / len(ascii_widths)) if ascii_widths else upm // 2

    family: str = font["name"].getDebugName(1)
    revision = round(float(font["head"].fontRevision), 4)
    digest = hashlib.sha256(raw).hexdigest()

    provenance: dict[str, object] = {
        "source_file": src.name,
        "font_family": family,
        "font_revision": revision,
        "sha256": digest,
        "units_per_em": upm,
        "glyph_count": len(widths),
        "extracted_utc": dt.datetime.now(dt.UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "extracted_by": "tools/extract_font_metrics.py",
        "accuracy_note": (
            "Advance widths only. No kerning, no ligatures, no OpenType shaping, "
            "no hinting or subpixel positioning. Scaled linearly by font size. "
            "Treat as an estimate within roughly 3% for Latin text; not valid for "
            "Arabic, which requires contextual shaping."
        ),
    }
    payload: dict[str, object] = {
        "_provenance": provenance,
        "units_per_em": upm,
        "fallback_width": fallback,
        "widths": {k: widths[k] for k in sorted(widths, key=int)},
    }

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, indent=1, sort_keys=False) + "\n", encoding="utf-8")

    print(f"Wrote {OUT}")
    print(f"  family    : {family}")
    print(f"  revision  : {revision}")
    print(f"  unitsPerEm: {upm}")
    print(f"  glyphs    : {len(widths)}")
    print(f"  fallback  : {fallback}")
    print(f"  sha256    : {digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
