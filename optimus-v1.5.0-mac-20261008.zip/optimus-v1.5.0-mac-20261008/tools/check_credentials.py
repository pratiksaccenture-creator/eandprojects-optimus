"""Confirm the live credentials work, without spending anything.

    .\\.venv\\Scripts\\python.exe tools\\check_credentials.py

Both checks hit endpoints that are free on both accounts: DataForSEO's `appendix/user_data`
(which also reports the balance) and OpenAI's model list. Nothing here generates copy or
looks up a volume, so it can be run as often as you like and before the first real batch.

It lives in `tools/` rather than `app/` deliberately: it talks to vendor SDKs directly,
which is exactly what `tests/test_provider_boundary.py` forbids inside the application.
This is a diagnostic, not a code path the tool uses.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# Importing app.config loads `.env`, which is the thing under test.
from app.config import settings  # noqa: E402
from app.providers.llm._openai import model_name  # noqa: E402

ACCOUNT_ENDPOINT = "https://api.dataforseo.com/v3/appendix/user_data"
TIMEOUT = 30.0


def say(status: str, message: str) -> None:
    print(f"  [{status:^4}] {message}")


def check_dataforseo() -> bool:
    """Free account endpoint. Proves the login and API password are right, and shows the
    balance — the two things that otherwise only fail once a real batch is running."""
    print("\nDataForSEO")
    login = os.environ.get("DATAFORSEO_LOGIN", "")
    password = os.environ.get("DATAFORSEO_PASSWORD", "")
    if not login or not password:
        missing = [
            n for n, v in (("DATAFORSEO_LOGIN", login), ("DATAFORSEO_PASSWORD", password))
            if not v
        ]
        say("fail", f"not set: {', '.join(missing)}")
        return False

    try:
        response = httpx.get(
            ACCOUNT_ENDPOINT, auth=httpx.BasicAuth(login, password), timeout=TIMEOUT
        )
    except httpx.HTTPError as error:
        say("fail", f"could not reach the API: {error}")
        return False

    if response.status_code == 401:
        say("fail", "401 — wrong login or API password.")
        say("   ", "The password is the API password from app.dataforseo.com/api-access,")
        say("   ", "not the password you use to sign in to the dashboard.")
        return False

    payload = response.json() if response.headers.get("content-type", "").startswith(
        "application/json"
    ) else {}
    if payload.get("status_code") != 20000:
        say("fail", f"{payload.get('status_code')} {payload.get('status_message', '')}")
        return False

    tasks = payload.get("tasks") or [{}]
    results = tasks[0].get("result") or [{}]
    account = results[0]
    say("ok", f"authenticated as {account.get('login', login)}")

    money = account.get("money") or {}
    balance = money.get("balance")
    if isinstance(balance, (int, float)):
        say("ok" if balance > 0 else "warn", f"balance: ${balance:.2f}")
        if balance <= 0:
            say("   ", "A zero balance fails at request time, not here.")
    return True


def check_openai() -> bool:
    """Listing models is free and answers both questions at once: is the key valid, and is
    the configured model actually reachable by this account."""
    print("\nOpenAI")
    if not os.environ.get("OPENAI_API_KEY"):
        say("fail", "not set: OPENAI_API_KEY")
        return False

    import openai

    base_url = os.environ.get("OPENAI_BASE_URL") or None
    client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"], base_url=base_url)
    if base_url:
        say("ok", f"base URL: {base_url}")

    wanted = model_name()
    try:
        available = sorted(model.id for model in client.models.list())
    except openai.AuthenticationError as error:
        say("fail", f"the key was rejected: {error}")
        return False
    except openai.APIError as error:
        # A gateway may not expose /models. That is not a failure of the key.
        say("warn", f"could not list models ({error}); skipping the model-id check")
        return True

    say("ok", f"key accepted, {len(available)} models visible")
    if wanted in available:
        say("ok", f"model: {wanted}")
        return True

    say("fail", f"model {wanted!r} is not available to this account")
    near = [m for m in available if m.split("-")[0] == wanted.split("-")[0]]
    if near:
        say("   ", f"similar: {', '.join(near[:8])}")
    say("   ", "Set OPENAI_MODEL in .env to one your account can reach.")
    return False


def main() -> int:
    config = settings()
    print("Resolved providers")
    say("ok" if config.keyword_provider != "fixture" else "----",
        f"volumes: {config.keyword_provider}")
    say("ok" if config.llm_provider != "fixture" else "----",
        f"model:   {config.llm_provider}")
    say("ok" if config.page_provider != "none" else "----",
        f"pages:   {config.page_provider}")

    ok = True
    if config.keyword_provider == "dataforseo":
        ok &= check_dataforseo()
    if config.llm_provider == "openai":
        ok &= check_openai()

    if config.keyword_provider == "fixture" and config.llm_provider == "fixture":
        print("\nNothing live is configured — the tool will run on seeded data.")
        print("Copy .env.example to .env and fill it in to go live.")
        return 0

    print("\nAll good — nothing was charged for these checks." if ok
          else "\nSomething is wrong above. The tool will refuse to run rather than "
               "quietly fall back to seeded data.")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
