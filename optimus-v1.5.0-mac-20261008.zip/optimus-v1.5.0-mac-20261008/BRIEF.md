# Claude Code build prompt — e& SEO & AEO Copy Tool (clickable prototype)

> Paste everything below into Claude Code as the opening brief. Drop the two reference
> workbooks into `fixtures/` before you start so it can read the real schema.

---

## 0. What you are building and who it is for

Build a **clickable prototype** of an internal web tool for e&'s (Etisalat's) digital content
team in the UAE. It takes an Excel batch of product and category page URLs, researches keywords
with real search volumes, gets a human to approve those keywords, then generates SEO and AEO copy
inside hard character and pixel limits, and exports an Excel file in the team's existing format.

**Audience for this build: senior leadership, in a live demo.** Optimise for a walkthrough that
survives scrutiny, not for scale. That means:

- It must run end to end with **zero external API keys** using fixture data.
- Every number on screen must be traceable to a source, labelled as seeded where it is seeded.
- Nothing may be faked in a way a viewer could mistake for real. No mock tool outputs presented
  as live results, no invented search volumes, no placeholder lorem text in a field that looks
  finished.
- It must look like a tool, not a notebook. Clean, quiet, confident.

Do not build auth, multi-tenancy, RBAC, or deployment infrastructure. Do build the database and
the history feature properly, because "six months of downloadable history" is an explicit
requirement leadership will ask about.

---

## 1. Non-negotiable rules

These are the rules that make the tool defensible. Violating any one of them invalidates the
build even if everything else works.

1. **An LLM never produces a search volume.** Not as an estimate, not as a fallback, not
   "approximately". Volumes come only from a `KeywordVolumeProvider` implementation. If a
   provider returns no data for a term, that term is marked `unverified` and excluded. Never
   inferred, never interpolated.
2. **Every length limit is enforced in code, with unit tests.** Never by prompt instruction
   alone. A prompt asking for "under 60 characters" is a suggestion; a validator is a rule.
3. **No price, tariff, instalment, stock or promotional claim** in any field that will be
   indexed. The reference file has `AED 225/month` inside live meta descriptions. That is the
   defect we are removing, not a pattern to copy.
4. **Every generated string is traceable.** Persist which keywords fed it, which model produced
   it, which prompt version, which attempt number, and the validation result.
5. **The model provider is behind one module.** e& requires a governed, in-region deployment
   (Azure OpenAI UAE or an internal endpoint). The prototype may default to fixture mode, but
   repointing must be a single file change with no call-site edits.
6. **Failures are visible, never silent.** A row that cannot be processed produces an explicit
   skipped-with-reason record. The reference file silently dropped 16 of 21 rows; the tool must
   make that impossible.

---

## 2. Stack

- **Next.js 15 (App Router) + TypeScript + Tailwind**, single repo, `npm run dev` and it works
- **SQLite via Prisma** — real persistence, zero infra, one-line migration path to Postgres
- **ExcelJS** for reading and writing workbooks (it preserves formulas and cell styling; SheetJS
  does not round-trip formulas as reliably)
- **Zod** for all parsing and validation schemas
- **Vitest** for unit tests
- No component library. Hand-built components, Tailwind only.

Seed the database from `fixtures/` on first run.

---

## 3. Reference data: read these files first

Two real workbooks go in `fixtures/`. Read both before writing any code. Match their schema
exactly; do not tidy it up.

### `fixtures/input.xlsx` — sheet `SEO Batch 6 Product List`

21 rows, 5 columns: `Batch No` | `Date` | `Category` | `Product URL` | `Go Live`.

Observed characteristics you must handle:

- No product name column and no keyword column. Both are derived.
- Three URL shapes, which need different handling:
  - **category/content pages**: `https://www.eand.ae/en/c/home/smart-locks.html`
  - **eshop product deep links**: `.../eshop/devices/configuration/key-prod1t...?productId=prod1T...&skuId=...&catName=Earbuds&listVal=Smartphones`
  - **preprod URLs**: `https://preprodnew.eand.ae/...` — not publicly reachable. These must be
    classified `unreachable` with a reason, not silently blanked.
- `Go Live` is dirty: sometimes a date, sometimes the literal string
  `Will be shared when config Pages are live`, often empty. Parse permissively, never throw.
- Categories are inconsistently cased and spelled (`Devices - Iphone Family`,
  `Devices - iPhone 18 pro`). Normalise for grouping, preserve the original for display.

### `fixtures/output.xlsx` — the format you must reproduce

Sheet 1, `SEO Batch 6 Product List`, 14 columns:

| Col | Header | Notes |
|-----|--------|-------|
| A | `Batch No` | |
| B | `Date` | |
| C | `Category` | |
| D | `Product URL` | **defect: overwritten with product name in rows 10–14. Fix this.** |
| E | `Keywords ` | trailing space in the header is real — reproduce it |
| F | `Go Live` | |
| G, H, I | *(empty)* | reserved; filename says `EN_AR` so these were intended for Arabic |
| J | `Meta Title (EN)` | |
| K | `Character count (<60)` | contains `=LEN(J10)` — keep as a live formula |
| L | `Meta Decsription (EN)` | **typo in the original. Reproduce it verbatim.** |
| M | `Character count (<160)` | contains `=LEN(L10)` |
| N | *(empty, bold header style)* | reserved |

Sheet 2, `keywords ` (trailing space): 30 rows, keyword in A, volume in B, **no headers, no
product mapping, duplicates present** (`apple watch` at 33,100 appears twice). Use these real
volumes to seed the fixture provider. The output version of this tab must add headers and keys.

**Known defects in the reference file — build a failing test for each:**

- `M12` equals exactly 160 against a stated limit of under 160
- descriptions contain live prices (`AED 225/month`, `AED 549`)
- brand suffix ` | e&` present on 2 of 5 titles, absent on 3
- stale generation names in keyword cells (`apple watch ultra 3` on an Ultra 4 row)
- heavy duplication inside one keyword cell (`apple watch` ×4 in E12)
- em-dashes glued to adjacent words (`Pro—ultimate`), trailing whitespace

---

## 4. Data model (Prisma)

```
User            id, name, email                                    // mocked, no auth
Batch           id, batchNo, sourceFileName, sheetName, uploadedAt,
                userId, status, locale, retentionExpiresAt         // uploadedAt + 6 months
BatchRow        id, batchId, rowIndex, categoryRaw, categoryNorm,
                productUrl, productName, goLiveRaw, pageType,
                fetchStatus, skipReason
Keyword         id, batchRowId, term, termNormalized, type,
                volume, cpc, competition, source, dataDate,
                locale, geo, status, approvedByUserId, approvedAt
CopyField       id, batchRowId, field, locale, text, charCount,
                pixelWidth, graphemeCount, byteLength, valid,
                validationJson, model, promptVersion, attempt, createdAt
KeywordRegistry id, categoryNorm, term, primaryForRowId, firstSeenAt
Export          id, batchId, createdAt, filePath, rowCount, createdByUserId
AuditEvent      id, batchId, actor, action, payloadJson, createdAt
```

`pageType`: `product` | `category` | `content`
`fetchStatus`: `ok` | `unreachable` | `blocked` | `not_attempted`
`Keyword.type`: `category` | `brand` | `benefit` | `geo_prompt`
`Keyword.status`: `approved` | `parked` | `unverified` | `rejected`

**Retention:** a `purgeExpired()` job, invocable from a dev route, deletes batches past
`retentionExpiresAt`. Exports are **regenerated from stored records**, not served from a saved
blob, so history stays consistent with the data.

---

## 5. Keyword volume provider

```ts
interface KeywordVolumeProvider {
  readonly name: string;
  readonly isLiveData: boolean;
  lookup(terms: string[], opts: { geo: string; locale: string })
    : Promise<VolumeResult[]>;   // { term, volume | null, cpc?, competition?, dataDate, source }
}
```

Implement three:

1. **`FixtureVolumeProvider`** — default. Seeded from `fixtures/output.xlsx` sheet 2. Terms not
   in the fixture return `volume: null`, which must surface in the UI as `unverified`. Do not
   invent a number to fill the gap; the demo is more credible with visible gaps.
2. **`GoogleAdsKeywordPlannerProvider`** — stub with the real request shape, geo constant for
   UAE, language constant, and a clear `NotConfiguredError`. This is the recommended production
   source: free, authoritative, native UAE and Arabic targeting.
3. **`DataForSeoProvider`** — stub. Commercial fallback if Ads developer-token approval drags.

Selected by `KEYWORD_PROVIDER` env var. **The UI must always display which provider produced the
numbers on screen**, with a visible badge when `isLiveData` is false.

---

## 6. Length and width validation

This is the technical core. Get it right before building any UI.

`lib/limits.ts`:

```ts
measure(text: string): {
  chars: number;        // UTF-16 length, matches Excel LEN()
  graphemes: number;    // Intl.Segmenter — the honest count, and correct for Arabic
  bytes: number;        // UTF-8 — required for Apple's keyword field
  pixelsTitle: number;  // rendered width at SERP title size
  pixelsDesc: number;   // rendered width at SERP description size
}
```

Pixel width via a per-character advance-width table for Arial, scaled linearly by font size.
Do **not** pull in `node-canvas`. Reference constants, all approximate and configurable:

| Surface | Pixel budget | Character guide |
|---|---|---|
| Title, desktop | ~580–600px | 50–60 chars |
| Description, desktop | ~920px | 120–155 chars |
| Description, mobile | ~680px | first ~120 chars must fit |

Google truncates on rendered width, not character count, so a 58-character title full of capitals
can truncate while a 62-character one survives. Report both numbers; gate on both.

### Validator set (all pure functions, all unit tested)

**Universal**
- `charLimit`, `pixelLimit` per field
- `primaryKeywordPresent` — and warn if it is not inside the first 40% of the title
- `noBannedTerms` — prices, `AED`, `/month`, `starting`, `free`, stock and availability claims,
  unproven superlatives, competitor trademarks
- `noStaleGeneration` — parse the generation number from the product name and flag any lower
  number appearing in copy or keywords (catches `ultra 3` on an Ultra 4 row)
- `brandSuffixPolicy` — append ` | e&` when it fits the pixel budget, and enforce the same
  decision across the whole batch rather than per row
- `uniqueAcrossBatch` — no two rows share a title; check the registry too
- `noDoubleSpace`, `noTrailingWhitespace`, `noGluedEmDash`

**Apple-specific** (these are hard store rules, not style preferences)
- keyword field limit is **100 bytes, not 100 characters** — decisive once Arabic arrives
- no word used in the app name or subtitle may reappear in the keyword field
- no spaces after commas in the keyword field; singular forms preferred
- no third-party trademarks

**Coverage map** (replaces the practitioner's "keyword stuffing" request)
- primary and secondary keyword placement per field
- density with an upper bound, flagged when exceeded
- duplicate-term flag across fields that must not repeat

Each validator returns `{ code, severity: 'error' | 'warning', message, field }`.
**Errors block export. Warnings do not.**

### Regeneration loop

Generate → validate → if errors, regenerate with the failures fed back, up to 3 attempts → then
route to the exception queue with every attempt retained. Never ship an invalid string, and never
silently truncate one to fit.

---

## 7. Generated outputs

**Tier 1 — production-grade, fully validated, gates the export**
- `meta_title_en`
- `meta_description_en`

**Tier 2 — demonstrated as drafts. Generate and display, validate on length only, and label
every one in the UI as a draft for review.**

- **Web content**: H1; a 40–60 word direct answer block for the top of the page; 3 benefit
  bullets; 3 FAQ pairs
- **App content**: screen headline ≤40 chars, subhead ≤90, CTA ≤20 — *these limits are
  placeholders. Surface them in a config file and label them in the UI as unconfirmed pending
  the app team.*
- **GEO/AEO artifacts**: 8–12 tracked user prompts an answer engine might be asked; the
  extractable answer block; FAQPage JSON-LD, validated as parseable JSON
- **Keyword coverage map**

**ASO — important structural note.** Apple's name, subtitle and keyword field belong to the
**app**, not to a product row. Generating ASO per SKU is a category error. Put ASO on its own
tab, driven by a small separate form (app name, locale, primary keyword set), producing:

| Field | Limit | Indexed? |
|---|---|---|
| Apple app name | 30 chars | yes, highest weight |
| Apple subtitle | 30 chars | yes |
| Apple keyword field | 100 **bytes** | yes |
| Apple promotional text | 170 chars | no |
| Apple description | 4,000 chars | **no — conversion only** |
| Play title | 30 chars | yes |
| Play short description | 80 chars | yes |
| Play full description | 4,000 chars | **yes, fully indexed** |

That asymmetry drives the copy strategy: on iOS the entire indexed budget is 160 characters
across three fields, so no word may be wasted on repetition; on Play the long description is
worth writing keywords into. Show this contrast in the UI, because it is a point leadership will
find genuinely new.

---

## 8. Front-end journey

A four-step wizard with a persistent step rail, plus a history page.

**Step 1 — Upload.** Drop zone for `.xlsx`. Parse, validate headers against the expected schema,
show a preview table with row count, detected page types, and any rows classified unreachable
with the reason stated. Never reject a file for dirty data; classify and continue.

**Step 2 — Keywords.** Table grouped by category. Candidate keywords stream in per row with a
skeleton state, then volumes populate from the provider. Columns: term, type, volume, status,
source. Show the provider badge. Sortable by volume. The user can edit, add, remove, and change a
primary. Cannibalisation warning when a primary is already claimed by another row in the same
category. Parked and unverified terms are visible but visually separated, never hidden.

**Step 3 — Approve and generate.** Explicit approve action per batch, recorded as an
`AuditEvent` with user and timestamp. Then copy generation streams in per row, per field.
Each field shows a validation chip: green pass, amber warning, red error with the reason in
plain language. A **SERP preview** component renders desktop and mobile with the real truncation
point marked. Fields are inline-editable and revalidate on blur. Regenerate button per field,
showing a diff against the previous attempt.

**Step 4 — Export.** Blocked while any Tier 1 error is unresolved, with the blocking rows named.
Generates the workbook and records the `Export`.

**History.** Table of all batches: batch number, date, user, row count, status, export count.
Re-download regenerates from stored records. Retention date shown per batch, with a note that
records purge at six months.

**Design direction.** Restrained and editorial. Deep red accent (e& brand territory) used
sparingly for primary actions only, warm neutral greys, generous whitespace, one clear type
scale. Validation state carried by chips and a left border rather than full-row colour fills.
No gradients, no drop shadows on everything, no emoji in the UI. It should look like a tool a
telco would licence, not a weekend hack. Do not use official e& logo files or brand assets.

---

## 9. Excel export

Using ExcelJS, preserving formulas:

- **Sheet 1** — the exact 14-column layout from §3, verbatim headers including the trailing space
  in `Keywords ` and the `Meta Decsription (EN)` typo. `=LEN(Jn)` and `=LEN(Ln)` written as live
  formulas, not computed values. Column D holds the **URL on every row**; product name gets its
  own new column appended to the right, so nothing existing shifts.
- **Sheet `keywords `** — now with headers: term, type, volume, source, data date, locale, geo,
  status, product URL, row index. Deduplicated case-insensitively.
- **Sheet `GEO`** — tracked prompts, answer blocks, JSON-LD per row.
- **Sheet `ASO`** — the store-field table with byte and character counts.
- **Sheet `Validation log`** — every row, every field, every validator result, plus skipped rows
  with reasons. This sheet is what makes the tool auditable; treat it as a headline feature, not
  a debug artifact.

Filename pattern: `Output_File_-_SEO_{batchNo}_{YYYYMMDD}_v{n}.xlsx`.

---

## 10. Build order

1. Prisma schema, migrations, fixture seed
2. `lib/limits.ts` and the full validator set, with tests, before any UI
3. Excel parse and write, with a round-trip test proving the reference layout reproduces exactly
4. `KeywordVolumeProvider` interface plus the fixture implementation
5. LLM provider module with a deterministic fixture mode
6. API routes
7. The four-step UI
8. History and retention
9. Seed a complete demo batch so the tool opens with something to show

---

## 11. Acceptance criteria

- `npm install && npm run dev` works with **no env vars set**, in fixture mode, end to end
- Uploading `fixtures/input.xlsx` produces 21 classified rows, with the three preprod URLs
  marked unreachable and reasons shown
- The three-word summary of every validator failure is legible to a non-technical reviewer
- A test asserts the reference file's `M12` value of 160 **fails** the description validator
- A test asserts a description containing `AED 225/month` fails the banned-terms validator
- A test asserts an Apple keyword field of 100 Arabic characters fails on byte length
- No code path anywhere can populate `Keyword.volume` from model output; a test enforces this
- Exporting, then re-downloading from history, yields a byte-identical workbook
- `npm test` green, `tsc --noEmit` clean

---

## 12. Where to stop and ask

Stop and ask rather than guessing if you hit any of these:

- the app content character limits (flagged as placeholders in §7)
- whether Arabic columns G–I and N should be populated in v1 (current answer: no, English only,
  but the schema must not make Arabic painful to add)
- whether the tool should fetch e& product pages for factual grounding, or take facts only from
  the input file — this has a real bearing on copy accuracy and needs a decision from the
  business, not a default

Write a short `DECISIONS.md` as you go, recording each choice you made and why. That file is
what gets reviewed alongside the demo.
