/*
 * A small progressive-enhancement layer: fetch HTML, swap it into the DOM.
 *
 * This is a deliberately minimal hand-rolled subset of what HTMX provides, not HTMX
 * itself. It exists so the tool ships with no third-party JavaScript runtime and is
 * provably offline — brief §0 requires the whole thing to run with no external
 * dependencies, and a CDN script tag would quietly break that.
 *
 * Supported attributes:
 *   data-get / data-post   URL to fetch
 *   data-trigger           "load" | "click" | "blur" | "change" | "submit" (default click)
 *   data-target            CSS selector to swap (default: the element itself)
 *   data-swap              "outer" (default) | "inner" | "none"
 *   data-confirm           confirm() text before firing
 *   data-indicator         selector to mark busy while in flight
 *   data-body              extra urlencoded pairs to send, e.g. "open_editor=1"
 *   data-autofocus         focus this field after the swap that brought it in
 *
 * Out-of-band swaps: any element in a response carrying data-swap-oob="true" replaces the
 * element with the same id already in the document. That is how one request updates a
 * table cell, its validation chip, the SERP preview and the export gate together.
 */
(function () {
  "use strict";

  var BUSY = "is-busy";

  function select(root, selector) {
    if (!selector) return null;
    if (selector === "this") return root;
    return document.querySelector(selector);
  }

  function applyOob(fragment) {
    var nodes = fragment.querySelectorAll("[data-swap-oob]");
    var landed = [];
    for (var i = 0; i < nodes.length; i++) {
      var incoming = nodes[i];
      incoming.removeAttribute("data-swap-oob");
      if (!incoming.id) continue;
      var existing = document.getElementById(incoming.id);
      if (existing) {
        existing.replaceWith(incoming);
        landed.push(incoming);
      }
    }
    // Bind anything that arrived out of band, so a server-emitted element carrying
    // data-trigger="load" fires. That is how the batch-level brand-suffix decision runs:
    // the server notices the last row has finished and sends back the trigger for it,
    // rather than the client having to count outstanding requests.
    for (var j = 0; j < landed.length; j++) {
      if (landed[j].hasAttribute("data-get") || landed[j].hasAttribute("data-post")) {
        bind(landed[j]);
      }
      init(landed[j]);
    }
  }

  /*
   * Parse a fragment with <template>, NOT a <div>.
   *
   * This matters and it is not obvious. Assigning `<tr>...</tr>` to `div.innerHTML` makes
   * the HTML parser discard the <tr> and <td> tags entirely, because a table row is not
   * valid as a direct child of a div — you get the bare text back and the table structure
   * is destroyed. A <template> element parses any fragment in a content-agnostic context
   * and keeps it intact. Both the keyword table and the generation table swap <tr>
   * fragments, so this is the difference between the tables working and silently emptying
   * themselves.
   */
  function parseFragment(html) {
    var template = document.createElement("template");
    template.innerHTML = html.trim();
    return template.content;
  }

  function swapIn(element, html) {
    var fragment = parseFragment(html);

    // Out-of-band nodes are taken out of the fragment first so they are not also swapped
    // into the primary target.
    applyOob(fragment);

    var mode = element.getAttribute("data-swap") || "outer";
    if (mode === "none") {
      init(document);
      return;
    }

    var target = select(element, element.getAttribute("data-target")) || element;
    if (mode === "inner") {
      target.replaceChildren(fragment);
      init(target);
      return;
    }

    var anchor = target.parentNode;
    if (!anchor) return;
    anchor.insertBefore(fragment, target);
    target.remove();
    init(anchor);
  }

  function fail(element, message) {
    // Brief §1 rule 6: failures are visible, never silent. A dropped request must not
    // leave a skeleton shimmering on screen forever.
    var target = select(element, element.getAttribute("data-target")) || element;
    var note = document.createElement("div");
    note.className = "row-error";
    note.setAttribute("role", "alert");
    note.textContent = "Could not load this: " + message + ". Reload to try again.";
    if (target.parentNode) {
      target.replaceWith(note);
    }
  }

  function request(element, event) {
    var url = element.getAttribute("data-get") || element.getAttribute("data-post");
    if (!url) return;

    var confirmText = element.getAttribute("data-confirm");
    if (confirmText && !window.confirm(confirmText)) return;

    var isPost = element.hasAttribute("data-post");
    var options = { method: isPost ? "POST" : "GET", headers: { "X-Partial": "1" } };

    if (isPost) {
      var form = element.closest("form");
      if (element.tagName === "FORM") form = element;
      var body = form ? new FormData(form) : new FormData();
      if (!form && element.name) body.append(element.name, element.value);

      // Literal pairs declared on the element itself, for a control that is not a field
      // and has no form to read — the "open the editor" button, for instance. Applied
      // last so an element can override a field it sits beside.
      var extra = element.getAttribute("data-body");
      if (extra) {
        var pairs = new URLSearchParams(extra);
        pairs.forEach(function (value, key) {
          body.set(key, value);
        });
      }
      options.body = body;
    }

    if (event) event.preventDefault();

    var indicator = select(element, element.getAttribute("data-indicator")) || element;
    indicator.classList.add(BUSY);

    fetch(url, options)
      .then(function (response) {
        if (!response.ok) throw new Error("HTTP " + response.status);
        return response.text();
      })
      .then(function (html) {
        indicator.classList.remove(BUSY);
        swapIn(element, html);
      })
      .catch(function (error) {
        indicator.classList.remove(BUSY);
        fail(element, error.message);
      });
  }

  /*
   * Lazy loading, in batches, for a long list.
   *
   * A batch of twenty products fired twenty requests at once and then sat there: the
   * server caps concurrency, so the last rows waited behind the first eight anyway, and
   * the page showed twenty shimmering skeletons with no sense of progress.
   *
   * Instead the first `data-lazy-first` rows start immediately, and the rest wait in a
   * "queued" state. Reaching the bottom of the list releases the next batch — by
   * IntersectionObserver where it exists, and by an ordinary button everywhere, which is
   * also how it works for anyone navigating by keyboard.
   */
  function releaseNext(list) {
    var size = parseInt(list.getAttribute("data-lazy-size") || "8", 10);
    var queued = list.querySelectorAll("[data-lazy-url]");
    var released = 0;

    for (var i = 0; i < queued.length && released < size; i++) {
      var element = queued[i];
      element.setAttribute("data-get", element.getAttribute("data-lazy-url"));
      element.removeAttribute("data-lazy-url");
      element.removeAttribute("data-s");
      bind(element);
      released++;
    }

    // Nothing queued left: retire the control rather than leave a dead button.
    if (!list.querySelectorAll("[data-lazy-url]").length) {
      var more = document.querySelector("[data-lazy-more]");
      if (more) more.remove();
    }
    progress();
  }

  function initLazy(scope) {
    var list = scope.querySelector
      ? scope.querySelector("[data-lazy-list]") || document.querySelector("[data-lazy-list]")
      : null;
    if (!list) return;

    var more = document.querySelector("[data-lazy-more]");
    if (!more || more.dataset.lazyBound === "1") return;
    more.dataset.lazyBound = "1";

    more.addEventListener("click", function (event) {
      event.preventDefault();
      releaseNext(list);
    });

    if (!("IntersectionObserver" in window)) return;
    // Released a little before the sentinel is actually reached, so the next rows are
    // already working by the time the reader arrives at them.
    var observer = new IntersectionObserver(
      function (entries) {
        for (var i = 0; i < entries.length; i++) {
          if (entries[i].isIntersecting) releaseNext(list);
        }
      },
      { rootMargin: "300px" }
    );
    observer.observe(more);
  }

  function bind(element) {
    if (element.dataset.swapBound === "1") return;
    element.dataset.swapBound = "1";

    var trigger = element.getAttribute("data-trigger") || "click";

    if (trigger === "load") {
      request(element, null);
      return;
    }
    element.addEventListener(trigger, function (event) {
      request(element, event);
    });
  }

  /*
   * The inline editor: a live character count, and Escape to cancel.
   *
   * The counter is characters only. Pixel width stays server-authoritative — two
   * slightly different pixel numbers on screen would undermine the one that actually
   * gates the export, and the browser cannot measure the way the server does.
   */
  function bindEditor(area) {
    if (area.dataset.editorBound === "1") return;
    area.dataset.editorBound = "1";

    var counter = document.getElementById(area.getAttribute("data-counter"));
    var limit = parseInt(area.getAttribute("data-limit") || "0", 10);

    function count() {
      if (!counter) return;
      var n = area.value.length;
      counter.textContent = limit ? n + "/" + limit : String(n);
      counter.classList.toggle("count--over", limit > 0 && n > limit);
    }

    area.addEventListener("input", count);
    area.addEventListener("keydown", function (event) {
      if (event.key !== "Escape") return;
      event.preventDefault();
      var url = area.getAttribute("data-cancel");
      var target = document.querySelector(area.getAttribute("data-cancel-target"));
      if (!url || !target) return;
      fetch(url, { headers: { "X-Partial": "1" } })
        .then(function (r) { return r.text(); })
        .then(function (html) {
          var fragment = parseFragment(html);
          target.replaceWith(fragment);
          init(document);
        });
    });

    count();
    // Put the caret at the end rather than selecting everything, so the first keystroke
    // does not wipe the copy someone only meant to tweak.
    var end = area.value.length;
    try { area.setSelectionRange(end, end); } catch (e) { /* not all inputs support it */ }
  }

  /*
   * Progress for a step that streams one row at a time.
   *
   * Both numbers are real. "Done" counts rows that have actually landed — a row still
   * carrying data-get has not been answered yet — and the clock is the wall clock. The
   * bar is the ratio of the two, so it moves when work completes and sits still when the
   * providers are slow. Nothing advances on a timer: brief §0 forbids staging work to
   * look live, and a bar that creeps forward while the server is stuck would be doing
   * exactly that.
   */
  var started = null;

  function clock(ms) {
    var total = Math.floor(ms / 1000);
    var mins = Math.floor(total / 60);
    var secs = total % 60;
    return mins + ":" + (secs < 10 ? "0" : "") + secs;
  }

  function progress() {
    var box = document.querySelector("[data-progress]");
    if (!box) return;

    var prefix = box.getAttribute("data-row-prefix") || "";
    var rows = document.querySelectorAll('tr[id^="' + prefix + '"]');
    if (!rows.length) {
      box.hidden = true;
      return;
    }

    // Three states, not two. A row is finished only when it is neither working nor
    // waiting its turn — counting "no data-get" alone made every queued row look
    // complete the moment lazy loading arrived, so the bar read 20 of 20 while 12 rows
    // were still blank.
    var done = 0;
    var queued = 0;
    var working = 0;
    for (var i = 0; i < rows.length; i++) {
      if (rows[i].hasAttribute("data-lazy-url")) queued++;
      else if (rows[i].hasAttribute("data-get")) working++;
      else done++;
    }

    if (done === rows.length) {
      // Leave the final time on screen rather than hiding it. "21 rows in 0:47" is worth
      // seeing, and it is the honest alternative to a fake pacing delay.
      var spin = box.querySelector(".spin");
      if (spin) spin.remove();
      var label = box.getAttribute("data-label") || "";
      document.getElementById("progress-count").textContent =
        rows.length + " rows" + (started ? " in " + clock(Date.now() - started) : "") +
        (label ? " · " + label : "");
      document.getElementById("progress-elapsed").textContent = "";
      document.getElementById("progress-fill").style.width = "100%";
      return;
    }

    if (started === null) started = Date.now();
    box.hidden = false;

    var spinner = box.querySelector(".spin");
    var label = box.getAttribute("data-label") || "";

    if (!working && queued) {
      // Everything released has finished and the rest are waiting to be asked for. Saying
      // "researching row 9" here claimed work that was not happening, and the spinner
      // kept turning over an idle page.
      if (spinner) spinner.hidden = true;
      document.getElementById("progress-count").textContent =
        done + " of " + rows.length + " done · " + queued +
        " waiting — scroll down for the next batch";
      document.getElementById("progress-elapsed").textContent = "";
    } else {
      if (spinner) spinner.hidden = false;
      document.getElementById("progress-count").textContent =
        (box.getAttribute("data-verb") || "Working") + " " + (done + 1) +
        " of " + rows.length +
        (queued ? " · " + queued + " waiting" : "") +
        (label ? " · " + label : "");
      document.getElementById("progress-elapsed").textContent = clock(Date.now() - started);
    }

    document.getElementById("progress-fill").style.width =
      Math.round((done / rows.length) * 100) + "%";
  }

  function init(root) {
    var scope = root || document;
    var nodes = scope.querySelectorAll("[data-get],[data-post]");
    for (var i = 0; i < nodes.length; i++) bind(nodes[i]);

    var editors = scope.querySelectorAll("[data-editor]");
    for (var j = 0; j < editors.length; j++) bindEditor(editors[j]);
    if (editors.length) editors[editors.length - 1].focus();

    // A field the server decided should have the caret — a keyword's text box arriving
    // open. Focus follows the swap, so clicking "edit" lands you in the box rather than
    // somewhere above it.
    var focusable = scope.querySelectorAll("[data-autofocus]");
    if (focusable.length) {
      var field = focusable[focusable.length - 1];
      field.focus();
      var end = (field.value || "").length;
      try { field.setSelectionRange(end, end); } catch (e) { /* unsupported type */ }
    }

    initLazy(scope);
    progress();
  }

  document.addEventListener("DOMContentLoaded", function () {
    init(document);
    // One tick a second, only to move the clock. The counts come from the DOM as rows
    // land, not from this interval.
    window.setInterval(progress, 1000);
  });

  window.Swap = { init: init };
})();
