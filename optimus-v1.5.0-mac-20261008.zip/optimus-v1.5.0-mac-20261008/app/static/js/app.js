/*
 * Editing affordances that genuinely need a client.
 *
 * Everything that can be decided on the server is decided on the server: sorting,
 * validation, pixel width and truncation all come back as rendered HTML. This file only
 * handles things with no server equivalent — caret placement, Escape to cancel, a live
 * character count while typing, and a guard against losing an unsaved edit.
 *
 * The character counter deliberately counts characters only. Pixel width stays
 * server-authoritative so there is one source of truth for it, and a second, slightly
 * different number appearing in the browser would undermine the one on the server.
 */
(function () {
  "use strict";

  var dirty = false;

  function markDirty() {
    dirty = true;
  }

  document.addEventListener("focusin", function (event) {
    var field = event.target;
    if (!field.matches || !field.matches("[data-editor]")) return;
    // Caret to the end, so editing appends rather than overwriting from the start.
    var length = field.value.length;
    field.setSelectionRange(length, length);
  });

  document.addEventListener("input", function (event) {
    var field = event.target;
    if (!field.matches || !field.matches("[data-editor]")) return;
    markDirty();

    var counter = document.getElementById(field.getAttribute("data-counter"));
    if (!counter) return;

    // UTF-16 code units, matching Excel's LEN() and the server's char count.
    var count = field.value.length;
    var limit = parseInt(field.getAttribute("data-limit") || "0", 10);
    counter.textContent = limit ? count + " / " + limit : String(count);
    counter.classList.toggle("over", limit > 0 && count >= limit);
  });

  document.addEventListener("keydown", function (event) {
    var field = event.target;
    if (!field.matches || !field.matches("[data-editor]")) return;

    if (event.key === "Escape") {
      var cancel = field.getAttribute("data-cancel");
      dirty = false;
      if (cancel) {
        window.location.href = cancel;
      } else {
        field.blur();
      }
    }
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      dirty = false;
      field.blur(); // blur triggers the save
    }
  });

  document.addEventListener("focusout", function (event) {
    if (event.target.matches && event.target.matches("[data-editor]")) {
      dirty = false;
    }
  });

  window.addEventListener("beforeunload", function (event) {
    if (!dirty) return;
    event.preventDefault();
    event.returnValue = "";
  });
})();
