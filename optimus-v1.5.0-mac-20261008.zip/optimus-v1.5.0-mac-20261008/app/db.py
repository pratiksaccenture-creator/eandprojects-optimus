"""Database engine and session handling.

WAL mode and a serialised write path matter here: step 2 and step 3 of the wizard fire one
request per row, so up to 21 requests hit SQLite at once. Without WAL that produces
intermittent "database is locked" errors — the kind that surface during a live demo.
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from sqlalchemy import Engine, create_engine, event
from sqlalchemy import inspect as sa_inspect
from sqlalchemy.orm import Session, sessionmaker

from app.config import settings
from app.models import Base

log = logging.getLogger(__name__)

# One lock per event loop, created on first use.
#
# This was a `threading.Lock`, and that was a serious bug rather than a style choice. The
# wizard's row handlers are `async` and hold this lock across their `await`s — the page
# fetch, the model call, the volume lookup. A threading lock acquired on the event loop
# thread does not yield: while row 1 waited on DataForSEO and OpenAI, the entire server
# was blocked. Not merely serialised — frozen. No other row could start, the page could
# not repaint, `/healthz` did not answer. The visible symptom was "the keywords page takes
# forever and nothing happens", and no amount of loading animation would have helped,
# because the browser had nothing to render and the server could not send it.
#
# An `asyncio.Lock` yields while waiting. Rows still take their turn — which is also what
# DataForSEO's 12-requests-a-minute limit wants — but the server stays responsive
# throughout, so each row appears the moment it is done.
#
# Keyed by running loop because the test suite builds a fresh event loop per test, and an
# asyncio primitive bound to a dead loop raises on its next use.
_write_locks: dict[asyncio.AbstractEventLoop, asyncio.Lock] = {}


def write_lock() -> asyncio.Lock:
    """The write lock for the current event loop. Use as `async with write_lock():`."""
    loop = asyncio.get_running_loop()
    lock = _write_locks.get(loop)
    if lock is None:
        lock = asyncio.Lock()
        _write_locks[loop] = lock
    return lock


def _configure_sqlite(dbapi_connection: Any, _record: Any) -> None:
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA synchronous=NORMAL")
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.execute("PRAGMA busy_timeout=5000")
    cursor.close()


def build_engine(url: str | None = None) -> Engine:
    target = url or settings().database_url
    if target.startswith("sqlite:///"):
        path = Path(target.removeprefix("sqlite:///"))
        path.parent.mkdir(parents=True, exist_ok=True)
    engine = create_engine(target, future=True, connect_args={"check_same_thread": False})
    if target.startswith("sqlite"):
        event.listen(engine, "connect", _configure_sqlite)
    return engine


_engine: Engine | None = None
_session_factory: sessionmaker[Session] | None = None


def engine() -> Engine:
    global _engine
    if _engine is None:
        _engine = build_engine()
    return _engine


def session_factory() -> sessionmaker[Session]:
    global _session_factory
    if _session_factory is None:
        _session_factory = sessionmaker(bind=engine(), expire_on_commit=False, future=True)
    return _session_factory


def create_all() -> None:
    Base.metadata.create_all(engine())
    add_missing_columns(engine())


def add_missing_columns(bound: Engine) -> list[str]:
    """Add nullable columns that the models declare and the database lacks.

    `create_all` creates missing TABLES and silently ignores missing COLUMNS, which was
    fine until a column was first added to a table that already held data. Adding
    `months_covered` to `keywords` and `volume_cache` broke every query against them —
    "no such column" on a database that looked perfectly healthy.

    This is deliberately the smallest thing that solves it, not a migration framework:

      * only NULLABLE columns with no server default, because SQLite can add those to an
        existing table without rewriting it and without inventing a value for rows that
        predate the column;
      * anything else RAISES rather than guessing. A column that needs a value for
        existing rows is a decision about data, and that belongs in a written migration,
        not in a startup hook that quietly picks something;
      * nothing is ever dropped, renamed or retyped here.

    Returns what it added, so the caller can log it. Logged rather than silent: a schema
    that changes under you is worth a line even when it works.
    """
    inspector = sa_inspect(bound)
    existing_tables = set(inspector.get_table_names())
    added: list[str] = []

    with bound.begin() as connection:
        for table in Base.metadata.sorted_tables:
            if table.name not in existing_tables:
                continue
            present = {c["name"] for c in inspector.get_columns(table.name)}
            for column in table.columns:
                if column.name in present:
                    continue
                if not column.nullable or column.server_default is not None:
                    raise RuntimeError(
                        f"{table.name}.{column.name} is missing from the database and "
                        "cannot be added automatically: it is not nullable, or carries a "
                        "server default. Existing rows would need a value, which is a "
                        "decision about data — write a migration."
                    )
                ddl = column.type.compile(bound.dialect)
                connection.exec_driver_sql(
                    f'ALTER TABLE "{table.name}" ADD COLUMN "{column.name}" {ddl}'
                )
                added.append(f"{table.name}.{column.name}")

    if added:
        log.info("added missing columns: %s", ", ".join(added))
    return added


@contextmanager
def session_scope() -> Iterator[Session]:
    session = session_factory()()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def get_session() -> Iterator[Session]:
    """FastAPI dependency."""
    with session_scope() as session:
        yield session


def reset_for_tests(url: str) -> Engine:
    """Point the module at a throwaway database. Tests only."""
    global _engine, _session_factory
    _engine = build_engine(url)
    _session_factory = None
    Base.metadata.create_all(_engine)
    add_missing_columns(_engine)
    return _engine
