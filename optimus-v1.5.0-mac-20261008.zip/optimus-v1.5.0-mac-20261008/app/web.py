"""Templates and the few filters the three pages need.

The richer version of this module — SERP truncation splitting, server-rendered word diffs,
validation chip mapping, per-field measurement summaries — is preserved at
`archive/full-ui/web.py`.
"""

from __future__ import annotations

import datetime as dt

from fastapi import Request
from fastapi.templating import Jinja2Templates

from app.config import BUILD_VERSION, ROOT
from app.lib.validators import banned_in_copy

templates = Jinja2Templates(directory=str(ROOT / "app" / "templates"))


def is_partial(request: Request) -> bool:
    return request.headers.get("X-Partial") == "1"


def thousands(value: object) -> str:
    if value is None:
        return "—"
    if isinstance(value, (int, float)):
        return f"{int(value):,}"
    return str(value)


def humanise_date(value: dt.datetime | None) -> str:
    return value.strftime("%d %b %Y") if value else "—"


def humanise_datetime(value: dt.datetime | None) -> str:
    return value.strftime("%d %b %Y, %H:%M") if value else "—"


def research_only_reason(term: object) -> str:
    """Why a keyword can be measured but never published, or "" if it can be.

    A filter rather than a model property so the templates can explain the state without
    the ORM taking a dependency on the validator set.
    """
    rule = banned_in_copy(str(term))
    return f"Research only — contains a {rule.label}, which must not be indexed." if rule else ""


templates.env.filters["thousands"] = thousands
templates.env.filters["research_only"] = research_only_reason

# A global rather than a context key on every route, so no page can forget it.
templates.env.globals["build_version"] = BUILD_VERSION
templates.env.filters["date_only"] = humanise_date
templates.env.filters["date_time"] = humanise_datetime
