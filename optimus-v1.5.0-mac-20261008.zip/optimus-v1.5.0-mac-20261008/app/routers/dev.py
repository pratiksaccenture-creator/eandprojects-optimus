"""Maintenance endpoints. No UI — JSON only, and not linked from the interface.

Brief §4 requires `purgeExpired()` to be invocable from a dev route. That requirement is met
here without adding anything to the three-page journey. The diagnostics *page* that used to
show font-metric provenance and the editorial rules table is preserved in
`archive/full-ui/templates/dev.html`.
"""

from __future__ import annotations

import datetime as dt
from typing import Any

from fastapi import APIRouter
from sqlalchemy import select

from app.db import session_scope, write_lock
from app.lib import limits
from app.models import Batch
from app.services import retention

router = APIRouter(prefix="/dev")


@router.get("/")
async def status() -> dict[str, Any]:
    with session_scope() as session:
        batches = list(session.scalars(select(Batch).order_by(Batch.id)))
        return {
            "batches": [
                {
                    "id": b.id,
                    "batch_no": b.batch_no,
                    "rows": len(b.rows),
                    "status": b.status.value,
                    "expires": b.retention_expires_at.date().isoformat(),
                    "days_left": retention.days_until_expiry(b),
                    "expired": b.is_expired,
                }
                for b in batches
            ],
            # Where the pixel numbers come from, so they stay traceable.
            "pixel_metrics": limits.metrics_provenance(),
        }


@router.post("/purge")
async def purge() -> dict[str, Any]:
    async with write_lock():
        with session_scope() as session:
            result = retention.purge_expired(session, actor="dev-route")
            return {
                "purged": result.count,
                "batch_numbers": list(result.purged_batch_numbers),
                "files_removed": result.files_removed,
            }


@router.post("/purge-simulated")
async def purge_simulated() -> dict[str, Any]:
    """Purge as if a year from now. The clock moves; the deletion is real."""
    async with write_lock():
        with session_scope() as session:
            result = retention.purge_expired(
                session,
                as_of=dt.datetime.now() + dt.timedelta(days=365),
                actor="dev-route-simulated",
            )
            return {
                "purged": result.count,
                "batch_numbers": list(result.purged_batch_numbers),
                "files_removed": result.files_removed,
                "simulated": True,
            }
