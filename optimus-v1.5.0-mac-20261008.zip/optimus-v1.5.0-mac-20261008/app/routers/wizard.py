"""The three-page journey: upload, keywords, copy.

  1. Upload an Excel file.
  2. See the keywords and volumes, then approve.
  3. See the title and description for each row, refresh any of them, then export.

Deliberately thin. The validators, the regeneration loop, the audit trail, retention and all
five export sheets are unchanged underneath — only the amount of it shown on screen changed.
The richer interface, and the route handlers that drove it, are preserved in
`archive/full-ui/` with instructions for putting any of it back.
"""

from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
from typing import Annotated, Any

from fastapi import APIRouter, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import settings
from app.db import session_scope, write_lock
from app.excel.reader import read_any_workbook, read_price
from app.lib import limits
from app.lib.policy import ROWS_PER_PAGE
from app.models import (
    AuditEvent,
    Batch,
    BatchRow,
    BatchStatus,
    BatchStatus as BS,
    KeywordTier,
    PriceSource,
    RowStage,
    utcnow,
)
from app.providers.keywords import NotConfiguredError
from app.providers.llm import ModelNotConfiguredError, get_llm
from app.services import export_service, generation, ingest, keyword_service, validation
from app.services.export_service import ExportBlocked
from app.web import templates

router = APIRouter()

TIER1 = ("meta_title_en", "meta_description_en")

# How many rows may be out at the providers at once.
#
# Not unlimited: DataForSEO's live endpoints allow twelve requests a minute, and nine
# rows firing together would trip that and return errors instead of keywords. Three
# keeps the run comfortably inside the limit while overlapping the slow part — a row
# takes about a minute, almost all of it spent waiting on someone else's server.
MAX_CONCURRENT_ROWS = int(os.environ.get("MAX_CONCURRENT_ROWS", "") or 3)

# One per event loop, for the same reason the write lock is: the test suite builds a
# fresh loop per test and an asyncio primitive bound to a dead one raises on next use.
_research_slots: dict[asyncio.AbstractEventLoop, asyncio.Semaphore] = {}


def research_slots() -> asyncio.Semaphore:
    loop = asyncio.get_running_loop()
    slots = _research_slots.get(loop)
    if slots is None:
        slots = asyncio.Semaphore(max(1, MAX_CONCURRENT_ROWS))
        _research_slots[loop] = slots
    return slots
FIELD_LIMITS = {"meta_title_en": 60, "meta_description_en": 160}

XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


# ---------------------------------------------------------------- helpers


def _batch(session: Session, batch_id: int) -> Batch:
    batch = session.get(Batch, batch_id)
    if batch is None:
        raise HTTPException(status_code=404, detail=f"No batch {batch_id}.")
    return batch


def _row(session: Session, batch: Batch, row_index: int) -> BatchRow:
    row = next((r for r in batch.rows if r.row_index == row_index), None)
    if row is None:
        raise HTTPException(status_code=404, detail=f"Batch {batch.id} has no row {row_index}.")
    return row


async def _pacing() -> None:
    """The opt-in artificial delay, per brief §0 — asleep, not blocked.

    `time.sleep` here stopped the event loop for the whole delay, so with pacing enabled
    the server went unresponsive in exactly the way the threading lock used to make it.
    Same bug, second hiding place: a synchronous sleep inside an async handler does not
    pace one row, it pauses the entire application.
    """
    ms = settings().demo_pacing_ms
    if ms > 0:
        await asyncio.sleep(ms / 1000)


def _providers(batch: Batch | None = None) -> dict[str, Any]:
    """What to name on screen as the source of the numbers and the copy.

    When a batch is given, the badge describes what ACTUALLY produced its stored rows,
    not what happens to be configured now. Those differ more often than is comfortable —
    a batch researched on seeded data and then viewed after credentials were added showed
    "DataForSEO" above figures that came from a spreadsheet. That is precisely the
    failure this tool exists to make impossible, and it was sitting in the header.
    """
    from app.providers.keywords import get_keyword_provider
    from app.providers.llm import get_llm
    from app.providers.pages import get_page_provider

    # An unconfigured provider raises. That must not take the whole page down — the
    # point of refusing at the point of use is that someone can still open the tool and
    # be told what is missing, rather than meeting a stack trace.
    try:
        keywords = get_keyword_provider()
        volumes_live, provider_name = keywords.is_live_data, keywords.name
    except NotConfiguredError:
        volumes_live, provider_name = False, "not configured"
    try:
        model = get_llm()
        model_live, model_name = model.is_live_model, model.model
    except ModelNotConfiguredError:
        model_live, model_name = False, "not configured"
    pages_provider = get_page_provider()

    provider_is_live = volumes_live
    model_is_live = model_live

    if batch is not None:
        stored = [k for row in batch.rows for k in row.keywords]
        if stored:
            sources = sorted({k.source for k in stored})
            provider_name = sources[0] if len(sources) == 1 else " + ".join(sources)
            provider_is_live = all(k.is_live_data for k in stored)
        attempts = [
            c for row in batch.rows for c in row.copy_fields if c.is_current and c.model
        ]
        if attempts:
            models = sorted({c.model for c in attempts})
            model_name = models[0] if len(models) == 1 else " + ".join(models)
            model_is_live = "fixture" not in " ".join(models).lower()

    return {
        "provider_name": provider_name,
        "provider_is_live": provider_is_live,
        "model_name": model_name,
        "model_is_live": model_is_live,
        # Whether copy is grounded in the real page or only in the input file. Shown
        # because it changes what the copy is allowed to claim.
        "pages_fetched": pages_provider.fetches,
        # What a waiting row is waiting for, in the reader's terms rather than the
        # vendor's. See `_waiting_label`.
        # The keywords page says "finding keywords" even though a model runs there too —
        # because on that page the model is proposing seed terms, which IS finding
        # keywords. It writes no copy until step 3. Saying "writing copy" on step 2 was
        # simply describing the wrong work.
        "research_label": _waiting_label(volumes_live, False),
        "writing_label": _waiting_label(False, model_live),
        # The one disclosure that has to survive: are these numbers real? Only meaningful
        # once there are numbers, so an unconfigured tool shows the configuration banner
        # instead of a "sample data" chip over an empty table.
        "sample_data": bool(batch and batch.rows and not provider_is_live),
        "missing_providers": settings().missing_providers,
    }


def _blocked_view(error: Exception, *, row: BatchRow, row_id: str) -> dict[str, Any]:
    """Turn a provider-configuration failure into something a person can act on.

    A rejected key is not a row failure. Nothing about this row caused it and regenerating
    will not fix it, so it must not be reported as "this row failed" — and it must not be
    a bare 500 either. When an OpenAI key was revoked mid-batch the user saw nine copies of
    "Could not load this: HTTP 500" while the sentence that mattered, "Your API key has
    been invalidated", was only in a log file.
    """
    from app.providers.keywords import NotConfiguredError
    from app.providers.llm import ModelNotConfiguredError

    detail = str(error)
    if isinstance(error, ModelNotConfiguredError):
        service = "The copy model"
        fix = (
            "Check OPENAI_API_KEY in .env, then restart the app. "
            "Run .\\run.ps1 -Keys to test the key without spending anything."
        )
    elif isinstance(error, NotConfiguredError):
        service = "The keyword volume provider"
        fix = (
            "Check DATAFORSEO_LOGIN and DATAFORSEO_PASSWORD in .env, then restart. "
            "Run .\\run.ps1 -Keys to test them without spending anything."
        )
    else:  # pragma: no cover - defensive
        service = "A provider"
        fix = "Check the provider credentials in .env, then restart."

    return {"row": row, "row_id": row_id, "service": service, "detail": detail, "fix": fix}


def _waiting_label(volumes_live: bool, model_live: bool) -> str:
    """What a waiting row is waiting for, said in the reader's terms.

    Vendor names are deliberately absent. "DataForSEO + gpt-6-astra" told a content writer
    nothing they could act on and read as leaked plumbing on a screen meant for senior
    leadership. Which supplier is behind a number is an operational fact, and it stays
    where operational facts belong: `/healthz`, the audit trail, and the stored `source`
    on every keyword.

    What must NOT disappear is whether the numbers are real. That is a claim about the
    output, not about the supplier, so "sample data" survives this simplification while
    the brand names do not.
    """
    if not volumes_live and not model_live:
        return "sample data"
    if volumes_live and model_live:
        return "finding keywords and writing copy"
    if volumes_live:
        return "finding keywords"
    return "writing copy"


def _keyword_view(row: BatchRow, *, error: str = "", editing: int = 0) -> dict[str, Any]:
    """One row's keywords, split by tier and by whether they were measured.

    `error` carries a message back from an add or edit that was refused — a duplicate
    term, an over-long claim — so the box the reader typed into is where the reason
    appears, rather than the page silently not changing.

    `editing` is the keyword whose text box is open. Held in the view rather than in the
    browser so a swap cannot lose it.
    """
    from app.models import KeywordStatus, KeywordTier

    live = [k for k in row.keywords if k.status is not KeywordStatus.rejected]

    def in_tier(tier: KeywordTier) -> list[Any]:
        chosen = [k for k in live if k.tier is tier]
        chosen.sort(key=lambda k: (-(k.volume or 0), k.term_normalized))
        return chosen

    verified = sorted(
        (k for k in live if k.volume is not None),
        # Tiered terms first, so making a selection does not scroll it away from the
        # reader, then by demand. `tier` sorts by its own declaration order, which is the
        # order the click cycle walks.
        key=lambda k: (
            k.tier is KeywordTier.unranked,
            -(k.volume or 0),
            k.term_normalized,
        ),
    )
    # Terms Google reported no data for. Shown rather than hidden: an empty bucket is a
    # finding about the market, and hiding it would make the research look more complete
    # than it is. Brief §5 — the demo is more credible with visible gaps.
    unverified = sorted(
        (k for k in live if k.volume is None),
        key=lambda k: k.term_normalized,
    )
    # Kept so a removal can be undone. `reject_keyword` never deletes, and without this
    # the stored record was unreachable from the screen.
    removed = sorted(
        (k for k in row.keywords if k.status is KeywordStatus.rejected),
        key=lambda k: k.term_normalized,
    )
    return {
        "row": row,
        "verified": verified,
        "unverified": unverified,
        "removed": removed,
        "primary": next((k for k in live if k.tier is KeywordTier.primary), None),
        "tiers": {
            "primary": in_tier(KeywordTier.primary),
            "secondary": in_tier(KeywordTier.secondary),
            "tertiary": in_tier(KeywordTier.tertiary),
        },
        "usps": sorted(row.usps, key=lambda u: (not u.is_selected, u.id)),
        "kw_error": error,
        "editing": editing,
    }


def _field_view(row: BatchRow, field: str) -> dict[str, Any]:
    current = validation.current_field(row, field)
    text = current.text if current else ""
    findings = validation.findings_from_json(current.validation_json) if current else []
    errors = [f for f in findings if f.severity == "error"]
    return {
        "field": field,
        "text": text,
        "chars": limits.char_count(text) if text else 0,
        "limit": FIELD_LIMITS.get(field),
        "has_error": bool(errors),
        "first_error": errors[0].message if errors else "",
        # Every error, not just the first. One at a time is tolerable when a machine is
        # retrying — it fixes what it is told and tries again — but it is a poor deal for
        # a person editing by hand, who would otherwise fix the length, save, and only
        # then discover the missing keyword.
        "errors": [f.message for f in errors],
        "warnings": [f.message for f in findings if f.severity == "warning"],
        "cell_id": f"f-{row.row_index}-{field}",
        "edited": bool(current and current.edited_by_user),
    }


def _row_view(row: BatchRow) -> dict[str, Any]:
    fields = [_field_view(row, f) for f in TIER1]
    return {
        "row": row,
        "fields": fields,
        "has_error": any(f["has_error"] for f in fields),
        "row_id": f"cp-{row.row_index}",
    }


def _gate(session: Session, batch: Batch) -> dict[str, Any]:
    registry = keyword_service.registry_map(session, batch.id)
    report = validation.validate_whole_batch(batch, registry)

    # Batch-level errors are about a relationship BETWEEN rows — a duplicate title, say —
    # so no single row owns them and no cell shows them. They were counted in the total
    # and displayed nowhere, which produced "1 field need attention" with nothing on the
    # page to attend to. They are now carried out separately, with their own message.
    batch_errors: list[dict[str, Any]] = [
        {
            "row": validation.batch_finding_row(finding),
            "message": finding.message,
        }
        for finding in report.batch_errors
    ]
    rows_named: set[int] = {r.row_index for r in report.blocking_rows}
    for problem in batch_errors:
        row_index = problem["row"]
        if isinstance(row_index, int):
            rows_named.add(row_index)

    return {
        "can_export": report.can_export,
        "error_count": report.error_count,
        "blocking_rows": sorted(rows_named),
        "batch_errors": batch_errors,
    }


def _all_generated(batch: Batch) -> bool:
    return all(
        r.stage in (RowStage.generated, RowStage.failed, RowStage.skipped)
        for r in batch.rows
    )


# ---------------------------------------------------------------- 1. upload


@router.get("/", response_class=HTMLResponse)
async def index() -> Response:
    with session_scope() as session:
        latest = session.scalar(select(Batch).order_by(Batch.id.desc()))
        if latest is not None:
            step = 3 if latest.approved_at else 2
            return RedirectResponse(f"/batch/{latest.id}/step/{step}", status_code=303)
    return RedirectResponse("/upload", status_code=303)


@router.get("/upload", response_class=HTMLResponse)
async def upload_form(request: Request) -> Response:
    return templates.TemplateResponse(
        request,
        "upload.html",
        {
            "step": 1,
            "batch": None,
            "missing_providers": settings().missing_providers,
        },
    )


@router.post("/upload")
async def upload_submit(
    request: Request,
    batch_no: Annotated[str, Form()],
    file: Annotated[UploadFile | None, Form()] = None,
) -> Response:
    config = settings()
    # The campaign/file name. Named `batch_no` through the form and the schema because
    # that is the stored column, and renaming a database field to match a relabelled input
    # is churn with no reader benefit — but everything a user sees calls it what it is.
    label = batch_no.strip() or "Untitled campaign"

    if file is not None and file.filename:
        if not file.filename.lower().endswith((".xlsx", ".xlsm")):
            return templates.TemplateResponse(
                request,
                "upload.html",
                {
                    "step": 1,
                    "batch": None,
                    "batch_no": label,
                    "error": f"{file.filename} is not an .xlsx workbook.",
                },
                status_code=400,
            )
        upload_dir = config.exports_dir.parent / "uploads"
        upload_dir.mkdir(parents=True, exist_ok=True)
        target = upload_dir / file.filename
        target.write_bytes(await file.read())
        source: Path = target
        source_name = file.filename
    else:
        source = config.fixtures_dir / "input.xlsx"
        source_name = source.name

    parsed = read_any_workbook(source)

    # A file with no products must say so here, not become an empty batch.
    #
    # Uploading the blank template produced a batch of zero rows and a keyword page with
    # nothing on it — which looks exactly like a page still loading, and was reported as
    # "the keywords page is stuck". The tool had read the file correctly and simply never
    # mentioned that there was nothing in it.
    if not parsed.rows:
        return templates.TemplateResponse(
            request,
            "upload.html",
            {
                "step": 1,
                "batch": None,
                "batch_no": label,
                "error": (
                    f"{source_name} has no products in it. "
                    f'Found the headers {", ".join(h for h in parsed.headers if h) or "none"} '
                    f'on sheet "{parsed.sheet_name}", but every row below them is empty. '
                    "Fill in the Products tab from row 2 and upload it again."
                ),
            },
            status_code=400,
        )

    # The template carries a Batch No/Name column, so the file names the batch and the
    # form field is only a fallback. Taking the form value when the sheet has one would
    # quietly rename what the team labelled.
    if parsed.batch_numbers:
        label = parsed.batch_numbers[0]

    async with write_lock():
        with session_scope() as session:
            user = ingest.demo_user(session)
            summary = ingest.ingest_workbook(
                session,
                parsed=parsed,
                batch_no=label,
                source_file_name=source_name,
                user=user,
            )
            batch_id = summary.batch_id

    return RedirectResponse(f"/batch/{batch_id}/step/2", status_code=303)


# ---------------------------------------------------------------- 2. keywords


@router.get("/batch/{batch_id}/step/2", response_class=HTMLResponse)
async def keywords_page(request: Request, batch_id: int) -> Response:
    with session_scope() as session:
        batch = _batch(session, batch_id)
        rows = sorted(batch.rows, key=lambda r: r.row_index)
        return templates.TemplateResponse(
            request,
            "keywords.html",
            {
                "step": 2,
                "batch": batch,
                "rows": rows,
                "page_size": ROWS_PER_PAGE,
                # What period the figures on this page cover. Read off the data rather
                # than off the clock — the provider reports the window its average spans,
                # and until it was parsed the tool could not say how old any number was.
                "volume_period": keyword_service.data_date_note(
                    [k for r in rows for k in r.keywords]
                ),
                "views": {
                    r.row_index: _keyword_view(r)
                    for r in rows
                    if r.stage is not RowStage.pending
                },
                **_providers(batch),
            },
        )


@router.get("/batch/{batch_id}/rows/{row_index}/keywords", response_class=HTMLResponse)
async def keyword_row(request: Request, batch_id: int, row_index: int) -> Response:
    """Research one row.

    Three phases, and the middle one deliberately holds no lock:

      1. read what the row needs,
      2. call the model and the volume provider — the slow part, about a minute a row,
      3. take the write lock briefly and store the result.

    Holding the lock across phase 2 made every row wait for the one in front to finish
    its API calls, which is how nine rows became a ten-minute queue for work that can
    overlap. `research_slots()` still caps how many run at once, because the volume
    provider's live endpoints allow twelve requests a minute and firing all nine at
    once would trip that.
    """
    await _pacing()

    with session_scope() as session:
        batch = _batch(session, batch_id)
        row = _row(session, batch, row_index)
        locale, geo = batch.locale, batch.geo
        already_done = bool(row.keywords)

    if not already_done:
        async with research_slots():
            with session_scope() as session:
                batch = _batch(session, batch_id)
                row = _row(session, batch, row_index)
                try:
                    research = await keyword_service.research_only(
                        row, locale=locale, geo=geo
                    )
                except (ModelNotConfiguredError, NotConfiguredError) as error:
                    return templates.TemplateResponse(
                        request,
                        "_row_blocked.html",
                        _blocked_view(error, row=row, row_id=f"kw-{row.row_index}"),
                    )

            async with write_lock():
                with session_scope() as session:
                    batch = _batch(session, batch_id)
                    row = _row(session, batch, row_index)
                    keyword_service.store_row_keywords(
                        session, row, research, locale=locale, geo=geo
                    )

    with session_scope() as session:
        batch = _batch(session, batch_id)
        row = _row(session, batch, row_index)
        return _row_fragment(request, batch, row)


def _row_fragment(
    request: Request, batch: Batch, row: BatchRow, *, error: str = "", editing: int = 0
) -> Response:
    """Re-render one keyword row. The single response shape for every edit on the page."""
    return templates.TemplateResponse(
        request,
        "_keyword_row.html",
        {"batch": batch, "view": _keyword_view(row, error=error, editing=editing)},
    )


@router.get("/batch/{batch_id}/rows/{row_index}/row", response_class=HTMLResponse)
async def keyword_row_fragment(
    request: Request, batch_id: int, row_index: int
) -> Response:
    """Re-render one row from stored state, changing nothing.

    What "cancel" means. An editor closes by asking the server what the row looks like,
    rather than the browser reconstructing it — so a cancelled edit cannot leave a half
    applied change on screen, and the same route serves the Escape key.
    """
    with session_scope() as session:
        batch = _batch(session, batch_id)
        row = _row(session, batch, row_index)
        return _row_fragment(request, batch, row)


@router.post("/batch/{batch_id}/rows/{row_index}/primary", response_class=HTMLResponse)
async def set_primary(
    request: Request, batch_id: int, row_index: int, keyword_id: int
) -> Response:
    """Promote one term straight to primary.

    Kept alongside the cycle below because they answer different questions. "Make this the
    primary" is one click here; walking a term round the tiers is the cycle. Both write
    through `set_keyword_tier`, so the two cannot disagree about what primary means.
    """
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            keyword_service.set_primary(session, row, keyword_id)
            return _row_fragment(request, batch, row)


@router.post("/batch/{batch_id}/rows/{row_index}/cycle", response_class=HTMLResponse)
async def cycle_tier(
    request: Request, batch_id: int, row_index: int, keyword_id: int
) -> Response:
    """Move one term to the next tier: unranked, primary, secondary, tertiary, round again.

    One control per term rather than three. A row carries a dozen terms, so three buttons
    each would be thirty-six controls in a table cell — and cycling round to unranked
    means a mis-click is undone by clicking again rather than by hunting for a reset.
    """
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            current = next(
                (k.tier for k in row.keywords if k.id == keyword_id),
                KeywordTier.unranked,
            )
            keyword_service.set_keyword_tier(
                session, row, keyword_id, keyword_service.next_tier(current)
            )
            return _row_fragment(request, batch, row)


@router.post("/batch/{batch_id}/rows/{row_index}/keywords/add", response_class=HTMLResponse)
async def add_keyword(
    request: Request,
    batch_id: int,
    row_index: int,
    term: Annotated[str, Form()] = "",
) -> Response:
    """Add a term the researcher typed, and measure it.

    The lookup happens outside the write lock, like the research route, because it is a
    network call and holding the lock across one blocks every other row on the page.
    """
    with session_scope() as session:
        batch = _batch(session, batch_id)
        row = _row(session, batch, row_index)
        locale, geo = batch.locale, batch.geo

    if not term.strip():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            return _row_fragment(request, batch, row, error="Type a keyword first.")

    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            try:
                added = await keyword_service.add_manual_term(
                    session, row, term, locale=locale, geo=geo
                )
            except NotConfiguredError as error:
                return _row_fragment(request, batch, row, error=str(error))
            message = (
                "" if added is not None
                else f"{term.strip()!r} is not a term I can look up."
            )
            return _row_fragment(request, batch, row, error=message)


@router.post(
    "/batch/{batch_id}/rows/{row_index}/keywords/{keyword_id}/edit",
    response_class=HTMLResponse,
)
async def edit_keyword(
    request: Request,
    batch_id: int,
    row_index: int,
    keyword_id: int,
    term: Annotated[str, Form()] = "",
    open_editor: Annotated[str, Form()] = "",
) -> Response:
    """Open the editor for a term, or save a new spelling for it.

    `open_editor` makes this one route for both, so the page has one place a term's text
    is changed. Saving re-measures: the stored figure belongs to the old string, and
    carrying it across would be a fabricated number.
    """
    if open_editor:
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            return _row_fragment(request, batch, row, editing=keyword_id)

    with session_scope() as session:
        batch = _batch(session, batch_id)
        locale, geo = batch.locale, batch.geo

    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            try:
                _, message = await keyword_service.edit_keyword_term(
                    session, row, keyword_id, term, locale=locale, geo=geo
                )
            except NotConfiguredError as error:
                return _row_fragment(
                    request, batch, row, error=str(error), editing=keyword_id
                )
            # The editor stays open on a refusal, so the text is still there to correct.
            return _row_fragment(
                request, batch, row, error=message, editing=keyword_id if message else 0
            )


@router.post(
    "/batch/{batch_id}/rows/{row_index}/keywords/{keyword_id}/remove",
    response_class=HTMLResponse,
)
async def remove_keyword(
    request: Request, batch_id: int, row_index: int, keyword_id: int
) -> Response:
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            keyword_service.reject_keyword(session, row, keyword_id)
            return _row_fragment(request, batch, row)


@router.post(
    "/batch/{batch_id}/rows/{row_index}/keywords/{keyword_id}/restore",
    response_class=HTMLResponse,
)
async def restore_keyword(
    request: Request, batch_id: int, row_index: int, keyword_id: int
) -> Response:
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            keyword_service.restore_keyword(session, row, keyword_id)
            return _row_fragment(request, batch, row)


@router.post(
    "/batch/{batch_id}/rows/{row_index}/usps/{usp_id}/toggle", response_class=HTMLResponse
)
async def toggle_usp(
    request: Request, batch_id: int, row_index: int, usp_id: int
) -> Response:
    """Tick or untick a selling point. Ticking is what lets the copy step state it."""
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            user = ingest.demo_user(session)
            keyword_service.toggle_usp(session, row, usp_id, actor=user.email)
            return _row_fragment(request, batch, row)


@router.post("/batch/{batch_id}/rows/{row_index}/usps/propose", response_class=HTMLResponse)
async def propose_usps(request: Request, batch_id: int, row_index: int) -> Response:
    """Ask the model for selling points for a row that has none.

    The missing retry. Selling points are written during research; research does not
    re-run for a row that already has keywords; and a failed ideation call was swallowed.
    So a row whose model call failed showed "none proposed" for ever, which reads as "this
    product has no selling points" rather than "we failed to ask".

    The model call happens OUTSIDE the write lock, like research and like adding a
    keyword. It costs one seed-model call and no volume lookup — the measured keywords are
    not touched.
    """
    with session_scope() as session:
        batch = _batch(session, batch_id)
        row = _row(session, batch, row_index)
        locale, geo = batch.locale, batch.geo

    try:
        proposed = await keyword_service.fetch_usps(row, locale=locale, geo=geo)
    except (ModelNotConfiguredError, NotConfiguredError) as error:
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            return _row_fragment(request, batch, row, error=str(error))

    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            added = keyword_service.add_proposed_usps(
                session, row, proposed, model=get_llm().model
            )
            message = (
                "" if added
                else "The model proposed nothing usable for this product. Type a selling "
                     "point instead, or try again."
            )
            return _row_fragment(request, batch, row, error=message)


@router.post("/batch/{batch_id}/rows/{row_index}/usps/add", response_class=HTMLResponse)
async def add_usp(
    request: Request,
    batch_id: int,
    row_index: int,
    claim: Annotated[str, Form()] = "",
) -> Response:
    """Add a selling point someone typed. Needs no model and no provider call."""
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            user = ingest.demo_user(session)
            _, message = keyword_service.add_manual_usp(
                session, row, claim, actor=user.email
            )
            return _row_fragment(request, batch, row, error=message)


@router.post("/batch/{batch_id}/approve")
async def approve(batch_id: int) -> Response:
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            user = ingest.demo_user(session)
            keyword_service.approve_keywords(session, batch, user_id=user.id, actor=user.email)
            keyword_service.record_registry_claims(session, batch)
            batch.status = BatchStatus.approved
    return RedirectResponse(f"/batch/{batch_id}/step/3", status_code=303)


# ---------------------------------------------------------------- 3. copy and export


@router.get("/batch/{batch_id}/step/3", response_class=HTMLResponse)
async def copy_page(request: Request, batch_id: int) -> Response:
    with session_scope() as session:
        batch = _batch(session, batch_id)
        rows = sorted(batch.rows, key=lambda r: r.row_index)
        done = [r for r in rows if r.stage in (RowStage.generated, RowStage.failed)]
        context: dict[str, Any] = {
            "step": 3,
            "batch": batch,
            "rows": rows,
            "page_size": ROWS_PER_PAGE,
            "views": {r.row_index: _row_view(r) for r in done},
            "can_export": False,
            "error_count": 0,
            "blocking_rows": [],
            **_providers(batch),
        }
        if _all_generated(batch):
            context.update(_gate(session, batch))
        return templates.TemplateResponse(request, "copy.html", context)


@router.get("/batch/{batch_id}/rows/{row_index}/generate", response_class=HTMLResponse)
async def generate_row(request: Request, batch_id: int, row_index: int) -> Response:
    await _pacing()
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            if row.stage not in (RowStage.generated, RowStage.failed):
                try:
                    await generation.generate_row(
                        session, row,
                        locale=batch.locale,
                        brand_suffix_applied=batch.brand_suffix_applied,
                    )
                except (ModelNotConfiguredError, NotConfiguredError) as error:
                    # The row keeps its pending stage, so fixing the credentials and
                    # reloading picks it up rather than leaving it permanently failed.
                    return templates.TemplateResponse(
                        request,
                        "_row_blocked.html",
                        _blocked_view(error, row=row, row_id=f"cp-{row.row_index}"),
                    )
            remaining = sum(
                1 for r in batch.rows
                if r.stage not in (RowStage.generated, RowStage.failed, RowStage.skipped)
            )
            settle_now = remaining == 0 and batch.brand_suffix_applied is None
            return templates.TemplateResponse(
                request,
                "_copy_row.html",
                {
                    "batch": batch,
                    "settle_now": settle_now,
                    # Refresh the export control once the last row lands and no settle step
                    # will follow to do it.
                    "emit_gate": remaining == 0 and not settle_now,
                    **_row_view(row),
                    **(_gate(session, batch) if remaining == 0 else {}),
                },
            )


@router.get("/batch/{batch_id}/settle", response_class=HTMLResponse)
async def settle(request: Request, batch_id: int) -> Response:
    """Settle the batch-wide brand suffix once every title exists, then refresh the rows.

    The decision needs all the titles before it can be made, so it cannot happen before
    generation. It shows nothing on screen; the rows and the export gate just update.
    """
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            decision = validation.decide_batch_brand_suffix(batch)
            validation.persist_brand_decision(session, batch, decision)
            if decision.applied:
                for row in sorted(batch.rows, key=lambda r: r.row_index):
                    if not row.skip_reason:
                        generation.apply_brand_suffix(session, row, locale=batch.locale)
            batch.status = BatchStatus.generated
            return templates.TemplateResponse(
                request,
                "_settled.html",
                {
                    "batch": batch,
                    "views": [
                        _row_view(r) for r in sorted(batch.rows, key=lambda r: r.row_index)
                    ],
                    **_gate(session, batch),
                },
            )


@router.post(
    "/batch/{batch_id}/rows/{row_index}/fields/{field}/regenerate",
    response_class=HTMLResponse,
)
async def regenerate(
    request: Request, batch_id: int, row_index: int, field: str
) -> Response:
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            await generation.regenerate_field(
                session, row, field,
                locale=batch.locale,
                brand_suffix_applied=batch.brand_suffix_applied,
            )
            return templates.TemplateResponse(
                request,
                "_field_response.html",
                {
                    "batch": batch,
                    "row": row,
                    **_field_view(row, field),
                    **_gate(session, batch),
                },
            )


@router.get(
    "/batch/{batch_id}/rows/{row_index}/fields/{field}/editor",
    response_class=HTMLResponse,
)
async def field_editor(
    request: Request, batch_id: int, row_index: int, field: str
) -> Response:
    """Swap a field's cell for an editor. Read-only — nothing is written until Save."""
    with session_scope() as session:
        batch = _batch(session, batch_id)
        row = _row(session, batch, row_index)
        return templates.TemplateResponse(
            request,
            "_field_editor.html",
            {"batch": batch, "row": row, **_field_view(row, field)},
        )


@router.get(
    "/batch/{batch_id}/rows/{row_index}/fields/{field}/cell",
    response_class=HTMLResponse,
)
async def field_cell(
    request: Request, batch_id: int, row_index: int, field: str
) -> Response:
    """The read-only cell again, for Cancel.

    Re-read from storage rather than restored from the DOM, so cancelling cannot leave
    unsaved text on screen looking like it was kept.
    """
    with session_scope() as session:
        batch = _batch(session, batch_id)
        row = _row(session, batch, row_index)
        return templates.TemplateResponse(
            request,
            "_field.html",
            {"batch": batch, "row": row, "oob": False, **_field_view(row, field)},
        )


@router.post(
    "/batch/{batch_id}/rows/{row_index}/fields/{field}/edit",
    response_class=HTMLResponse,
)
async def save_field(
    request: Request,
    batch_id: int,
    row_index: int,
    field: str,
    text: Annotated[str, Form()] = "",
) -> Response:
    """Save a human edit as a new attempt, revalidate it, and refresh the export gate.

    The edit is not a mutation: the generated original is kept as an earlier attempt and
    this becomes the current one. Everything downstream reads "current", so the export
    carries the human's wording with no special case anywhere.

    It is validated exactly as generated copy is. An edit that breaks a rule — too long,
    a price nobody supplied — fails and blocks the export, because the rules are about
    what gets published, not about who typed it.
    """
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            generation.edit_field(
                session, row, field, text.strip(),
                locale=batch.locale,
                brand_suffix_applied=batch.brand_suffix_applied,
            )
            return templates.TemplateResponse(
                request,
                "_field_response.html",
                {
                    "batch": batch,
                    "row": row,
                    **_field_view(row, field),
                    **_gate(session, batch),
                },
            )


@router.post(
    "/batch/{batch_id}/rows/{row_index}/price", response_class=HTMLResponse
)
async def set_price(
    request: Request,
    batch_id: int,
    row_index: int,
    price: Annotated[str, Form()] = "",
) -> Response:
    """Record a starting price for one row and rewrite its description around it.

    The guidelines require a price in the second sentence; the tool will not let a model
    invent one. This route is the bridge: a person types the figure, it is stored with
    their name and the time, and only then does the description validator permit that
    exact string to appear in indexed copy.

    An empty box clears the price and regenerates without one, so a figure entered by
    mistake can be taken out again rather than living in the row forever.
    """
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            row = _row(session, batch, row_index)
            user = ingest.demo_user(session)

            parsed = read_price(price)
            if price.strip() and parsed is None:
                # Unreadable input leaves the stored price untouched rather than silently
                # clearing it — a typo should not quietly delete a correct figure.
                return templates.TemplateResponse(
                    request,
                    "_field_response.html",
                    {
                        "batch": batch,
                        "row": row,
                        **_field_view(row, "meta_description_en"),
                        **_gate(session, batch),
                        "price_error": f"{price!r} is not a price I can read.",
                    },
                )

            row.price_aed = parsed
            row.price_source = PriceSource.entered if parsed is not None else None
            row.price_entered_by = user.email if parsed is not None else None
            row.price_set_at = utcnow() if parsed is not None else None
            session.add(
                AuditEvent(
                    batch_id=batch.id,
                    actor=user.email,
                    action="price_set",
                    payload_json=json.dumps(
                        {"row_index": row_index, "price_aed": parsed}, sort_keys=True
                    ),
                )
            )
            session.flush()

            await generation.regenerate_field(
                session, row, "meta_description_en",
                locale=batch.locale,
                brand_suffix_applied=batch.brand_suffix_applied,
            )
            return templates.TemplateResponse(
                request,
                "_field_response.html",
                {
                    "batch": batch,
                    "row": row,
                    **_field_view(row, "meta_description_en"),
                    **_gate(session, batch),
                },
            )


@router.post("/batch/{batch_id}/export")
async def export(batch_id: int) -> Response:
    """Generate the workbook and return it as a download.

    Blocked while any Tier 1 error stands — the button is disabled in the UI, and this is
    the server-side half of the same gate.
    """
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            user = ingest.demo_user(session)
            try:
                outcome = export_service.create_export(session, batch, user=user)
            except ExportBlocked as blocked:
                rows = ", ".join(str(i) for i in blocked.blocking_rows)
                raise HTTPException(
                    status_code=409,
                    detail=f"{blocked} Rows: {rows or 'batch-level rules'}",
                ) from blocked
            return Response(
                content=outcome.content,
                media_type=XLSX,
                headers={
                    "Content-Disposition": f'attachment; filename="{outcome.file_name}"',
                    "X-Export-Sha256": outcome.sha256,
                },
            )


@router.post("/batch/{batch_id}/reopen")
async def reopen(batch_id: int) -> Response:
    """Return to the keyword step after approval. Generated copy is marked stale, retained."""
    async with write_lock():
        with session_scope() as session:
            batch = _batch(session, batch_id)
            user = ingest.demo_user(session)
            affected = sum(generation.mark_copy_stale(session, r) for r in batch.rows)
            batch.status = BS.keywords_ready
            session.add(
                AuditEvent(
                    batch_id=batch.id,
                    actor=user.email,
                    action="keywords_reopened",
                    payload_json=f'{{"stale_copy_fields": {affected}}}',
                )
            )
    return RedirectResponse(f"/batch/{batch_id}/step/2", status_code=303)
