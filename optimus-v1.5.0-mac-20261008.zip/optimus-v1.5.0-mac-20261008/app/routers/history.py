"""History and re-download.

A download regenerates the workbook from the stored records rather than serving a saved
file, replaying the original version and timestamp, so it is byte-identical to the first
download and history can never drift from the data.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, Response
from sqlalchemy import select

from app.db import session_scope
from app.models import Batch, Export
from app.services import export_service, retention
from app.services.export_service import ExportBlocked
from app.web import templates

router = APIRouter()

XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"


@router.get("/history", response_class=HTMLResponse)
async def history(request: Request) -> Response:
    with session_scope() as session:
        batches = list(session.scalars(select(Batch).order_by(Batch.id.desc())))
        rows = [
            {
                "batch": batch,
                "row_count": len(batch.rows),
                "export_count": len(batch.exports),
                "latest_export": max(batch.exports, key=lambda e: e.version, default=None),
                "days_left": retention.days_until_expiry(batch),
                "expired": batch.is_expired,
            }
            for batch in batches
        ]
        return templates.TemplateResponse(request, "history.html", {"rows": rows})


@router.get("/exports/{export_id}/download")
async def download_export(export_id: int) -> Response:
    with session_scope() as session:
        export = session.get(Export, export_id)
        if export is None:
            raise HTTPException(status_code=404, detail=f"No export {export_id}.")
        try:
            outcome = export_service.regenerate_export(session, export)
        except ExportBlocked as blocked:
            raise HTTPException(
                status_code=409,
                detail=(
                    f"This export can no longer be regenerated: {blocked} "
                    "The batch has been edited since it was created."
                ),
            ) from blocked
        return Response(
            content=outcome.content,
            media_type=XLSX,
            headers={
                "Content-Disposition": f'attachment; filename="{outcome.file_name}"',
                "X-Export-Sha256": outcome.sha256,
            },
        )
