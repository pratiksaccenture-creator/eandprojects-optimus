"""Runtime configuration.

Every setting has a working default, because brief §11 requires the app to run end to end
with no environment variables set at all.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# The build, shown in the masthead and reported by /healthz.
#
# Worth having on screen once anyone other than the person who built it is testing. "It
# did something odd" is unanswerable without knowing which build they were on, and a
# client testing a hosted copy cannot be asked to check a commit they have no access to.
# Bumped by hand: there is no git on this machine, so nothing can derive it.
BUILD_VERSION = "1.5.0"

# What a provider resolves to when nothing is configured for it.
#
# This used to be "fixture", so a tool with no credentials quietly served the 29 seeded
# volumes the team collected once for an Apple batch. Labelled as sample data, but served
# all the same — and after the build went to leadership the decision was that seeded
# numbers should not be reachable by accident at all, only by asking for them.
#
# So the absence of a key is now an unconfigured provider, and an unconfigured provider
# refuses at the point of use with a message naming the fix. It never substitutes.
#
# This means brief §11's "runs end to end with no environment variables set" no longer
# holds. That is a deliberate reversal, not an oversight — see DECISIONS.md §29.
UNCONFIGURED = "unconfigured"


def _load_dotenv() -> None:
    """Load credentials from a gitignored `.env`, if one exists.

    Real environment variables always win — `override=False` — so a deployment that sets
    them properly is unaffected. The file exists so nobody has to paste a key into a
    terminal, a ticket, or a chat window to get the tool running.
    """
    env_file = ROOT / ".env"
    if not env_file.exists():
        return
    try:
        from dotenv import load_dotenv
    except ImportError:  # optional dependency; the tool runs fine without it
        return
    load_dotenv(env_file, override=False)


_load_dotenv()


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name, "").strip()
    try:
        return int(raw) if raw else default
    except ValueError:
        return default


@dataclass(frozen=True, slots=True)
class Settings:
    database_url: str
    keyword_provider: str
    llm_provider: str
    page_provider: str
    locale: str
    geo: str
    retention_months: int
    exports_dir: Path
    fixtures_dir: Path
    demo_pacing_ms: int
    demo_user_email: str
    demo_user_name: str
    # Cache expiry, measured on the DATA and not on when we fetched it.
    #
    # `volume_max_vintage_days` is how old the averaged period may be. `volume_recheck_days`
    # is the cost guard: when the published window really is old, re-fetching returns the
    # same old window, so an entry we checked recently is served rather than bought again.
    # Set the first to 0 to bypass the cache entirely.
    volume_max_vintage_days: int
    volume_recheck_days: int

    @property
    def volume_cache_enabled(self) -> bool:
        return self.volume_max_vintage_days > 0

    @property
    def pacing_enabled(self) -> bool:
        return self.demo_pacing_ms > 0

    @property
    def fully_live(self) -> bool:
        return (
            self.keyword_provider not in {"fixture", UNCONFIGURED}
            and self.llm_provider not in {"fixture", UNCONFIGURED}
            and self.page_provider != "none"
        )

    @property
    def configured(self) -> bool:
        """Whether the tool can actually do its job. False means it will refuse."""
        return UNCONFIGURED not in {self.keyword_provider, self.llm_provider}

    @property
    def missing_providers(self) -> tuple[str, ...]:
        """Which providers have nothing configured, for the message that says so."""
        missing: list[str] = []
        if self.keyword_provider == UNCONFIGURED:
            missing.append("search volumes")
        if self.llm_provider == UNCONFIGURED:
            missing.append("copy model")
        return tuple(missing)


def _resolve_provider(
    explicit_var: str, default: str, *candidates: tuple[str, tuple[str, ...]]
) -> str:
    """Pick a provider, preferring an explicit setting and otherwise detecting credentials.

    An explicit `KEYWORD_PROVIDER` / `LLM_PROVIDER` / `PAGE_PROVIDER` always wins. That
    is how the offline demo mode survives: `KEYWORD_PROVIDER=fixture` still works and is
    the only way to reach seeded volumes, because nothing resolves to them on its own any
    more. A break-glass for a venue with no network, not a default.

    Otherwise the first candidate whose credentials are present is selected, so the live
    path works as soon as a key is added with no second setting to remember. When none
    are present the result is `UNCONFIGURED`, and the provider factory refuses rather
    than substituting anything.

    Candidate order is the preference order when more than one is configured.
    """
    explicit = os.environ.get(explicit_var, "").strip()
    if explicit:
        return explicit.lower()
    for value, keys in candidates:
        if any(os.environ.get(key) for key in keys):
            return value
    return default


def _page_provider(llm_provider: str) -> str:
    """Whether to fetch pages, following the RESOLVED model rather than raw credentials.

    Keying this off the credentials directly meant `LLM_PROVIDER=fixture` still fetched
    every page over the network — twelve seconds a row on a run explicitly asked to stay
    offline, with nothing configured that could read the result. Reading a page nothing
    can interpret is pure cost and pure delay.

    An explicit `PAGE_PROVIDER` still wins, so fetching can be forced either way.
    """
    explicit = os.environ.get("PAGE_PROVIDER", "").strip()
    if explicit:
        return explicit.lower()
    # Nothing to read a page WITH means nothing to read a page FOR — an unconfigured
    # model is as good a reason not to fetch as a fixture one.
    return "http" if llm_provider not in {"fixture", UNCONFIGURED} else "none"


def _any_model_credential() -> tuple[tuple[str, tuple[str, ...]], ...]:
    return (
        ("openai", ("OPENAI_API_KEY",)),
        ("anthropic", ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN")),
    )


@lru_cache(maxsize=1)
def settings() -> Settings:
    data_dir = ROOT / "data"
    llm_provider = _resolve_provider(
        "LLM_PROVIDER", UNCONFIGURED, *_any_model_credential()
    )
    return Settings(
        database_url=os.environ.get("DATABASE_URL", f"sqlite:///{data_dir / 'app.db'}"),
        keyword_provider=_resolve_provider(
            "KEYWORD_PROVIDER",
            UNCONFIGURED,
            ("dataforseo", ("DATAFORSEO_LOGIN", "DATAFORSEO_PASSWORD")),
            ("semrush", ("SEMRUSH_API_KEY",)),
        ),
        llm_provider=llm_provider,
        # Page fetching follows the RESOLVED model, not the raw credentials. Keying it off
        # the credentials meant `LLM_PROVIDER=fixture` still fetched every page over the
        # network — twelve seconds a row, on a run explicitly asked to stay offline, with
        # nothing able to read the result. Reading a page nothing can interpret is pure
        # cost.
        page_provider=_page_provider(llm_provider),
        locale=os.environ.get("LOCALE", "en"),
        geo=os.environ.get("GEO", "AE"),
        retention_months=_env_int("RETENTION_MONTHS", 6),
        exports_dir=Path(os.environ.get("EXPORTS_DIR", str(data_dir / "exports"))),
        fixtures_dir=Path(os.environ.get("FIXTURES_DIR", str(ROOT / "fixtures"))),
        # Artificial per-row delay. Defaults to zero: brief §0 forbids presenting staged
        # work as live computation, so any pacing is opt-in and labelled in the UI.
        demo_pacing_ms=_env_int("DEMO_PACING_MS", 0),
        demo_user_email=os.environ.get("DEMO_USER_EMAIL", "content.team@eand.ae"),
        demo_user_name=os.environ.get("DEMO_USER_NAME", "Content Team"),
        # 120 days, set from a measurement rather than a guess.
        #
        # On 8 October 2026 a live lookup returned figures covering the twelve months to
        # **August 2026** — the published window was already 68 days behind. The first
        # value here was 75 days, which would have called that data stale within a week
        # and re-bought every term on a schedule set by our own threshold rather than by
        # anything changing.
        #
        # 120 days accommodates that observed lag with room for a refresh to arrive late.
        # It is a tolerance, explicitly NOT an alignment to a cadence: DECISIONS.md §38
        # records that Google publishes none and that DataForSEO's is unverified.
        volume_max_vintage_days=_env_int("VOLUME_MAX_VINTAGE_DAYS", 120),
        volume_recheck_days=_env_int("VOLUME_RECHECK_DAYS", 14),
    )
