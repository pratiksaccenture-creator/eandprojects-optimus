"""Persistence model — brief §4.

Mirrors the schema in the brief, with three additions the fixtures force and one the
byte-identical export guarantee forces. Each is marked below.

Brief §1 rule 4 requires every generated string to be traceable: which keywords fed it,
which model produced it, which prompt version, which attempt, and the validation result.
`CopyField` therefore appends rather than mutates — an edit or a regeneration creates a new
attempt and the previous one is retained.
"""

from __future__ import annotations

import datetime as dt
import enum
from typing import Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    Enum,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.UTC).replace(tzinfo=None)


# ---------------------------------------------------------------- enums


class PageType(str, enum.Enum):
    product = "product"
    category = "category"
    content = "content"


class FetchStatus(str, enum.Enum):
    ok = "ok"
    unreachable = "unreachable"
    blocked = "blocked"
    not_attempted = "not_attempted"


class KeywordType(str, enum.Enum):
    """The buckets the content team produces by hand today, one ChatGPT prompt each.

    `benefit` and `geo_prompt` predate the keyword-research pivot and are kept so older
    batches still load. New work uses the six buckets in `policy.KEYWORD_BUCKETS`.
    """

    brand = "brand"
    product = "product"
    device = "device"
    category = "category"
    usp = "usp"
    smartpay = "smartpay"
    benefit = "benefit"
    geo_prompt = "geo_prompt"


class KeywordTier(str, enum.Enum):
    """How hard a page works for a term.

    The SEO Copy Guidelines ask for the primary keyword plus "secondary and tertiary
    keywords (where space permits and based on relevance and volume)". Until now the tool
    only modelled the primary and lumped everything else together as "supporting", so the
    guideline's three levels could not actually be expressed.

    Each tier is a different instruction to the writer:

      primary    must appear in the meta title, early. Exactly one per row.
      secondary  should appear in the description. A handful.
      tertiary   used if there is room after the above. Nice to have.
      unranked   researched and shown, but not targeted.
    """

    primary = "primary"
    secondary = "secondary"
    tertiary = "tertiary"
    unranked = "unranked"


class PriceSource(str, enum.Enum):
    """Where a price came from. There is no `model` member, and that is the point.

    The SEO Copy Guidelines require a starting price in every description; the tool allows
    one only when a human supplied it. Both members below are human acts — a column someone
    filled in, or a figure someone typed into the row.
    """

    input_sheet = "input_sheet"
    entered = "entered"


class UspSource(str, enum.Enum):
    """Who proposed a selling point.

    Unlike `PriceSource` there IS a `model` member, because a model proposing a claim is
    the normal case here and hiding that would be the dishonest part. What a model cannot
    do is approve one: `ProductUsp.is_selected` is only ever written by a person.
    """

    model = "model"
    entered = "entered"


class KeywordStatus(str, enum.Enum):
    approved = "approved"
    parked = "parked"
    unverified = "unverified"
    rejected = "rejected"


class BatchStatus(str, enum.Enum):
    uploaded = "uploaded"
    keywords_ready = "keywords_ready"
    approved = "approved"
    generated = "generated"
    exported = "exported"


class RowStage(str, enum.Enum):
    """Per-row progress, so a reload mid-generation resumes only what is unfinished."""

    pending = "pending"
    keywords_ready = "keywords_ready"
    generated = "generated"
    failed = "failed"
    skipped = "skipped"


# ---------------------------------------------------------------- tables


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(200), unique=True)


class Batch(Base):
    __tablename__ = "batches"

    id: Mapped[int] = mapped_column(primary_key=True)
    batch_no: Mapped[str] = mapped_column(String(60))
    source_file_name: Mapped[str] = mapped_column(String(260))
    sheet_name: Mapped[str] = mapped_column(String(200))
    uploaded_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    status: Mapped[BatchStatus] = mapped_column(
        Enum(BatchStatus, native_enum=False), default=BatchStatus.uploaded
    )
    locale: Mapped[str] = mapped_column(String(10), default="en")
    geo: Mapped[str] = mapped_column(String(10), default="AE")
    retention_expires_at: Mapped[dt.datetime] = mapped_column(DateTime)

    # Which input format this batch came from: "template" for the keyword-research sheet,
    # "legacy" for the original URL batch file. Stored rather than re-sniffed, because the
    # export has to give back the shape the file arrived in, and the uploaded file may be
    # long gone by the time someone re-downloads from history.
    input_layout: Mapped[str] = mapped_column(String(20), default="legacy")

    # The brand-suffix decision is stored rather than recomputed. Recomputing at export
    # time would make a re-export produce different bytes if the limits config had changed,
    # breaking the byte-identical guarantee in §11.
    brand_suffix_applied: Mapped[Optional[bool]] = mapped_column(Boolean, default=None)
    brand_suffix_reason: Mapped[Optional[str]] = mapped_column(Text, default=None)
    brand_suffix_blocking_row: Mapped[Optional[int]] = mapped_column(Integer, default=None)

    approved_at: Mapped[Optional[dt.datetime]] = mapped_column(DateTime, default=None)
    approved_by_user_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id"), default=None
    )

    rows: Mapped[list["BatchRow"]] = relationship(
        back_populates="batch", cascade="all, delete-orphan", order_by="BatchRow.row_index"
    )
    exports: Mapped[list["Export"]] = relationship(
        back_populates="batch", cascade="all, delete-orphan", order_by="Export.version"
    )
    events: Mapped[list["AuditEvent"]] = relationship(
        back_populates="batch", cascade="all, delete-orphan", order_by="AuditEvent.id"
    )

    @property
    def is_expired(self) -> bool:
        return self.retention_expires_at <= utcnow()


class BatchRow(Base):
    __tablename__ = "batch_rows"
    __table_args__ = (UniqueConstraint("batch_id", "row_index", name="uq_batch_row_index"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    batch_id: Mapped[int] = mapped_column(ForeignKey("batches.id"), index=True)
    row_index: Mapped[int] = mapped_column(Integer)

    category_raw: Mapped[str] = mapped_column(Text)
    category_norm: Mapped[str] = mapped_column(Text, index=True)
    # Optional since the keyword-research pivot: the input template carries no URL. Kept
    # because the older three-URL-column format still reads into this schema, and because
    # a row that does have a URL can still be grounded against the live page.
    product_url: Mapped[str] = mapped_column(Text, default="")
    product_name: Mapped[str] = mapped_column(Text, default="")
    go_live_raw: Mapped[Optional[str]] = mapped_column(Text, default=None)

    # The template has a Brand column that arrives empty on every row today. When it is
    # filled it is authoritative; when it is not, the brand is read off the product name
    # and `brand_derived` records that it was a guess, so the UI can show it as one.
    brand: Mapped[str] = mapped_column(Text, default="")
    brand_derived: Mapped[bool] = mapped_column(Boolean, default=False)

    # The starting price, and where it came from. Null means no price was supplied, which
    # is allowed: the description is then written without one and carries a warning.
    price_aed: Mapped[Optional[float]] = mapped_column(Float, default=None)
    price_source: Mapped[Optional[PriceSource]] = mapped_column(
        Enum(PriceSource, native_enum=False), default=None
    )
    price_entered_by: Mapped[Optional[str]] = mapped_column(String(200), default=None)
    price_set_at: Mapped[Optional[dt.datetime]] = mapped_column(DateTime, default=None)

    # The input carries two different date number formats (m/d/yyyy and d-mmm-yy). Both the
    # serial and its format are kept, or the exported Date column degrades to text.
    date_serial: Mapped[Optional[float]] = mapped_column(Float, default=None)
    date_number_format: Mapped[Optional[str]] = mapped_column(String(60), default=None)
    date_value: Mapped[Optional[dt.datetime]] = mapped_column(DateTime, default=None)

    page_type: Mapped[PageType] = mapped_column(
        Enum(PageType, native_enum=False), default=PageType.content
    )
    fetch_status: Mapped[FetchStatus] = mapped_column(
        Enum(FetchStatus, native_enum=False), default=FetchStatus.not_attempted
    )
    fetch_note: Mapped[Optional[str]] = mapped_column(Text, default=None)

    # Facts read off the live page, when one was fetched. Stored as JSON so copy generation
    # can cite only what the page actually said, and so the export can show where a
    # specification came from. Empty means nothing was read and no specifics may be stated.
    page_title: Mapped[Optional[str]] = mapped_column(Text, default=None)
    facts_json: Mapped[str] = mapped_column(Text, default="{}")
    page_fetched_at: Mapped[Optional[dt.datetime]] = mapped_column(DateTime, default=None)
    skip_reason: Mapped[Optional[str]] = mapped_column(Text, default=None)
    stage: Mapped[RowStage] = mapped_column(
        Enum(RowStage, native_enum=False), default=RowStage.pending
    )

    batch: Mapped[Batch] = relationship(back_populates="rows")
    keywords: Mapped[list["Keyword"]] = relationship(
        back_populates="row", cascade="all, delete-orphan", order_by="Keyword.id"
    )
    copy_fields: Mapped[list["CopyField"]] = relationship(
        back_populates="row", cascade="all, delete-orphan", order_by="CopyField.id"
    )
    usps: Mapped[list["ProductUsp"]] = relationship(
        back_populates="row", cascade="all, delete-orphan", order_by="ProductUsp.id"
    )

    @property
    def formatted_price(self) -> Optional[str]:
        """The supplied price as it may appear in copy, or None.

        Single source of truth for the string: the generator puts this into the prompt and
        the validator forgives exactly this string and nothing else, so the two cannot
        disagree about what was authorised.
        """
        from app.lib.policy import format_price

        return None if self.price_aed is None else format_price(self.price_aed)


class Keyword(Base):
    __tablename__ = "keywords"
    __table_args__ = (Index("ix_keyword_row_term", "batch_row_id", "term_normalized"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    batch_row_id: Mapped[int] = mapped_column(ForeignKey("batch_rows.id"), index=True)

    term: Mapped[str] = mapped_column(Text)
    term_normalized: Mapped[str] = mapped_column(Text, index=True)
    type: Mapped[KeywordType] = mapped_column(
        Enum(KeywordType, native_enum=False), default=KeywordType.category
    )

    # Nullable by design. A provider that has no data for a term yields NULL, the term is
    # marked `unverified` and excluded. Brief §1 rule 1: an LLM never produces a volume,
    # and a missing number is never inferred or interpolated. See
    # tests/test_no_llm_volumes.py, which enforces this structurally.
    volume: Mapped[Optional[int]] = mapped_column(Integer, default=None)
    cpc: Mapped[Optional[float]] = mapped_column(Float, default=None)
    competition: Mapped[Optional[str]] = mapped_column(String(30), default=None)

    source: Mapped[str] = mapped_column(String(80))
    is_live_data: Mapped[bool] = mapped_column(Boolean, default=False)
    # The end of the period this figure averages, not when it was fetched. See
    # `VolumeResult.data_date` — this used to hold the time of the request.
    data_date: Mapped[Optional[dt.datetime]] = mapped_column(DateTime, default=None)
    months_covered: Mapped[Optional[int]] = mapped_column(Integer, default=None)

    # True when the volume provider produced this term by expanding a seed, false when the
    # model proposed it. Recorded because the two carry different weight: an expanded term
    # is something people demonstrably search for, a seed is a hypothesis until priced.
    is_expansion: Mapped[bool] = mapped_column(Boolean, default=False)

    locale: Mapped[str] = mapped_column(String(10), default="en")
    geo: Mapped[str] = mapped_column(String(10), default="AE")
    status: Mapped[KeywordStatus] = mapped_column(
        Enum(KeywordStatus, native_enum=False), default=KeywordStatus.parked
    )
    # `is_primary` is kept as the mirror of `tier == primary`, because a lot of existing
    # code and several ORDER BYs read it. `set_keyword_tier` is the only place either is
    # written, so they cannot drift.
    is_primary: Mapped[bool] = mapped_column(Boolean, default=False)
    tier: Mapped[KeywordTier] = mapped_column(
        Enum(KeywordTier, native_enum=False), default=KeywordTier.unranked
    )

    approved_by_user_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("users.id"), default=None
    )
    approved_at: Mapped[Optional[dt.datetime]] = mapped_column(DateTime, default=None)

    row: Mapped[BatchRow] = relationship(back_populates="keywords")

    @property
    def is_verified(self) -> bool:
        return self.volume is not None


class ProductUsp(Base):
    """A selling point offered to the writer for one row.

    Separate from `Keyword` because it answers a different question. A keyword is a
    measured fact about demand; a USP is an unmeasured claim about the product, and the
    two must not be shown or treated as the same kind of thing. The content team asked for
    these alongside the keywords so they have something to write from.

    Nothing here reaches copy until `is_selected` is set, and selecting records who and
    when — an approved claim has an owner. `is_grounded` is true only when the claim came
    off a fetched page; otherwise it is model recall and the screen says so.
    """

    __tablename__ = "product_usps"
    __table_args__ = (Index("ix_usp_row", "batch_row_id", "id"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    batch_row_id: Mapped[int] = mapped_column(ForeignKey("batch_rows.id"), index=True)

    claim: Mapped[str] = mapped_column(Text)
    source: Mapped[UspSource] = mapped_column(
        Enum(UspSource, native_enum=False), default=UspSource.model
    )
    # True only for a claim taken off a page the tool actually read. Never set from the
    # model's own assertion that it was — see `_prompts.read_ideas`.
    is_grounded: Mapped[bool] = mapped_column(Boolean, default=False)
    model: Mapped[str] = mapped_column(String(120), default="")

    is_selected: Mapped[bool] = mapped_column(Boolean, default=False)
    selected_by: Mapped[Optional[str]] = mapped_column(String(200), default=None)
    selected_at: Mapped[Optional[dt.datetime]] = mapped_column(DateTime, default=None)

    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)

    row: Mapped[BatchRow] = relationship(back_populates="usps")


class CopyField(Base):
    __tablename__ = "copy_fields"
    __table_args__ = (
        Index("ix_copy_row_field_attempt", "batch_row_id", "field", "attempt"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    batch_row_id: Mapped[int] = mapped_column(ForeignKey("batch_rows.id"), index=True)

    field: Mapped[str] = mapped_column(String(60))
    locale: Mapped[str] = mapped_column(String(10), default="en")
    text: Mapped[str] = mapped_column(Text)

    char_count: Mapped[int] = mapped_column(Integer)
    grapheme_count: Mapped[int] = mapped_column(Integer)
    byte_length: Mapped[int] = mapped_column(Integer)
    pixel_width: Mapped[float] = mapped_column(Float)

    valid: Mapped[bool] = mapped_column(Boolean, default=False)
    validation_json: Mapped[str] = mapped_column(Text, default="[]")

    model: Mapped[str] = mapped_column(String(120))
    prompt_version: Mapped[str] = mapped_column(String(40))
    attempt: Mapped[int] = mapped_column(Integer, default=1)
    keywords_used: Mapped[str] = mapped_column(Text, default="[]")
    edited_by_user: Mapped[bool] = mapped_column(Boolean, default=False)

    # Superseded rather than deleted, so history stays complete. Set when keywords are
    # reopened after approval, per brief §1 rule 4.
    is_current: Mapped[bool] = mapped_column(Boolean, default=True)
    is_stale: Mapped[bool] = mapped_column(Boolean, default=False)

    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)

    row: Mapped[BatchRow] = relationship(back_populates="copy_fields")


class VolumeCache(Base):
    """A search volume already paid for, keyed on what was asked.

    DataForSEO bills per request, and the tool was asking the same questions repeatedly:
    every batch that contains a Samsung phone looks up "samsung", every projector row
    looks up "projector". Across the seven batches in testing, the same terms were bought
    several times over.

    What makes this safe to cache is that the figure is a **monthly average**, not a live
    reading. Google's keyword planner reports the average monthly searches over the last
    twelve months, updated monthly, so a figure fetched on the 1st and a figure fetched on
    the 20th are the same number. Caching it for a month loses nothing; caching it for ever
    would quietly serve a figure nobody could date, which is why `fetched_at` is stored and
    enforced rather than just recorded.

    A miss and a measured zero are different things and are stored differently: `volume`
    is nullable, and a cached NULL means "we asked, and Google had no data" — worth
    remembering, because asking again costs the same as asking the first time.
    """

    __tablename__ = "volume_cache"
    __table_args__ = (
        UniqueConstraint("term_normalized", "geo", "locale", name="uq_volume_cache_key"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    term_normalized: Mapped[str] = mapped_column(Text, index=True)
    geo: Mapped[str] = mapped_column(String(10), default="AE")
    locale: Mapped[str] = mapped_column(String(10), default="en")

    # Nullable, and the null is meaningful. See the class docstring.
    volume: Mapped[Optional[int]] = mapped_column(Integer, default=None)
    cpc: Mapped[Optional[float]] = mapped_column(Float, default=None)
    competition: Mapped[Optional[str]] = mapped_column(String(30), default=None)

    # Carried through so a cached figure keeps its provenance. A term served from here must
    # be as auditable as one served from the network.
    source: Mapped[str] = mapped_column(String(80), default="")
    # The END of the period the figure averages, read from the provider's own monthly
    # breakdown. NULL means the vintage is unknown, and an entry with an unknown vintage
    # is never served — expiry is measured on this, not on `fetched_at`.
    data_date: Mapped[Optional[dt.datetime]] = mapped_column(DateTime, default=None)
    months_covered: Mapped[Optional[int]] = mapped_column(Integer, default=None)

    # When we last asked. Not a measure of the data's age — the two are unrelated — but
    # the clock the re-check guard reads, so a stale-but-newest figure is not re-bought on
    # every row.
    fetched_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow, index=True)
    hits: Mapped[int] = mapped_column(Integer, default=0)


class KeywordRegistry(Base):
    """Which row owns a term in a category, across batches — feeds cannibalisation checks."""

    __tablename__ = "keyword_registry"
    __table_args__ = (
        UniqueConstraint("category_norm", "term", name="uq_registry_category_term"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    category_norm: Mapped[str] = mapped_column(Text, index=True)
    term: Mapped[str] = mapped_column(Text)
    primary_for_row_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("batch_rows.id", ondelete="SET NULL"), default=None
    )
    first_seen_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)


class Export(Base):
    """A generated workbook.

    `file_path` is where the bytes were written, but re-download regenerates from the
    stored records rather than serving that file, so history can never drift from the
    data. The stored `created_at` and `version` are replayed into the regenerated workbook
    so the bytes match the original exactly.
    """

    __tablename__ = "exports"
    __table_args__ = (UniqueConstraint("batch_id", "version", name="uq_export_version"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    batch_id: Mapped[int] = mapped_column(ForeignKey("batches.id"), index=True)
    version: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    file_name: Mapped[str] = mapped_column(String(260))
    file_path: Mapped[Optional[str]] = mapped_column(Text, default=None)
    row_count: Mapped[int] = mapped_column(Integer, default=0)
    sha256: Mapped[Optional[str]] = mapped_column(String(64), default=None)
    created_by_user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))

    batch: Mapped[Batch] = relationship(back_populates="exports")


class AsoProfile(Base):
    """App store copy, per brief §7.

    Deliberately NOT attached to a `BatchRow`. Apple's name, subtitle and keyword field
    belong to the APP, not to a product SKU, so generating them per row would be a category
    error. This is its own record driven by its own form, and the export's ASO sheet reads
    from the most recently updated one.
    """

    __tablename__ = "aso_profiles"

    id: Mapped[int] = mapped_column(primary_key=True)
    app_name: Mapped[str] = mapped_column(String(120), default="")
    subtitle: Mapped[str] = mapped_column(String(120), default="")
    keyword_field: Mapped[str] = mapped_column(Text, default="")
    promo_text: Mapped[str] = mapped_column(Text, default="")
    play_title: Mapped[str] = mapped_column(String(120), default="")
    play_short: Mapped[str] = mapped_column(Text, default="")
    locale: Mapped[str] = mapped_column(String(10), default="en")
    updated_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)


class AuditEvent(Base):
    __tablename__ = "audit_events"

    id: Mapped[int] = mapped_column(primary_key=True)
    batch_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("batches.id"), index=True, default=None
    )
    actor: Mapped[str] = mapped_column(String(200))
    action: Mapped[str] = mapped_column(String(80))
    payload_json: Mapped[str] = mapped_column(Text, default="{}")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)

    batch: Mapped[Optional[Batch]] = relationship(back_populates="events")
