"""Validation orchestration — the bridge between the ORM and the pure validators.

The validators in `app.lib.validators` never touch the database. This module builds the
frozen value objects they consume and turns their findings back into persisted records, so
the validation layer stays unit-testable against literals.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

import regex
from sqlalchemy.orm import Session

from app.lib import limits
from app.lib.surfaces import GATING_SURFACE, TITLE_DESKTOP
from app.lib.validators import (
    BatchSnapshot,
    BrandDecision,
    FieldContext,
    Finding,
    RowSnapshot,
    decide_brand_suffix,
    parse_identity,
    sort_findings,
    validate_batch,
    validate_field,
    validate_keyword_cell,
)
from app.models import Batch, BatchRow, CopyField, KeywordStatus, KeywordTier
from app.services.keyword_service import approved_terms_for_row

TIER1_FIELDS = ("meta_title_en", "meta_description_en")


def current_text(row: BatchRow, field: str) -> str:
    current = current_field(row, field)
    return current.text if current else ""


def current_field(row: BatchRow, field: str) -> CopyField | None:
    """The live attempt for a field: highest attempt number that is still current."""
    candidates = [c for c in row.copy_fields if c.field == field and c.is_current]
    if not candidates:
        return None
    return max(candidates, key=lambda c: (c.attempt, c.id))


def row_snapshot(row: BatchRow) -> RowSnapshot:
    primary = next((k for k in row.keywords if k.is_primary), None)
    return RowSnapshot(
        row_index=row.row_index,
        category_norm=row.category_norm,
        category_raw=row.category_raw,
        url=row.product_url,
        product_name=row.product_name,
        title=current_text(row, "meta_title_en"),
        description=current_text(row, "meta_description_en"),
        primary_keyword=primary.term if primary else None,
        keyword_terms=approved_terms_for_row(row),
        skipped_reason=row.skip_reason,
    )


def batch_snapshot(
    batch: Batch, registry: dict[tuple[str, str], int] | None = None
) -> BatchSnapshot:
    return BatchSnapshot(
        rows=tuple(row_snapshot(r) for r in sorted(batch.rows, key=lambda r: r.row_index)),
        registry=registry or {},
        locale=batch.locale,
    )


def field_context(
    row: BatchRow,
    field: str,
    *,
    locale: str,
    brand_suffix_applied: bool | None,
    human_edited: bool = False,
) -> FieldContext:
    primary = next((k for k in row.keywords if k.is_primary), None)
    secondary = tuple(
        k.term for k in sorted(
            (k for k in row.keywords
             if not k.is_primary and k.status is KeywordStatus.approved and k.volume is not None),
            key=lambda k: (-(k.volume or 0), k.term_normalized),
        )
    )
    # The terms that carry a tier — what the page is actually targeting, and what the
    # prompt was given. Narrower than `secondary` above, which is every approved term on
    # the row, because "available to target" and "chosen to target" are different claims
    # and `no_unrequested_location` depends on the second one.
    requested = tuple(
        k.term for k in row.keywords
        if k.tier is not KeywordTier.unranked and k.status is not KeywordStatus.rejected
    )
    return FieldContext(
        field=field,
        row_index=row.row_index,
        locale=locale,
        surface=GATING_SURFACE.get(field),
        product_name=row.product_name,
        brand=row.brand,
        identity=parse_identity(row.product_name),
        primary_keyword=primary.term if primary else None,
        secondary_keywords=secondary,
        requested_terms=requested,
        human_edited=human_edited,
        brand_suffix_applied=brand_suffix_applied,
        # Read off the row, so the permission to print a figure comes from the stored
        # human decision and nothing else. A price the model produced on a row where
        # `price_aed` is null has no matching allowance and stays a blocking error.
        allowed_price=row.formatted_price,
    )


def validate_row_field(
    row: BatchRow,
    field: str,
    text: str,
    *,
    locale: str,
    brand_suffix_applied: bool | None,
    human_edited: bool = False,
) -> list[Finding]:
    context = field_context(
        row,
        field,
        locale=locale,
        brand_suffix_applied=brand_suffix_applied,
        human_edited=human_edited,
    )
    return validate_field(text, context)


def decide_batch_brand_suffix(batch: Batch) -> BrandDecision:
    return decide_brand_suffix(batch_snapshot(batch), TITLE_DESKTOP)


def persist_brand_decision(session: Session, batch: Batch, decision: BrandDecision) -> None:
    batch.brand_suffix_applied = decision.applied
    batch.brand_suffix_reason = decision.reason
    batch.brand_suffix_blocking_row = decision.blocking_row
    session.flush()


@dataclass(frozen=True, slots=True)
class RowReport:
    row_index: int
    product_name: str
    findings: tuple[Finding, ...]

    @property
    def errors(self) -> tuple[Finding, ...]:
        return tuple(f for f in self.findings if f.severity == "error")

    @property
    def warnings(self) -> tuple[Finding, ...]:
        return tuple(f for f in self.findings if f.severity == "warning")

    @property
    def blocks_export(self) -> bool:
        return bool(self.errors)


_BATCH_FIELD = regex.compile(r"^row(\d+)\.(.+)$")


def batch_finding_row(finding: Finding) -> int | None:
    """The row a batch-level finding is about, if it names one.

    Batch validators encode it in the field as `row5.meta_title_en`, because the finding
    is about a relationship BETWEEN rows and has no single owner. That row number was
    being thrown away: the export banner counted the error and could not name it, so a
    duplicate title blocked the export while the screen said only "1 field need
    attention" with nothing highlighted anywhere.
    """
    match = _BATCH_FIELD.match(finding.field)
    return int(match.group(1)) if match else None


@dataclass(frozen=True, slots=True)
class BatchReport:
    rows: tuple[RowReport, ...]
    batch_findings: tuple[Finding, ...]

    @property
    def blocking_rows(self) -> tuple[RowReport, ...]:
        return tuple(r for r in self.rows if r.blocks_export)

    @property
    def batch_errors(self) -> tuple[Finding, ...]:
        return tuple(f for f in self.batch_findings if f.severity == "error")

    @property
    def error_count(self) -> int:
        return sum(len(r.errors) for r in self.rows) + len(self.batch_errors)

    @property
    def warning_count(self) -> int:
        return (
            sum(len(r.warnings) for r in self.rows)
            + sum(1 for f in self.batch_findings if f.severity == "warning")
        )

    @property
    def can_export(self) -> bool:
        # Batch-level errors count. A duplicate title is only visible when comparing rows,
        # so a gate that looked at rows in isolation would let two pages ship competing for
        # the same title.
        return not self.blocking_rows and not self.batch_errors


def validate_whole_batch(
    batch: Batch, registry: dict[tuple[str, str], int] | None = None
) -> BatchReport:
    """Validate every Tier 1 field on every row, plus the batch-level rules.

    Rows are visited in index order and findings are sorted, so the validation log and the
    export bytes are reproducible.
    """
    reports: list[RowReport] = []
    for row in sorted(batch.rows, key=lambda r: r.row_index):
        findings: list[Finding] = []

        if row.skip_reason:
            findings.append(
                Finding(
                    code="ROW_SKIPPED",
                    severity="error",
                    message=f"Row not processed: {row.skip_reason}",
                    field="row",
                )
            )
        else:
            for field in TIER1_FIELDS:
                text = current_text(row, field)
                if not text:
                    findings.append(
                        Finding(
                            code="FIELD_MISSING",
                            severity="error",
                            message="Not generated yet.",
                            field=field,
                        )
                    )
                    continue
                findings.extend(
                    validate_row_field(
                        row, field, text,
                        locale=batch.locale,
                        brand_suffix_applied=batch.brand_suffix_applied,
                    )
                )

            keyword_cell = ", ".join(approved_terms_for_row(row))
            if keyword_cell:
                findings.extend(
                    validate_keyword_cell(
                        keyword_cell,
                        field_context(
                            row, "keywords",
                            locale=batch.locale,
                            brand_suffix_applied=batch.brand_suffix_applied,
                        ),
                    )
                )

        reports.append(
            RowReport(
                row_index=row.row_index,
                product_name=row.product_name,
                findings=tuple(sort_findings(findings)),
            )
        )

    snapshot = batch_snapshot(batch, registry)
    return BatchReport(
        rows=tuple(reports),
        batch_findings=tuple(validate_batch(snapshot)),
    )


def measure_and_store(
    copy_field: CopyField, findings: list[Finding], surface_field: str
) -> None:
    """Attach measurements and the validation result to a persisted attempt."""
    measurement = limits.measure(copy_field.text)
    copy_field.char_count = measurement.chars
    copy_field.grapheme_count = measurement.graphemes
    copy_field.byte_length = measurement.bytes
    copy_field.pixel_width = (
        measurement.pixels_title if surface_field == "meta_title_en"
        else measurement.pixels_desc
    )
    copy_field.valid = not any(f.severity == "error" for f in findings)
    copy_field.validation_json = json.dumps(
        [
            {
                "code": f.code,
                "severity": f.severity,
                "message": f.message,
                "field": f.field,
            }
            for f in sort_findings(findings)
        ],
        sort_keys=True,
    )


def findings_from_json(payload: str) -> list[Finding]:
    try:
        raw = json.loads(payload or "[]")
    except json.JSONDecodeError:
        return []
    out: list[Finding] = []
    for item in raw:
        severity = item.get("severity")
        if severity not in ("error", "warning"):
            continue
        out.append(
            Finding(
                code=str(item.get("code", "")),
                severity=severity,
                message=str(item.get("message", "")),
                field=str(item.get("field", "")),
            )
        )
    return out
