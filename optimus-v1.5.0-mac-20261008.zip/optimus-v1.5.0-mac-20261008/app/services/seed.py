"""First-run seed — brief §10 step 9: "Seed a complete demo batch so the tool opens with
something to show."

The seeded batch is produced by the real pipeline, not by inserting pre-baked rows. It is
ingested, keyword-looked-up, approved and generated exactly as an uploaded file would be,
so nothing on screen is a fixture pretending to be a result.
"""

from __future__ import annotations

import os

import anyio
from sqlalchemy import select

from app.config import settings
from app.db import session_scope
from app.models import AsoProfile, Batch, BatchStatus
from app.services import generation, ingest, keyword_service

DEMO_BATCH_NO = "Batch 6"

# Brief §7 requires ASO to be driven by its own form rather than derived per product row.
# These are starting values for the demo, chosen to fit Apple's limits so the tab opens in
# a valid state; the keyword field deliberately avoids repeating words from the name and
# subtitle, since Apple already indexes those.
DEMO_ASO = {
    "app_name": "e& Smart Home",
    "subtitle": "Control lights, locks, climate",
    "keyword_field": "automation,sensor,thermostat,camera,plug,switch,energy,routine",
    "promo_text": "Set up your first routine in minutes and manage every room from one place.",
    "play_title": "e& Smart Home",
    "play_short": "Control lighting, locks, climate and sensors from one app.",
}


def should_seed() -> bool:
    """Whether to build the demo batch on startup.

    The seed runs the real pipeline over every row of the reference file. On fixture
    providers that is instant, free and deterministic, which is exactly what a demo wants.
    On live providers it is none of those things: it would fetch 21 pages and make dozens
    of model calls before the server accepts its first connection, spending real money that
    nobody asked it to spend and leaving the port closed for minutes. So a live
    configuration opens on the upload page instead, and the first live batch is one the
    user chose to run.

    Seeding with fixture providers while the header says "live" was the other option and is
    worse — a seeded batch presented as a live result is the one thing this tool must never
    do.

    `SEED_DEMO_BATCH=1` forces it anyway, for a rehearsal where the cost is intended.
    """
    forced = os.environ.get("SEED_DEMO_BATCH", "").strip().lower()
    if forced in {"1", "true", "yes", "on"}:
        return True
    if forced in {"0", "false", "no", "off"}:
        return False
    config = settings()
    return config.keyword_provider == "fixture" and config.llm_provider == "fixture"


def ensure_aso_profile() -> None:
    with session_scope() as session:
        if session.scalar(select(AsoProfile).limit(1)) is not None:
            return
        session.add(AsoProfile(locale="en", **DEMO_ASO))


async def ensure_demo_batch() -> None:
    """Create the demo batch if the database has none. Safe to call on every start.

    Async because it is awaited from the app lifespan, which is already inside an event
    loop — starting a second one with `anyio.run` there would fail.
    """
    ensure_aso_profile()

    if not should_seed():
        return

    with session_scope() as session:
        if session.scalar(select(Batch).limit(1)) is not None:
            return

    source = settings().fixtures_dir / "input.xlsx"
    if not source.exists():
        return

    with session_scope() as session:
        user = ingest.demo_user(session)
        summary = ingest.ingest_path(session, source, batch_no=DEMO_BATCH_NO, user=user)
        batch_id = summary.batch_id
        user_id = user.id
        actor = user.email

    with session_scope() as session:
        batch = session.get(Batch, batch_id)
        if batch is None:
            return
        for row in batch.rows:
            await keyword_service.populate_row_keywords(
                session, row, locale=batch.locale, geo=batch.geo
            )
        keyword_service.approve_keywords(session, batch, user_id=user_id, actor=actor)
        keyword_service.record_registry_claims(session, batch)
        await generation.generate_batch(session, batch)
        batch.status = BatchStatus.generated


def seed_demo_batch_sync() -> None:
    """Synchronous entry point, for scripts and tests outside an event loop."""
    anyio.run(ensure_demo_batch)
