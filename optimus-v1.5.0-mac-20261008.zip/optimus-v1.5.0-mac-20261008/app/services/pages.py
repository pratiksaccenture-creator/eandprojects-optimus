"""Page fetching and fact extraction.

Runs per row, during the keyword step, because that step already fans out one request per
row and the facts are needed before copy generation.

Two things are deliberate:

  * `fetch_status` becomes truthful. With a fetching provider selected, `ok` means a page
    really responded. With the no-fetch provider, no row is ever `ok`.
  * Facts are verbatim-or-absent. The extractor is instructed to copy what the page says
    and leave out anything it does not. A row with no facts generates copy without
    specifics rather than copy with invented ones.

A failure here never fails the row: it is recorded as a status and a reason, which surface
on the row and in the export's validation log.
"""

from __future__ import annotations

import json

from sqlalchemy.orm import Session

from app.models import BatchRow, FetchStatus, utcnow
from app.providers.llm import PageFacts, get_llm
from app.providers.pages import get_page_provider

STATUS_MAP = {
    "ok": FetchStatus.ok,
    "unreachable": FetchStatus.unreachable,
    "blocked": FetchStatus.blocked,
    "not_attempted": FetchStatus.not_attempted,
}


def stored_facts(row: BatchRow) -> PageFacts:
    """Facts previously extracted for a row, or empty facts."""
    try:
        payload = json.loads(row.facts_json or "{}")
    except json.JSONDecodeError:
        return PageFacts()
    if not isinstance(payload, dict) or not payload:
        return PageFacts()
    return PageFacts(
        product_name=str(payload.get("product_name", "")),
        summary=str(payload.get("summary", "")),
        specifications=tuple(str(s) for s in payload.get("specifications", [])),
        features=tuple(str(f) for f in payload.get("features", [])),
        source_url=str(payload.get("source_url", "")),
        grounded=bool(payload.get("grounded", False)),
    )


def _store(row: BatchRow, facts: PageFacts) -> None:
    row.facts_json = json.dumps(
        {
            "product_name": facts.product_name,
            "summary": facts.summary,
            "specifications": list(facts.specifications),
            "features": list(facts.features),
            "source_url": facts.source_url,
            "grounded": facts.grounded,
        },
        sort_keys=True,
    )


async def ground_row(session: Session, row: BatchRow) -> PageFacts:
    """Fetch the row's page and extract facts. Idempotent per row.

    Returns the facts now known for the row, which may be empty — an empty result is a
    valid outcome, not an error.
    """
    existing = stored_facts(row)
    if existing.grounded or row.page_fetched_at is not None:
        return existing

    provider = get_page_provider()
    result = await provider.fetch(row.product_url)

    row.fetch_status = STATUS_MAP.get(result.status, FetchStatus.not_attempted)
    row.fetch_note = result.note
    row.page_title = result.title or None
    row.page_fetched_at = utcnow()

    if not result.has_content:
        _store(row, PageFacts(source_url=row.product_url, grounded=False))
        session.flush()
        return stored_facts(row)

    model = get_llm()
    try:
        facts = await model.extract_facts(
            product_name=row.product_name,
            url=row.product_url,
            page_title=result.title,
            page_text=result.text,
        )
    except Exception as error:  # noqa: BLE001 - a failed extraction must not fail the row
        row.fetch_note = (
            f"{result.note or 'Page read'} — facts could not be extracted "
            f"({type(error).__name__}). Copy will avoid specifics."
        )
        _store(row, PageFacts(source_url=row.product_url, grounded=False))
        session.flush()
        return stored_facts(row)

    _store(row, facts)
    session.flush()
    return facts


def facts_summary(row: BatchRow) -> str:
    """A short human line about what grounds this row, for the UI."""
    facts = stored_facts(row)
    if not facts.grounded:
        return "not grounded"
    count = len(facts.specifications) + len(facts.features)
    if not count:
        return "page read, no specifics found"
    return f"{count} fact{'s' if count != 1 else ''} from page"
