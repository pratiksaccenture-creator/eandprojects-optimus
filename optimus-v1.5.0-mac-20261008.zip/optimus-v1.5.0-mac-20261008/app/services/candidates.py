"""Candidate keyword ideation — brief §8 step 2.

Candidates are DERIVED from the product name and category by the rules below. They are not
model output and they carry no volume: a candidate is only a question ("does anybody search
for this?") which a `KeywordVolumeProvider` then answers. A candidate the provider has no
data for stays visible as `unverified` and is excluded from copy generation.

Deriving candidates rather than generating them has a second benefit worth stating in the
demo: the term shapes are auditable. Anyone can read this file and see exactly which
queries the tool will ask about.
"""

from __future__ import annotations

from dataclasses import dataclass

import regex

from app.lib.normalise import normalise_term
from app.lib.policy import MAX_SEEDS_PER_ROW
from app.lib.terms import (
    category_phrases,
    is_attribute_term,
    names_a_different_model,
    shares_a_word_with_product,
    strip_attributes,
)
from app.lib.validators import ProductIdentity, parse_identity
from app.models import KeywordType

# Re-exported so existing callers keep one import site. The implementations live in
# `app.lib.terms` because the copy providers need them too, and a provider must not
# import a service.
__all__ = [
    "Candidate",
    "candidate_terms",
    "category_phrases",
    "derive_seeds",
    "is_attribute_term",
    "names_a_different_model",
    "shares_a_word_with_product",
    "strip_attributes",
]


@dataclass(frozen=True, slots=True)
class Candidate:
    term: str
    type: KeywordType


@dataclass(frozen=True, slots=True)
class FamilyProfile:
    brand: str
    family_phrase: str
    generics: tuple[str, ...]


FAMILY_PROFILES: dict[str, FamilyProfile] = {
    "watch": FamilyProfile(
        brand="apple",
        family_phrase="apple watch",
        generics=("smart watch", "fitness tracker", "health watch", "wearable"),
    ),
    "iphone": FamilyProfile(
        brand="apple",
        family_phrase="iphone",
        generics=("smartphone", "best camera phone", "best battery life phone", "cellphone"),
    ),
    "airpods": FamilyProfile(
        brand="apple",
        family_phrase="airpods",
        generics=("wireless earbuds", "noise cancelling earphones", "earphones"),
    ),
    "ipad": FamilyProfile(
        brand="apple",
        family_phrase="ipad",
        generics=("tablet", "android tablet alternative"),
    ),
}

SMART_HOME_PROFILE = FamilyProfile(
    brand="e&",
    family_phrase="smart home",
    generics=("smart home devices", "home automation", "smart lock", "smart thermostat"),
)


def _profile(product_name: str, category_raw: str, identity: ProductIdentity) -> FamilyProfile:
    if identity.family and identity.family in FAMILY_PROFILES:
        return FAMILY_PROFILES[identity.family]
    haystack = f"{product_name} {category_raw}".casefold()
    if "smart" in haystack or "home" in haystack:
        return SMART_HOME_PROFILE
    return FamilyProfile(
        brand="e&",
        family_phrase=normalise_term(product_name or category_raw),
        generics=(),
    )


def _dedupe(candidates: list[Candidate], limit: int | None = None) -> tuple[Candidate, ...]:
    seen: set[str] = set()
    out: list[Candidate] = []
    for candidate in candidates:
        term = normalise_term(candidate.term)
        if not term or term in seen:
            continue
        seen.add(term)
        out.append(Candidate(term, candidate.type))
        if limit is not None and len(out) >= limit:
            break
    return tuple(out)


def derive_seeds(
    product_name: str, *, brand: str = "", category_raw: str = "", geo: str = "AE"
) -> tuple[Candidate, ...]:
    """Seed terms for keyword expansion, derived rather than generated.

    Short and broad on purpose: a seed's job is to be expanded by the volume provider into
    the long tail, and a seed carrying every attribute of the product expands into nothing
    because nobody searches it. Two to four words each.

    Used as the floor under model-proposed seeds, and as the whole set when no model is
    configured. Every shape here is readable in this function, which is the point — a
    reviewer can see exactly which queries the tool will pay to measure.
    """
    core = strip_attributes(product_name)
    words = core.split()
    brand_term = normalise_term(brand)
    market = "uae" if geo.upper() in {"AE", "UAE"} else geo.casefold()

    ordered: list[Candidate] = []

    # The product, at two levels of specificity. Four words is about where a query stops
    # being something people type.
    if words:
        ordered.append(Candidate(" ".join(words[:4]), KeywordType.product))
    if len(words) > 2:
        ordered.append(Candidate(" ".join(words[:3]), KeywordType.product))
    if len(words) > 1:
        ordered.append(Candidate(" ".join(words[:2]), KeywordType.product))

    # The brand on its own, and the brand with the product line.
    if brand_term:
        ordered.append(Candidate(brand_term, KeywordType.brand))
        rest = [w for w in words if w != brand_term]
        if rest:
            ordered.append(Candidate(f"{brand_term} {rest[0]}", KeywordType.brand))

    # What kind of thing it is, from the category.
    for phrase in category_phrases(category_raw):
        ordered.append(Candidate(phrase, KeywordType.category))

    # Market-qualified, at two lengths on purpose. "In UAE" attaches to the specific
    # product someone has settled on, so it takes the full name; price and buy intent
    # skews short and generic, so those take the head. Truncating both the same way gave
    # "apple watch series price in uae", which drops the generation and is nobody's query.
    if words:
        specific = " ".join(words[:4])
        generic = " ".join(words[:2]) if len(words) > 2 else specific
        ordered.append(Candidate(f"{specific} {market}", KeywordType.device))
        ordered.append(Candidate(f"{generic} price in {market}", KeywordType.usp))
        ordered.append(Candidate(f"buy {generic} online", KeywordType.usp))

    # Always present, never priced. A business rule rather than a demand signal.
    ordered.append(Candidate("smartpay", KeywordType.smartpay))

    return _dedupe(
        [c for c in ordered if c.type is KeywordType.smartpay or not is_attribute_term(c.term)],
        MAX_SEEDS_PER_ROW,
    )


def candidate_terms(
    product_name: str, category_raw: str, *, geo: str = "AE"
) -> tuple[Candidate, ...]:
    """Derive candidate search terms for one row, in a stable order.

    Ordered deterministically and deduplicated on the normalised form, because export
    bytes must be reproducible.
    """
    identity = parse_identity(product_name or category_raw)
    profile = _profile(product_name, category_raw, identity)
    family = profile.family_phrase
    market = "uae" if geo.upper() in {"AE", "UAE"} else geo.casefold()

    ordered: list[Candidate] = []

    # The product itself, most specific first.
    if product_name:
        ordered.append(Candidate(normalise_term(product_name), KeywordType.brand))
    if identity.family and identity.line and identity.generation is not None:
        ordered.append(
            Candidate(f"{family} {identity.line} {identity.generation}", KeywordType.brand)
        )
        ordered.append(Candidate(f"{family} {identity.line}", KeywordType.brand))

    # iPhone naming puts the generation before the line, so it needs its own shapes.
    if identity.family == "iphone" and identity.generation is not None:
        generation = identity.generation
        ordered.append(Candidate(f"iphone {generation}", KeywordType.brand))
        if identity.line:
            ordered.append(Candidate(f"iphone {generation} {identity.line}", KeywordType.brand))
            ordered.append(
                Candidate(f"apple iphone {generation} {identity.line}", KeywordType.brand)
            )
        ordered.append(Candidate(f"iphone {generation} release date", KeywordType.brand))

    # The family, and the brand-qualified family.
    ordered.append(Candidate(family, KeywordType.category))
    if profile.brand != "e&" and not family.startswith(profile.brand):
        ordered.append(Candidate(f"{profile.brand} {family}", KeywordType.brand))
    ordered.append(Candidate(f"latest {family}", KeywordType.brand))
    if profile.brand != "e&":
        ordered.append(Candidate(profile.brand, KeywordType.brand))

    # Market-qualified shapes. A price query is legitimate demand signal, not copy — see
    # `no_banned_terms_in_keywords`.
    ordered.append(Candidate(f"{family} {market}", KeywordType.geo_prompt))
    ordered.append(Candidate(f"{family} price in {market}", KeywordType.geo_prompt))

    # Non-brand ways a customer describes the need.
    ordered.extend(Candidate(term, KeywordType.benefit) for term in profile.generics)

    seen: set[str] = set()
    unique: list[Candidate] = []
    for candidate in ordered:
        term = normalise_term(candidate.term)
        if not term or term in seen:
            continue
        seen.add(term)
        unique.append(Candidate(term, candidate.type))
    return tuple(unique)
