"""Export orchestration — brief §9 and §11.

Two properties matter and they interact:

  * The export is BLOCKED while any Tier 1 error stands. `build_payload` refuses rather
    than quietly emitting invalid copy.
  * Re-downloading regenerates from stored records, never from a saved blob, so history can
    never drift from the data. To make that byte-identical, a re-download replays the
    ORIGINAL `Export` row's `version` and `created_at` rather than minting new ones. Brief
    §4 and §11 are quietly in conflict about this; see DECISIONS.md.

Every collection written into the workbook is sorted by an explicit key, because iterating
an unordered collection would reorder `sharedStrings.xml` between runs and break the
byte-identical guarantee. `tests/test_export_determinism.py` verifies that across
interpreters with different hash seeds.
"""

from __future__ import annotations

import datetime as dt
import json
from dataclasses import dataclass

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.config import settings
from app.excel.determinism import sha256
from app.excel.template_writer import KeywordUsage, TemplatePayload, TemplateRow
from app.excel.template_writer import build_workbook as build_template_workbook
from app.lib.normalise import normalise_term
from app.excel.writer import (
    ExportAsoField,
    ExportFinding,
    ExportGeoRow,
    ExportKeyword,
    ExportPayload,
    ExportRow,
    build_workbook,
)
from app.lib import limits
from app.lib.policy import STORE_FIELDS
from app.lib.validators import validate_store_field
from app.models import (
    AsoProfile,
    AuditEvent,
    Batch,
    BatchRow,
    BatchStatus,
    Export,
    KeywordStatus,
    User,
    utcnow,
)
from app.providers.keywords import NotConfiguredError, get_keyword_provider
from app.providers.llm import ModelNotConfiguredError, get_llm
from app.services import keyword_service, validation


class ExportBlocked(RuntimeError):
    """Raised when Tier 1 errors remain. Carries the blocking rows so the UI can name them."""

    def __init__(self, message: str, blocking_rows: tuple[int, ...]) -> None:
        super().__init__(message)
        self.blocking_rows = blocking_rows


@dataclass(frozen=True, slots=True)
class ExportOutcome:
    export_id: int
    file_name: str
    version: int
    sha256: str
    row_count: int
    content: bytes


def _tier2_json(row: BatchRow, field: str) -> list[object]:
    current = validation.current_field(row, field)
    if current is None:
        return []
    try:
        parsed = json.loads(current.text)
    except json.JSONDecodeError:
        return []
    return parsed if isinstance(parsed, list) else []


def _aso_fields(profile: AsoProfile | None) -> tuple[ExportAsoField, ...]:
    if profile is None:
        return ()
    texts = {
        "apple_name": profile.app_name,
        "apple_subtitle": profile.subtitle,
        "apple_keywords": profile.keyword_field,
        "apple_promo": profile.promo_text,
        "apple_description": "",
        "play_title": profile.play_title,
        "play_short": profile.play_short,
        "play_full": "",
    }
    out: list[ExportAsoField] = []
    for spec in STORE_FIELDS:
        text = texts.get(spec.key, "")
        if not text:
            continue
        findings = validate_store_field(text, spec.key)
        out.append(
            ExportAsoField(
                key=spec.key,
                store=spec.store,
                label=spec.label,
                text=text,
                limit=spec.limit,
                unit=spec.unit,
                chars=limits.char_count(text),
                byte_length=limits.byte_count(text),
                indexed=spec.indexed,
                valid=not any(f.severity == "error" for f in findings),
                note=spec.note,
            )
        )
    return tuple(out)


def keywords_used_in(
    copy_text: str, terms: tuple[tuple[str, int | None], ...]
) -> tuple[KeywordUsage, ...]:
    """Which researched terms actually appear in the copy, highest demand first.

    Matched on the normalised form, so casing and punctuation in the copy do not decide
    whether a term counts. Computed at export time rather than stored, so the column can
    never disagree with the copy sitting next to it after someone edits it.

    Lives here rather than in the writer because building one of these writes a `volume=`,
    and only a module wired to the volume provider is allowed to do that.
    """
    haystack = normalise_term(copy_text)
    if not haystack:
        return ()
    found = [
        KeywordUsage(term=term, volume=volume)
        for term, volume in terms
        if normalise_term(term) and normalise_term(term) in haystack
    ]
    found.sort(key=lambda k: (-(k.volume or -1), k.term))
    return tuple(found)


def build_template_payload(
    session: Session, batch: Batch, *, version: int, created_at: dt.datetime, force: bool = False
) -> TemplatePayload:
    """The keyword-research export: the input sheet with the copy added.

    Same export gate as the legacy path — Tier 1 errors block it — and the same ordering
    discipline, so a re-download regenerates byte-identical bytes.
    """
    registry = keyword_service.registry_map(session, batch.id)
    report = validation.validate_whole_batch(batch, registry)
    if not report.can_export and not force:
        blocking = tuple(r.row_index for r in report.blocking_rows)
        detail = ", ".join(str(i) for i in blocking) or "batch-level rules"
        raise ExportBlocked(
            f"Export is blocked while errors remain: {detail}.", blocking
        )

    rows: list[TemplateRow] = []
    for row in sorted(batch.rows, key=lambda r: r.row_index):
        title = validation.current_text(row, "meta_title_en")
        description = validation.current_text(row, "meta_description_en")
        # Sorted by volume then term so the cell is reproducible across runs.
        researched = tuple(
            (keyword.term, keyword.volume)
            for keyword in sorted(
                row.keywords,
                key=lambda k: (-(k.volume or -1), k.term_normalized),
            )
            if keyword.status is not KeywordStatus.rejected
        )
        rows.append(
            TemplateRow(
                row_index=row.row_index,
                batch_no=batch.batch_no,
                category_raw=row.category_raw,
                brand=row.brand,
                product_name=row.product_name,
                meta_title=title,
                meta_description=description,
                keywords_used=keywords_used_in(f"{title} {description}", researched),
                price_aed=row.price_aed,
                skip_reason=row.skip_reason,
            )
        )

    return TemplatePayload(
        batch_no=batch.batch_no,
        created_at=created_at,
        version=version,
        rows=tuple(rows),
        # The price column comes back only if a price exists to put in it. An empty column
        # on every row is noise that implies the tool failed to fill something in.
        include_price=any(r.price_aed is not None for r in rows),
    )


def build_export_bytes(
    session: Session, batch: Batch, *, version: int, created_at: dt.datetime
) -> tuple[bytes, str, int]:
    """(content, file_name, row_count) in whichever shape this batch arrived in."""
    if batch.input_layout == "template":
        template_payload = build_template_payload(
            session, batch, version=version, created_at=created_at
        )
        return (
            build_template_workbook(template_payload),
            template_payload.file_name,
            len(template_payload.rows),
        )
    payload = build_payload(session, batch, version=version, created_at=created_at)
    return build_workbook(payload), payload.file_name, len(payload.rows)


def build_payload(
    session: Session, batch: Batch, *, version: int, created_at: object, force: bool = False
) -> ExportPayload:
    """Assemble the workbook payload from stored records.

    `force` exists only for internal diagnostics; the routes never set it, because §11
    requires the export to be blocked while Tier 1 errors remain.
    """
    registry = keyword_service.registry_map(session, batch.id)
    report = validation.validate_whole_batch(batch, registry)

    if not report.can_export and not force:
        blocking = tuple(r.row_index for r in report.blocking_rows)
        detail = ", ".join(str(i) for i in blocking) or "batch-level rules"
        raise ExportBlocked(
            f"{report.error_count} unresolved error(s). Blocking rows: {detail}.",
            blocking,
        )

    # Names for the workbook's provenance block. An export must still succeed when a
    # provider is no longer configured — the batch was researched with whatever was
    # configured at the time, and re-downloading it later must not depend on that still
    # being true.
    try:
        provider_name = get_keyword_provider().name
        provider_is_live = get_keyword_provider().is_live_data
    except NotConfiguredError:
        provider_name, provider_is_live = "not configured", False
    try:
        model_name = get_llm().model
        prompt_version = get_llm().prompt_version
    except ModelNotConfiguredError:
        model_name, prompt_version = "not configured", ""

    ordered_rows = sorted(batch.rows, key=lambda r: r.row_index)

    rows: list[ExportRow] = []
    keywords: list[ExportKeyword] = []
    geo_rows: list[ExportGeoRow] = []

    for row in ordered_rows:
        approved = keyword_service.approved_terms_for_row(row)
        rows.append(
            ExportRow(
                row_index=row.row_index,
                category_raw=row.category_raw,
                product_url=row.product_url,
                product_name=row.product_name,
                keywords_joined=", ".join(approved),
                meta_title=validation.current_text(row, "meta_title_en"),
                meta_description=validation.current_text(row, "meta_description_en"),
                date_value=row.date_value,
                date_serial=row.date_serial,
                date_number_format=row.date_number_format,
                fetch_status=row.fetch_status.value,
                fetch_note=row.fetch_note,
                skip_reason=row.skip_reason,
            )
        )

        for keyword in sorted(
            row.keywords,
            key=lambda k: (not k.is_primary, -(k.volume or 0), k.term_normalized),
        ):
            keywords.append(
                ExportKeyword(
                    row_index=row.row_index,
                    term=keyword.term,
                    type=keyword.type.value,
                    volume=keyword.volume,
                    source=keyword.source,
                    is_live_data=keyword.is_live_data,
                    data_date=keyword.data_date,
                    locale=keyword.locale,
                    geo=keyword.geo,
                    status=keyword.status.value,
                    product_url=row.product_url,
                    is_primary=keyword.is_primary,
                )
            )

        prompts = tuple(str(p) for p in _tier2_json(row, "geo_prompts"))
        answer = validation.current_text(row, "answer_block")
        jsonld = validation.current_text(row, "faq_jsonld")
        if prompts or answer or jsonld:
            geo_rows.append(
                ExportGeoRow(
                    row_index=row.row_index,
                    product_url=row.product_url,
                    product_name=row.product_name,
                    prompts=prompts,
                    answer_block=answer,
                    jsonld=jsonld,
                )
            )

    findings: list[ExportFinding] = []
    for row_report in report.rows:
        for finding in row_report.findings:
            findings.append(
                ExportFinding(
                    row_index=row_report.row_index,
                    field=finding.field,
                    code=finding.code,
                    severity=finding.severity,
                    message=finding.message,
                )
            )
    for finding in report.batch_findings:
        findings.append(
            ExportFinding(
                row_index=0,
                field=finding.field,
                code=finding.code,
                severity=finding.severity,
                message=finding.message,
            )
        )
    findings.sort(key=lambda f: (f.row_index, f.field, f.severity, f.code, f.message))

    profile = session.scalar(
        select(AsoProfile).order_by(AsoProfile.updated_at.desc(), AsoProfile.id.desc())
    )

    skipped = [r for r in ordered_rows if r.skip_reason]
    skipped_note = (
        "none"
        if not skipped
        else "; ".join(f"row {r.row_index}: {r.skip_reason}" for r in skipped)
    )

    return ExportPayload(
        batch_no=batch.batch_no,
        source_file_name=batch.source_file_name,
        created_at=created_at,  # type: ignore[arg-type]
        version=version,
        locale=batch.locale,
        geo=batch.geo,
        provider_name=provider_name,
        provider_is_live=provider_is_live,
        model_name=model_name,
        prompt_version=prompt_version,
        brand_suffix_note=batch.brand_suffix_reason or "not decided",
        rows=tuple(rows),
        keywords=tuple(keywords),
        geo_rows=tuple(geo_rows),
        aso_fields=_aso_fields(profile),
        findings=tuple(findings),
        skipped_note=skipped_note,
    )


def next_version(session: Session, batch: Batch) -> int:
    highest = session.scalar(
        select(func.max(Export.version)).where(Export.batch_id == batch.id)
    )
    return (highest or 0) + 1


def create_export(session: Session, batch: Batch, *, user: User) -> ExportOutcome:
    """Generate a new export and record it."""
    version = next_version(session, batch)
    created_at = utcnow()

    content, file_name, row_count = build_export_bytes(
        session, batch, version=version, created_at=created_at
    )
    digest = sha256(content)

    config = settings()
    config.exports_dir.mkdir(parents=True, exist_ok=True)
    path = config.exports_dir / file_name
    path.write_bytes(content)

    export = Export(
        batch_id=batch.id,
        version=version,
        created_at=created_at,
        file_name=file_name,
        file_path=str(path),
        row_count=row_count,
        sha256=digest,
        created_by_user_id=user.id,
    )
    session.add(export)
    batch.status = BatchStatus.exported
    session.add(
        AuditEvent(
            batch_id=batch.id,
            actor=user.email,
            action="batch_exported",
            payload_json=json.dumps(
                {
                    "version": version,
                    "file_name": file_name,
                    "rows": row_count,
                    "sha256": digest,
                },
                sort_keys=True,
            ),
        )
    )
    session.flush()

    return ExportOutcome(
        export_id=export.id,
        file_name=file_name,
        version=version,
        sha256=digest,
        row_count=row_count,
        content=content,
    )


def regenerate_export(session: Session, export: Export) -> ExportOutcome:
    """Rebuild a previous export from stored records.

    Replays the original version and timestamp so the bytes match the first download
    exactly. No new `Export` row is created — this is the same export, re-rendered.
    """
    batch = export.batch
    content, _, row_count = build_export_bytes(
        session, batch, version=export.version, created_at=export.created_at
    )
    return ExportOutcome(
        export_id=export.id,
        file_name=export.file_name,
        version=export.version,
        sha256=sha256(content),
        row_count=row_count,
        content=content,
    )


def verified_keyword_count(batch: Batch) -> tuple[int, int]:
    """(verified, total) keyword counts, for the provider-gap disclosure in the UI."""
    total = sum(len(r.keywords) for r in batch.rows)
    verified = sum(
        1 for r in batch.rows for k in r.keywords
        if k.volume is not None and k.status is KeywordStatus.approved
    )
    return verified, total
