"""Copy generation and the regeneration loop — brief §6 and §7.

"Generate → validate → if errors, regenerate with the failures fed back, up to 3 attempts →
then route to the exception queue with every attempt retained. Never ship an invalid string,
and never silently truncate one to fit."

Three properties of this implementation are load-bearing:

  * Attempts are APPENDED, never overwritten. Every attempt keeps its own validation
    result, model, prompt version and the keywords that fed it, per §1 rule 4.
  * Failures are fed back as validator CODES, so the next attempt responds to the actual
    problem rather than retrying blind.
  * Nothing is truncated to fit. A string that will not fit stays too long, fails
    validation, and blocks the export. Truncating would hide the failure, which is exactly
    what §6 forbids.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

from sqlalchemy.orm import Session

from app.lib.policy import APP_CONTENT_LIMITS, BRAND_SUFFIX
from app.lib.validators import Finding, banned_in_copy
from app.models import Batch, BatchRow, CopyField, Keyword, KeywordTier, RowStage
from app.providers.llm import CopyDraft, CopyRequest, get_llm
from app.services import pages, validation
from app.services.validation import TIER1_FIELDS

MAX_ATTEMPTS = 3


def supporting_tiers(
    row: BatchRow, primary: Keyword | None
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    """The row's secondary and tertiary terms, for the prompt.

    Falls back to the approved-terms list when nobody has tiered anything — an
    untouched row still gets supporting keywords, exactly as it did before tiers
    existed, so the simple page's behaviour is unchanged.

    Both paths drop terms the banned-term rules bar from an indexed field. Tiering already
    refuses them, so this is belt and braces for the rows that were tiered before it did —
    but the fallback path genuinely needs it: `approved_terms_for_row` is every approved
    term on the row, and asking the model to include one it is forbidden to write is how a
    projector row ended up with "projector price in uae" in its description.
    """
    from app.services.keyword_service import approved_terms_for_row, tiered_terms

    def publishable(terms: tuple[str, ...]) -> tuple[str, ...]:
        return tuple(t for t in terms if banned_in_copy(t) is None)

    secondary = publishable(tiered_terms(row, KeywordTier.secondary))
    tertiary = publishable(tiered_terms(row, KeywordTier.tertiary))
    if secondary or tertiary:
        return secondary, tertiary

    approved = publishable(approved_terms_for_row(row))
    return tuple(t for t in approved if not primary or t != primary.term), ()


def approved_usps(row: BatchRow) -> tuple[str, ...]:
    """The selling points a human ticked, filtered once more before the prompt sees them.

    The filter is belt and braces — `publishable_usps` drops unusable claims at research
    time and the add box refuses them — but this is the seam the model is on the other
    side of, and the rows researched before that filter existed still carry whatever the
    model first said.
    """
    from app.services.keyword_service import selected_usps

    return tuple(claim for claim in selected_usps(row) if banned_in_copy(claim) is None)

# The failures that mean "too long" rather than "wrong". Only these raise the compression
# level on a retry; everything else is fixed by rewriting, not by cutting words.
LENGTH_CODES = frozenset({"CHAR_LIMIT", "PIXEL_LIMIT", "BYTE_LIMIT"})

# Tier 2 is "demonstrated as drafts": generated, displayed, validated on LENGTH ONLY, and
# labelled a draft for review in the UI. Brief §7.
TIER2_TEXT_FIELDS = ("h1", "answer_block", "app_headline", "app_subhead", "app_cta")
TIER2_JSON_FIELDS = ("benefits", "faqs", "geo_prompts", "faq_jsonld")

APP_FIELD_LIMITS = {limit.key: limit for limit in APP_CONTENT_LIMITS}


@dataclass(frozen=True, slots=True)
class RowGenerationResult:
    row_index: int
    attempts_used: int
    succeeded: bool
    findings: tuple[Finding, ...]
    model: str
    is_live_model: bool

    @property
    def needs_review(self) -> bool:
        return not self.succeeded


def _supersede(session: Session, row: BatchRow, field: str) -> None:
    """Mark existing attempts for a field as no longer current. They are retained."""
    for existing in row.copy_fields:
        if existing.field == field and existing.is_current:
            existing.is_current = False
    session.flush()


def _store(
    session: Session,
    row: BatchRow,
    *,
    field: str,
    text: str,
    locale: str,
    model: str,
    prompt_version: str,
    attempt: int,
    keywords_used: tuple[str, ...],
    findings: list[Finding],
    edited_by_user: bool = False,
) -> CopyField:
    _supersede(session, row, field)
    copy_field = CopyField(
        field=field,
        locale=locale,
        text=text,
        char_count=0,
        grapheme_count=0,
        byte_length=0,
        pixel_width=0.0,
        model=model,
        prompt_version=prompt_version,
        attempt=attempt,
        keywords_used=json.dumps(list(keywords_used), sort_keys=True),
        edited_by_user=edited_by_user,
        is_current=True,
    )
    validation.measure_and_store(copy_field, findings, field)
    # Appended to the relationship rather than given a raw foreign key, so the loaded
    # collection on `row` stays correct. Setting `batch_row_id` directly leaves
    # `row.copy_fields` stale, which silently made every subsequent read see no copy at
    # all — and therefore skip the validators that depend on it.
    row.copy_fields.append(copy_field)
    session.flush()
    return copy_field


def _tier2_findings(field: str, text: str) -> list[Finding]:
    """Length-only validation for Tier 2, per brief §7.

    The three app limits are unconfirmed placeholders pending the app team, so exceeding
    one is a WARNING, not an error. Presenting an unagreed limit as a hard failure would
    misrepresent its status.
    """
    from app.lib import limits

    limit = APP_FIELD_LIMITS.get(field)
    if limit is None:
        return []
    count = limits.char_count(text)
    if count <= limit.limit:
        return []
    return [
        Finding(
            code="TIER2_LENGTH",
            severity="warning" if not limit.confirmed else "error",
            message=(
                f"{count} characters against a {limit.limit}-character guide"
                + ("" if limit.confirmed else " (limit unconfirmed, pending the app team)")
                + "."
            ),
            field=field,
        )
    ]


def _store_tier2(
    session: Session,
    row: BatchRow,
    draft: CopyDraft,
    *,
    locale: str,
    model: str,
    prompt_version: str,
    attempt: int,
) -> None:
    payloads: dict[str, str] = {
        "h1": draft.h1,
        "answer_block": draft.answer_block,
        "app_headline": draft.app_headline,
        "app_subhead": draft.app_subhead,
        "app_cta": draft.app_cta,
        "benefits": json.dumps(list(draft.benefits)),
        "faqs": json.dumps([list(pair) for pair in draft.faqs]),
        "geo_prompts": json.dumps(list(draft.geo_prompts)),
        "faq_jsonld": draft.jsonld,
    }
    for field in (*TIER2_TEXT_FIELDS, *TIER2_JSON_FIELDS):
        text = payloads.get(field, "")
        if not text:
            continue
        _store(
            session, row,
            field=field, text=text, locale=locale, model=model,
            prompt_version=prompt_version, attempt=attempt, keywords_used=(),
            findings=_tier2_findings(field, text),
        )


async def generate_row(
    session: Session,
    row: BatchRow,
    *,
    locale: str,
    brand_suffix_applied: bool | None,
) -> RowGenerationResult:
    """Generate, validate and retry one row. Up to `MAX_ATTEMPTS` attempts."""
    provider = get_llm()

    if row.skip_reason:
        row.stage = RowStage.skipped
        session.flush()
        return RowGenerationResult(
            row_index=row.row_index,
            attempts_used=0,
            succeeded=False,
            findings=(
                Finding(
                    code="ROW_SKIPPED",
                    severity="error",
                    message=f"Row not processed: {row.skip_reason}",
                    field="row",
                ),
            ),
            model=provider.model,
            is_live_model=provider.is_live_model,
        )

    primary = next((k for k in row.keywords if k.is_primary), None)
    secondary, tertiary = supporting_tiers(row, primary)

    feedback: tuple[str, ...] = ()
    findings: list[Finding] = []
    attempt = 0
    # Raised only by a length failure, never by the attempt number. A retry for a banned
    # term should fix the term, not also shorten copy that fits — that was how refreshing
    # a valid string used to walk it down to the bare product name.
    shrink = 0

    facts = pages.stored_facts(row)
    usps = approved_usps(row)

    for attempt in range(1, MAX_ATTEMPTS + 1):
        request = CopyRequest(
            row_index=row.row_index,
            product_name=row.product_name,
            category_raw=row.category_raw,
            product_url=row.product_url,
            page_type=row.page_type.value,
            brand=row.brand,
            price=row.formatted_price,
            primary_keyword=primary.term if primary else None,
            secondary_keywords=secondary,
            tertiary_keywords=tertiary,
            locale=locale,
            brand_suffix=bool(brand_suffix_applied),
            attempt=attempt,
            feedback=feedback,
            shrink=shrink,
            facts=facts,
            usps=usps,
        )
        result = await provider.generate(request)
        tier1 = result.draft.tier1()

        findings = []
        for field in TIER1_FIELDS:
            text = tier1.get(field, "")
            field_findings = validation.validate_row_field(
                row, field, text,
                locale=locale,
                brand_suffix_applied=brand_suffix_applied,
            )
            _store(
                session, row,
                field=field, text=text, locale=locale,
                model=result.model, prompt_version=result.prompt_version,
                attempt=attempt, keywords_used=result.keywords_used,
                findings=field_findings,
            )
            findings.extend(field_findings)

        _store_tier2(
            session, row, result.draft,
            locale=locale, model=result.model,
            prompt_version=result.prompt_version, attempt=attempt,
        )

        errors = [f for f in findings if f.severity == "error"]
        if not errors:
            row.stage = RowStage.generated
            session.flush()
            return RowGenerationResult(
                row_index=row.row_index,
                attempts_used=attempt,
                succeeded=True,
                findings=tuple(findings),
                model=result.model,
                is_live_model=result.is_live_model,
            )

        # Feed the actual failure codes back, deduplicated and sorted so the next attempt
        # is reproducible.
        feedback = tuple(sorted({f.code for f in errors}))
        if feedback and set(feedback) & LENGTH_CODES:
            shrink += 1

    # Out of attempts. The row goes to the exception queue with every attempt retained and
    # the offending text left exactly as generated — not truncated to fit.
    row.stage = RowStage.failed
    session.flush()
    return RowGenerationResult(
        row_index=row.row_index,
        attempts_used=attempt,
        succeeded=False,
        findings=tuple(findings),
        model=provider.model,
        is_live_model=provider.is_live_model,
    )


async def regenerate_field(
    session: Session,
    row: BatchRow,
    field: str,
    *,
    locale: str,
    brand_suffix_applied: bool | None,
) -> tuple[CopyField, list[Finding], str]:
    """Regenerate a single field, returning the new attempt and the previous text.

    The previous text is returned so the UI can show a diff, per brief §8 step 3.
    """
    previous = validation.current_field(row, field)
    previous_text = previous.text if previous else ""
    previous_findings = (
        validation.findings_from_json(previous.validation_json) if previous else []
    )

    provider = get_llm()
    primary = next((k for k in row.keywords if k.is_primary), None)
    secondary, tertiary = supporting_tiers(row, primary)
    next_attempt = (previous.attempt + 1) if previous else 1

    # `variant` rotates the phrasing so a refresh offers a genuine alternative. Without it
    # the attempt number alone drove compression, so repeatedly refreshing a perfectly valid
    # title eroded it towards just the product name.
    request = CopyRequest(
        row_index=row.row_index,
        product_name=row.product_name,
        category_raw=row.category_raw,
        product_url=row.product_url,
        page_type=row.page_type.value,
        brand=row.brand,
        price=row.formatted_price,
        primary_keyword=primary.term if primary else None,
        secondary_keywords=secondary,
        tertiary_keywords=tertiary,
        locale=locale,
        brand_suffix=bool(brand_suffix_applied),
        attempt=next_attempt,
        variant=next_attempt,
        feedback=tuple(sorted({f.code for f in previous_findings if f.severity == "error"})),
        facts=pages.stored_facts(row),
        usps=approved_usps(row),
    )
    result = await provider.generate(request)
    text = result.draft.tier1().get(field, "")

    findings = validation.validate_row_field(
        row, field, text, locale=locale, brand_suffix_applied=brand_suffix_applied
    )
    stored = _store(
        session, row,
        field=field, text=text, locale=locale,
        model=result.model, prompt_version=result.prompt_version,
        attempt=next_attempt, keywords_used=result.keywords_used,
        findings=findings,
    )
    return stored, findings, previous_text


def edit_field(
    session: Session,
    row: BatchRow,
    field: str,
    text: str,
    *,
    locale: str,
    brand_suffix_applied: bool | None,
) -> tuple[CopyField, list[Finding]]:
    """Accept a human edit as a new attempt and revalidate it.

    The edit does not mutate the previous attempt: an edit is a new record attributed to
    the user, so the generated original stays auditable.
    """
    previous = validation.current_field(row, field)
    next_attempt = (previous.attempt + 1) if previous else 1

    # `human_edited` so the location rule stands down. It exists to stop the MODEL adding
    # a place nobody asked for; refusing the same words from the person it defers to would
    # be the rule outliving its reason.
    findings = validation.validate_row_field(
        row,
        field,
        text,
        locale=locale,
        brand_suffix_applied=brand_suffix_applied,
        human_edited=True,
    )
    stored = _store(
        session, row,
        field=field, text=text, locale=locale,
        model="human-edit",
        prompt_version=previous.prompt_version if previous else "n/a",
        attempt=next_attempt,
        keywords_used=(),
        findings=findings,
        edited_by_user=True,
    )
    return stored, findings


@dataclass(frozen=True, slots=True)
class BatchGenerationSummary:
    results: tuple[RowGenerationResult, ...]
    brand_suffix_applied: bool
    brand_suffix_reason: str
    titles_resuffixed: int

    @property
    def generated(self) -> int:
        return sum(1 for r in self.results if r.succeeded)

    @property
    def needs_review(self) -> int:
        return sum(1 for r in self.results if r.needs_review)


async def generate_batch(session: Session, batch: Batch) -> BatchGenerationSummary:
    """Generate every row, then settle the batch-wide brand suffix.

    The brand suffix is a chicken-and-egg problem: brief §6 requires ONE decision across
    the whole batch, but the decision depends on whether every title still fits with
    ` | e&` appended — and there are no titles until generation has run. Deciding first
    would mean deciding on no evidence.

    So it runs in two phases: generate every title without the suffix, then decide from the
    real titles, then append the suffix to all of them if it fits all of them. That way the
    decision is evidence-based and still uniform, which is the property the reference file
    lacked — it carried the suffix on one title in five.
    """
    ordered = sorted(batch.rows, key=lambda r: r.row_index)

    results: list[RowGenerationResult] = []
    for row in ordered:
        results.append(
            await generate_row(
                session, row, locale=batch.locale, brand_suffix_applied=None
            )
        )

    decision = validation.decide_batch_brand_suffix(batch)
    validation.persist_brand_decision(session, batch, decision)

    resuffixed = 0
    if decision.applied:
        for row in ordered:
            if row.skip_reason:
                continue
            if apply_brand_suffix(session, row, locale=batch.locale):
                resuffixed += 1

        # The title changed, so each row's validity has to be re-established rather than
        # carried over from before the suffix was applied.
        results = [_revalidated(session, row, previous) for row, previous in zip(ordered, results)]

    return BatchGenerationSummary(
        results=tuple(results),
        brand_suffix_applied=bool(decision.applied),
        brand_suffix_reason=decision.reason,
        titles_resuffixed=resuffixed,
    )


def apply_brand_suffix(session: Session, row: BatchRow, *, locale: str) -> bool:
    """Append the batch's agreed suffix to an existing title and revalidate.

    This is deliberately NOT a regeneration. Asking the provider for another attempt would
    read as "the last one failed, try harder" and the template would shorten the title
    again, throwing away the benefit clause for no reason. Applying the batch decision is a
    mechanical transformation of text that already passed, so it is recorded as a new
    attempt for traceability but the copy itself is untouched apart from the suffix.
    """
    current = validation.current_field(row, "meta_title_en")
    if current is None:
        return False
    base = current.text.rstrip()
    if base.endswith(BRAND_SUFFIX.strip()):
        return False

    text = f"{base}{BRAND_SUFFIX}"
    findings = validation.validate_row_field(
        row, "meta_title_en", text, locale=locale, brand_suffix_applied=True
    )
    _store(
        session, row,
        field="meta_title_en", text=text, locale=locale,
        model=current.model, prompt_version=current.prompt_version,
        attempt=current.attempt + 1, keywords_used=(),
        findings=findings,
    )
    return True


def _revalidated(
    session: Session, row: BatchRow, previous: RowGenerationResult
) -> RowGenerationResult:
    if row.skip_reason:
        return previous
    findings: list[Finding] = []
    for field in TIER1_FIELDS:
        current = validation.current_field(row, field)
        if current is not None:
            findings.extend(validation.findings_from_json(current.validation_json))
    succeeded = not any(f.severity == "error" for f in findings)
    row.stage = RowStage.generated if succeeded else RowStage.failed
    session.flush()
    return RowGenerationResult(
        row_index=previous.row_index,
        attempts_used=previous.attempts_used,
        succeeded=succeeded,
        findings=tuple(findings),
        model=previous.model,
        is_live_model=previous.is_live_model,
    )


def attempt_history(row: BatchRow, field: str) -> list[CopyField]:
    """Every attempt for a field, oldest first. Nothing is ever deleted."""
    return sorted(
        (c for c in row.copy_fields if c.field == field),
        key=lambda c: (c.attempt, c.id),
    )


def mark_copy_stale(session: Session, row: BatchRow) -> int:
    """Flag a row's copy as stale after its keywords were reopened.

    Retained, not deleted — brief §1 rule 4 requires the history to stay complete.
    """
    touched = 0
    for copy_field in row.copy_fields:
        if copy_field.is_current and not copy_field.is_stale:
            copy_field.is_stale = True
            touched += 1
    session.flush()
    return touched
