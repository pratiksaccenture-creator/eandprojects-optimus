"""Keyword lookup, approval and primary selection — brief §5 and §8 step 2."""

from __future__ import annotations

import datetime as dt
import logging
from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.lib.normalise import normalise_term
from app.lib.quality import rejection_reason
from app.lib.policy import (
    EXPANSION_LIMIT,
    MAX_EXPANSION_SEEDS,
    MAX_KEYWORDS_SHOWN,
    MAX_SEEDS_PER_ROW,
    MAX_USP_CHARS,
    MAX_USPS,
    PRICED_BUCKETS,
)
from app.lib.validators import ProductIdentity, banned_in_copy, parse_identity
from app.models import (
    AuditEvent,
    Batch,
    BatchRow,
    Keyword,
    KeywordRegistry,
    KeywordStatus,
    KeywordTier,
    KeywordType,
    ProductUsp,
    RowStage,
    UspSource,
    utcnow,
)
from app.providers.keywords import (
    ExpansionResult,
    NotConfiguredError,
    VolumeResult,
    get_keyword_provider,
)
from app.providers.llm import ProposedUsp
from app.services import volume_cache

log = logging.getLogger(__name__)
from app.lib.terms import has_repeated_word, names_another_brand
from app.services.candidates import (
    Candidate,
    candidate_terms,
    derive_seeds,
    is_attribute_term,
    names_a_different_model,
    shares_a_word_with_product,
)

# Buckets eligible to be a page's primary keyword. A market-qualified, intent or SmartPay
# term makes a good secondary but a poor primary: it describes the market, the motive or a
# payment method rather than the thing the page is about.
PRIMARY_ELIGIBLE = (
    KeywordType.product,
    KeywordType.brand,
    KeywordType.category,
    KeywordType.device,
)


@dataclass(frozen=True, slots=True)
class ProviderInfo:
    name: str
    is_live_data: bool


@dataclass(frozen=True, slots=True)
class ResearchedTerm:
    """A term after measurement: what it is, and what the provider said about it."""

    term: str
    bucket: KeywordType
    volume: int | None
    cpc: float | None
    competition: str | None
    source: str
    #: End of the averaged period, not the time of the request. See `VolumeResult`.
    data_date: dt.datetime | None
    is_expansion: bool
    months_covered: int | None = None


def specificity(
    term: str, identity: ProductIdentity, family_phrase: str, product_name: str = ""
) -> int:
    """How specific a term is to THIS page. Higher is more specific.

    Volume alone is the wrong rule for choosing a primary keyword. In this batch the
    highest-volume verified term is the bare brand `apple` at 165,000, which is identical
    for all 21 rows, unrankable for a product page, and would make every row cannibalise
    every other. Specificity decides first and volume only breaks ties.
    """
    words = set(term.split())
    score = 0
    if identity.generation is not None and str(identity.generation) in words:
        score += 4
    if identity.line and all(part in term for part in identity.line.split()):
        score += 3
    if family_phrase and family_phrase in term:
        score += 1
    # A term the product name already contains is one the title can carry without
    # contortion. "apple airpods" on a row named "AirPods 5" is a perfectly good keyword
    # and a bad primary: the natural title is "AirPods 5", which does not contain it, so
    # the copy fails the primary-keyword check on every attempt and the row never ships.
    if product_name and words and words <= set(normalise_term(product_name).split()):
        score += 2
    # A single-word term that is just the manufacturer is the least useful primary there is.
    if len(words) == 1 and family_phrase and term not in family_phrase:
        score -= 5
    return score


def choose_primary(
    keywords: list[Keyword], product_name: str, brand: str = ""
) -> Keyword | None:
    """Pick the most specific verified term, breaking ties on volume.

    Only verified terms are eligible: an unverified term has no evidence anybody searches
    for it, so promoting one to primary would be a guess dressed as a decision.
    """
    identity = parse_identity(product_name)
    family_phrase = ""
    if identity.family:
        family_phrase = "apple watch" if identity.family == "watch" else identity.family

    eligible = [
        k for k in keywords
        if k.volume is not None
        and k.type in PRIMARY_ELIGIBLE
        # Belt and braces with the filter in `research_row_keywords`: a term naming a
        # different model must never become what this page targets, however it got here.
        and not names_a_different_model(k.term_normalized, product_name)
        # And it has to be about this page. A term with nothing in common with the product
        # name cannot honestly appear in its title, so promoting one only guarantees a
        # PRIMARY_KEYWORD_MISSING error later.
        and shares_a_word_with_product(k.term_normalized, product_name)
        # And we have to be allowed to publish it. A price-intent term as primary is a
        # term the title is required to contain and forbidden to contain at once.
        and banned_in_copy(k.term_normalized) is None
        # The bare manufacturer is never what a product page is about. "samsung" at
        # 110,000 outranked every real candidate on a Samsung tablet row and became its
        # primary keyword — a term that page cannot win and that every other Samsung row
        # in the batch would compete with it for.
        #
        # This used to be a scoring penalty, and the penalty only fired when the product
        # matched one of the four Apple families that had a family phrase. Every other
        # product in the catalogue skipped it entirely, which is why the defect appeared
        # the moment the input stopped being Apple devices.
        and not (brand and k.term_normalized == brand.casefold())
    ]
    if not eligible:
        return None
    best = max(
        eligible,
        key=lambda k: (
            specificity(k.term_normalized, identity, family_phrase, product_name),
            k.volume or 0,
            # Final tiebreak on the term itself so the choice is reproducible.
            k.term_normalized,
        ),
    )
    # No primary is better than a bad one. A negative score means the only thing left is
    # the bare manufacturer — "apple" as the target for an iPhone 17 page, unwinnable and
    # shared with every other Apple row in the batch. Returning None says "nothing here
    # is specific enough to target", which is a finding the reviewer can act on; naming
    # "apple" looks like an answer and is not one.
    if specificity(best.term_normalized, identity, family_phrase, product_name) < 0:
        return None
    return best


TYPE_BY_NAME = {t.value: t for t in KeywordType}


async def propose_candidates(
    row: BatchRow, *, locale: str, geo: str
) -> tuple[tuple[Candidate, ...], str, tuple[ProposedUsp, ...]]:
    """Seed terms for a row, how they were produced, and the row's proposed USPs.

    Asks the model first — it knows what the product is, who buys it and what they call it,
    which is the part string assembly cannot do. Falls back to the deterministic derivation
    when no model is configured, or when the model returns nothing or fails.

    These are seeds, not findings. A term acquires a figure solely from a volume provider,
    never from here, and attribute terms are dropped before anything is paid for: the
    content team's instruction is to measure products, brands and categories, not colours
    and case sizes.

    The USPs ride along on the same call rather than a second one. The model has to work
    out what the product is either way, and the keywords page is already the slowest in
    the tool — a second round trip for a second answer to the same question is latency
    nobody asked for.
    """
    from app.providers.llm import IdeationRequest, IdeationResult, get_llm
    from app.services.pages import stored_facts

    derived = derive_seeds(
        row.product_name, brand=row.brand, category_raw=row.category_raw, geo=geo
    )

    model = get_llm()
    try:
        result = await model.propose_keywords(
            IdeationRequest(
                row_index=row.row_index,
                product_name=row.product_name,
                category_raw=row.category_raw,
                product_url=row.product_url,
                page_type=row.page_type.value,
                brand=row.brand,
                locale=locale,
                geo=geo,
                facts=stored_facts(row),
            )
        )
    except Exception:  # noqa: BLE001 - seed generation failing must not stop the row
        # Logged, not just swallowed. Falling back to derived seeds is the right
        # behaviour — a row still gets measured keywords — but it costs the row its
        # selling points, and a silent catch made that indistinguishable from "this
        # product has no selling points". Three rows of a seven-row batch lost theirs
        # this way with no trace of why. The screen now offers a retry; this is the
        # record of what it is retrying.
        log.exception(
            "ideation failed for row %s (%r); falling back to derived seeds and no USPs",
            row.row_index,
            row.product_name,
        )
        result = IdeationResult()

    usps = publishable_usps(result.usps)

    proposed = tuple(
        Candidate(
            term=normalise_term(idea.term),
            type=TYPE_BY_NAME.get(idea.kind, KeywordType.product),
        )
        for idea in result.terms
        if normalise_term(idea.term)
    )
    if not proposed:
        return derived, "derived", usps

    # Union with the derived shapes rather than replacing them. They cost nothing, they are
    # auditable, and they reliably cover the market-qualified forms a model sometimes omits.
    seen: set[str] = set()
    merged: list[Candidate] = []
    for candidate in (*proposed, *derived):
        if candidate.term in seen:
            continue
        if candidate.type is not KeywordType.smartpay and is_attribute_term(candidate.term):
            continue
        seen.add(candidate.term)
        merged.append(candidate)
    return tuple(merged[:MAX_SEEDS_PER_ROW]), f"{model.model} + derived", usps


def publishable_usps(usps: tuple[ProposedUsp, ...]) -> tuple[ProposedUsp, ...]:
    """Drop selling points that could never be published, before anyone is offered one.

    The same rule the keywords learned: offering a claim that the copy step is forbidden
    to write offers a guaranteed failure. A USP mentioning a price, an instalment plan, a
    stock level or a competitor is dropped here rather than shown, ticked, and then
    rejected by the validator two pages later.

    Dropped rather than shown-and-locked, which is where this differs from a keyword. A
    locked keyword still carries information — its search volume is a fact about the
    market. An unusable USP carries nothing: it is a sentence we may not print.
    """
    return tuple(u for u in usps if banned_in_copy(u.claim) is None)


async def research_row_keywords(
    row: BatchRow, seeds: tuple[Candidate, ...], *, locale: str, geo: str
) -> tuple[list[ResearchedTerm], ProviderInfo, list[VolumeResult], list[str]]:
    """Turn seeds into measured keywords.

    Two calls to the volume provider, and the division between them is the whole design:

      * `expand()` asks Google what people actually type around these seeds, and returns
        those terms with their own volumes. This is where the long tail comes from — not
        from a model's idea of what people might search.
      * `lookup()` prices the seeds themselves, so a seed the expansion did not echo back
        still gets measured rather than silently disappearing.

    Terms with no data keep `volume=None` and stay visible as unverified. Nothing is
    estimated, and the SmartPay term is expected to come back empty — it is a standing
    business requirement, not a demand signal.
    """
    provider = get_keyword_provider()
    info = ProviderInfo(name=provider.name, is_live_data=provider.is_live_data)

    priced = [s for s in seeds if s.type.value in PRICED_BUCKETS]
    bucket_of = {s.term: s.type for s in seeds}

    # Expand on the PRODUCT only, and on a handful at that.
    #
    # Two things were wrong with expanding everything. It was slow: twenty seeds returned
    # 13,229 ideas and took 36 seconds, on top of a 26-second model call, which is how
    # nine rows became a ten-minute wait. And it was wrong: the broad seeds are the ones
    # that drag in the rubbish. A PlayStation row seeded with "games" and "gaming" came
    # back with chess, solitaire, minecraft and geometry dash — real search demand, for
    # browser games, on a page selling a console.
    #
    # Category, device and intent seeds are still PRICED, so their demand is reported.
    # They are just not used as the root of an expansion, because "gaming" expands into
    # the entire gaming universe while "sony playstation ps5" expands into this product.
    expandable = [
        s for s in priced
        if s.type is KeywordType.product and len(s.term.split()) >= 2
    ][:MAX_EXPANSION_SEEDS]

    expansions: list[ExpansionResult] = []
    if expandable and getattr(provider, "can_expand", False):
        try:
            expansions = await provider.expand(
                [s.term for s in expandable],
                geo=geo,
                locale=locale,
                limit=EXPANSION_LIMIT,
            )
        except NotConfiguredError:
            raise
        except Exception:  # noqa: BLE001 - a failed expansion still leaves priced seeds
            expansions = []

    # Price only the seeds the expansion did not already report on.
    #
    # Measured: 22 of 23 seeds came back from the expansion with their volumes attached,
    # so the second call was a paid request for figures already in hand. When expansion
    # covers everything this call disappears entirely.
    expanded_volumes: dict[str, ExpansionResult] = {
        normalise_term(e.term): e for e in expansions
    }
    unpriced = [s.term for s in seeds if normalise_term(s.term) not in expanded_volumes]

    # Terms already bought. Every batch with a Samsung phone asks for "samsung"; every
    # projector row asks for "projector". The figure is a twelve-month average Google
    # updates monthly, so reusing it inside the TTL returns the same number the call
    # would have. See `app.services.volume_cache`.
    cached = volume_cache.read(unpriced, geo=geo, locale=locale)
    to_buy = [t for t in unpriced if normalise_term(t) not in cached]

    by_term: dict[str, VolumeResult] = dict(cached)
    fetched: list[VolumeResult] = []
    if to_buy:
        results = await provider.lookup(to_buy, geo=geo, locale=locale)
        fetched = list(results)
        by_term.update({normalise_term(r.term): r for r in results})

    # Figures from the expansion are worth remembering too — the same term recurs across
    # rows and batches — but only the ones this row KEPT. Caching the whole expansion
    # stored 3,131 rows for a single product, which is 3,131 selects and inserts under the
    # write lock to retain figures for terms the quality gate had just rejected. Nothing
    # would ever ask for them again. The kept terms are collected below, once `out` is
    # built, because that is where "kept" is decided.

    out: list[ResearchedTerm] = []
    seen: set[str] = set()

    for seed in seeds:
        key = normalise_term(seed.term)
        if key in seen:
            continue
        seen.add(key)
        # A seed's figure comes from whichever call reported it. The expansion usually
        # does, which is why the lookup now only covers what it missed.
        result: VolumeResult | ExpansionResult | None = (
            expanded_volumes.get(key) or by_term.get(key)
        )
        out.append(
            ResearchedTerm(
                term=seed.term,
                bucket=seed.type,
                volume=result.volume if result else None,
                cpc=result.cpc if result else None,
                competition=result.competition if result else None,
                source=result.source if result else info.name,
                data_date=result.data_date if result else None,
                months_covered=getattr(result, "months_covered", None),
                is_expansion=False,
            )
        )

    # The vocabulary this row is entitled to: what it is called, who makes it, how it is
    # filed, and every seed it was researched with. Computed once.
    seed_terms = tuple(s.term for s in seeds)

    for expansion in expansions:
        key = normalise_term(expansion.term)
        if key in seen or is_attribute_term(key):
            continue
        # The quality gate. Expansion returns real demand for things that are not this
        # product: a Galaxy Fold row came back with "semsem galaxy" (not a word),
        # "samsung s24 ultra", "samsung a56" and "samsung a17" (three other phones, one of
        # which got tiered second on volume alone). See `app.lib.quality`.
        reason = rejection_reason(
            key,
            product_name=row.product_name,
            brand=row.brand,
            category=row.category_raw,
            seeds=seed_terms,
        )
        if reason is not None:
            log.debug("dropped %r from row %s: %s", key, row.row_index, reason)
            continue
        # Dropped, not merely demoted. An expanded term naming a different model is a
        # competitor SKU's keyword, and leaving it on screen invites someone to promote
        # it — it will usually have the higher volume, which is exactly why it is there.
        if names_a_different_model(key, row.product_name):
            continue
        # Another manufacturer's term. Expansion does not know whose page it is working
        # on: seeded with "robot vacuum" it returned "dyson vacuum", and from a Samsung
        # tablet it returned "ipad" and "lenovo tablet". Those would be handed to the
        # copy model as supporting keywords — a competitor's brand written into e&'s own
        # product page.
        if names_another_brand(key, row.brand):
            continue
        # "robot vacuum robot", "robot robot vacuum cleaner" — permutations the ads
        # platform produces, not phrases anyone types. One of them had become a primary
        # keyword.
        if has_repeated_word(key):
            continue
        seen.add(key)
        out.append(
            ResearchedTerm(
                term=key,
                # Inherited from the seed that produced it. The API does not report the
                # relationship, so this is an attribution for the reviewer rather than a
                # claim from Google.
                bucket=bucket_of.get(expansion.seed, KeywordType.product),
                volume=expansion.volume,
                cpc=expansion.cpc,
                competition=expansion.competition,
                source=expansion.source,
                data_date=expansion.data_date,
                months_covered=expansion.months_covered,
                is_expansion=True,
            )
        )

    # Everything this row kept and did not already have. Bounded by `MAX_KEYWORDS_SHOWN`
    # and the seed count, so the write phase stays short.
    already = set(cached)
    seen_cacheable: set[str] = {normalise_term(r.term) for r in fetched}
    for entry in out:
        key = normalise_term(entry.term)
        if key in already or key in seen_cacheable:
            continue
        seen_cacheable.add(key)
        fetched.append(
            VolumeResult(
                term=entry.term,
                volume=entry.volume,
                cpc=entry.cpc,
                competition=entry.competition,
                source=entry.source,
                data_date=entry.data_date,
                months_covered=entry.months_covered,
            )
        )

    return out, info, fetched, sorted(cached)


def rank_researched(entries: list[ResearchedTerm]) -> list[ResearchedTerm]:
    """Order for the screen and trim to what a reviewer can read.

    Highest volume first, which is how the content team sorts today. Two deliberate
    exceptions ride above the sort:

      * SmartPay is always kept. It has no demand and is required anyway, so dropping it
        for scoring zero would quietly lose a business rule.
      * One seed per bucket is kept even if unmeasured, so a bucket that Google had no data
        for shows as an empty bucket rather than vanishing. A missing row is invisible; an
        empty one is a finding.
    """
    kept: list[ResearchedTerm] = []
    seen_buckets: set[KeywordType] = set()

    measured = sorted(
        (e for e in entries if e.volume is not None),
        key=lambda e: (-(e.volume or 0), e.term),
    )
    for entry in measured[:MAX_KEYWORDS_SHOWN]:
        kept.append(entry)
        seen_buckets.add(entry.bucket)

    for entry in entries:
        if entry.volume is not None or entry in kept:
            continue
        if entry.bucket is KeywordType.smartpay or entry.bucket not in seen_buckets:
            kept.append(entry)
            seen_buckets.add(entry.bucket)
    return kept


@dataclass(frozen=True, slots=True)
class RowResearch:
    """Everything one row's network phase produced, ready to be written.

    A single object rather than a widening tuple, because this crosses the boundary
    between the part that holds no lock and the part that holds the write lock, and that
    boundary is worth being able to read at a glance.
    """

    terms: list[ResearchedTerm]
    info: ProviderInfo
    usps: tuple[ProposedUsp, ...] = ()
    seed_source: str = ""
    # Figures that came from a live provider call this time, to be cached by the write
    # phase, and the terms that were served from the cache, to be counted there. Both
    # cross the no-lock/lock boundary with everything else.
    fetched: tuple[VolumeResult, ...] = ()
    cache_hits: tuple[str, ...] = ()


async def research_only(row: BatchRow, *, locale: str, geo: str) -> RowResearch:
    """The network half: seeds from the model, volumes from the provider. No writes.

    Split out so a route can do it WITHOUT holding the database write lock. Every row was
    otherwise waiting for the one in front to finish its API calls — around a minute each
    — which turned nine rows into a ten-minute queue for work that could overlap.
    """
    seeds, source, usps = await propose_candidates(row, locale=locale, geo=geo)
    terms, info, fetched, hits = await research_row_keywords(
        row, seeds, locale=locale, geo=geo
    )
    return RowResearch(
        terms=terms,
        info=info,
        usps=usps,
        seed_source=source,
        fetched=tuple(fetched),
        cache_hits=tuple(hits),
    )


def store_row_keywords(
    session: Session,
    row: BatchRow,
    research: RowResearch,
    *,
    locale: str,
    geo: str,
) -> list[Keyword]:
    """The database half: persist what the research found. No network.

    Re-checks for existing keywords, because two requests for the same row can now be in
    flight at once — a reload while a row is still working is the obvious way in.
    """
    existing = list(
        session.scalars(
            select(Keyword).where(Keyword.batch_row_id == row.id).order_by(Keyword.id)
        )
    )
    if existing:
        return existing
    store_row_usps(session, row, research.usps, model=research.seed_source)
    # Under the write lock, which is why it happens here and not in the network phase.
    volume_cache.remember(session, list(research.fetched), geo=geo, locale=locale)
    volume_cache.record_hits(session, list(research.cache_hits), geo=geo, locale=locale)
    return _persist_keywords(
        session, row, research.terms, research.info, locale=locale, geo=geo
    )


async def fetch_usps(row: BatchRow, *, locale: str, geo: str) -> tuple[ProposedUsp, ...]:
    """Ask the model for selling points for one row. Network only, no writes.

    Exists because there was no way back from a failed ideation call. USPs are written
    during research, research does not re-run for a row that already has keywords, and the
    failure was swallowed — so a row that lost its selling points had lost them for good,
    and the screen said "none proposed" as though the product had none.

    Cheaper than it looks: one call to the seed model, and no volume lookup at all. The
    keywords are already measured and are not touched.
    """
    from app.providers.llm import IdeationRequest, get_llm
    from app.services.pages import stored_facts

    model = get_llm()
    result = await model.propose_keywords(
        IdeationRequest(
            row_index=row.row_index,
            product_name=row.product_name,
            category_raw=row.category_raw,
            product_url=row.product_url,
            page_type=row.page_type.value,
            brand=row.brand,
            locale=locale,
            geo=geo,
            facts=stored_facts(row),
        )
    )
    return publishable_usps(result.usps)


def add_proposed_usps(
    session: Session, row: BatchRow, usps: tuple[ProposedUsp, ...], *, model: str
) -> int:
    """Store proposed selling points, skipping any the row already carries.

    Additive, unlike `store_row_usps`, which refuses outright if the row has any. A retry
    on a row where one claim was typed by hand must not discard it, and asking twice must
    not produce the same claim twice.
    """
    held = {u.claim.casefold() for u in row.usps}
    room = MAX_USPS - len(row.usps)
    added = 0
    for usp in usps:
        if room <= 0:
            break
        if usp.claim.casefold() in held:
            continue
        row.usps.append(
            ProductUsp(
                claim=usp.claim,
                source=UspSource.model,
                is_grounded=usp.grounded,
                model=model,
            )
        )
        held.add(usp.claim.casefold())
        room -= 1
        added += 1
    session.flush()
    return added


def store_row_usps(
    session: Session,
    row: BatchRow,
    usps: tuple[ProposedUsp, ...],
    *,
    model: str = "",
) -> list[ProductUsp]:
    """Persist proposed selling points for a row, unselected.

    Unselected on purpose. A keyword gets an opening tier because a measured term is
    evidence and a starting point costs the reviewer nothing to change. A USP is an
    unverified claim about the product, so pre-ticking one would put words in a writer's
    mouth and, with them, a claim nobody chose to make.
    """
    if row.usps:
        return list(row.usps)
    created = [
        ProductUsp(
            claim=usp.claim,
            source=UspSource.model,
            is_grounded=usp.grounded,
            model=model,
        )
        for usp in usps[:MAX_USPS]
    ]
    row.usps.extend(created)
    session.flush()
    return created


async def populate_row_keywords(
    session: Session, row: BatchRow, *, locale: str, geo: str
) -> tuple[list[Keyword], ProviderInfo]:
    """Research a row and persist the result, holding the session throughout.

    The sequential path, used by the seed and by tests. Routes use `research_only` and
    `store_row_keywords` instead so the network work happens outside the write lock.

    Idempotent: calling it again for a row that already has keywords returns the stored
    ones, so a page reload mid-run does not duplicate work or double-write.
    """
    provider = get_keyword_provider()
    info = ProviderInfo(name=provider.name, is_live_data=provider.is_live_data)

    existing = list(
        session.scalars(
            select(Keyword).where(Keyword.batch_row_id == row.id).order_by(Keyword.id)
        )
    )
    if existing:
        return existing, info

    # Read the page first when there is one, so seeds and copy can both use what it says.
    # The template carries no URL, in which case this is a no-op.
    from app.services.pages import ground_row

    await ground_row(session, row)

    research = await research_only(row, locale=locale, geo=geo)
    store_row_usps(session, row, research.usps, model=research.seed_source)
    volume_cache.remember(session, list(research.fetched), geo=geo, locale=locale)
    volume_cache.record_hits(session, list(research.cache_hits), geo=geo, locale=locale)
    created = _persist_keywords(
        session, row, research.terms, research.info, locale=locale, geo=geo
    )
    return created, research.info


def _persist_keywords(
    session: Session,
    row: BatchRow,
    researched: list[ResearchedTerm],
    info: ProviderInfo,
    *,
    locale: str,
    geo: str,
) -> list[Keyword]:
    created: list[Keyword] = []
    for entry in rank_researched(researched):
        created.append(
            Keyword(
                term=entry.term,
                term_normalized=normalise_term(entry.term),
                type=entry.bucket,
                # The ONLY place a volume is written, and it comes straight from the
                # provider. Never inferred, never interpolated. Brief §1 rule 1.
                volume=entry.volume,
                cpc=entry.cpc,
                competition=entry.competition,
                source=entry.source,
                is_live_data=info.is_live_data,
                data_date=entry.data_date,
                months_covered=entry.months_covered,
                is_expansion=entry.is_expansion,
                locale=locale,
                geo=geo,
                # A term with no volume data is `unverified` and excluded from copy, but it
                # stays visible. Brief §5: the demo is more credible with visible gaps.
                status=(
                    KeywordStatus.parked if entry.volume is not None
                    else KeywordStatus.unverified
                ),
            )
        )

    # Appended to the relationship, not given raw foreign keys, so `row.keywords` stays
    # correct for callers in the same session. Setting `batch_row_id` directly left the
    # collection empty, which made the primary-keyword validator silently find no primary.
    row.keywords.extend(created)
    session.flush()

    auto_tier(session, row, created)

    row.stage = RowStage.keywords_ready
    session.flush()
    return created


#: How many measured terms become secondary as a starting point.
AUTO_SECONDARY = 3


def auto_tier(
    session: Session, row: BatchRow, candidates: list[Keyword] | None = None
) -> Keyword | None:
    """Give a row an opening set of tiers, and return the primary.

    A starting point, not a decision: one primary plus the next few measured terms as
    secondary, so the copy step has something to work with before anyone touches the page.
    Everything is one click from being changed.

    Terms are eligible only if they are measured AND publishable. Ranking on volume alone
    put "projector price in uae" (1,900) into the prompt ahead of "home projector" (590) on
    a projector row, and the copy that produced could not pass the banned-term rules —
    see `banned_in_copy`.

    Separate from `store_row_keywords` because re-tiering a row whose keywords are already
    researched must not re-run the research: the lookups cost money, and the stored volumes
    are the same figures. `candidates` defaults to everything on the row.
    """
    pool = list(row.keywords) if candidates is None else candidates

    for keyword in pool:
        keyword.tier = KeywordTier.unranked
        keyword.is_primary = False

    primary = choose_primary(pool, row.product_name, row.brand)
    if primary is None:
        session.flush()
        return None

    primary.is_primary = True
    primary.tier = KeywordTier.primary

    supporting = [
        k for k in pool
        if k is not primary
        and k.volume is not None
        and banned_in_copy(k.term_normalized) is None
    ]
    supporting.sort(key=lambda k: (-(k.volume or 0), k.term_normalized))
    for keyword in supporting[:AUTO_SECONDARY]:
        keyword.tier = KeywordTier.secondary

    session.flush()
    return primary


async def _measure_one(
    term: str, *, geo: str, locale: str, session: Session
) -> VolumeResult | None:
    """One term's figure, from the cache if it is held and from the provider if not.

    Used by the two routes where a person's click costs a request — adding a term and
    rewording one. Re-adding a term the batch already measured was a second charge for a
    figure already on the row.
    """
    held = volume_cache.read([term], geo=geo, locale=locale)
    cached = held.get(normalise_term(term))
    if cached is not None:
        volume_cache.record_hits(session, [term], geo=geo, locale=locale)
        return cached

    provider = get_keyword_provider()
    results = await provider.lookup([term], geo=geo, locale=locale)
    result = results[0] if results else None
    if result is not None:
        volume_cache.remember(session, [result], geo=geo, locale=locale)
    return result


async def add_manual_term(
    session: Session, row: BatchRow, term: str, *, locale: str, geo: str
) -> Keyword | None:
    """Add a term a user typed.

    The term still goes through the volume provider like any other. A hand-added term
    cannot acquire a volume the provider did not supply — if the provider has no data it is
    stored `unverified` with a null volume, exactly as a derived candidate would be.

    A term already on the row is returned rather than duplicated, including a rejected
    one: typing back something you removed is the plainest way to ask for it again.
    """
    cleaned = normalise_term(term)
    if not cleaned:
        return None
    duplicate = next((k for k in row.keywords if k.term_normalized == cleaned), None)
    if duplicate is not None:
        if duplicate.status is KeywordStatus.rejected:
            duplicate.status = (
                KeywordStatus.unverified if duplicate.volume is None
                else KeywordStatus.approved if row.batch.approved_at
                else KeywordStatus.parked
            )
            session.flush()
        return duplicate

    result = await _measure_one(cleaned, geo=geo, locale=locale, session=session)
    provider = get_keyword_provider()
    volume = result.volume if result else None

    keyword = Keyword(
        term=cleaned,
        term_normalized=cleaned,
        type=KeywordType.benefit,
        volume=volume,
        cpc=result.cpc if result else None,
        competition=result.competition if result else None,
        source=result.source if result else provider.name,
        is_live_data=provider.is_live_data,
        data_date=result.data_date if result else None,
        months_covered=result.months_covered if result else None,
        locale=locale,
        geo=geo,
        status=(
            KeywordStatus.approved if volume is not None and row.batch.approved_at
            else KeywordStatus.parked if volume is not None
            else KeywordStatus.unverified
        ),
    )
    row.keywords.append(keyword)
    session.flush()
    return keyword


async def edit_keyword_term(
    session: Session, row: BatchRow, keyword_id: int, term: str, *, locale: str, geo: str
) -> tuple[Keyword | None, str]:
    """Change a term's text and re-measure it. Returns the keyword and an error message.

    **The volume cannot survive the edit.** "home projector" measured 590 searches a
    month; "home projectors" is a different query with a different figure, and carrying
    the old number across would be exactly the fabrication the whole tool is built to
    prevent. So an edit is a fresh lookup, and a term the provider has no data for comes
    back unverified with its figure cleared — a visible gap rather than a stale number.

    Two consequences worth stating because they look like bugs otherwise:

      * An edit costs a provider call, the same as adding a term.
      * `is_expansion` goes false. The term is no longer one the provider returned; it is
        one a person wrote, and the provenance has to say so.
    """
    keyword = next((k for k in row.keywords if k.id == keyword_id), None)
    if keyword is None:
        return None, "That keyword is no longer on this row."

    cleaned = normalise_term(term)
    if not cleaned:
        return None, "Type a keyword first."
    if cleaned == keyword.term_normalized:
        return keyword, ""
    if any(k.id != keyword_id and k.term_normalized == cleaned for k in row.keywords):
        return None, f"{cleaned!r} is already on this row."

    result = await _measure_one(cleaned, geo=geo, locale=locale, session=session)
    provider = get_keyword_provider()

    keyword.term = cleaned
    keyword.term_normalized = cleaned
    # Straight from the provider, or None. Never the previous figure.
    keyword.volume = result.volume if result else None
    keyword.cpc = result.cpc if result else None
    keyword.competition = result.competition if result else None
    keyword.source = result.source if result else provider.name
    keyword.is_live_data = provider.is_live_data
    keyword.data_date = result.data_date if result else None
    keyword.months_covered = result.months_covered if result else None
    keyword.is_expansion = False
    keyword.status = (
        KeywordStatus.approved if keyword.volume is not None and row.batch.approved_at
        else KeywordStatus.parked if keyword.volume is not None
        else KeywordStatus.unverified
    )

    # An edit can turn a usable term into an unpublishable one — "projector" into
    # "projector price". Demote it rather than leave a tier the copy step would ignore.
    if banned_in_copy(cleaned) is not None and keyword.tier is not KeywordTier.unranked:
        keyword.tier = KeywordTier.unranked
        keyword.is_primary = False

    session.flush()
    return keyword, ""


def restore_keyword(session: Session, row: BatchRow, keyword_id: int) -> Keyword | None:
    """Undo a removal.

    `reject_keyword` keeps the record, so the term is still there to bring back. Without
    this the only way to recover a mis-click was to retype the term and pay for a second
    lookup of a figure already stored.
    """
    keyword = next((k for k in row.keywords if k.id == keyword_id), None)
    if keyword is None or keyword.status is not KeywordStatus.rejected:
        return None

    keyword.status = (
        KeywordStatus.unverified if keyword.volume is None
        else KeywordStatus.approved if row.batch.approved_at
        else KeywordStatus.parked
    )
    session.flush()
    return keyword


def toggle_usp(
    session: Session, row: BatchRow, usp_id: int, *, actor: str
) -> ProductUsp | None:
    """Tick or untick a selling point, recording who did it.

    The name and time are the whole point. An approved claim about a product is a claim
    the business is making in a search result, and "the model said so" is not an answer to
    who decided that. Unticking clears both rather than keeping a stale owner.
    """
    usp = next((u for u in row.usps if u.id == usp_id), None)
    if usp is None:
        return None

    usp.is_selected = not usp.is_selected
    usp.selected_by = actor if usp.is_selected else None
    usp.selected_at = utcnow() if usp.is_selected else None
    session.flush()
    return usp


def add_manual_usp(
    session: Session, row: BatchRow, claim: str, *, actor: str
) -> tuple[ProductUsp | None, str]:
    """Add a selling point a person typed. Returns the USP and an error message.

    Selected immediately, unlike a model-proposed one: someone typing a claim into the box
    is the approval. Recorded as `entered` so the export and the audit trail can tell the
    two apart.
    """
    cleaned = " ".join(claim.split()).rstrip(".")
    if not cleaned:
        return None, "Type a selling point first."
    if len(cleaned) > MAX_USP_CHARS:
        return None, (
            f"Too long at {len(cleaned)} characters. A selling point has to fit inside a "
            f"160-character description, so keep it under {MAX_USP_CHARS}."
        )
    if any(u.claim.casefold() == cleaned.casefold() for u in row.usps):
        return None, f"{cleaned!r} is already on this row."

    rule = banned_in_copy(cleaned)
    if rule is not None:
        return None, (
            f"Cannot be used: contains a {rule.label}. {rule.reason}"
        )

    usp = ProductUsp(
        claim=cleaned,
        source=UspSource.entered,
        # A typed claim is not grounded in a page the tool read. The person who typed it
        # is the source, which `selected_by` records.
        is_grounded=False,
        is_selected=True,
        selected_by=actor,
        selected_at=utcnow(),
    )
    row.usps.append(usp)
    session.flush()
    return usp, ""


def selected_usps(row: BatchRow) -> tuple[str, ...]:
    """The claims a human approved, in a reproducible order. What reaches the prompt."""
    chosen = sorted(
        (u for u in row.usps if u.is_selected), key=lambda u: (u.claim.casefold(), u.id)
    )
    return tuple(u.claim for u in chosen)


def reject_keyword(session: Session, row: BatchRow, keyword_id: int) -> Keyword | None:
    """Reject a term.

    Marked rejected rather than deleted, so the record of what was considered and dismissed
    survives. If it held the primary flag, the primary is re-chosen from what remains
    rather than left empty.
    """
    keyword = next((k for k in row.keywords if k.id == keyword_id), None)
    if keyword is None:
        return None

    keyword.status = KeywordStatus.rejected
    was_primary = keyword.is_primary
    keyword.is_primary = False
    session.flush()

    if was_primary:
        remaining = [
            k for k in row.keywords
            if k.id != keyword_id and k.status is not KeywordStatus.rejected
        ]
        replacement = choose_primary(remaining, row.product_name, row.brand)
        if replacement is not None:
            replacement.is_primary = True
        session.flush()
    return keyword


#: The order the cycle walks when a term is clicked. Ends back at `unranked` so a
#: mis-click is undone by carrying on clicking rather than by hunting for a reset.
TIER_CYCLE: tuple[KeywordTier, ...] = (
    KeywordTier.unranked,
    KeywordTier.primary,
    KeywordTier.secondary,
    KeywordTier.tertiary,
)


def next_tier(current: KeywordTier) -> KeywordTier:
    position = TIER_CYCLE.index(current) if current in TIER_CYCLE else 0
    return TIER_CYCLE[(position + 1) % len(TIER_CYCLE)]


def set_keyword_tier(
    session: Session, row: BatchRow, keyword_id: int, tier: KeywordTier
) -> Keyword | None:
    """Put one term into a tier, keeping the row's tiers coherent.

    Two invariants, both enforced here rather than trusted to callers:

      * At most one primary per row. Promoting a term demotes the previous primary to
        secondary rather than to nothing — it was the best term a moment ago, and
        silently discarding that is worse than keeping it as support.
      * `is_primary` mirrors `tier == primary`. Both exist because a lot of code reads
        the boolean; writing them anywhere but here is how they would drift apart.

    An unverified term can still be tiered. That is deliberate: no volume data is not the
    same as no value, and a writer who knows the market may want a term Google has no
    figure for. It stays visibly unmeasured wherever it appears.

    A term the banned-term rules bar from an indexed field cannot be tiered at all, and
    the attempt is refused here rather than filtered out later. Filtering later would mean
    a click that appeared to work and silently did nothing; refusing here keeps the chip
    showing its "research only" reason, which is the honest answer to why.
    """
    keyword = next((k for k in row.keywords if k.id == keyword_id), None)
    if keyword is None:
        return None

    if tier is not KeywordTier.unranked and banned_in_copy(keyword.term_normalized):
        return keyword

    if tier is KeywordTier.primary:
        for other in row.keywords:
            if other.id != keyword_id and other.tier is KeywordTier.primary:
                other.tier = KeywordTier.secondary
                other.is_primary = False

    keyword.tier = tier
    keyword.is_primary = tier is KeywordTier.primary
    session.flush()
    return keyword


def tiered_terms(row: BatchRow, tier: KeywordTier) -> tuple[str, ...]:
    """Terms in one tier, highest demand first, in a reproducible order."""
    chosen = [
        k for k in row.keywords
        if k.tier is tier and k.status is not KeywordStatus.rejected
    ]
    chosen.sort(key=lambda k: (-(k.volume or 0), k.term_normalized))
    return tuple(k.term for k in chosen)


def set_primary(session: Session, row: BatchRow, keyword_id: int) -> Keyword | None:
    """Move the primary to a specific keyword. The simple page's one control.

    Delegates rather than setting the flag itself, so there is exactly one place that
    decides what "primary" means to a row and the two pages cannot disagree.
    """
    return set_keyword_tier(session, row, keyword_id, KeywordTier.primary)


def approve_keywords(
    session: Session, batch: Batch, *, user_id: int, actor: str
) -> int:
    """Approve every verified keyword on the batch and record the decision.

    Unverified terms are never approved — there is no evidence to approve. Brief §8 step 3
    requires this to be an explicit act with a user and a timestamp attached.
    """
    now = utcnow()
    approved = 0
    for row in batch.rows:
        for keyword in row.keywords:
            if keyword.volume is None:
                continue
            keyword.status = KeywordStatus.approved
            keyword.approved_by_user_id = user_id
            keyword.approved_at = now
            approved += 1

    batch.approved_at = now
    batch.approved_by_user_id = user_id

    session.add(
        AuditEvent(
            batch_id=batch.id,
            actor=actor,
            action="keywords_approved",
            payload_json=_json(
                {
                    "approved_keywords": approved,
                    "rows": len(batch.rows),
                    "approved_at": now.isoformat(),
                }
            ),
        )
    )
    session.flush()
    return approved


def record_registry_claims(session: Session, batch: Batch) -> int:
    """Record which row owns each primary term in each category, for future batches."""
    claimed = 0
    for row in batch.rows:
        primary = next((k for k in row.keywords if k.is_primary), None)
        if primary is None:
            continue
        existing = session.scalar(
            select(KeywordRegistry).where(
                KeywordRegistry.category_norm == row.category_norm,
                KeywordRegistry.term == primary.term_normalized,
            )
        )
        if existing is None:
            session.add(
                KeywordRegistry(
                    category_norm=row.category_norm,
                    term=primary.term_normalized,
                    primary_for_row_id=row.id,
                )
            )
            claimed += 1
    session.flush()
    return claimed


def registry_map(session: Session, exclude_batch_id: int | None = None) -> dict[tuple[str, str], int]:
    """The registry as a lookup for the cannibalisation validator."""
    statement = select(KeywordRegistry).order_by(KeywordRegistry.id)
    out: dict[tuple[str, str], int] = {}
    for entry in session.scalars(statement):
        if entry.primary_for_row_id is None:
            continue
        row = session.get(BatchRow, entry.primary_for_row_id)
        if row is None or (exclude_batch_id is not None and row.batch_id == exclude_batch_id):
            continue
        out[(entry.category_norm, entry.term)] = row.row_index
    return out


def approved_terms_for_row(row: BatchRow) -> tuple[str, ...]:
    """Approved terms for a row, primary first, then by descending volume.

    Sorted explicitly because this feeds the export, and export bytes must be reproducible.
    """
    approved = [
        k for k in row.keywords
        if k.status is KeywordStatus.approved and k.volume is not None
    ]
    approved.sort(key=lambda k: (not k.is_primary, -(k.volume or 0), k.term_normalized))
    return tuple(k.term for k in approved)


def _json(payload: dict[str, object]) -> str:
    import json

    return json.dumps(payload, sort_keys=True)


def data_date_note(keywords: list[Keyword]) -> str:
    """What period these figures cover, in words a reader can check.

    "covers the 12 months to September 2026", not a timestamp. The column used to hold
    the moment of the request, so the only honest note this could produce was the date we
    happened to ask — which answers a question nobody has.

    When the figures on a row span more than one published window, both ends are named
    rather than only the newest: a row averaging two vintages is a fact about the row.
    """
    dated = [k for k in keywords if k.data_date is not None]
    if not dated:
        return "period not reported"

    periods = sorted({k.data_date for k in dated if k.data_date is not None})
    spans = {k.months_covered for k in dated if k.months_covered}
    span = f"the {spans.pop()} months" if len(spans) == 1 else "the period"

    # Plural verb: this describes a set of figures, unlike `VolumeResult.period_note`,
    # which describes one. "Search volumes covers the 12 months to..." was the first
    # thing rendered on the page.
    newest = periods[-1]
    if len(periods) == 1:
        return f"cover {span} to {newest:%B %Y}"
    oldest = periods[0]
    return f"cover {span} to {newest:%B %Y}; some are older, to {oldest:%B %Y}"
