"""Reuse of search volumes already paid for.

DataForSEO bills per request, and the tool repeats itself: every batch with a Samsung
phone asks for "samsung", every projector row asks for "projector", and across the test
batches the same terms were bought several times over.

The division of labour mirrors the research route, and for the same reason:

    read()    no write lock. Called during the network phase, alongside the provider
              calls it is there to avoid.
    remember() under the write lock, from the phase that persists the row.

Writing cache rows in the network phase would mean taking the write lock during the slow
part, which is exactly the thing that turned nine rows into a ten-minute queue.

**What is NOT cached, deliberately:** the expansion. `expand()` asks "what else do people
type around this seed", and the answer set changes as search behaviour does; caching it
would freeze a row's long tail to whenever the seed was first researched. Only the figure
attached to a specific term is reused, because that figure is a twelve-month average which
Google itself only updates monthly.

This module writes `volume=`, so it imports `app.providers.keywords` — the rule from
`tests/test_no_llm_volumes.py`, and the right rule: a cache is a place a wrong figure could
enter, so it is held to the same standard as the provider.
"""

from __future__ import annotations

import datetime as dt
import logging

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import settings
from app.db import session_scope
from app.lib.normalise import normalise_term
from app.models import VolumeCache, utcnow
from app.providers.keywords import VolumeResult

log = logging.getLogger(__name__)


def _vintage_floor() -> dt.datetime:
    """The oldest DATA period that may still be served.

    Measured against the figure's own window, not against when we fetched it. The two are
    unrelated: a figure bought yesterday can already describe a window that closed months
    ago, and a figure bought months ago can still be the newest one published.
    """
    return utcnow() - dt.timedelta(days=settings().volume_max_vintage_days)


def _recheck_floor() -> dt.datetime:
    """How recently we must have asked to stop asking again.

    The cost guard, and it is needed because the vintage rule alone does not terminate: if
    the published window really is old, re-fetching returns the same old window, which is
    still stale, which would re-fetch on the next row and every row after it. So an entry
    whose data is out of date but which we checked recently is served anyway — it is the
    newest figure that exists, and buying it again changes nothing but the bill.
    """
    return utcnow() - dt.timedelta(days=settings().volume_recheck_days)


def read(terms: list[str], *, geo: str, locale: str) -> dict[str, VolumeResult]:
    """Figures already held for these terms, keyed by normalised term.

    Opens its own short read-only session: the caller is in the network phase and holds no
    write lock, and a read on a WAL database does not need one.

    Returns nothing at all when the cache is switched off, so `VOLUME_CACHE_DAYS=0` is a
    complete bypass rather than a cache that pretends to be empty.
    """
    if not terms or not settings().volume_cache_enabled:
        return {}

    wanted = {normalise_term(t) for t in terms}
    wanted.discard("")
    if not wanted:
        return {}

    vintage_floor = _vintage_floor()
    recheck_floor = _recheck_floor()
    hits: dict[str, VolumeResult] = {}
    with session_scope() as session:
        rows = session.scalars(
            select(VolumeCache).where(
                VolumeCache.term_normalized.in_(wanted),
                VolumeCache.geo == geo,
                VolumeCache.locale == locale,
            )
        ).all()
        for entry in rows:
            # An entry with no recorded vintage is never served. Rows written before the
            # provider reported one hold `datetime.now()` in that column — the moment of
            # the request, which says nothing about the age of the figure — and serving
            # them would carry that error forward under a column that now means
            # something else.
            if entry.data_date is None:
                continue
            fresh_enough = entry.data_date >= vintage_floor
            asked_recently = entry.fetched_at >= recheck_floor
            if not (fresh_enough or asked_recently):
                continue
            hits[entry.term_normalized] = VolumeResult(
                term=entry.term_normalized,
                # Straight out of storage, and it only ever got there from a provider.
                volume=entry.volume,
                cpc=entry.cpc,
                competition=entry.competition,
                source=entry.source or "cache",
                data_date=entry.data_date,
                months_covered=entry.months_covered,
            )
    if hits:
        log.debug("volume cache served %d of %d terms", len(hits), len(wanted))
    return hits


def remember(
    session: Session,
    entries: list[VolumeResult],
    *,
    geo: str,
    locale: str,
) -> int:
    """Store figures that came from a live provider call. Returns how many were written.

    `fetched_at` is only moved forward when the figure is being refreshed from the
    network. A cache that renewed its own expiry on every read would never expire.
    """
    if not entries or not settings().volume_cache_enabled:
        return 0

    now = utcnow()
    written = 0
    for result in entries:
        key = normalise_term(result.term)
        if not key:
            continue
        existing = session.scalars(
            select(VolumeCache).where(
                VolumeCache.term_normalized == key,
                VolumeCache.geo == geo,
                VolumeCache.locale == locale,
            )
        ).first()
        if existing is None:
            session.add(
                VolumeCache(
                    term_normalized=key,
                    geo=geo,
                    locale=locale,
                    volume=result.volume,
                    cpc=result.cpc,
                    competition=result.competition,
                    source=result.source,
                    data_date=result.data_date,
                    months_covered=result.months_covered,
                    fetched_at=now,
                )
            )
        else:
            existing.volume = result.volume
            existing.cpc = result.cpc
            existing.competition = result.competition
            existing.source = result.source
            existing.data_date = result.data_date
            existing.months_covered = result.months_covered
            # Moved only on a real fetch. This is the "we asked" clock, and the re-check
            # guard reads it; a read must not touch it or the guard never lapses.
            existing.fetched_at = now
        written += 1
    session.flush()
    return written


def record_hits(session: Session, terms: list[str], *, geo: str, locale: str) -> None:
    """Count how often the cache saved a call, so the saving can be reported.

    Separate from `read` because `read` holds no write lock. Called from the persisting
    phase, where a write is already safe.
    """
    if not terms:
        return
    keys = {normalise_term(t) for t in terms}
    keys.discard("")
    if not keys:
        return
    rows = session.scalars(
        select(VolumeCache).where(
            VolumeCache.term_normalized.in_(keys),
            VolumeCache.geo == geo,
            VolumeCache.locale == locale,
        )
    ).all()
    for entry in rows:
        entry.hits += 1
    session.flush()


def statistics() -> dict[str, object]:
    """What the cache holds, how old the DATA in it is, and how much it has saved."""
    with session_scope() as session:
        rows = session.scalars(select(VolumeCache)).all()
        floor = _vintage_floor()
        vintages = sorted(r.data_date for r in rows if r.data_date is not None)
        return {
            "terms_held": len(rows),
            "terms_within_vintage": sum(
                1 for r in rows if r.data_date is not None and r.data_date >= floor
            ),
            "terms_without_a_known_period": sum(1 for r in rows if r.data_date is None),
            "lookups_avoided": sum(r.hits for r in rows),
            "with_no_data": sum(1 for r in rows if r.volume is None),
            # The actual spread of data vintages held, which is the number that says
            # whether the figures on screen are current.
            "oldest_period": vintages[0].strftime("%Y-%m") if vintages else None,
            "newest_period": vintages[-1].strftime("%Y-%m") if vintages else None,
            "max_vintage_days": settings().volume_max_vintage_days,
            "recheck_days": settings().volume_recheck_days,
        }


def forget_undated(session: Session) -> int:
    """Drop entries with no recorded data period. Returns how many went.

    One-off housekeeping for rows written while the provider was recording
    `datetime.now()` as the figure's date. They are not served — `read` skips them — so
    this only reclaims the space and stops the statistics reporting a holding that can
    never be used.
    """
    rows = session.scalars(
        select(VolumeCache).where(VolumeCache.data_date.is_(None))
    ).all()
    for entry in rows:
        session.delete(entry)
    session.flush()
    return len(rows)
