"""Upload ingestion — brief §8 step 1.

"Never reject a file for dirty data; classify and continue." A row that cannot be processed
produces an explicit skipped-with-reason record rather than disappearing, per §1 rule 6 —
the reference file silently dropped 16 of 21 rows and the point of this service is that
doing so is not possible.
"""

from __future__ import annotations

import datetime as dt
import json
from dataclasses import dataclass
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import settings
from app.excel.reader import ParsedWorkbook, read_any_workbook
from app.models import (
    AuditEvent,
    Batch,
    BatchRow,
    BatchStatus,
    FetchStatus,
    PriceSource,
    RowStage,
    User,
    utcnow,
)


@dataclass(frozen=True, slots=True)
class IngestSummary:
    batch_id: int
    row_count: int
    unreachable: int
    skipped: int
    page_type_counts: dict[str, int]
    header_warnings: tuple[str, ...]
    layout: str = "legacy"
    derived_brands: int = 0
    priced: int = 0
    batch_numbers: tuple[str, ...] = ()


def retention_expiry(uploaded_at: dt.datetime, months: int | None = None) -> dt.datetime:
    """Six months after upload, per brief §4.

    Calendar-aware rather than a flat 180 days, and clamped to the last valid day of the
    target month so 31 August + 6 does not overflow into March.
    """
    span = settings().retention_months if months is None else months
    month_index = uploaded_at.month - 1 + span
    year = uploaded_at.year + month_index // 12
    month = month_index % 12 + 1
    if month == 12:
        next_month_start = dt.datetime(year + 1, 1, 1)
    else:
        next_month_start = dt.datetime(year, month + 1, 1)
    last_day = (next_month_start - dt.timedelta(days=1)).day
    return uploaded_at.replace(year=year, month=month, day=min(uploaded_at.day, last_day))


def demo_user(session: Session) -> User:
    """The single mocked user. Brief §0: no auth, no RBAC, no multi-tenancy."""
    config = settings()
    user = session.scalar(select(User).where(User.email == config.demo_user_email))
    if user is None:
        user = User(name=config.demo_user_name, email=config.demo_user_email)
        session.add(user)
        session.flush()
    return user


def ingest_workbook(
    session: Session,
    *,
    parsed: ParsedWorkbook,
    batch_no: str,
    source_file_name: str,
    user: User,
) -> IngestSummary:
    config = settings()
    uploaded_at = utcnow()

    batch = Batch(
        batch_no=batch_no,
        source_file_name=source_file_name,
        sheet_name=parsed.sheet_name,
        uploaded_at=uploaded_at,
        user_id=user.id,
        status=BatchStatus.uploaded,
        locale=config.locale,
        geo=config.geo,
        retention_expires_at=retention_expiry(uploaded_at),
        input_layout=parsed.layout,
    )
    session.add(batch)
    session.flush()

    page_type_counts: dict[str, int] = {}
    for parsed_row in parsed.rows:
        page_type_counts[parsed_row.page_type.value] = (
            page_type_counts.get(parsed_row.page_type.value, 0) + 1
        )
        session.add(
            BatchRow(
                batch_id=batch.id,
                row_index=parsed_row.row_index,
                category_raw=parsed_row.category_raw,
                category_norm=parsed_row.category_norm,
                product_url=parsed_row.product_url,
                product_name=parsed_row.product_name,
                go_live_raw=parsed_row.go_live_raw,
                date_serial=parsed_row.date_serial,
                date_number_format=parsed_row.date_number_format,
                date_value=parsed_row.date_value,
                page_type=parsed_row.page_type,
                fetch_status=parsed_row.fetch_status,
                fetch_note=parsed_row.fetch_note,
                skip_reason=parsed_row.skip_reason,
                brand=parsed_row.brand,
                brand_derived=parsed_row.brand_derived,
                price_aed=parsed_row.price_aed,
                price_source=(
                    PriceSource.input_sheet if parsed_row.price_aed is not None else None
                ),
                price_set_at=uploaded_at if parsed_row.price_aed is not None else None,
                price_entered_by=user.email if parsed_row.price_aed is not None else None,
                # A row is only `skipped` if it genuinely cannot be processed. An
                # unreachable preprod URL is NOT such a row: nothing downstream needs the
                # page to respond, because the tool does not fetch it. Skipping those three
                # would reproduce the dropped-rows defect. See DECISIONS.md §4.
                stage=RowStage.skipped if parsed_row.skip_reason else RowStage.pending,
            )
        )

    session.add(
        AuditEvent(
            batch_id=batch.id,
            actor=user.email,
            action="batch_uploaded",
            payload_json=json.dumps(
                {
                    "batch_no": batch_no,
                    "source_file_name": source_file_name,
                    "sheet_name": parsed.sheet_name,
                    "rows": len(parsed.rows),
                    "unreachable": parsed.unreachable_count,
                    "skipped": parsed.skipped_count,
                    "header_warnings": list(parsed.header_warnings),
                },
                sort_keys=True,
            ),
        )
    )
    session.flush()

    return IngestSummary(
        batch_id=batch.id,
        row_count=len(parsed.rows),
        unreachable=parsed.unreachable_count,
        skipped=parsed.skipped_count,
        page_type_counts=page_type_counts,
        header_warnings=parsed.header_warnings,
        layout=parsed.layout,
        derived_brands=parsed.derived_brand_count,
        priced=parsed.priced_count,
        batch_numbers=parsed.batch_numbers,
    )


def ingest_path(
    session: Session, path: Path, *, batch_no: str, user: User, sheet_name: str | None = None
) -> IngestSummary:
    parsed = read_any_workbook(path, sheet_name=sheet_name)
    return ingest_workbook(
        session,
        parsed=parsed,
        batch_no=batch_no,
        source_file_name=path.name,
        user=user,
    )


def unreachable_rows(batch: Batch) -> list[BatchRow]:
    return [r for r in batch.rows if r.fetch_status is FetchStatus.unreachable]
