"""Six-month retention — brief §4.

"A `purgeExpired()` job, invocable from a dev route, deletes batches past
`retentionExpiresAt`."

Exports are regenerated from stored records rather than served from a saved blob, so
purging a batch necessarily removes its downloadable history too. That is the intended
behaviour — the alternative is a stale file nobody can reconcile with the data — and the
UI states the retention date per batch so it is never a surprise.
"""

from __future__ import annotations

import datetime as dt
import json
from dataclasses import dataclass
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import AuditEvent, Batch, utcnow


@dataclass(frozen=True, slots=True)
class PurgeResult:
    purged_batch_ids: tuple[int, ...]
    purged_batch_numbers: tuple[str, ...]
    files_removed: int
    as_of: dt.datetime

    @property
    def count(self) -> int:
        return len(self.purged_batch_ids)


def expired_batches(session: Session, as_of: dt.datetime | None = None) -> list[Batch]:
    moment = as_of or utcnow()
    return list(
        session.scalars(
            select(Batch)
            .where(Batch.retention_expires_at <= moment)
            .order_by(Batch.id)
        )
    )


def purge_expired(
    session: Session, *, as_of: dt.datetime | None = None, actor: str = "system"
) -> PurgeResult:
    moment = as_of or utcnow()
    doomed = expired_batches(session, moment)

    ids: list[int] = []
    numbers: list[str] = []
    files_removed = 0

    for batch in doomed:
        for export in batch.exports:
            if not export.file_path:
                continue
            path = Path(export.file_path)
            if path.exists():
                path.unlink()
                files_removed += 1
        ids.append(batch.id)
        numbers.append(batch.batch_no)
        # Rows, keywords, copy fields, exports and events cascade from the batch.
        session.delete(batch)

    if ids:
        # Recorded without a batch_id, since the batch it refers to no longer exists.
        session.add(
            AuditEvent(
                batch_id=None,
                actor=actor,
                action="retention_purge",
                payload_json=json.dumps(
                    {
                        "as_of": moment.isoformat(),
                        "batch_ids": ids,
                        "batch_numbers": numbers,
                        "files_removed": files_removed,
                    },
                    sort_keys=True,
                ),
            )
        )
    session.flush()

    return PurgeResult(
        purged_batch_ids=tuple(ids),
        purged_batch_numbers=tuple(numbers),
        files_removed=files_removed,
        as_of=moment,
    )


def days_until_expiry(batch: Batch, as_of: dt.datetime | None = None) -> int:
    moment = as_of or utcnow()
    return (batch.retention_expires_at - moment).days
