"""The no-fetch provider — default.

Makes no request at all, so the tool runs fully offline. Preprod hosts are still reported
`unreachable` because that is a fact about the hostname rather than an inference about a
server; everything else is `not_attempted`. Nothing is ever `ok`, because claiming a
successful fetch that never happened would be a lie.
"""

from __future__ import annotations

from urllib.parse import urlparse

from app.providers.pages import PageResult

PROVIDER_NAME = "NoFetchProvider"
PUBLIC_HOSTS = frozenset({"www.eand.ae", "eand.ae"})


class NoFetchProvider:
    @property
    def name(self) -> str:
        return PROVIDER_NAME

    @property
    def fetches(self) -> bool:
        return False

    async def fetch(self, url: str) -> PageResult:
        host = (urlparse(url).hostname or "").lower()
        if not url or not host:
            return PageResult(url=url, status="blocked", note="Not a usable URL.")
        if host not in PUBLIC_HOSTS:
            return PageResult(
                url=url,
                status="unreachable",
                note=(
                    f"Host {host} is not the public site, so this page cannot be reached "
                    "or indexed."
                ),
            )
        return PageResult(
            url=url,
            status="not_attempted",
            note="Page not fetched — copy is grounded in the input file only.",
        )
