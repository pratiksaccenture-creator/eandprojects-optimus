"""Page content providers — the third outside-world seam.

Fetching an e& page is a call to an external service, so it sits behind a provider boundary
like volumes and copy do. That keeps HTTP clients out of the service layer (enforced by
`tests/test_provider_boundary.py`) and means the tool can run entirely offline by selecting
the no-fetch provider.

Selected by `PAGE_PROVIDER`:

  `none`  (default)  Never fetches. Every row is `not_attempted`. Copy is grounded in the
                     category name and URL only — the original behaviour.
  `http`             Really fetches. `fetch_status` becomes truthful: `ok` when the page
                     responded, `unreachable` when it did not, `blocked` on a 4xx.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

__all__ = ["PageProvider", "PageResult", "get_page_provider"]


@dataclass(frozen=True, slots=True)
class PageResult:
    """What a fetch attempt established about a URL.

    `status` maps onto `app.models.FetchStatus`. It is only ever `ok` when a page actually
    responded — the tool never claims a fetch it did not make.
    """

    url: str
    status: str  # ok | unreachable | blocked | not_attempted
    note: str | None = None
    http_status: int | None = None
    title: str = ""
    text: str = ""
    fetched_bytes: int = 0

    @property
    def has_content(self) -> bool:
        return bool(self.text.strip())


@runtime_checkable
class PageProvider(Protocol):
    @property
    def name(self) -> str: ...

    @property
    def fetches(self) -> bool:
        """False when the provider never makes a request. Surfaced in the UI."""
        ...

    async def fetch(self, url: str) -> PageResult: ...


def get_page_provider(name: str | None = None) -> PageProvider:
    from app.config import settings

    selected = (name or settings().page_provider or "none").strip().lower()

    if selected in {"none", "off", "fixture"}:
        from app.providers.pages._none import NoFetchProvider

        return NoFetchProvider()
    if selected in {"http", "live"}:
        from app.providers.pages._http import HttpPageProvider

        return HttpPageProvider()

    raise ValueError(f"Unknown PAGE_PROVIDER {selected!r}. Expected 'none' or 'http'.")
