"""Real page fetching.

Deliberately conservative: a short timeout, a size cap, one redirect hop budget, and no
concurrency of its own — the caller already fans out one request per row. The point is to
gather facts for copy, not to crawl a site.

Failures are reported, never raised. A page that times out yields `unreachable` with the
reason attached, which flows through to the row's badge and the export's validation log.
"""

from __future__ import annotations

import httpx
from bs4 import BeautifulSoup

from app.providers.pages import PageResult

PROVIDER_NAME = "HttpPageProvider"

TIMEOUT_SECONDS = 12.0
MAX_BYTES = 1_500_000
MAX_TEXT_CHARS = 20_000

USER_AGENT = (
    "Optimus/0.1 (internal SEO tooling; +https://www.eand.ae) "
    "python-httpx"
)

# Stripped before text extraction — none of it is page copy.
NOISE_TAGS = (
    "script", "style", "noscript", "nav", "header", "footer", "svg", "iframe", "form",
)


META_NAMES = ("description", "keywords")
META_PROPERTIES = ("og:title", "og:description")


def _meta_values(soup: BeautifulSoup) -> list[str]:
    """Head metadata, which on this site is often the ONLY server-rendered product copy.

    The eshop product pages are client-side rendered: 888KB of HTML yields about 1,000
    characters of DOM text, and the specifications appear nowhere in the markup except the
    existing `<meta name="description">`. Reading the head is therefore not a nicety, it is
    the only way to ground a product row at all without a headless browser.

    Note what this means: the facts come from the page's CURRENT copy, which for this batch
    is the very copy being replaced — including its prices. The extractor is instructed to
    drop price and availability language, and the banned-terms validator blocks anything
    that slips through, so two independent layers stand between the old defect and the new
    copy. See DECISIONS.md.
    """
    out: list[str] = []
    for name in META_NAMES:
        tag = soup.find("meta", attrs={"name": name})
        if tag is not None:
            content = " ".join(str(tag.get("content") or "").split())
            if content:
                out.append(f"{name}: {content}")
    for prop in META_PROPERTIES:
        tag = soup.find("meta", attrs={"property": prop})
        if tag is not None:
            content = " ".join(str(tag.get("content") or "").split())
            if content:
                out.append(f"{prop}: {content}")
    for heading in soup.find_all(["h1", "h2"], limit=6):
        text = " ".join(heading.get_text(" ", strip=True).split())
        if text:
            out.append(f"heading: {text}")
    return out


def extract_text(html: str) -> tuple[str, str]:
    """Return (title, readable text) from an HTML document.

    Head metadata comes first and is labelled, then the visible body text. Labelling the
    provenance matters: it lets the extractor treat "this is the page's current meta
    description" differently from "this is body copy", and it is what makes a
    client-side-rendered product page usable at all.

    Degrades to empty strings rather than raising on malformed markup.
    """
    soup = BeautifulSoup(html, "html.parser")

    title = ""
    if soup.title and soup.title.string:
        title = " ".join(soup.title.string.split())

    # Read the head before stripping, since NOISE_TAGS removes surrounding chrome.
    metadata = _meta_values(soup)

    for tag_name in NOISE_TAGS:
        for tag in soup.find_all(tag_name):
            tag.decompose()

    main = soup.find("main") or soup.find(None, {"role": "main"}) or soup.body or soup
    body_text = main.get_text(separator="\n", strip=True)
    kept = [line.strip() for line in body_text.splitlines() if len(line.strip()) > 1]

    sections: list[str] = []
    if metadata:
        sections.append("PAGE METADATA (the page's current copy):\n" + "\n".join(metadata))
    if kept:
        sections.append("PAGE TEXT:\n" + "\n".join(kept))

    return title, "\n\n".join(sections)[:MAX_TEXT_CHARS]


class HttpPageProvider:
    @property
    def name(self) -> str:
        return PROVIDER_NAME

    @property
    def fetches(self) -> bool:
        return True

    async def fetch(self, url: str) -> PageResult:
        if not url:
            return PageResult(url=url, status="blocked", note="No URL for this row.")

        try:
            async with httpx.AsyncClient(
                timeout=TIMEOUT_SECONDS,
                follow_redirects=True,
                headers={"User-Agent": USER_AGENT, "Accept": "text/html,*/*"},
            ) as client:
                response = await client.get(url)
        except httpx.TimeoutException:
            return PageResult(
                url=url,
                status="unreachable",
                note=f"No response within {TIMEOUT_SECONDS:.0f}s.",
            )
        except httpx.RequestError as error:
            # Covers DNS failure, refused connections and TLS problems — which is what a
            # preprod hostname looks like from outside the network.
            return PageResult(
                url=url,
                status="unreachable",
                note=f"Could not connect: {type(error).__name__}.",
            )

        if response.status_code >= 500:
            return PageResult(
                url=url,
                status="unreachable",
                note=f"Server returned {response.status_code}.",
                http_status=response.status_code,
            )
        if response.status_code >= 400:
            return PageResult(
                url=url,
                status="blocked",
                note=f"Returned {response.status_code} — not publicly readable.",
                http_status=response.status_code,
            )

        body = response.content[:MAX_BYTES]
        content_type = response.headers.get("content-type", "")
        if "html" not in content_type.lower():
            return PageResult(
                url=url,
                status="blocked",
                note=f"Not an HTML page (content-type {content_type or 'unknown'}).",
                http_status=response.status_code,
            )

        try:
            title, text = extract_text(body.decode(response.encoding or "utf-8", "replace"))
        except Exception as error:  # noqa: BLE001 - a parse failure must not fail the row
            return PageResult(
                url=url,
                status="blocked",
                note=f"Page could not be parsed: {type(error).__name__}.",
                http_status=response.status_code,
            )

        return PageResult(
            url=url,
            status="ok",
            note=f"Fetched {len(body):,} bytes.",
            http_status=response.status_code,
            title=title,
            text=text,
            fetched_bytes=len(body),
        )
