"""Fixture volume provider — the default, per brief §5.

Seeded from the reference workbook's `keywords ` sheet: 30 rows of real search volumes the
team collected, deduplicated to 29 distinct terms.

Terms absent from that seed return `volume=None`, which surfaces in the UI as `unverified`.
No number is invented to fill the gap — brief §5 is explicit that the demo is more credible
with visible gaps, and §1 rule 1 forbids inferring a volume at all.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import openpyxl

from app.config import settings
from app.lib.normalise import clean_cell, normalise_term
from app.providers.keywords import ExpansionResult, VolumeResult

PROVIDER_NAME = "FixtureVolumeProvider"
SEED_SHEET = "keywords "  # trailing space is real


@dataclass(frozen=True, slots=True)
class SeededVolume:
    term: str
    term_normalized: str
    volume: int | None


def read_keyword_seed(
    path: Path, sheet_name: str = SEED_SHEET
) -> tuple[SeededVolume, ...]:
    """Read the seeded volumes from the reference workbook's second sheet.

    This lives inside the provider package rather than in `app.excel` because a search
    volume may only originate here — the storage format is an implementation detail of
    this provider, exactly as HTTP is for the live ones.

    That sheet has no header row, carries trailing spaces on most terms, repeats
    `apple watch ` at two rows with the same volume, and has a cell holding a single
    space. Terms are trimmed and deduplicated case-insensitively, first occurrence
    winning; whitespace-only cells are treated as empty. A non-numeric volume yields
    `None` rather than a guess.
    """
    workbook = openpyxl.load_workbook(path, data_only=True)
    sheet = workbook[sheet_name]

    seen: set[str] = set()
    out: list[SeededVolume] = []
    for cells in sheet.iter_rows(min_row=1):
        if not cells:
            continue
        term = clean_cell(cells[0].value)
        if not term:
            continue
        key = term.casefold()
        if key in seen:
            continue
        seen.add(key)

        parsed: int | None = None
        if len(cells) > 1:
            raw = cells[1].value
            if isinstance(raw, (int, float)):
                parsed = int(raw)
            else:
                digits = clean_cell(raw).replace(",", "").replace(" ", "")
                parsed = int(digits) if digits.isdigit() else None
        out.append(SeededVolume(term=term, term_normalized=key, volume=parsed))
    return tuple(out)


@lru_cache(maxsize=1)
def _seed() -> tuple[dict[str, int], dt.datetime]:
    """Load the seed table once.

    The data date is the modification time of the source workbook, not `now()`: these are
    volumes someone collected on a particular day and presenting them as fresh would
    misrepresent them.

    It is a COLLECTION date standing in for a vintage, which is the best this source can
    offer — the sheet records figures without saying which months they average. The live
    provider reports the real window, and `months_covered` stays None here rather than
    claiming a span nobody wrote down.
    """
    path = settings().fixtures_dir / "output.xlsx"
    table: dict[str, int] = {}
    for entry in read_keyword_seed(path):
        if entry.volume is not None:
            table.setdefault(entry.term_normalized, entry.volume)
    collected = dt.datetime.fromtimestamp(path.stat().st_mtime).replace(microsecond=0)
    return table, collected


def seed_terms() -> tuple[tuple[str, int], ...]:
    """The seed table, sorted by descending volume. Sorted because export bytes must be
    reproducible and `dict` ordering is not a guarantee worth relying on here."""
    table, _ = _seed()
    return tuple(sorted(table.items(), key=lambda kv: (-kv[1], kv[0])))


def _contains_phrase(haystack: str, phrase: str) -> bool:
    """Whether `phrase` appears in `haystack` as whole words."""
    return f" {phrase} " in f" {haystack} "


class FixtureVolumeProvider:
    @property
    def name(self) -> str:
        return PROVIDER_NAME

    @property
    def is_live_data(self) -> bool:
        return False

    @property
    def can_expand(self) -> bool:
        return True

    async def expand(
        self, seeds: list[str], *, geo: str, locale: str, limit: int = 200
    ) -> list[ExpansionResult]:
        """Offline expansion: seeded terms that contain a seed word.

        Not a simulation of what DataForSEO would return, and not presented as one. It
        matches against the same 29 real terms the team collected, so the demo has
        something to show and the shape of the result is exercised end to end, while
        `is_live_data` stays False and the UI keeps saying so.
        """
        table, collected = _seed()
        folded = [normalise_term(s) for s in seeds if s.strip()]
        out: list[ExpansionResult] = []
        for term, volume in seed_terms():
            # Whole words only. A bare `in` test matched the seed "smart" against the
            # seeded term "smartphone", which handed a page about smart appliances a
            # primary keyword of "smartphone" — wrong, and wrong in a way that looked
            # like a working result.
            seed = next((s for s in folded if s and _contains_phrase(term, s)), None)
            if seed is None:
                continue
            out.append(
                ExpansionResult(
                    term=term,
                    volume=volume,
                    source=PROVIDER_NAME,
                    seed=seed,
                    data_date=collected,
                )
            )
            if len(out) >= limit:
                break
        return out

    async def lookup(
        self, terms: list[str], *, geo: str, locale: str
    ) -> list[VolumeResult]:
        table, collected = _seed()
        results: list[VolumeResult] = []
        for term in terms:
            volume = table.get(normalise_term(term))
            results.append(
                VolumeResult(
                    term=term,
                    volume=volume,
                    source=PROVIDER_NAME,
                    # No date when there is no number — a date would imply a measurement.
                    data_date=collected if volume is not None else None,
                )
            )
        return results
