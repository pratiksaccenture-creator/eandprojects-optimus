"""DataForSEO — keyword expansion and search volumes.

Two endpoints, both Google Ads data resold without needing a developer token or ad spend:

    POST /v3/keywords_data/google_ads/search_volume/live
        Price a list of terms you already have.

    POST /v3/keywords_data/google_ads/keywords_for_keywords/live
        Expand up to 20 seed terms into the real long tail — up to 20,000 related
        keywords, each with its own volume, for one charge per request.

The second endpoint is what makes the research honest. The model proposes seeds because it
knows the product; Google supplies the terms people actually type and how many of them do.
A model asked to produce the long tail directly would be inventing both the phrasing and,
implicitly, the demand.

A keyword Google has no data for returns `null`. That null is preserved as `None` — never
smoothed to a zero, never estimated.
"""

from __future__ import annotations

import asyncio
import datetime as dt
import os
from dataclasses import dataclass
from typing import Any

import httpx

from app.lib.normalise import normalise_term
from app.providers.keywords import ExpansionResult, NotConfiguredError, VolumeResult

PROVIDER_NAME = "DataForSEO"

BASE = "https://api.dataforseo.com/v3/keywords_data/google_ads"
ENDPOINT = f"{BASE}/search_volume/live"
EXPAND_ENDPOINT = f"{BASE}/keywords_for_keywords/live"

# The endpoint accepts 1,000 keywords per task. Kept well under so one batch is one call
# and a partial failure loses less.
MAX_KEYWORDS_PER_TASK = 700

# keywords_for_keywords is capped at 20 seeds per request by DataForSEO. Not a choice.
MAX_SEEDS_PER_EXPANSION = 20

TIMEOUT_SECONDS = 60.0

# Google location criteria IDs — DataForSEO reuses Google's. 2784 is the UAE.
LOCATION_CODES = {"AE": 2784, "UAE": 2784, "SA": 2012, "EG": 2818, "US": 2840, "UK": 2826}

# DataForSEO rejects phrases over 80 characters or 10 words.
MAX_PHRASE_CHARS = 80
MAX_PHRASE_WORDS = 10

REQUIRED_ENV = ("DATAFORSEO_LOGIN", "DATAFORSEO_PASSWORD")


def missing_env() -> tuple[str, ...]:
    return tuple(name for name in REQUIRED_ENV if not os.environ.get(name))


def location_code_for(geo: str) -> int:
    override = os.environ.get("DATAFORSEO_LOCATION_CODE", "").strip()
    if override.isdigit():
        return int(override)
    code = LOCATION_CODES.get(geo.upper())
    if code is None:
        raise NotConfiguredError(
            f"No DataForSEO location code mapped for geo={geo!r}. Set "
            "DATAFORSEO_LOCATION_CODE, or add it to LOCATION_CODES."
        )
    return code


def language_code_for(locale: str) -> str:
    override = os.environ.get("DATAFORSEO_LANGUAGE_CODE", "").strip()
    if override:
        return override
    return "ar" if locale.lower().startswith("ar") else "en"


def acceptable(term: str) -> bool:
    """Whether DataForSEO will accept this phrase.

    Filtered rather than sent and rejected: one bad phrase fails the whole task, which
    would turn a single over-long candidate into a batch with no volumes at all.
    """
    return bool(term) and len(term) <= MAX_PHRASE_CHARS and len(term.split()) <= MAX_PHRASE_WORDS


def chunk(terms: list[str], size: int = MAX_KEYWORDS_PER_TASK) -> list[list[str]]:
    return [terms[i : i + size] for i in range(0, len(terms), size)]


def build_task(terms: list[str], *, location_code: int, language_code: str) -> dict[str, Any]:
    """One task object. Pure, so it is testable without network."""
    if len(terms) > MAX_KEYWORDS_PER_TASK:
        raise ValueError(
            f"At most {MAX_KEYWORDS_PER_TASK} keywords per task; got {len(terms)}. "
            "Use `chunk()`."
        )
    return {
        "keywords": terms,
        "location_code": location_code,
        "language_code": language_code,
        "search_partners": False,
    }


@dataclass(frozen=True, slots=True)
class DataForSeoRow:
    term: str
    search_volume: int | None
    cpc: float | None
    competition: str | None
    competition_index: int | None
    # The last month the average covers, and how many months it spans. Read from the
    # response's own `monthly_searches` breakdown, which this parser used to discard.
    #
    # Without it the tool could not say what period any figure described, and recorded
    # `datetime.now()` as the figure's date — the time we asked, dressed as the time it
    # was measured.
    period_end: dt.date | None = None
    months_covered: int | None = None


def _as_datetime(value: dt.date | None) -> dt.datetime | None:
    """The stored column is a datetime; the vintage is a month. Midnight on the 1st."""
    return None if value is None else dt.datetime(value.year, value.month, 1)


def read_period(row: dict[str, Any]) -> tuple[dt.date | None, int | None]:
    """The window a `search_volume` describes, from the row's monthly breakdown.

    Google Ads reports `search_volume` as an average over a trailing window and returns
    that window month by month in `monthly_searches`:

        [{"year": 2025, "month": 10, "search_volume": 8100}, ... twelve of them]

    The last entry is the vintage. Returning it is what lets a cached figure be expired on
    the age of the DATA rather than on how long ago we happened to ask, and lets a screen
    say "covers the 12 months to September 2026" — a claim that can be checked.

    Returns `(None, None)` when the breakdown is absent or malformed, and the caller must
    treat that as "vintage unknown" rather than substituting today.
    """
    months = row.get("monthly_searches")
    if not isinstance(months, list) or not months:
        return None, None

    dated: list[dt.date] = []
    for entry in months:
        if not isinstance(entry, dict):
            continue
        year, month = entry.get("year"), entry.get("month")
        if not isinstance(year, int) or not isinstance(month, int):
            continue
        if not (1 <= month <= 12 and 2000 <= year <= 2100):
            continue
        dated.append(dt.date(year, month, 1))

    if not dated:
        return None, None
    return max(dated), len(dated)


def parse_response(payload: dict[str, Any]) -> dict[str, DataForSeoRow]:
    """Pull rows out of the response, keyed by normalised term.

    A non-20000 status is raised rather than returning nothing. Returning an empty mapping
    would make an auth, quota or billing failure indistinguishable from "Google has no data
    for these terms" — which is exactly the confusion this tool exists to prevent.
    """
    status = payload.get("status_code")
    if status != 20000:
        raise NotConfiguredError(
            f"DataForSEO rejected the request: {status} "
            f"{payload.get('status_message', '')}".strip()
        )

    out: dict[str, DataForSeoRow] = {}
    for task in payload.get("tasks") or []:
        task_status = task.get("status_code")
        if task_status != 20000:
            raise NotConfiguredError(
                f"DataForSEO task failed: {task_status} "
                f"{task.get('status_message', '')}".strip()
            )
        for row in task.get("result") or []:
            term = str(row.get("keyword") or "").strip()
            if not term:
                continue
            raw_volume = row.get("search_volume")
            raw_cpc = row.get("cpc")
            raw_index = row.get("competition_index")
            period_end, months_covered = read_period(row)
            out[normalise_term(term)] = DataForSeoRow(
                term=term,
                # `null` means Google reports no data. Preserved, never zeroed.
                search_volume=int(raw_volume) if isinstance(raw_volume, (int, float)) else None,
                cpc=float(raw_cpc) if isinstance(raw_cpc, (int, float)) else None,
                competition=str(row.get("competition")) if row.get("competition") else None,
                competition_index=int(raw_index) if isinstance(raw_index, (int, float)) else None,
                period_end=period_end,
                months_covered=months_covered,
            )
    return out


def cost_of(payload: dict[str, Any]) -> float:
    """What the response says it cost, in USD. Reported rather than estimated."""
    value = payload.get("cost")
    return float(value) if isinstance(value, (int, float)) else 0.0


def build_expansion_task(
    seeds: list[str], *, location_code: int, language_code: str, limit: int
) -> dict[str, Any]:
    """One keywords_for_keywords task.

    `sort_by="search_volume"` matters: the endpoint can return thousands of terms and we
    keep a few dozen, so the ones we keep should be the ones with demand rather than the
    first few alphabetically.
    """
    if len(seeds) > MAX_SEEDS_PER_EXPANSION:
        raise ValueError(
            f"At most {MAX_SEEDS_PER_EXPANSION} seeds per expansion; got {len(seeds)}."
        )
    return {
        "keywords": seeds,
        "location_code": location_code,
        "language_code": language_code,
        "search_partners": False,
        "include_adult_keywords": False,
        "sort_by": "search_volume",
        "limit": limit,
    }


def parse_expansion(payload: dict[str, Any]) -> list[DataForSeoRow]:
    """Rows from an expansion response, in the order the API returned them.

    Order is preserved rather than re-sorted because the API was asked to sort by volume
    and honouring that keeps the two consistent. Errors raise, for the same reason they do
    in `parse_response`: an auth or quota failure must not read as "no demand".
    """
    status = payload.get("status_code")
    if status != 20000:
        raise NotConfiguredError(
            f"DataForSEO rejected the expansion: {status} "
            f"{payload.get('status_message', '')}".strip()
        )

    out: list[DataForSeoRow] = []
    seen: set[str] = set()
    for task in payload.get("tasks") or []:
        task_status = task.get("status_code")
        if task_status != 20000:
            raise NotConfiguredError(
                f"DataForSEO expansion task failed: {task_status} "
                f"{task.get('status_message', '')}".strip()
            )
        for row in task.get("result") or []:
            term = str(row.get("keyword") or "").strip()
            if not term:
                continue
            key = normalise_term(term)
            if key in seen:
                continue
            seen.add(key)
            raw_volume = row.get("search_volume")
            raw_cpc = row.get("cpc")
            raw_index = row.get("competition_index")
            period_end, months_covered = read_period(row)
            out.append(
                DataForSeoRow(
                    term=term,
                    search_volume=int(raw_volume) if isinstance(raw_volume, (int, float)) else None,
                    cpc=float(raw_cpc) if isinstance(raw_cpc, (int, float)) else None,
                    competition=str(row.get("competition")) if row.get("competition") else None,
                    competition_index=int(raw_index) if isinstance(raw_index, (int, float)) else None,
                    period_end=period_end,
                    months_covered=months_covered,
                )
            )
    return out


class DataForSeoProvider:
    @property
    def name(self) -> str:
        return PROVIDER_NAME

    @property
    def is_live_data(self) -> bool:
        return True

    @property
    def can_expand(self) -> bool:
        return True

    def _credentials(self) -> tuple[str, str]:
        absent = missing_env()
        if absent:
            raise NotConfiguredError(
                f"{PROVIDER_NAME} is not configured. Missing: {', '.join(absent)}. "
                "Set KEYWORD_PROVIDER=fixture to run on seeded data instead — the tool "
                "will not substitute fixture data silently."
            )
        return os.environ["DATAFORSEO_LOGIN"], os.environ["DATAFORSEO_PASSWORD"]

    async def expand(
        self, seeds: list[str], *, geo: str, locale: str, limit: int = 200
    ) -> list[ExpansionResult]:
        login, password = self._credentials()
        location_code = location_code_for(geo)
        language_code = language_code_for(locale)

        usable = sorted({normalise_term(s) for s in seeds if s.strip() and acceptable(s)})
        if not usable:
            return []
        usable = usable[:MAX_SEEDS_PER_EXPANSION]

        async with httpx.AsyncClient(
            timeout=TIMEOUT_SECONDS, auth=httpx.BasicAuth(login, password)
        ) as client:
            response = await client.post(
                EXPAND_ENDPOINT,
                json=[
                    build_expansion_task(
                        usable,
                        location_code=location_code,
                        language_code=language_code,
                        limit=limit,
                    )
                ],
            )
            response.raise_for_status()
            rows = parse_expansion(response.json())

        source = f"{PROVIDER_NAME} (Google Ads ideas, location {location_code})"
        # Which seed produced which idea is not reported per row, so the seed recorded is
        # the closest containing one. Stated rather than fabricated: it is an attribution
        # for the reviewer's benefit, not a claim from the API.
        # Longest first and whole words only, so "apple watch" is credited over "apple"
        # and a seed never matches inside a longer word.
        by_length = sorted(usable, key=len, reverse=True)
        results: list[ExpansionResult] = []
        for row in rows:
            folded = f" {normalise_term(row.term)} "
            seed = next((s for s in by_length if f" {s} " in folded), usable[0])
            results.append(
                ExpansionResult(
                    term=row.term,
                    volume=row.search_volume,
                    source=source,
                    seed=seed,
                    # The month the average ends, out of the response — not the moment we
                    # asked. A row whose breakdown is missing gets None, which the cache
                    # reads as "vintage unknown" and refuses to serve.
                    data_date=_as_datetime(row.period_end),
                    months_covered=row.months_covered,
                    cpc=row.cpc,
                    competition=row.competition,
                )
            )
        return results

    async def lookup(
        self, terms: list[str], *, geo: str, locale: str
    ) -> list[VolumeResult]:
        login, password = self._credentials()
        location_code = location_code_for(geo)
        language_code = language_code_for(locale)

        # Deduplicated and sorted so identical input produces an identical request.
        wanted = sorted({normalise_term(t) for t in terms if t.strip()})
        sendable = [t for t in wanted if acceptable(t)]

        found: dict[str, DataForSeoRow] = {}
        async with httpx.AsyncClient(
            timeout=TIMEOUT_SECONDS, auth=httpx.BasicAuth(login, password)
        ) as client:
            batches = chunk(sendable)
            for position, batch in enumerate(batches):
                if position:
                    # The live endpoint allows 12 requests a minute. One batch never gets
                    # near that, but a very large upload might.
                    await asyncio.sleep(5)
                response = await client.post(
                    ENDPOINT,
                    json=[
                        build_task(
                            batch,
                            location_code=location_code,
                            language_code=language_code,
                        )
                    ],
                )
                response.raise_for_status()
                found.update(parse_response(response.json()))

        source = f"{PROVIDER_NAME} (Google Ads, location {location_code})"
        results: list[VolumeResult] = []
        for term in terms:
            row = found.get(normalise_term(term))
            volume = row.search_volume if row else None
            results.append(
                VolumeResult(
                    term=term,
                    volume=volume,
                    source=source,
                    # The period the figure covers, read from the response. No date
                    # without a figure — a date would imply a measurement — and no date
                    # when the response carried no breakdown, because "we asked today" is
                    # not the age of the data and recording it as such is what this
                    # replaces.
                    data_date=_as_datetime(row.period_end) if row and volume is not None else None,
                    months_covered=row.months_covered if row else None,
                    cpc=row.cpc if row else None,
                    competition=row.competition if row else None,
                )
            )
        return results
