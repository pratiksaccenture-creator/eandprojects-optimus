"""Google Ads Keyword Planner provider — stub, per brief §5.

This is the recommended production source: free, authoritative, with native UAE and Arabic
targeting. It is a stub with the real request shape rather than a fake, so the work needed
to make it live is visible and reviewable.

It raises `NotConfiguredError` when credentials are absent. It never falls back to fixture
data, because a silent fallback would present seeded numbers as live ones.

To go live: obtain a Google Ads developer token (approval takes time, which is why
`DataForSeoProvider` exists as a commercial fallback), then set the environment variables
listed in `REQUIRED_ENV`. No call site changes.
"""

from __future__ import annotations

import os

from app.providers.keywords import ExpansionResult, NotConfiguredError, VolumeResult

PROVIDER_NAME = "GoogleAdsKeywordPlannerProvider"

ENDPOINT = "https://googleads.googleapis.com/v18/customers/{customer_id}:generateKeywordIdeas"

# Google Ads geo target constant for the United Arab Emirates.
GEO_TARGET_UAE = "geoTargetConstants/2784"
# Language constants.
LANGUAGE_ENGLISH = "languageConstants/1000"
LANGUAGE_ARABIC = "languageConstants/1019"

REQUIRED_ENV = (
    "GOOGLE_ADS_DEVELOPER_TOKEN",
    "GOOGLE_ADS_CLIENT_ID",
    "GOOGLE_ADS_CLIENT_SECRET",
    "GOOGLE_ADS_REFRESH_TOKEN",
    "GOOGLE_ADS_CUSTOMER_ID",
)


def language_for(locale: str) -> str:
    return LANGUAGE_ARABIC if locale.lower().startswith("ar") else LANGUAGE_ENGLISH


def build_request(terms: list[str], *, geo: str, locale: str) -> dict[str, object]:
    """The request body this provider would send. Pure, so it is testable without network."""
    if geo.upper() not in {"AE", "UAE"}:
        raise NotConfiguredError(
            f"Only UAE targeting is configured; got geo={geo!r}. Add the geo target "
            "constant for that market before using it."
        )
    return {
        "keywordSeed": {"keywords": sorted(set(terms))},
        "geoTargetConstants": [GEO_TARGET_UAE],
        "language": language_for(locale),
        "includeAdultKeywords": False,
        "keywordPlanNetwork": "GOOGLE_SEARCH",
        # Monthly search volume is returned in `keywordIdeaMetrics.avgMonthlySearches`.
        "pageSize": 1000,
    }


def missing_env() -> tuple[str, ...]:
    return tuple(name for name in REQUIRED_ENV if not os.environ.get(name))


class GoogleAdsKeywordPlannerProvider:
    @property
    def name(self) -> str:
        return PROVIDER_NAME

    @property
    def is_live_data(self) -> bool:
        return True

    @property
    def can_expand(self) -> bool:
        # Keyword Planner's own ideas service would do this, but this provider is a stub
        # with request shapes only — claiming a capability it has not implemented would be
        # worse than declaring the gap.
        return False

    async def expand(
        self, seeds: list[str], *, geo: str, locale: str, limit: int = 200
    ) -> list[ExpansionResult]:
        raise NotConfiguredError(
            "The Google Ads provider is a stub and does not expand keywords. Use "
            "KEYWORD_PROVIDER=dataforseo for keyword research."
        )

    async def lookup(
        self, terms: list[str], *, geo: str, locale: str
    ) -> list[VolumeResult]:
        absent = missing_env()
        if absent:
            raise NotConfiguredError(
                f"{PROVIDER_NAME} is not configured. Missing: {', '.join(absent)}. "
                "Set KEYWORD_PROVIDER=fixture to run on seeded data instead — the tool "
                "will not substitute fixture data silently."
            )
        # Deliberately unimplemented. Wiring the HTTP call is the remaining work; the
        # request shape above is what it would send, and `avgMonthlySearches` is what it
        # would read. Raising here rather than returning empty results keeps a
        # half-configured provider from looking like a provider with no data.
        raise NotConfiguredError(
            f"{PROVIDER_NAME} has credentials but no HTTP implementation in this "
            "prototype. See the module docstring for what remains."
        )
