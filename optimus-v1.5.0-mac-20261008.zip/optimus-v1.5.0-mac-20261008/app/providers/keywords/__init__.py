"""Keyword volume providers — brief §5.

This package is the ONLY place a search volume may come from. Brief §1 rule 1 is absolute:
an LLM never produces a volume — not as an estimate, not as a fallback, not
"approximately". If a provider has no data for a term, the term gets `volume=None`, is
marked `unverified` and is excluded. Nothing is inferred and nothing is interpolated.

`tests/test_no_llm_volumes.py` enforces that structurally by walking the import graph, so
the rule survives someone not having read this docstring.

Implementations are underscore-private and reached only through `get_keyword_provider()`,
so adding or repointing a provider never touches a call site.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

__all__ = [
    "ExpansionResult",
    "KeywordVolumeProvider",
    "NotConfiguredError",
    "VolumeResult",
    "available_providers",
    "get_keyword_provider",
]


class NotConfiguredError(RuntimeError):
    """A provider was selected but its credentials or configuration are absent.

    Raised loudly rather than silently falling back to fixture data, because a silent
    fallback would present seeded numbers as live ones.
    """


@dataclass(frozen=True, slots=True)
class VolumeResult:
    term: str
    volume: int | None
    source: str
    # The END of the period this figure averages, not when we asked for it.
    #
    # That distinction used to be lost: the DataForSEO provider set this to
    # `datetime.now()`, so the tool recorded the time of the request as the age of the
    # data and could not report the vintage of any number it held. `search_volume` is an
    # average over a trailing window, and the response says which one.
    #
    # None means the vintage is unknown — either no figure was returned, or the response
    # carried no monthly breakdown. It is never filled in with today.
    data_date: dt.datetime | None = None
    #: How many months that average spans. Twelve, for Google Ads.
    months_covered: int | None = None
    cpc: float | None = None
    competition: str | None = None

    @property
    def is_verified(self) -> bool:
        return self.volume is not None

    @property
    def period_note(self) -> str:
        """"covers the 12 months to September 2026", or a plain statement that we cannot
        say. Used wherever a figure is shown with its provenance."""
        if self.data_date is None:
            return "period not reported"
        span = f"{self.months_covered} months" if self.months_covered else "the period"
        return f"covers {span} to {self.data_date:%B %Y}"


@dataclass(frozen=True, slots=True)
class ExpansionResult:
    """A keyword the provider produced itself, from a seed, with its own demand figure.

    Distinct from `VolumeResult` because the term did not exist before the call. This is
    what makes the research honest: the long tail comes from the provider's own data about
    what people type, not from a model's idea of what they might.
    """

    term: str
    volume: int | None
    source: str
    seed: str
    #: Same meaning as on `VolumeResult`: the end of the averaged period, never "now".
    data_date: dt.datetime | None = None
    months_covered: int | None = None
    cpc: float | None = None
    competition: str | None = None

    @property
    def is_verified(self) -> bool:
        return self.volume is not None


@runtime_checkable
class KeywordVolumeProvider(Protocol):
    @property
    def name(self) -> str: ...

    @property
    def is_live_data(self) -> bool:
        """False for seeded data. The UI must show a badge whenever this is False."""
        ...

    @property
    def can_expand(self) -> bool:
        """Whether `expand()` does real work. False providers return seeds priced only."""
        ...

    async def lookup(
        self, terms: list[str], *, geo: str, locale: str
    ) -> list[VolumeResult]: ...

    async def expand(
        self, seeds: list[str], *, geo: str, locale: str, limit: int = 200
    ) -> list[ExpansionResult]:
        """Turn seed terms into the real long tail, each with its own volume.

        Lives on the volume provider rather than beside the model on purpose. Keyword
        expansion and volume measurement are the same act here — the provider returns
        terms *because* it has demand data for them — and putting expansion anywhere else
        would create a second place a term could acquire a number.
        """
        ...


def available_providers() -> tuple[str, ...]:
    return ("fixture", "semrush", "google_ads", "dataforseo")


def get_keyword_provider(name: str | None = None) -> KeywordVolumeProvider:
    """Resolve the provider named by `KEYWORD_PROVIDER`.

    With nothing configured this RAISES. It used to fall back to seeded volumes, which
    meant a tool with no credentials quietly served 29 numbers collected once for an
    Apple batch. Seeded data is now reachable only by asking for it by name. See
    DECISIONS.md §29.
    """
    from app.config import UNCONFIGURED, settings

    selected = (name or settings().keyword_provider or UNCONFIGURED).strip().lower()

    if selected == UNCONFIGURED:
        raise NotConfiguredError(
            "No search-volume provider is configured, and this tool will not invent or "
            "substitute a search volume. Add DATAFORSEO_LOGIN and DATAFORSEO_PASSWORD "
            "to .env and restart. To run a demo with no network, set "
            "KEYWORD_PROVIDER=fixture — the numbers are then seeded and every screen "
            "says so."
        )

    if selected == "fixture":
        from app.providers.keywords._fixture import FixtureVolumeProvider

        return FixtureVolumeProvider()
    if selected in {"semrush", "sem_rush", "semrush_api"}:
        from app.providers.keywords._semrush import SemrushVolumeProvider

        return SemrushVolumeProvider()
    if selected in {"google_ads", "google", "googleads"}:
        from app.providers.keywords._google_ads import GoogleAdsKeywordPlannerProvider

        return GoogleAdsKeywordPlannerProvider()
    if selected in {"dataforseo", "data_for_seo"}:
        from app.providers.keywords._dataforseo import DataForSeoProvider

        return DataForSeoProvider()

    raise NotConfiguredError(
        f"Unknown KEYWORD_PROVIDER {selected!r}. Expected one of "
        f"{', '.join(available_providers())}."
    )
