"""Semrush volume provider — the recommended live source.

Uses the **Analytics API v3 REST endpoint**, not the Semrush MCP. That is deliberate: the
MCP is documented as "designed for AI agents rather than direct server-to-server calls",
and Semrush's own note on it says "AI responses may be incomplete or inaccurate, so always
verify them". Putting a language model between this tool and a search volume would
reintroduce exactly the failure mode the whole design exists to prevent. Both paths consume
the same API units from the same subscription, so the REST call costs no more and needs no
extra access.

Endpoint: `phrase_these` (Batch Keyword Overview, one database)

    GET https://api.semrush.com/
        ?type=phrase_these
        &key=<API key>
        &phrase=term one;term two;term three
        &database=ae
        &export_columns=Ph,Nq,Cp,Co,Nr,Kd,In

Response is `;`-delimited with a header line. Up to 100 phrases per request at 10 API units
per returned line. A term Semrush has no data for is simply absent from the response — that
absence becomes `volume=None`, never a zero and never a guess.
"""

from __future__ import annotations

import datetime as dt
import os
from dataclasses import dataclass

import httpx

from app.lib.normalise import normalise_term
from app.providers.keywords import ExpansionResult, NotConfiguredError, VolumeResult

PROVIDER_NAME = "Semrush"

ENDPOINT = "https://api.semrush.com/"
REPORT_TYPE = "phrase_these"

# Semrush caps a batch request at 100 phrases.
MAX_PHRASES_PER_REQUEST = 100
UNITS_PER_LINE = 10
TIMEOUT_SECONDS = 30.0

# Ph keyword, Nq volume, Cp CPC, Co competition, Nr results, Kd difficulty, In intent
EXPORT_COLUMNS = "Ph,Nq,Cp,Co,Nr,Kd,In"

REQUIRED_ENV = ("SEMRUSH_API_KEY",)

# Semrush regional database codes. `ae` is the United Arab Emirates.
DEFAULT_DATABASE = "ae"

# A semicolon is the field separator, so it cannot appear inside a phrase.
ILLEGAL_IN_PHRASE = ";"


def missing_env() -> tuple[str, ...]:
    return tuple(name for name in REQUIRED_ENV if not os.environ.get(name))


def database_for(geo: str) -> str:
    mapping = {"AE": "ae", "UAE": "ae", "SA": "sa", "EG": "eg", "US": "us", "UK": "uk"}
    code = mapping.get(geo.upper())
    if code is None:
        raise NotConfiguredError(
            f"No Semrush database mapped for geo={geo!r}. Add it to `database_for` first."
        )
    return code


def chunk(terms: list[str], size: int = MAX_PHRASES_PER_REQUEST) -> list[list[str]]:
    return [terms[i : i + size] for i in range(0, len(terms), size)]


def build_params(terms: list[str], *, api_key: str, database: str) -> dict[str, str]:
    """The query string for one batch. Pure, so it is testable without network."""
    if len(terms) > MAX_PHRASES_PER_REQUEST:
        raise ValueError(
            f"Semrush accepts at most {MAX_PHRASES_PER_REQUEST} phrases per request; "
            f"got {len(terms)}. Use `chunk()`."
        )
    return {
        "type": REPORT_TYPE,
        "key": api_key,
        "phrase": ";".join(terms),
        "database": database,
        "export_columns": EXPORT_COLUMNS,
    }


@dataclass(frozen=True, slots=True)
class SemrushRow:
    term: str
    search_volume: int | None
    cpc: float | None
    competition: str | None
    difficulty: str | None
    intent: str | None


def parse_response(body: str) -> dict[str, SemrushRow]:
    """Parse the `;`-delimited report into rows keyed by normalised term.

    Semrush prefixes an error response with `ERROR` and a code; that is raised rather than
    parsed, because silently returning no rows would be indistinguishable from "no data for
    these terms" and would quietly turn a billing or auth problem into missing volumes.
    """
    text = body.strip()
    if not text:
        return {}
    if text.upper().startswith("ERROR"):
        raise NotConfiguredError(f"Semrush rejected the request: {text.splitlines()[0]}")

    lines = text.splitlines()
    header = [column.strip() for column in lines[0].split(";")]
    index = {name: position for position, name in enumerate(header)}

    def field(parts: list[str], name: str) -> str:
        position = index.get(name)
        if position is None or position >= len(parts):
            return ""
        return parts[position].strip()

    out: dict[str, SemrushRow] = {}
    for line in lines[1:]:
        if not line.strip():
            continue
        parts = line.split(";")
        term = field(parts, "Keyword")
        if not term:
            continue

        raw_volume = field(parts, "Search Volume").replace(",", "")
        volume = int(raw_volume) if raw_volume.isdigit() else None

        raw_cpc = field(parts, "CPC")
        try:
            cpc = float(raw_cpc) if raw_cpc else None
        except ValueError:
            cpc = None

        out[normalise_term(term)] = SemrushRow(
            term=term,
            search_volume=volume,
            cpc=cpc,
            competition=field(parts, "Competition") or None,
            difficulty=field(parts, "Keyword Difficulty Index") or None,
            intent=field(parts, "Intent") or None,
        )
    return out


def units_for(term_count: int) -> int:
    """API units this many terms will cost, for the cost note shown in the UI."""
    return term_count * UNITS_PER_LINE


class SemrushVolumeProvider:
    @property
    def name(self) -> str:
        return PROVIDER_NAME

    @property
    def is_live_data(self) -> bool:
        return True

    @property
    def can_expand(self) -> bool:
        # Semrush does have a keyword-ideas report, but `phrase_these` — the endpoint
        # wired here — only prices terms you already hold. Declaring False is honest;
        # claiming expansion and returning the seeds back would look like a thin long tail
        # rather than a missing feature.
        return False

    async def expand(
        self, seeds: list[str], *, geo: str, locale: str, limit: int = 200
    ) -> list[ExpansionResult]:
        raise NotConfiguredError(
            "The Semrush provider prices terms but does not expand them. Use "
            "KEYWORD_PROVIDER=dataforseo for keyword research."
        )

    async def lookup(
        self, terms: list[str], *, geo: str, locale: str
    ) -> list[VolumeResult]:
        absent = missing_env()
        if absent:
            raise NotConfiguredError(
                f"{PROVIDER_NAME} is not configured. Missing: {', '.join(absent)}. "
                "Set KEYWORD_PROVIDER=fixture to run on seeded data instead — the tool "
                "will not substitute fixture data silently."
            )

        api_key = os.environ["SEMRUSH_API_KEY"]
        database = os.environ.get("SEMRUSH_DATABASE") or database_for(geo)
        collected = dt.datetime.now().replace(microsecond=0)

        # Deduplicate and sort so the same input always produces the same request, and
        # drop the separator character rather than corrupting the batch with it.
        wanted = sorted({normalise_term(t) for t in terms if t.strip()})
        safe = [t for t in wanted if ILLEGAL_IN_PHRASE not in t]

        found: dict[str, SemrushRow] = {}
        async with httpx.AsyncClient(timeout=TIMEOUT_SECONDS) as client:
            for batch in chunk(safe):
                response = await client.get(
                    ENDPOINT, params=build_params(batch, api_key=api_key, database=database)
                )
                response.raise_for_status()
                found.update(parse_response(response.text))

        results: list[VolumeResult] = []
        for term in terms:
            row = found.get(normalise_term(term))
            volume = row.search_volume if row else None
            results.append(
                VolumeResult(
                    term=term,
                    # Straight from Semrush. A term it has no data for stays None.
                    volume=volume,
                    source=f"{PROVIDER_NAME} ({database})",
                    data_date=collected if volume is not None else None,
                    cpc=row.cpc if row else None,
                    competition=row.competition if row else None,
                )
            )
        return results
