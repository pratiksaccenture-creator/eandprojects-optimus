"""OpenAI provider — fact extraction, keyword ideation and copy drafting.

Same three jobs and the same prompts as the Claude provider; only the transport differs.
The prompts live in `_prompts.py` so the two implementations cannot drift apart — a rule
tightened for one model applies to both, and a comparison between them is a fair one.

Uses the Responses API with `text_format`, so replies are validated against a Pydantic
schema before reaching the rest of the tool. A malformed reply raises here rather than
becoming a half-empty row downstream.

What this module must never do is produce a figure for search demand. No schema below has
a field for one, the package cannot import the volume providers, and
`tests/test_no_llm_volumes.py` parses this file to prove the identifier never appears.
"""

from __future__ import annotations

import os
from typing import Any

import openai
from pydantic import BaseModel

from app.providers.llm import (
    CopyDraft,
    CopyRequest,
    CopyResult,
    IdeationRequest,
    IdeationResult,
    ModelNotConfiguredError,
    PageFacts,
)
from app.providers.llm._prompts import (
    COPY_SYSTEM,
    FACTS_SYSTEM,
    IDEATION_SYSTEM,
    PROMPT_VERSION,
    CopySchema,
    FactsSchema,
    IdeasSchema,
    build_copy_prompt,
    build_ideation_prompt,
    faq_jsonld,
    normalise_draft,
    read_ideas,
)

DEFAULT_MODEL = "gpt-6-astra"
REQUIRED_ENV = ("OPENAI_API_KEY",)


def missing_env() -> tuple[str, ...]:
    return tuple(name for name in REQUIRED_ENV if not os.environ.get(name))


def model_name() -> str:
    return os.environ.get("OPENAI_MODEL", DEFAULT_MODEL).strip() or DEFAULT_MODEL


def seed_model_name() -> str:
    """The model used to propose keyword seeds, which need not be the one writing copy.

    Measured at 26 seconds a row on the copy model — nearly half the wait on the keywords
    page, for a task that is "list twenty short search phrases for this product". Copy has
    to satisfy a page of editorial rules and is worth the strongest model available;
    seeds are a recall task and a faster model does them just as well.

    Defaults to the copy model so nothing changes silently. Set `OPENAI_SEED_MODEL` to
    trade a little breadth for a much shorter wait.
    """
    return os.environ.get("OPENAI_SEED_MODEL", "").strip() or model_name()


class OpenAIProvider:
    def __init__(self) -> None:
        self._client: openai.AsyncOpenAI | None = None

    @property
    def model(self) -> str:
        return model_name()

    @property
    def prompt_version(self) -> str:
        return PROMPT_VERSION

    @property
    def is_live_model(self) -> bool:
        return True

    def _api(self) -> openai.AsyncOpenAI:
        absent = missing_env()
        if absent:
            raise ModelNotConfiguredError(
                f"OpenAI is not configured. Missing: {', '.join(absent)}. Set "
                "LLM_PROVIDER=fixture to run on deterministic templates instead — the tool "
                "will not substitute template text for model output silently."
            )
        if self._client is None:
            # `base_url` lets this point at Azure OpenAI or an internal gateway, which is
            # what an in-region deployment would need.
            self._client = openai.AsyncOpenAI(
                api_key=os.environ["OPENAI_API_KEY"],
                base_url=os.environ.get("OPENAI_BASE_URL") or None,
            )
        return self._client

    async def _parse(
        self,
        *,
        system: str,
        prompt: str,
        schema: type[BaseModel],
        model: str | None = None,
    ) -> Any:
        chosen = model or self.model
        try:
            response = await self._api().responses.parse(
                model=chosen,
                input=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": prompt},
                ],
                text_format=schema,
            )
        except openai.AuthenticationError as error:
            raise ModelNotConfiguredError(
                f"OpenAI rejected the credentials: {error}"
            ) from error
        except openai.NotFoundError as error:
            raise ModelNotConfiguredError(
                f"Model {chosen!r} is not available to this account: {error}"
            ) from error
        except openai.RateLimitError as error:
            raise ModelNotConfiguredError(
                f"OpenAI rate limit or quota reached: {error}"
            ) from error

        # A refusal arrives as its own output item rather than as the schema, so checking
        # `output_parsed` alone would read as "the model returned nothing".
        for item in getattr(response, "output", None) or []:
            if getattr(item, "type", None) == "refusal":
                raise ModelNotConfiguredError(
                    f"OpenAI declined this request: {getattr(item, 'refusal', '')}"
                )
            for block in getattr(item, "content", None) or []:
                if getattr(block, "type", None) == "refusal":
                    raise ModelNotConfiguredError(
                        f"OpenAI declined this request: {getattr(block, 'refusal', '')}"
                    )

        parsed = response.output_parsed
        if parsed is None:
            raise ModelNotConfiguredError(
                "OpenAI returned no structured output for this request."
            )
        return parsed

    async def extract_facts(
        self, *, product_name: str, url: str, page_title: str, page_text: str
    ) -> PageFacts:
        if not page_text.strip():
            return PageFacts(source_url=url, grounded=False)

        prompt = "\n".join(
            [
                f"Expected product: {product_name or 'unknown'}",
                f"URL: {url}",
                f"Page title: {page_title}",
                "",
                "PAGE TEXT:",
                page_text,
            ]
        )
        parsed: FactsSchema = await self._parse(
            system=FACTS_SYSTEM, prompt=prompt, schema=FactsSchema
        )
        return PageFacts(
            product_name=parsed.product_name.strip(),
            summary=parsed.summary.strip(),
            specifications=tuple(s.strip() for s in parsed.specifications if s.strip()),
            features=tuple(f.strip() for f in parsed.features if f.strip()),
            source_url=url,
            grounded=True,
        )

    async def propose_keywords(self, request: IdeationRequest) -> IdeationResult:
        parsed: IdeasSchema = await self._parse(
            system=IDEATION_SYSTEM,
            prompt=build_ideation_prompt(request),
            schema=IdeasSchema,
            model=seed_model_name(),
        )
        return read_ideas(
            parsed,
            max_terms=request.max_terms,
            grounded_allowed=bool(request.facts and request.facts.grounded),
        )

    async def generate(self, request: CopyRequest) -> CopyResult:
        parsed: CopySchema = await self._parse(
            system=COPY_SYSTEM,
            prompt=build_copy_prompt(request),
            schema=CopySchema,
        )
        draft_fields = normalise_draft(parsed)
        draft = CopyDraft(**draft_fields, jsonld=faq_jsonld(draft_fields["faqs"]))
        return CopyResult(
            draft=draft,
            model=self.model,
            prompt_version=PROMPT_VERSION,
            is_live_model=True,
            keywords_used=tuple(
                t for t in (request.primary_keyword, *request.secondary_keywords) if t
            ),
        )
