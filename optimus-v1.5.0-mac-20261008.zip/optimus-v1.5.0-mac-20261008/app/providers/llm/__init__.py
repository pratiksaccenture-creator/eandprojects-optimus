"""Copy generation provider — brief §1 rule 5.

e& requires a governed, in-region deployment (Azure OpenAI UAE or an internal endpoint).
This package is the single seam for that: implementations are underscore-private and
reached only through `get_llm()`, so repointing is one file plus one environment variable
with **no call-site edits**. `tests/test_provider_boundary.py` enforces that by walking the
import graph.

Two hard rules this boundary carries:

  * A provider here returns COPY. It never returns a search volume. Brief §1 rule 1 —
    volumes come only from `app.providers.keywords`, and `tests/test_no_llm_volumes.py`
    proves no path exists from here to `Keyword.volume`.
  * Nothing returned here is presented as validated. The generation service validates
    every string, and only the validators decide what ships.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

__all__ = [
    "CopyDraft",
    "CopyRequest",
    "CopyResult",
    "IdeationRequest",
    "IdeationResult",
    "KeywordIdea",
    "LLMProvider",
    "ModelNotConfiguredError",
    "PageFacts",
    "ProposedUsp",
    "get_llm",
]


class ModelNotConfiguredError(RuntimeError):
    """A model provider was selected but is not configured.

    Never caught and turned into fixture output — that would present template text as
    model output.
    """


@dataclass(frozen=True, slots=True)
class PageFacts:
    """Facts read off a fetched page.

    Every field is optional and every one is verbatim-or-absent: the extractor is told to
    copy what the page says or leave it out. Nothing here may be inferred, because a
    fabricated specification in indexed copy is the same class of error as a fabricated
    search figure.
    """

    product_name: str = ""
    summary: str = ""
    specifications: tuple[str, ...] = ()
    features: tuple[str, ...] = ()
    source_url: str = ""
    grounded: bool = False  # True only when a real page was read

    @property
    def is_empty(self) -> bool:
        return not (self.summary or self.specifications or self.features)


@dataclass(frozen=True, slots=True)
class KeywordIdea:
    """A proposed search term — a seed, not a finding.

    Carries no figures of any kind. A term from here is only ever a question ("does anyone
    search for this?") which `app.providers.keywords` then answers, both by pricing it and
    by expanding it into terms people demonstrably type.
    `tests/test_no_llm_volumes.py` enforces that this package cannot express a figure.
    """

    term: str
    # One of `policy.KEYWORD_BUCKETS`: brand | product | device | category | usp | smartpay.
    kind: str = "category"
    rationale: str = ""


@dataclass(frozen=True, slots=True)
class ProposedUsp:
    """A selling point the model proposes for a product — a draft, not a fact.

    The content team asked for USPs alongside the keywords so they have something to write
    the copy from. This is the one place in the tool where a model is asked to say what a
    product is good at, and it is therefore the one place where a model could put an
    untrue claim in front of a writer. Three things keep that honest:

      * `grounded` is True only when the text came from a fetched page's facts. Otherwise
        it is the model's own recall and the screen says so.
      * Nothing here reaches copy until a human selects it. Selection is recorded with a
        name and a time, so an approved claim has an owner.
      * `claim` is kept short and whole, so a reviewer reads the actual sentence they are
        approving rather than a fragment that reads differently in context.
    """

    claim: str
    grounded: bool = False


@dataclass(frozen=True, slots=True)
class IdeationResult:
    """What one ideation call returns: seed terms, and selling points.

    Both come back together deliberately. They are the same question asked twice ("what
    is this product and who wants it?"), the model has to work it out either way, and a
    second round trip would add seconds to a page the team already finds slow.
    """

    terms: tuple[KeywordIdea, ...] = ()
    usps: tuple[ProposedUsp, ...] = ()


@dataclass(frozen=True, slots=True)
class IdeationRequest:
    row_index: int
    product_name: str
    category_raw: str
    product_url: str = ""
    page_type: str = "product"
    brand: str = ""
    locale: str = "en"
    geo: str = "AE"
    facts: PageFacts | None = None
    max_terms: int = 20


@dataclass(frozen=True, slots=True)
class CopyRequest:
    row_index: int
    product_name: str
    category_raw: str
    product_url: str = ""
    page_type: str = "product"
    brand: str = ""
    primary_keyword: str | None = None
    secondary_keywords: tuple[str, ...] = ()
    # Third tier, per the SEO Copy Guidelines: "Include the primary keyword and, where
    # possible, secondary and tertiary keywords (where space permits and based on
    # relevance and volume)". Separate from secondary because the instruction differs —
    # secondary should be worked in, tertiary only if there is room left.
    tertiary_keywords: tuple[str, ...] = ()
    locale: str = "en"
    brand_suffix: bool = False
    attempt: int = 1
    # The starting price a human supplied for this row, pre-formatted ("3,499"), or None.
    #
    # The single channel through which a figure may enter copy. A model is never asked to
    # recall or estimate a price; it is handed one that a person typed, or none at all. The
    # validator forgives exactly this string, so prompt and rule cannot disagree.
    price: str | None = None
    # Validator codes from the previous attempt, fed back so the next attempt can respond
    # to the actual failure instead of retrying blind.
    feedback: tuple[str, ...] = ()
    # Which phrasing to use. Rotated when a human asks for a different option, so "refresh"
    # offers an alternative rather than just a shorter version of the same sentence.
    variant: int = 0
    # How hard to compress. Driven by length failures, never by the attempt number alone.
    shrink: int = 0
    # Facts read off the real page, when one was fetched. Absent means the copy must stay
    # general rather than invent a specification.
    facts: PageFacts | None = None
    # Selling points a human ticked on the keywords page. Treated by the prompt as claims
    # it MAY state — the same standing as `facts` — because a person took responsibility
    # for each one. An unticked USP is not here, and the model never sees it.
    usps: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class CopyDraft:
    meta_title: str = ""
    meta_description: str = ""
    h1: str = ""
    answer_block: str = ""
    benefits: tuple[str, ...] = ()
    faqs: tuple[tuple[str, str], ...] = ()
    app_headline: str = ""
    app_subhead: str = ""
    app_cta: str = ""
    geo_prompts: tuple[str, ...] = ()
    jsonld: str = ""

    def tier1(self) -> dict[str, str]:
        return {
            "meta_title_en": self.meta_title,
            "meta_description_en": self.meta_description,
        }


@dataclass(frozen=True, slots=True)
class CopyResult:
    draft: CopyDraft
    model: str
    prompt_version: str
    is_live_model: bool
    keywords_used: tuple[str, ...] = field(default=())


@runtime_checkable
class LLMProvider(Protocol):
    @property
    def model(self) -> str: ...

    @property
    def prompt_version(self) -> str: ...

    @property
    def is_live_model(self) -> bool:
        """False for deterministic template output. The UI must label it as such."""
        ...

    async def generate(self, request: CopyRequest) -> CopyResult: ...

    async def extract_facts(
        self, *, product_name: str, url: str, page_title: str, page_text: str
    ) -> PageFacts:
        """Read facts off fetched page text. Returns empty facts when there is nothing."""
        ...

    async def propose_keywords(self, request: IdeationRequest) -> IdeationResult:
        """Propose candidate search terms and selling points.

        Never returns figures of any kind — not a volume, not a price. The terms are
        questions for the volume provider to answer; the USPs are drafts for a human to
        approve.
        """
        ...


def get_llm(name: str | None = None) -> LLMProvider:
    """Resolve the provider named by `LLM_PROVIDER`.

    With nothing configured this RAISES, matching the volume provider. One rule for both
    avoids the confusing half-state where the numbers are real and the copy is templated.
    DECISIONS.md §29.
    """
    from app.config import UNCONFIGURED, settings

    selected = (name or settings().llm_provider or UNCONFIGURED).strip().lower()

    if selected == UNCONFIGURED:
        raise ModelNotConfiguredError(
            "No copy model is configured. Add OPENAI_API_KEY to .env and restart. "
            "To run a demo with no network, set LLM_PROVIDER=fixture — the copy is then "
            "written from templates and every screen says so."
        )

    if selected == "fixture":
        from app.providers.llm._fixture import FixtureCopyProvider

        return FixtureCopyProvider()
    if selected in {"openai", "gpt"}:
        from app.providers.llm._openai import OpenAIProvider

        return OpenAIProvider()
    if selected in {"anthropic", "claude"}:
        from app.providers.llm._anthropic import ClaudeProvider

        return ClaudeProvider()
    if selected in {"azure", "azure_openai", "azure-openai"}:
        from app.providers.llm._azure import AzureOpenAIProvider

        return AzureOpenAIProvider()

    raise ModelNotConfiguredError(
        f"Unknown LLM_PROVIDER {selected!r}. "
        "Expected 'fixture', 'openai', 'anthropic' or 'azure'."
    )
