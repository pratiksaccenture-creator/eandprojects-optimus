"""Azure OpenAI (UAE region) provider — stub.

e& requires a governed, in-region deployment. This is the intended production target and
the reason the provider boundary exists: making it live is this file plus `LLM_PROVIDER=azure`,
with no changes anywhere else.

It raises `ModelNotConfiguredError` when unconfigured and never falls back to the template
provider, because template text presented as model output would violate brief §0.
"""

from __future__ import annotations

import os

from app.providers.llm import (
    CopyRequest,
    CopyResult,
    IdeationRequest,
    IdeationResult,
    ModelNotConfiguredError,
    PageFacts,
)

PROMPT_VERSION = "v1"

REQUIRED_ENV = (
    "AZURE_OPENAI_ENDPOINT",     # e.g. https://<resource>.openai.azure.com
    "AZURE_OPENAI_API_KEY",
    "AZURE_OPENAI_DEPLOYMENT",   # the in-region deployment name
)

API_VERSION = "2024-10-21"

# The governance requirement is regional: the resource must be provisioned in a UAE region
# so prompts and completions do not leave the jurisdiction.
ALLOWED_REGIONS = ("uaenorth", "uaecentral")

SYSTEM_PROMPT = """You write SEO and AEO copy for e& (Etisalat) in the United Arab Emirates.

Hard rules:
- Never state a price, tariff, instalment, discount, stock level or availability promise.
- Never invent a specification, capacity, measurement or search volume.
- Never use an unproven superlative.
- Write only about the product named in the request.
- Respect the character limit given for each field. Do not exceed it.

You will be told which validation rules the previous attempt failed. Fix those specific
failures without introducing new ones."""


def missing_env() -> tuple[str, ...]:
    return tuple(name for name in REQUIRED_ENV if not os.environ.get(name))


def build_messages(request: CopyRequest) -> list[dict[str, str]]:
    """The chat messages this provider would send. Pure, so it is testable without network."""
    keywords = ", ".join(t for t in (request.primary_keyword, *request.secondary_keywords) if t)
    user = [
        f"Product: {request.product_name}",
        f"Category: {request.category_raw}",
        f"Page type: {request.page_type}",
        f"URL: {request.product_url}",
        f"Approved keywords (use the first as primary): {keywords or 'none verified'}",
        f"Locale: {request.locale}",
        f"Append the brand suffix ' | e&': {'yes' if request.brand_suffix else 'no'}",
        "",
        "Produce a meta title under 60 characters and a meta description under 160 "
        "characters.",
    ]
    if request.feedback:
        user += [
            "",
            f"Attempt {request.attempt}. The previous attempt failed these validators:",
            *(f"- {code}" for code in request.feedback),
        ]
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": "\n".join(user)},
    ]


class AzureOpenAIProvider:
    async def extract_facts(
        self, *, product_name: str, url: str, page_title: str, page_text: str
    ) -> PageFacts:
        raise ModelNotConfiguredError(
            "Azure OpenAI has no HTTP implementation in this prototype."
        )

    async def propose_keywords(self, request: IdeationRequest) -> IdeationResult:
        raise ModelNotConfiguredError(
            "Azure OpenAI has no HTTP implementation in this prototype."
        )

    @property
    def model(self) -> str:
        return os.environ.get("AZURE_OPENAI_DEPLOYMENT", "azure-openai-unconfigured")

    @property
    def prompt_version(self) -> str:
        return PROMPT_VERSION

    @property
    def is_live_model(self) -> bool:
        return True

    async def generate(self, request: CopyRequest) -> CopyResult:
        absent = missing_env()
        if absent:
            raise ModelNotConfiguredError(
                f"Azure OpenAI is not configured. Missing: {', '.join(absent)}. "
                "Set LLM_PROVIDER=fixture to run on deterministic templates instead — "
                "the tool will not substitute template text for model output silently."
            )
        endpoint = os.environ["AZURE_OPENAI_ENDPOINT"]
        if not any(region in endpoint for region in ALLOWED_REGIONS):
            raise ModelNotConfiguredError(
                f"Endpoint {endpoint!r} is not in a UAE region "
                f"({', '.join(ALLOWED_REGIONS)}). e& requires an in-region deployment; "
                "refusing to send prompts out of jurisdiction."
            )
        raise ModelNotConfiguredError(
            "Azure OpenAI has configuration but no HTTP implementation in this prototype. "
            "`build_messages` is the request shape; wiring the call is the remaining work."
        )
