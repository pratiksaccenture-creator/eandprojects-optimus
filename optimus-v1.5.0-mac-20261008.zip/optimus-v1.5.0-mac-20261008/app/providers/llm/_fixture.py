"""Deterministic copy provider — the default.

**This is a template engine, not a model.** It reports `is_live_model = False` and a model
name of `fixture-templates`, and the UI labels every string it produces accordingly. Brief
§0 forbids presenting mock output as a live result, so nothing here pretends otherwise.

It is deterministic: the same row and attempt number always produce the same text, which is
what makes the export byte-identical guarantee in §11 achievable.

Attempts get progressively shorter rather than randomly different, and they respond to the
actual validator codes fed back from the previous attempt. That means the regeneration loop
in brief §6 does real work: the long variant names in this batch — `Apple Watch Series 12
GPS + Cellular Aluminium` is 46 characters on its own — genuinely cannot fit a 60-character
title with any qualifier attached, so those rows genuinely shorten across attempts and some
genuinely reach the exception queue. No failure is manufactured to demonstrate the feature.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

from app.lib.normalise import normalise_term
from app.lib.policy import (
    BRAND_SUFFIX,
    CURRENCY_PREFIX,
    PRICE_SENTENCE_TEMPLATE,
    SMARTPAY_SENTENCE_TEMPLATE,
    SMARTPAY_TERM,
)
from app.lib.surfaces import DESCRIPTION_DESKTOP, TITLE_DESKTOP
from app.lib.terms import display_name

# Above this, a product name cannot share a 60-character title with a benefit clause, so
# the attributes come out. Set below 60 on purpose: a title that is only the product name
# is technically valid and editorially useless.
TITLE_NAME_BUDGET = 42

DESCRIPTION_LIMIT = DESCRIPTION_DESKTOP.char_hard_limit
TITLE_LIMIT = TITLE_DESKTOP.char_hard_limit
from app.providers.llm import (
    CopyDraft,
    CopyRequest,
    CopyResult,
    IdeationRequest,
    IdeationResult,
    PageFacts,
    ProposedUsp,
)

MODEL_NAME = "fixture-templates"
PROMPT_VERSION = "v1"


@dataclass(frozen=True, slots=True)
class Angle:
    """Ways of describing one product family.

    `benefits` and `features` hold several phrasings rather than one, so asking for a
    different option genuinely produces different copy instead of the same sentence with
    words removed.
    """

    benefits: tuple[str, ...]
    short_benefit: str
    features: tuple[str, ...]
    audience: str

    def benefit(self, variant: int) -> str:
        return self.benefits[variant % len(self.benefits)]

    def feature(self, variant: int) -> str:
        return self.features[variant % len(self.features)]


# Deliberately free of price, tariff, stock and availability language, and free of unproven
# superlatives — the validators would reject those, and generating text designed to fail
# would waste attempts.
FAMILY_ANGLES: dict[str, Angle] = {
    "watch": Angle(
        benefits=("Health & GPS tracking", "Fitness & heart rate", "GPS, sleep & workouts"),
        short_benefit="Health tracking",
        features=(
            "Track workouts, heart rate and sleep, with GPS built in",
            "Built-in GPS, heart-rate sensing and sleep tracking",
            "Heart rate, sleep stages and route mapping on your wrist",
        ),
        audience="everyday training and daily health tracking",
    ),
    "iphone": Angle(
        benefits=("Camera & battery life", "Pro camera system", "Display, camera & chip"),
        short_benefit="Camera & battery",
        features=(
            "A pro camera system, all-day battery and a bright display",
            "A bright display, all-day battery and a fast chip",
            "Pro cameras, a fast chip and a display built for daylight",
        ),
        audience="photography and everyday performance",
    ),
    "airpods": Angle(
        benefits=("Noise cancellation", "ANC & spatial audio", "Wireless earbuds"),
        short_benefit="Wireless earbuds",
        features=(
            "Active noise cancellation, spatial audio and a wireless charging case",
            "Spatial audio, adaptive noise control and a charging case",
            "Noise cancellation, sweat resistance and all-day listening",
        ),
        audience="commuting, calls and everyday listening",
    ),
    "ipad": Angle(
        benefits=("Display & performance", "Screen & battery", "Tablet performance"),
        short_benefit="Tablets",
        features=(
            "A large display, long battery life and accessory support",
            "A bright screen, long battery life and keyboard support",
            "A large screen, pencil support and all-day battery",
        ),
        audience="work, study and entertainment",
    ),
}

SMART_HOME_ANGLE = Angle(
    benefits=("Smart home control", "Lights, locks & climate", "Home automation"),
    short_benefit="Smart home",
    features=(
        "Control lighting, climate, locks and sensors from a single app",
        "Set routines for lighting, climate and security in one place",
        "Manage locks, sensors, lights and climate from your phone",
    ),
    audience="a connected home",
)

# Additional families, added when the keyword-research template arrived carrying products
# the original Apple-and-smart-home batch never had. Ordered checks below, so the more
# specific word wins.
EXTRA_ANGLES: tuple[tuple[tuple[str, ...], Angle], ...] = (
    (
        ("playstation", "console", "xbox", "nintendo"),
        Angle(
            benefits=("Next-gen gaming", "Console gaming", "Play at home"),
            short_benefit="Console gaming",
            features=(
                "Fast load times, high frame rates and a library of titles",
                "High frame rates, quick loading and online multiplayer",
                "A games library, online play and quick resume",
            ),
            audience="players at home",
        ),
    ),
    (
        ("monitor", "display", "screen"),
        Angle(
            benefits=("High refresh rate", "Gaming display", "Sharp, fast visuals"),
            short_benefit="Gaming display",
            features=(
                "A high refresh rate, low response time and wide viewing angles",
                "Fast response, high refresh and adjustable positioning",
                "Sharp detail, a fast panel and flexible connectivity",
            ),
            audience="gaming and everyday desk work",
        ),
    ),
    (
        ("vacuum", "robot", "cleaner"),
        Angle(
            benefits=("Automated cleaning", "Hands-free cleaning", "Cleans on schedule"),
            short_benefit="Robot cleaning",
            features=(
                "Mapped cleaning routes, scheduling and app control",
                "Scheduled cleaning, obstacle avoidance and app control",
                "Room mapping, scheduling and self-emptying",
            ),
            audience="busy households",
        ),
    ),
    (
        ("doorbell", "camera", "security", "lock", "sensor"),
        Angle(
            benefits=("Home security", "See who's at the door", "Monitor your home"),
            short_benefit="Home security",
            features=(
                "Video at the door, motion alerts and two-way talk",
                "Motion alerts, night vision and two-way audio",
                "Live video, alerts on your phone and recorded clips",
            ),
            audience="keeping an eye on the front door",
        ),
    ),
    (
        ("tab", "tablet"),
        Angle(
            benefits=("Display & performance", "Screen & battery", "Tablet performance"),
            short_benefit="Tablets",
            features=(
                "A large display, long battery life and accessory support",
                "A bright screen, all-day battery and keyboard support",
                "A large screen, stylus support and long battery life",
            ),
            audience="work, study and entertainment",
        ),
    ),
    (
        ("phone", "razr", "redmi", "pixel", "galaxy"),
        Angle(
            benefits=("Camera & battery life", "Display & performance", "Camera & display"),
            short_benefit="Camera & battery",
            features=(
                "A capable camera system, all-day battery and a bright display",
                "A bright display, fast charging and all-day battery",
                "A multi-lens camera, a fast chip and a large display",
            ),
            audience="photography and everyday performance",
        ),
    ),
)

# The fallback, and it deliberately claims NOTHING about the product.
#
# It used to carry smart-home features, which was invisible while every row in the batch
# was an Apple device or a smart-home page and actively wrong the moment the template
# arrived: a PlayStation 5 was described as controlling your lighting and climate. Copy
# that asserts a feature the tool has no evidence for is the same defect as an invented
# specification, and the fallback is exactly where it is least likely to be noticed.
DEFAULT_ANGLE = Angle(
    benefits=("Available at e&", "Order online", "Shop at e&"),
    short_benefit="Available at e&",
    features=(
        "Compare models and check the full specification before you buy",
        "See the range and order with delivery",
        "Browse the options and choose the one that suits you",
    ),
    audience="customers",
)


def _angle(request: CopyRequest) -> Angle:
    haystack = f"{request.product_name} {request.category_raw}".casefold()
    for family, angle in FAMILY_ANGLES.items():
        if family in haystack:
            return angle
    # Whole words. A prefix test gave a Ring video doorbell the gaming-monitor angle,
    # because its category is "Smart Home & Monitorting" and "monitor" is a prefix of the
    # source's typo.
    padded = f" {haystack} "
    for words, angle in EXTRA_ANGLES:
        if any(f" {word} " in padded for word in words):
            return angle
    if "smart" in haystack or "home" in haystack:
        return SMART_HOME_ANGLE
    return DEFAULT_ANGLE


def _shrink_level(request: CopyRequest) -> int:
    """How much to compress.

    Driven by length failures, never by the attempt number on its own. That distinction
    matters for the refresh control: asking for another option must not quietly erode the
    copy, while a genuine length failure must still shorten it.
    """
    if request.shrink:
        return request.shrink
    too_long = bool(set(request.feedback) & {"CHAR_LIMIT", "PIXEL_LIMIT"})
    return max(request.attempt - 1, 1) if too_long else 0


def _display_name(request: CopyRequest, level: int) -> str:
    """Progressively shorter forms of the product name.

    Only trailing material and connectivity qualifiers are dropped, and only when a
    shorter name is needed to fit. Nothing is invented and no generation number is ever
    removed, because dropping it would create exactly the stale-generation defect the
    validators exist to catch.
    """
    name = request.product_name or request.category_raw

    # A name carrying pipe-separated variant detail cannot fit a 60-character title at
    # any compression level — the template's "Apple Watch Series 12 GPS + Cellular
    # Ceramic | Pearl White | Case Size 42MM" is 75 characters before a benefit clause is
    # added. Drop the attributes people do not search for, using the SAME rule the live
    # prompt states and the keyword pipeline applies, so offline and live agree about
    # which words matter.
    #
    # Pipes go regardless of length: the title joins its own parts with " | ", so a name
    # like "Apple iPhone 17 | 512GB" produced "Apple iPhone 17 | 512GB | Camera & battery
    # | e&", where the reader cannot tell the product name from the benefit clause.
    if len(name) > TITLE_NAME_BUDGET or "|" in name:
        name = display_name(name)

    if level <= 0:
        return name

    # Case, material and finish are NOT droppable. They are the only thing distinguishing
    # the three Series 12 Cellular variants in this batch from each other, so dropping them
    # to save characters produces three identical titles — which the uniqueness validator
    # would then correctly reject. Only genuinely redundant phrasing is removed.
    droppable = ("with Wireless Charging Case",)
    shortened = name
    for token in droppable:
        if level >= 1 and shortened.endswith(f" {token}"):
            shortened = shortened[: -len(token) - 1].rstrip()
    if level >= 1:
        # "GPS + Cellular" implies GPS, so the compressed form loses no information.
        # Both spellings, because `display_name` may already have removed the "+".
        shortened = shortened.replace(" GPS + Cellular", " Cellular")
        shortened = shortened.replace(" GPS Cellular", " Cellular")
    if level >= 2:
        # Last resort, and still information-preserving: a Cellular watch has GPS.
        shortened = shortened.replace(" GPS ", " ")
    return " ".join(shortened.split()).strip(" +-") or name


def _lead_in(name: str, primary: str | None) -> str:
    """Prefix the product name with the words the primary keyword needs, if any.

    The primary keyword is chosen from measured demand, so it does not always match how
    the row is named: a row called "AirPods 5" can have "apple airpods" as its only
    measured relevant term. Writing the title from the name alone then fails
    PRIMARY_KEYWORD_MISSING on every attempt and the row never ships.

    Deliberately narrow. The prefix is added only when the rest of the keyword already
    begins the name, so "apple airpods" + "AirPods 5" gives "Apple AirPods 5", while
    "smart watch" + "Apple Watch Ultra 4" is left alone rather than becoming "Smart Apple
    Watch Ultra 4". Where it cannot help, it does nothing and the validator reports the
    mismatch honestly.
    """
    if not primary:
        return name
    folded_name = normalise_term(name)
    folded_primary = normalise_term(primary)
    if not folded_primary or folded_primary in folded_name:
        return name

    primary_words = folded_primary.split()
    name_words = folded_name.split()
    for cut in range(1, len(primary_words)):
        tail = primary_words[cut:]
        if name_words[: len(tail)] == tail:
            return " ".join(w.capitalize() for w in primary_words[:cut]) + " " + name
    return name


def _title(request: CopyRequest, angle: Angle) -> str:
    """Build a title. `variant` changes the angle; `shrink` compresses it."""
    shrink = _shrink_level(request)
    name = _lead_in(_display_name(request, level=max(shrink - 1, 0)), request.primary_keyword)

    if shrink == 0:
        parts = [name, angle.benefit(request.variant)]
    elif shrink == 1:
        parts = [name, angle.short_benefit]
    else:
        parts = [name]

    title = " | ".join(p for p in parts if p)

    # Leave room for the brand suffix even when this attempt is not adding it.
    #
    # The suffix decision is all-or-nothing across the batch, so a single title that
    # cannot fit " | e&" switches branding off for all 21 rows. That happened here: one
    # Apple Watch row landed at 64 characters with the suffix and the whole batch lost
    # its brand mark, for a reason no one reading the output would guess. Trading a
    # longer benefit clause for a consistent brand mark is the better bargain, and a
    # shorter clause is still a real clause.
    if not request.brand_suffix and len(title) + len(BRAND_SUFFIX) > TITLE_LIMIT:
        title = " | ".join(p for p in (name, angle.short_benefit) if p)
        if len(title) + len(BRAND_SUFFIX) > TITLE_LIMIT:
            title = name

    wants_suffix = request.brand_suffix and "BRAND_SUFFIX_UNEXPECTED" not in set(request.feedback)
    if wants_suffix and not title.endswith(BRAND_SUFFIX.strip()):
        title = f"{title}{BRAND_SUFFIX}"
    return title.strip()


def _second_sentence(request: CopyRequest, name: str, room: int) -> str:
    """The guidelines' second sentence: SmartPay always, the price only if one was given.

    Three forms, tried longest first, because the guideline gives an exact formula but the
    160-character ceiling is a hard rule and some product names are 50 characters on their
    own. The formula is the target; the shorter forms are what honesty under a hard limit
    looks like. SmartPay survives every form — it is the part that is unconditional.

    `request.price` is the only figure that can appear, and it arrives already formatted.
    Nothing here computes, rounds or infers a price.
    """
    if request.price:
        candidates = [
            PRICE_SENTENCE_TEMPLATE.format(product=name, price=request.price),
            f"Shop from {CURRENCY_PREFIX} {request.price} via {SMARTPAY_TERM} with e&.",
            f"From {CURRENCY_PREFIX} {request.price} via {SMARTPAY_TERM}.",
        ]
    else:
        candidates = [
            SMARTPAY_SENTENCE_TEMPLATE.format(product=name),
            f"Shop via {SMARTPAY_TERM} with e&.",
            f"Buy with {SMARTPAY_TERM}.",
        ]
    for candidate in candidates:
        if len(candidate) <= room:
            return candidate
    return candidates[-1]


def _description(request: CopyRequest, angle: Angle) -> str:
    """Guideline shape: benefit-led opener, then price and SmartPay in the second sentence."""
    shrink = _shrink_level(request)
    name = _lead_in(_display_name(request, level=max(shrink - 1, 0)), request.primary_keyword)
    feature = angle.feature(request.variant)

    if shrink == 0:
        opener = f"Explore the {name} at e&. {feature}."
    elif shrink == 1:
        opener = f"Explore the {name}. {angle.short_benefit}."
    else:
        opener = f"{name} at e&."

    second = _second_sentence(request, name, DESCRIPTION_LIMIT - len(opener) - 1)
    return " ".join(f"{opener} {second}".split())


def _answer_block(request: CopyRequest, angle: Angle) -> str:
    """A 40-60 word extractable answer for the top of the page, per brief §7."""
    name = request.product_name or request.category_raw
    text = (
        f"The {name} is available from e&. "
        f"{angle.feature(request.variant)}. It suits {angle.audience}. "
        f"You can compare models, check the specification and order online from e&, "
        f"with delivery available and support from e& stores."
    )
    return " ".join(text.split())


def _benefits(angle: Angle, variant: int) -> tuple[str, ...]:
    parts = [p.strip() for p in angle.feature(variant).replace(" and ", ", ").split(",")]
    parts = [p for p in parts if p][:3]
    while len(parts) < 3:
        parts.append(angle.short_benefit)
    return tuple(p[0].upper() + p[1:] for p in parts[:3])


def _faqs(request: CopyRequest, angle: Angle) -> tuple[tuple[str, str], ...]:
    name = request.product_name or request.category_raw
    feature = angle.feature(request.variant)
    return (
        (
            f"What is the {name}?",
            f"The {name} is available from e&. {feature}.",
        ),
        (
            f"Can I order the {name} from e&?",
            f"Yes. You can compare models and order the {name} online from e&, with "
            "delivery from e&.",
        ),
        (
            f"Is the {name} suitable for {angle.audience}?",
            f"Yes. It is designed for {angle.audience}.",
        ),
    )


def _geo_prompts(request: CopyRequest, angle: Angle) -> tuple[str, ...]:
    """Tracked prompts an answer engine might be asked about this page, per brief §7."""
    name = request.product_name or request.category_raw
    return (
        f"What is the {name}?",
        f"Where can I buy the {name}?",
        f"Is the {name} available from e&?",
        f"What are the main features of the {name}?",
        f"Is the {name} good for {angle.audience}?",
        f"How do I order the {name} online in Dubai?",
        f"Does e& sell the {name}?",
        f"What should I know before choosing the {name}?",
        f"How does the {name} compare with other models?",
        f"Which {angle.short_benefit.lower()} options does e& offer?",
    )


def _jsonld(faqs: tuple[tuple[str, str], ...]) -> str:
    """FAQPage JSON-LD. Serialised with sorted keys so the output is byte-stable, and
    validated as parseable by `tests/test_generation.py` per brief §7."""
    payload = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": question,
                "acceptedAnswer": {"@type": "Answer", "text": answer},
            }
            for question, answer in faqs
        ],
    }
    return json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)


class FixtureCopyProvider:
    async def extract_facts(
        self, *, product_name: str, url: str, page_title: str, page_text: str
    ) -> PageFacts:
        """No facts. Fixture mode reads no pages, and inventing specifications to fill the
        gap is exactly what the templates exist to avoid."""
        return PageFacts(source_url=url, grounded=False)

    async def propose_keywords(self, request: IdeationRequest) -> IdeationResult:
        """No seed terms, and only USPs that are true by construction.

        No terms, so the caller falls back to the deterministic derivation in
        `app.services.candidates` — returning invented terms here would make fixture mode
        look like ideation it is not doing.

        The USPs are a different case. Returning none would leave the feature invisible
        offline and untestable, but a template cannot know what a product is good at, so
        every claim below is one that holds for anything e& sells: where it is sold, how
        it can be paid for, who makes it, what it is listed under. None asserts a
        property of the product itself. `grounded=False` on all of them, and the page
        labels the whole row as sample data.
        """
        usps = [
            ProposedUsp(claim="Available from e&"),
            ProposedUsp(claim=f"Pay over time with {SMARTPAY_TERM}"),
        ]
        if request.brand:
            usps.append(ProposedUsp(claim=f"Genuine {request.brand} product"))
        if request.category_raw:
            usps.append(ProposedUsp(claim=f"Part of the {request.category_raw} range"))
        return IdeationResult(terms=(), usps=tuple(usps))

    @property
    def model(self) -> str:
        return MODEL_NAME

    @property
    def prompt_version(self) -> str:
        return PROMPT_VERSION

    @property
    def is_live_model(self) -> bool:
        return False

    async def generate(self, request: CopyRequest) -> CopyResult:
        angle = _angle(request)
        name = request.product_name or request.category_raw
        faqs = _faqs(request, angle)

        draft = CopyDraft(
            meta_title=_title(request, angle),
            meta_description=_description(request, angle),
            h1=f"{name}",
            answer_block=_answer_block(request, angle),
            benefits=_benefits(angle, request.variant),
            faqs=faqs,
            app_headline=f"{angle.short_benefit} from e&",
            app_subhead=f"{angle.feature(request.variant)}."[:90],
            app_cta="See models",
            geo_prompts=_geo_prompts(request, angle),
            jsonld=_jsonld(faqs),
        )
        used = tuple(
            t for t in (request.primary_keyword, *request.secondary_keywords) if t
        )
        return CopyResult(
            draft=draft,
            model=MODEL_NAME,
            prompt_version=PROMPT_VERSION,
            is_live_model=False,
            keywords_used=used,
        )
