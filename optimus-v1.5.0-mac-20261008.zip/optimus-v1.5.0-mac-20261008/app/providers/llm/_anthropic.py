"""Claude provider — fact extraction, keyword ideation and copy drafting.

Same three jobs and the same prompts as the OpenAI provider; only the transport differs.
The prompts and schemas live in `_prompts.py` so the two cannot drift apart.

Uses structured output (`messages.parse` with a Pydantic schema) so a reply is validated
before it reaches the rest of the tool — a malformed response raises here rather than
becoming a half-empty row downstream.

Prompt caching: the system prompt is the stable prefix and is marked cacheable. It is
identical for every row in a batch, so rows 2..21 read it from cache.

What this module must never do is produce a figure for search demand. No schema has a field
for one, the package cannot import the volume providers, and `tests/test_no_llm_volumes.py`
parses this file to prove the identifier never appears.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import anthropic
from pydantic import BaseModel

from app.providers.llm import (
    CopyDraft,
    CopyRequest,
    CopyResult,
    IdeationRequest,
    IdeationResult,
    ModelNotConfiguredError,
    PageFacts,
)
from app.providers.llm._prompts import (
    COPY_SYSTEM,
    FACTS_SYSTEM,
    IDEATION_SYSTEM,
    PROMPT_VERSION,
    CopySchema,
    FactsSchema,
    IdeasSchema,
    build_copy_prompt,
    build_ideation_prompt,
    faq_jsonld,
    normalise_draft,
    read_ideas,
)

DEFAULT_MODEL = "claude-opus-5"
MAX_TOKENS = 16000
REQUIRED_ENV = ("ANTHROPIC_API_KEY",)


def missing_env() -> tuple[str, ...]:
    """Empty when the SDK can find a credential.

    An unset `ANTHROPIC_API_KEY` does not mean there is none — the SDK also reads
    `ANTHROPIC_AUTH_TOKEN` and an `ant auth login` profile — so this reports a problem only
    when none of those is present.
    """
    if os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN"):
        return ()
    if (Path.home() / ".config" / "anthropic").exists():
        return ()
    return REQUIRED_ENV


def model_name() -> str:
    return os.environ.get("ANTHROPIC_MODEL", DEFAULT_MODEL).strip() or DEFAULT_MODEL


class ClaudeProvider:
    def __init__(self) -> None:
        self._client: anthropic.AsyncAnthropic | None = None

    @property
    def model(self) -> str:
        return model_name()

    @property
    def prompt_version(self) -> str:
        return PROMPT_VERSION

    @property
    def is_live_model(self) -> bool:
        return True

    def _api(self) -> anthropic.AsyncAnthropic:
        absent = missing_env()
        if absent:
            raise ModelNotConfiguredError(
                f"Claude is not configured. Missing: {', '.join(absent)}. Set "
                "LLM_PROVIDER=fixture to run on deterministic templates instead — the tool "
                "will not substitute template text for model output silently."
            )
        if self._client is None:
            self._client = anthropic.AsyncAnthropic()
        return self._client

    async def _parse(self, *, system: str, prompt: str, schema: type[BaseModel]) -> Any:
        try:
            response = await self._api().messages.parse(
                model=self.model,
                max_tokens=MAX_TOKENS,
                thinking={"type": "adaptive"},
                system=[
                    {
                        "type": "text",
                        "text": system,
                        "cache_control": {"type": "ephemeral"},
                    }
                ],
                messages=[{"role": "user", "content": prompt}],
                output_format=schema,
            )
        except anthropic.AuthenticationError as error:
            raise ModelNotConfiguredError(
                f"Claude rejected the credentials: {error}"
            ) from error
        except anthropic.NotFoundError as error:
            raise ModelNotConfiguredError(
                f"Model {self.model!r} is not available to this account: {error}"
            ) from error
        except anthropic.RateLimitError as error:
            raise ModelNotConfiguredError(
                f"Claude rate limit reached: {error}"
            ) from error

        if response.stop_reason == "refusal":
            detail = getattr(response.stop_details, "explanation", "") or ""
            raise ModelNotConfiguredError(f"Claude declined this request. {detail}".strip())
        if response.parsed_output is None:
            raise ModelNotConfiguredError(
                "Claude returned no structured output for this request."
            )
        return response.parsed_output

    async def extract_facts(
        self, *, product_name: str, url: str, page_title: str, page_text: str
    ) -> PageFacts:
        if not page_text.strip():
            return PageFacts(source_url=url, grounded=False)

        prompt = "\n".join(
            [
                f"Expected product: {product_name or 'unknown'}",
                f"URL: {url}",
                f"Page title: {page_title}",
                "",
                "PAGE TEXT:",
                page_text,
            ]
        )
        parsed: FactsSchema = await self._parse(
            system=FACTS_SYSTEM, prompt=prompt, schema=FactsSchema
        )
        return PageFacts(
            product_name=parsed.product_name.strip(),
            summary=parsed.summary.strip(),
            specifications=tuple(s.strip() for s in parsed.specifications if s.strip()),
            features=tuple(f.strip() for f in parsed.features if f.strip()),
            source_url=url,
            grounded=True,
        )

    async def propose_keywords(self, request: IdeationRequest) -> IdeationResult:
        parsed: IdeasSchema = await self._parse(
            system=IDEATION_SYSTEM,
            prompt=build_ideation_prompt(request),
            schema=IdeasSchema,
        )
        return read_ideas(
            parsed,
            max_terms=request.max_terms,
            grounded_allowed=bool(request.facts and request.facts.grounded),
        )

    async def generate(self, request: CopyRequest) -> CopyResult:
        parsed: CopySchema = await self._parse(
            system=COPY_SYSTEM,
            prompt=build_copy_prompt(request),
            schema=CopySchema,
        )
        draft_fields = normalise_draft(parsed)
        draft = CopyDraft(**draft_fields, jsonld=faq_jsonld(draft_fields["faqs"]))
        return CopyResult(
            draft=draft,
            model=self.model,
            prompt_version=PROMPT_VERSION,
            is_live_model=True,
            keywords_used=tuple(
                t for t in (request.primary_keyword, *request.secondary_keywords) if t
            ),
        )
