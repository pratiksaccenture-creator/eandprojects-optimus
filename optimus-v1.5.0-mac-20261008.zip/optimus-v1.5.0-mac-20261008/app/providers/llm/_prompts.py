"""Prompts and response schemas, shared by every live model provider.

Deliberately in one file. The rules below are editorial policy, not transport detail — if
Claude and OpenAI carried their own copies they would drift the first time one was
tightened, and a comparison between the two models would stop being a fair test of the
models. Swapping provider changes who answers, never what was asked.

Nothing here defines a field for search demand. A model is never given a slot to put a
figure in, which is what makes `tests/test_no_llm_volumes.py` a structural guarantee rather
than a style rule.
"""

from __future__ import annotations

import json
from typing import Any, Literal

from pydantic import BaseModel, Field

from app.lib.policy import (
    BRAND_SUFFIX,
    CURRENCY_PREFIX,
    KEYWORD_BUCKETS,
    MAX_USP_CHARS,
    MAX_USPS,
    SMARTPAY_TERM,
)
from app.providers.llm import (
    CopyRequest,
    IdeationRequest,
    IdeationResult,
    KeywordIdea,
    PageFacts,
    ProposedUsp,
)

# Bumped from shared-v1 when the SEO Copy Guidelines landed. Every stored attempt records
# the version that produced it, so copy written under the old rules stays identifiable.
PROMPT_VERSION = "guidelines-v2"


# ---------------------------------------------------------------- schemas


class FactsSchema(BaseModel):
    product_name: str = Field(default="", description="Product name exactly as the page states it.")
    summary: str = Field(default="", description="One neutral sentence describing what this page is about.")
    specifications: list[str] = Field(
        default_factory=list,
        description=(
            "Specifications copied VERBATIM from the page, e.g. '6.3-inch display'. "
            "Include an item only if the page states it. Never infer or complete a value."
        ),
    )
    features: list[str] = Field(
        default_factory=list,
        description="Short feature phrases stated on the page, e.g. 'water resistant'.",
    )


class IdeaSchema(BaseModel):
    term: str = Field(description="A search phrase, lowercase, no punctuation.")
    kind: Literal["brand", "product", "device", "category", "usp", "smartpay"]
    rationale: str = Field(default="", description="Why someone would search this. One short clause.")


class UspSchema(BaseModel):
    claim: str = Field(
        description=(
            "One selling point, as a short phrase a writer could lift straight into copy. "
            "No figures, no prices, no superlatives."
        )
    )
    from_page: bool = Field(
        default=False,
        description=(
            "True only if this is stated in the FACTS section. False if it is your own "
            "knowledge of the product."
        ),
    )


class IdeasSchema(BaseModel):
    terms: list[IdeaSchema]
    usps: list[UspSchema] = Field(
        default_factory=list,
        description="Selling points for this product, for a human to review.",
    )


class CopySchema(BaseModel):
    meta_title: str = Field(description="Meta title. 60 characters or fewer.")
    meta_description: str = Field(description="Meta description. 160 characters or fewer.")
    h1: str = Field(description="Page H1.")
    answer_block: str = Field(description="A direct answer for the top of the page, 40-60 words.")
    benefits: list[str] = Field(description="Exactly 3 short benefit bullets.")
    faqs: list[list[str]] = Field(description="Exactly 3 items, each a [question, answer] pair.")
    app_headline: str = Field(description="In-app screen headline, at most 40 characters.")
    app_subhead: str = Field(description="In-app subhead, at most 90 characters.")
    app_cta: str = Field(description="Call to action, at most 20 characters.")
    geo_prompts: list[str] = Field(
        description="8-12 questions an answer engine might be asked about this page."
    )


# ---------------------------------------------------------------- system prompts

COPY_SYSTEM = f"""You write SEO copy for e& (formerly Etisalat), a telecommunications and \
electronics retailer. Your output goes straight onto pages that search engines index. You \
are working to the e& SEO Copy Guidelines, reproduced below.

MONEY. Read this first, it is the rule most easily broken:

1. Never produce a price, tariff, instalment figure, discount or any amount of money from \
your own knowledge. You do not know what anything costs.
2. If — and only if — the request contains a PRICE line, you may use that exact figure, \
once, in the second sentence of the meta description, in this shape:
   "{CURRENCY_PREFIX} <the figure exactly as given>"
   Any other figure, or a price on a row that has no PRICE line, makes the output unusable.
3. Never write "/month", "per month", "0% interest", "discount", "cashback", "% off", \
"free delivery" or "free gift", whatever the request says.
4. Never write the words "price", "cost" or "discount" — not even when a keyword you were \
given contains one. A keyword is a record of what people search for, not a phrase you must \
reproduce. Target the intent with wording you are allowed to use, and let the price line in \
rule 2 do the rest.

PLACE. The second rule most easily broken, and it used to be broken on nearly every row:

5. Never add a location. No "in the UAE", no "United Arab Emirates", no "in Dubai", no \
"across the Emirates" — not as scene-setting, not to fill a title, not because the market \
is mentioned anywhere in the request. The page is already on a UAE storefront and the \
reader knows which country they are shopping in; saying it spends characters to tell them \
nothing, and it reads like a template.
6. The ONE exception: if a keyword you were given contains a place, you may use that \
keyword as written, because someone chose to target it. "projector in uae" as a given \
keyword is fair; inventing "in the UAE" around a keyword that does not say it is not.

THE GUIDELINES:

7. Meta title: 60 characters or fewer. Meta description: 160 characters or fewer.
   Aim to use most of that space, and earn it with SUBSTANCE about the product — what it \
is, what it does, who it suits, an approved selling point. A description of 120-155 \
characters that says four useful things is the target.
   What you must NEVER do is reach a length with filler: a place, the filing category, a \
restatement of the product name, or a phrase like "explore your options" that would read \
the same on any product in the catalogue. If you have nothing more to say about THIS \
product, stop early — a short description that says something beats a padded one that does \
not.
8. Front-load. Put the primary keyword and the key benefit at the START of both fields, so \
they survive truncation in a search result.
9. Use the primary keyword in the title. Use the primary keyword in the description, and \
secondary keywords too where they fit naturally and the MONEY and PLACE rules allow them.
10. Write the description with an action verb reflecting search intent: Shop, Buy, Get, \
Explore, Discover, Pre-order.
11. Mention "{SMARTPAY_TERM}" in the second sentence of every meta description. It is e&'s \
instalment option and is required whether or not a price was supplied.
12. UK English spelling — colour, optimise, instalment, favourite, centre — EXCEPT inside a \
brand or product name officially spelled the American way. Never alter the product name.
13. Never keyword-stuff. Write for a reader; a term repeated three times reads as spam and \
will be rejected.
14. Every title and every description must be unique across the batch. Two products in the \
same category must not get interchangeable copy. Make them different by saying something \
different about the PRODUCT, never by bolting on a place or a filler phrase.

NEVER:

15. Never invent a specification, measurement, capacity, battery life or camera figure. Use \
a specification only if it appears in the FACTS section or in the product name itself. If \
neither has it, write copy that is accurate without specifics.
16. Never state stock or availability — no "in stock", "while stocks last", "selling fast".
17. Never use an unproven superlative — no "best", "ultimate", "fastest", "perfect".
18. Never name a competing telecom operator.
19. Never mention an earlier generation of the product. If it is a "Series 12", never write \
"Series 11".
20. No em-dash pressed against a word, no double spaces, no leading or trailing space.
21. End the description with a full stop. A sentence that stops mid-air — "...for AED 549" \
— reads as truncated copy, and a reader cannot tell it from a field that got cut off.
22. Capitalise the first word of the title and of the description, even when the keyword \
you are leading with is lowercase. Keywords are stored lowercase because that is how \
demand is measured; "sony headphones: Sony WH-1000XM6" is not a title anyone would write.

The brand suffix "{BRAND_SUFFIX.strip()}" is appended by the system when it fits. Do not add \
it yourself unless the request explicitly asks for it — but DO leave {len(BRAND_SUFFIX)} \
characters spare in the title for it. The suffix is applied to the whole batch or to none \
of it, so one title with no room for it removes the brand mark from every page.

When the request lists validator failures from a previous attempt, fix exactly those \
failures without introducing new ones."""

FACTS_SYSTEM = """You read a web page and report what it says. You are an extractor, not a \
writer.

Copy values verbatim. If the page does not state something, leave it out — an empty list is \
the correct answer when there is nothing to report. Never infer, complete, round, or \
normalise a value. Never add a specification that is not on the page.

The input may include a PAGE METADATA section holding the page's CURRENT title, meta \
description and keywords. Treat it as a source of product facts, because on \
client-side-rendered pages it is often the only one. But it is existing marketing copy, so:

- Take the durable product facts from it — screen size, camera resolution, chip name, \
battery figures, materials, connectivity.
- Discard everything commercial or time-bound: any price, instalment, tariff, discount, \
"pre-order", "out of stock", "coming soon", and any superlative. Those must not reach the \
`specifications` or `features` lists.

Report only what belongs to the product itself."""

IDEATION_SYSTEM = f"""You are a keyword researcher for the United Arab Emirates market. \
You produce SEED terms for a product. Something else measures demand and expands your seeds \
into the long tail; your job is to give it the right places to start.

You will be given a product name, its category and its brand. Work out what it is, who \
buys it, what they call it, and what they type into Google in the UAE. Use what you know \
about how this product is listed and searched for on UAE e-commerce — eand.ae, amazon.ae, \
noon.com, sharafdg.com — and how those listings title it.

Produce seeds in these buckets, a few in each:

{chr(10).join(f'  {b.key}: {b.prompt_hint}' for b in KEYWORD_BUCKETS)}

Rules:

- Terms, never figures. You do not know and must not guess how many people search for \
anything. Demand is measured elsewhere, from Google's own data.
- Seeds must be SHORT and BROAD. "apple watch" is a good seed because it expands into \
hundreds of real queries; "apple watch series 12 gps cellular ceramic pearl white 42mm" \
expands into nothing. Two to four words each.
- Do NOT produce seeds for colours, storage sizes, case sizes, materials, model codes or \
other attributes. Nobody searches "pearl white" and measuring it wastes the budget.
- Do include the market-qualified forms people actually type: "... in uae", "... dubai".
- Include price-intent phrasings such as "<product> price in uae" — those are genuine \
demand signals, even though the page copy itself may only quote a price a human supplied.
- Lowercase, no punctuation, no duplicates.
- Never a competing telecom operator's name.
- Include exactly one `smartpay` seed: "{SMARTPAY_TERM.lower()}". It is a standing business \
requirement rather than a demand signal, and it is expected to come back with no volume.

SELLING POINTS. Alongside the seeds, list up to six USPs for this product — the reasons \
someone chooses it — for a human writer to review and pick from. These are NOT search \
terms. They are phrases a writer could lift into copy.

- Short. Three to eight words, sentence case, no full stop. "Compact enough for one hand", \
not "This product is compact enough to be held in one hand".
- A benefit a reader recognises, not a spec sheet line.
- Set `from_page` TRUE only for a point stated in the FACTS section. Set it FALSE when it \
comes from your own knowledge of the product. This is the difference between a claim we can \
point at and a claim someone has to check, and a human reads that flag before using it. \
Marking your own recall as `from_page` is the worst thing you can do here.
- NEVER a figure, measurement, capacity, battery life, resolution or camera number unless \
it is in the FACTS section or in the product name. If you are unsure of a number, leave the \
number out and keep the benefit.
- NEVER a price, discount, instalment, tariff or anything about cost.
- NEVER a superlative you cannot prove — no "best", "fastest", "unbeatable", "perfect".
- NEVER a stock or availability claim.
- If you do not know this product, return fewer USPs, or none. An empty list is a correct \
answer and is far better than a plausible invention."""


# ---------------------------------------------------------------- prompt builders


def facts_block(facts: PageFacts | None) -> str:
    if facts is None or facts.is_empty:
        return (
            "FACTS: none available. No page was read for this row, so do not state any "
            "specification, measurement or feature as fact."
        )
    lines = ["FACTS (the only specifics you may state, taken from the live page):"]
    if facts.summary:
        lines.append(f"- summary: {facts.summary}")
    for spec in facts.specifications:
        lines.append(f"- specification: {spec}")
    for feature in facts.features:
        lines.append(f"- feature: {feature}")
    if facts.source_url:
        lines.append(f"- source: {facts.source_url}")
    return "\n".join(lines)


def price_block(request: CopyRequest) -> str:
    """The only route by which a figure reaches the model.

    Two distinct instructions rather than one conditional sentence, because "mention the
    price if there is one" invites a model with no price to supply a plausible-looking one.
    The no-price branch says outright that the figure is unknown.
    """
    if request.price:
        return (
            f"PRICE: {request.price}\n"
            f"Use it once, in the second sentence, as "
            f'"{CURRENCY_PREFIX} {request.price}". Exactly this figure, digits and '
            f"separators unchanged. Do not round it, convert it or add a period to it."
        )
    return (
        "PRICE: none supplied. The price of this product is unknown to you. Write the "
        "second sentence with " + SMARTPAY_TERM + " but with no figure and no currency, "
        "and do not imply one with words like 'affordable' or 'from just'."
    )


def usp_block(request: CopyRequest) -> str:
    """Selling points a human ticked, given the same standing as page facts.

    Worth being precise about why this is safe. Rule 13 forbids inventing a specification
    and permits one only from FACTS or the product name. A USP is neither — so without
    this block, a writer who ticked "Works with your smart home setup" would watch the
    model ignore it, or use it and get flagged. The thing that makes it usable is not the
    model's confidence, it is that a named person approved the claim and the tool recorded
    when. That is what this block tells the model, in those terms.

    The silent case says so explicitly, for the same reason `price_block` does: "use the
    selling points if there are any" invites a model with none to invent one.
    """
    if not request.usps:
        return (
            "SELLING POINTS: none approved for this row. Say nothing about what this "
            "product is good at beyond what the FACTS section and the product name "
            "support."
        )
    lines = [
        "SELLING POINTS (a person reviewed and approved these — you may state them):",
        *(f"- {claim}" for claim in request.usps),
        "Use the ones that fit naturally. They are permission, not a checklist: forcing "
        "all of them in is worse copy than using one well. Do not add a figure to one, "
        "and do not sharpen a claim into a superlative.",
    ]
    return "\n".join(lines)


def build_copy_prompt(request: CopyRequest) -> str:
    lines = [
        f"Product: {request.product_name}",
        f"Brand: {request.brand or 'not stated'}",
        # Labelled as an internal filing label, because it was being printed. The sheet
        # files projectors and monitors under "Smart Home" and AirPods under "Devices";
        # the model turned those into "listed under Smart Home" and "in our Smart Home
        # range" — a claim about e&'s merchandising, on a monitor, from a spreadsheet cell.
        f"Internal filing category (NOT for the copy): {request.category_raw}",
        "That category is how this product is filed in a spreadsheet. Use it only to work "
        "out what the product IS. Never print it, never say a product is 'listed under' "
        "or 'in our' anything, and never describe it as part of a range.",
        # Locale, not market. The market line used to read "Market: United Arab Emirates",
        # and it was the single biggest reason almost every title carried "in the UAE":
        # stating the market as context reads to a model as a thing worth mentioning. The
        # locale is what the copy actually needs — which English to write — and the PLACE
        # rules in the system prompt cover the rest.
        f"Locale: {request.locale}. Write British English.",
        "",
        f"PRIMARY keyword — must appear in the meta title, early, and in the "
        f"description: {request.primary_keyword or 'none chosen'}",
        (
            "SECONDARY keywords — work these into the description naturally: "
            f"{', '.join(request.secondary_keywords) or 'none'}"
        ),
        (
            "TERTIARY keywords — use only if there is room after the above, and never "
            "at the cost of readability: "
            f"{', '.join(request.tertiary_keywords) or 'none'}"
        ),
        "Never force a keyword in. A term repeated to hit a list is keyword stuffing and "
        "will be rejected; leaving a tertiary term out is always the better choice.",
        "",
        price_block(request),
        "",
        facts_block(request.facts),
        "",
        usp_block(request),
        "",
        "Limits: meta title 60 characters or fewer, meta description 160 or fewer. Aim "
        "for 120-155 on the description and fill it with things about this product — not "
        "with a place, a category, or a phrase that would fit any product.",
        (
            "The product name above is longer than a meta title allows, so do not use it "
            "whole. Keep the parts people search for — brand, model, generation — and drop "
            "the attributes they do not, such as colour, case size and storage."
            if len(request.product_name) > 45
            else "Keep the product name intact in the title where it fits."
        ),
        f"Append the brand suffix yourself: {'yes' if request.brand_suffix else 'no'}",
    ]
    if request.variant:
        lines += [
            "",
            f"This is alternative phrasing number {request.variant}. Produce a genuinely "
            "different angle from a plain first attempt — not the same sentence shortened.",
        ]
    if request.shrink:
        lines += [
            "",
            f"Compression level {request.shrink}: the previous attempt was too long. Cut "
            "words, but keep the product name complete including any generation number.",
        ]
    if request.feedback:
        lines += [
            "",
            f"Attempt {request.attempt}. The previous attempt failed these validators — fix "
            "exactly these:",
            *(f"- {code}" for code in request.feedback),
        ]
    return "\n".join(lines)


def build_ideation_prompt(request: IdeationRequest) -> str:
    return "\n".join(
        [
            f"Product: {request.product_name}",
            f"Brand: {request.brand or 'work it out from the product name'}",
            f"Category as supplied: {request.category_raw}",
            f"Market: {request.geo}. Locale: {request.locale}.",
            "",
            facts_block(request.facts),
            "",
            f"Produce at most {request.max_terms} seed terms across the buckets, "
            "and up to six selling points.",
        ]
    )


# ---------------------------------------------------------------- response mapping


def read_ideas(
    parsed: IdeasSchema, *, max_terms: int, grounded_allowed: bool = False
) -> IdeationResult:
    """Map one ideation reply into terms and USPs. Shared, so providers cannot drift.

    `grounded_allowed` is False when no page was read for the row, and it overrides the
    model's own `from_page` flag rather than trusting it. A model marking its recall as
    page-sourced is the one failure here that a reviewer cannot catch by reading — the
    label is the whole basis on which they decide how hard to check a claim — so it is
    checked against something the model does not control.
    """
    seen: set[str] = set()
    ideas: list[KeywordIdea] = []
    for item in parsed.terms:
        term = " ".join(item.term.lower().split())
        if not term or term in seen:
            continue
        seen.add(term)
        ideas.append(
            KeywordIdea(term=term, kind=item.kind, rationale=item.rationale.strip())
        )

    seen_claims: set[str] = set()
    usps: list[ProposedUsp] = []
    for usp in parsed.usps:
        claim = " ".join(usp.claim.split()).rstrip(".")
        key = claim.casefold()
        if not claim or key in seen_claims or len(claim) > MAX_USP_CHARS:
            continue
        seen_claims.add(key)
        usps.append(
            ProposedUsp(claim=claim, grounded=bool(usp.from_page) and grounded_allowed)
        )

    return IdeationResult(terms=tuple(ideas[:max_terms]), usps=tuple(usps[:MAX_USPS]))


def normalise_draft(parsed: CopySchema) -> dict[str, Any]:
    """Tidy a model reply into `CopyDraft` fields.

    Shared so both providers clean up identically: whitespace collapsed, over-long lists
    trimmed to the documented count, and malformed FAQ pairs dropped rather than
    half-stored.
    """
    faqs = tuple(
        (pair[0].strip(), pair[1].strip())
        for pair in parsed.faqs
        if len(pair) >= 2 and pair[0].strip() and pair[1].strip()
    )[:3]
    return {
        "meta_title": parsed.meta_title.strip(),
        "meta_description": parsed.meta_description.strip(),
        "h1": parsed.h1.strip(),
        "answer_block": " ".join(parsed.answer_block.split()),
        "benefits": tuple(b.strip() for b in parsed.benefits if b.strip())[:3],
        "faqs": faqs,
        "app_headline": parsed.app_headline.strip(),
        "app_subhead": parsed.app_subhead.strip(),
        "app_cta": parsed.app_cta.strip(),
        "geo_prompts": tuple(p.strip() for p in parsed.geo_prompts if p.strip()),
    }


def faq_jsonld(faqs: tuple[tuple[str, str], ...]) -> str:
    payload = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": question,
                "acceptedAnswer": {"@type": "Answer", "text": answer},
            }
            for question, answer in faqs
        ],
    }
    return json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True)
