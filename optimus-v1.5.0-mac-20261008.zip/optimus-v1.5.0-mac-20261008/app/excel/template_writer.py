"""Writing the keyword-research export.

The brief the content team gave for this file is one sentence: give back the input sheet
with the copy added. So that is exactly what this produces — every input column in its
original order, then three new ones:

    Meta Title | Meta Description | Keywords & Volumes

No second sheet, no validation log, no GEO or ASO tabs. Those exist in `writer.py` for the
older layout and are still reachable; they are not in this file because nobody asked for
them, and an export with five sheets when one was requested is not a more helpful export.

"Keywords & Volumes" holds only the terms that actually reached the copy, which is the
question the column is there to answer: not "what did the tool consider" but "what is this
page targeting, and how much demand is behind it".
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.worksheet import Worksheet

from app.excel.determinism import normalise_xlsx

SHEET_NAME = "Products"

# The input columns, reproduced in the template's own order and spelling, then the three
# new ones. `Brand ` keeps its trailing space: the supplied template has one, and a column
# renamed on the way back out is a column some downstream lookup stops finding.
#
# The first column is the exception, and deliberately so. It used to be "Batch No/Name",
# read from a column in the input sheet. The input sheet no longer carries one — the name
# is typed once on the upload page — so reproducing a header for a column that was never
# supplied would be wrong. It comes back as "Campaign/File Name", which is what it is and
# what the field that collects it is called, so the delivered sheet records which run
# produced it without anyone having to maintain a column for it.
CAMPAIGN_HEADER = "Campaign/File Name"
INPUT_HEADERS: tuple[str, ...] = (
    CAMPAIGN_HEADER,
    "Product Category",
    "Brand ",
    "Product Name",
)
PRICE_HEADER = "Price (AED)"
OUTPUT_HEADERS: tuple[str, ...] = (
    "Meta Title",
    "Meta Description",
    "Keywords & Volumes",
)

WIDTHS: tuple[float, ...] = (28.0, 26.0, 14.0, 52.0, 52.0, 62.0, 62.0, 14.0)

HEADER_FONT = Font(bold=True)
HEADER_FILL = PatternFill("solid", fgColor="F2EFED")
NEW_HEADER_FILL = PatternFill("solid", fgColor="E8F0E4")
WRAP_TOP = Alignment(vertical="top", wrap_text=True)
TOP = Alignment(vertical="top")


@dataclass(frozen=True, slots=True)
class KeywordUsage:
    term: str
    volume: int | None

    def render(self) -> str:
        """`apple watch series 12 (33,100)`, or `(no data)` when unmeasured.

        The parenthetical is never left blank and never shows a zero. A term Google has no
        data for is not a term with no demand, and printing "0" would assert something
        nobody measured.
        """
        return f"{self.term} ({self.volume:,})" if self.volume is not None else f"{self.term} (no data)"


@dataclass(frozen=True, slots=True)
class TemplateRow:
    row_index: int
    batch_no: str
    category_raw: str
    brand: str
    product_name: str
    meta_title: str = ""
    meta_description: str = ""
    keywords_used: tuple[KeywordUsage, ...] = ()
    price_aed: float | None = None
    skip_reason: str | None = None

    def keywords_cell(self) -> str:
        return ", ".join(k.render() for k in self.keywords_used)


@dataclass(frozen=True, slots=True)
class TemplatePayload:
    batch_no: str
    created_at: dt.datetime
    version: int
    rows: tuple[TemplateRow, ...] = field(default=())
    include_price: bool = False

    @property
    def file_name(self) -> str:
        stamp = self.created_at.strftime("%Y%m%d")
        safe = self.batch_no.replace(" ", "_").replace("/", "-")
        return f"SEO_Copy_{safe}_{stamp}_v{self.version}.xlsx"

    @property
    def headers(self) -> tuple[str, ...]:
        middle = (PRICE_HEADER,) if self.include_price else ()
        return (*INPUT_HEADERS, *middle, *OUTPUT_HEADERS)


# `keywords_used_in` deliberately does NOT live here.
#
# Building a `KeywordUsage` means writing a `volume=`, and `tests/test_no_llm_volumes.py`
# requires any module that writes one to import `app.providers.keywords`. That rule caught
# this function sitting in the writer, and the rule is right: assembling the payload is the
# export service's job and rendering it is this module's. A writer that can mint a figure
# is a writer that can mint the wrong figure.
#
# See `app.services.export_service.keywords_used_in`.


def _write_header(sheet: Worksheet, headers: tuple[str, ...]) -> None:
    new_from = len(headers) - len(OUTPUT_HEADERS)
    for index, title in enumerate(headers, start=1):
        cell = sheet.cell(row=1, column=index, value=title)
        cell.font = HEADER_FONT
        # The three added columns are tinted so it is obvious at a glance which part of
        # the sheet the tool produced and which part came back unchanged.
        cell.fill = NEW_HEADER_FILL if index > new_from else HEADER_FILL
        cell.alignment = TOP
    sheet.freeze_panes = "A2"

    for index, width in enumerate(WIDTHS[: len(headers)], start=1):
        sheet.column_dimensions[sheet.cell(row=1, column=index).column_letter].width = width


def build_workbook(payload: TemplatePayload) -> bytes:
    workbook = Workbook()
    sheet = workbook.active
    if sheet is None:  # pragma: no cover - openpyxl always creates one
        sheet = workbook.create_sheet()
    sheet.title = SHEET_NAME

    headers = payload.headers
    _write_header(sheet, headers)

    for offset, row in enumerate(payload.rows, start=2):
        values: list[object] = [
            row.batch_no,
            row.category_raw,
            row.brand,
            row.product_name,
        ]
        if payload.include_price:
            values.append(row.price_aed)
        values.extend(
            [
                # A row that could not be processed keeps its place and states why, rather
                # than shipping an empty cell that reads as an oversight. Brief §1 rule 6.
                row.meta_title or (f"NOT GENERATED: {row.skip_reason}" if row.skip_reason else ""),
                row.meta_description,
                row.keywords_cell(),
            ]
        )

        for column, value in enumerate(values, start=1):
            cell = sheet.cell(row=offset, column=column, value=value)
            cell.alignment = WRAP_TOP if column >= 4 else TOP
        if payload.include_price and row.price_aed is not None:
            sheet.cell(row=offset, column=5).number_format = "#,##0.00"

    buffer = BytesIO()
    workbook.save(buffer)
    # Same determinism guarantee as the legacy export: re-downloading a past export
    # regenerates it from the stored records and must produce identical bytes.
    return normalise_xlsx(buffer.getvalue(), timestamp=payload.created_at)
