"""Deterministic workbook bytes.

Brief §11 requires that exporting and then re-downloading from history yields a
byte-identical workbook, where the re-download regenerates from stored records rather than
serving a saved blob. An xlsx is a zip, and two sources of drift defeat that by default:

  1. `openpyxl` writes each zip entry with `time.localtime()`, so every save differs.
  2. `openpyxl` stamps `created`/`modified` into `docProps/core.xml` from `datetime.now()`.

(1) is fixed here by rewriting the archive with a frozen timestamp and a canonical entry
order. (2) is fixed by the caller, which sets workbook properties from the stored `Export`
record instead of the current clock — see `app/services/export_service.py`.

A third source of drift is more insidious and lives in our own code: iterating a `set` of
strings varies with `PYTHONHASHSEED`, so unsorted keyword or finding collections would
reorder between runs and change `sharedStrings.xml`. Every collection written to a workbook
is explicitly sorted at its source; `tests/test_export_determinism.py` runs the export under
two different hash seeds to prove it.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import io
import re
import zipfile

# The zip epoch. Any fixed value works; 1980-01-01 is the earliest a zip can represent.
FIXED_TIMESTAMP = (1980, 1, 1, 0, 0, 0)

CORE_PROPS = "docProps/core.xml"

# openpyxl assigns `properties.modified` from the wall clock inside `save()`, overwriting
# whatever the caller set. Setting it on the workbook is therefore not enough — the value
# has to be forced after save, which is why it is done here on the serialised XML.
_CORE_DATE = re.compile(
    rb"(<dcterms:(created|modified)\b[^>]*>)[^<]*(</dcterms:\2>)"
)


def _force_core_timestamps(data: bytes, when: dt.datetime) -> bytes:
    stamp = when.strftime("%Y-%m-%dT%H:%M:%SZ").encode("ascii")
    return _CORE_DATE.sub(lambda m: m.group(1) + stamp + m.group(3), data)


def normalise_xlsx(raw: bytes, *, timestamp: dt.datetime | None = None) -> bytes:
    """Rewrite an xlsx so identical content always produces identical bytes.

    `timestamp` replaces the document created/modified properties. Pass the stored
    `Export.created_at` so a re-download reproduces the original bytes exactly.
    """
    source = zipfile.ZipFile(io.BytesIO(raw))
    buffer = io.BytesIO()

    # Sorted order happens to put "[Content_Types].xml" first, which is conventional, and
    # is deterministic regardless.
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as target:
        for name in sorted(source.namelist()):
            data = source.read(name)
            if timestamp is not None and name == CORE_PROPS:
                data = _force_core_timestamps(data, timestamp)
            info = zipfile.ZipInfo(filename=name, date_time=FIXED_TIMESTAMP)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 0
            info.external_attr = 0o600 << 16
            target.writestr(info, data)

    source.close()
    return buffer.getvalue()


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()
