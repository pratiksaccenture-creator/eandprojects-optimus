"""Writing the export workbook — brief §9.

Sheet 1 reproduces the team's existing layout verbatim, including the trailing space in the
`Keywords ` header and the `Meta Decsription (EN)` typo. Those are not tidied: the file has
to drop into an existing process, and a renamed column breaks whatever consumes it
downstream.

Two things are deliberately changed, because they are the defects the tool exists to fix:

  * Column C holds the product URL on EVERY row. The reference file overwrote it with the
    product name on rows 10-14, losing the URL entirely.
  * Product name gets its own new column J, to the right of the reserved column I, so
    nothing existing shifts.

The `Validation log` sheet is treated as a headline feature rather than a debug artifact,
per §9 — it is what makes the output auditable.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

from app.excel.determinism import normalise_xlsx

SHEET_MAIN = "SEO Batch 6 Product List"
SHEET_KEYWORDS = "keywords "  # trailing space is real
SHEET_GEO = "GEO"
SHEET_ASO = "ASO"
SHEET_VALIDATION = "Validation log"

# Verbatim from the reference workbook. The trailing space and the typo are reproduced
# intentionally; see the module docstring.
MAIN_HEADERS: tuple[str | None, ...] = (
    "Date",
    "Category",
    "Product URL",
    "Keywords ",
    "Meta Title (EN)",
    "Character count (<60)",
    "Meta Decsription (EN)",
    "Character count (<160)",
    None,  # column I: empty value, header style only. Reserved in the original.
    "Product Name",  # column J: new, appended so nothing existing shifts
)

# Column widths as measured in the reference file, with J added.
MAIN_WIDTHS: dict[str, float] = {
    "A": 12.81640625,
    "B": 29.6328125,
    "C": 29.453125,
    "D": 81.1796875,
    "E": 46.6328125,
    "F": 18.36328125,
    "G": 44.453125,
    "H": 18.81640625,
    "I": 18.36328125,
    "J": 34.0,
}

HEADER_FONT = Font(bold=True)
HEADER_FILL = PatternFill("solid", fgColor="F2EFED")
WRAP_TOP = Alignment(vertical="top", wrap_text=True)
TOP = Alignment(vertical="top")


@dataclass(frozen=True, slots=True)
class ExportRow:
    row_index: int
    category_raw: str
    product_url: str
    product_name: str
    keywords_joined: str = ""
    meta_title: str = ""
    meta_description: str = ""
    date_value: dt.datetime | None = None
    date_serial: float | None = None
    date_number_format: str | None = None
    fetch_status: str = "not_attempted"
    fetch_note: str | None = None
    skip_reason: str | None = None


@dataclass(frozen=True, slots=True)
class ExportKeyword:
    row_index: int
    term: str
    type: str
    volume: int | None
    source: str
    is_live_data: bool
    data_date: dt.datetime | None
    locale: str
    geo: str
    status: str
    product_url: str
    is_primary: bool = False


@dataclass(frozen=True, slots=True)
class ExportGeoRow:
    row_index: int
    product_url: str
    product_name: str
    prompts: tuple[str, ...]
    answer_block: str
    jsonld: str


@dataclass(frozen=True, slots=True)
class ExportAsoField:
    key: str
    store: str
    label: str
    text: str
    limit: int
    unit: str
    chars: int
    byte_length: int
    indexed: bool
    valid: bool
    note: str


@dataclass(frozen=True, slots=True)
class ExportFinding:
    row_index: int
    field: str
    code: str
    severity: str
    message: str


@dataclass(frozen=True, slots=True)
class ExportPayload:
    batch_no: str
    source_file_name: str
    created_at: dt.datetime
    version: int
    locale: str
    geo: str
    provider_name: str
    provider_is_live: bool
    model_name: str
    prompt_version: str
    brand_suffix_note: str
    rows: tuple[ExportRow, ...]
    keywords: tuple[ExportKeyword, ...] = ()
    geo_rows: tuple[ExportGeoRow, ...] = ()
    aso_fields: tuple[ExportAsoField, ...] = ()
    findings: tuple[ExportFinding, ...] = field(default=())
    skipped_note: str = ""

    @property
    def file_name(self) -> str:
        stamp = self.created_at.strftime("%Y%m%d")
        safe_batch = self.batch_no.replace(" ", "_").replace("/", "-")
        return f"Output_File_-_SEO_{safe_batch}_{stamp}_v{self.version}.xlsx"


def _write_header(sheet: Worksheet, headers: tuple[str | None, ...]) -> None:
    for index, title in enumerate(headers, start=1):
        cell = sheet.cell(row=1, column=index)
        if title is not None:
            cell.value = title
        # The reserved column keeps the header style with no value, exactly as found.
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = TOP
    sheet.freeze_panes = "A2"


def _apply_widths(sheet: Worksheet, widths: dict[str, float]) -> None:
    for letter, width in widths.items():
        sheet.column_dimensions[letter].width = width


def _build_main_sheet(sheet: Worksheet, payload: ExportPayload) -> None:
    _write_header(sheet, MAIN_HEADERS)
    _apply_widths(sheet, MAIN_WIDTHS)

    for offset, row in enumerate(payload.rows, start=2):
        if row.date_value is not None:
            sheet.cell(row=offset, column=1, value=row.date_value)
        elif row.date_serial is not None:
            sheet.cell(row=offset, column=1, value=row.date_serial)
        date_cell = sheet.cell(row=offset, column=1)
        if row.date_number_format:
            date_cell.number_format = row.date_number_format
        date_cell.alignment = TOP

        sheet.cell(row=offset, column=2, value=row.category_raw).alignment = TOP
        # Column C: the URL, on every row, always.
        sheet.cell(row=offset, column=3, value=row.product_url).alignment = TOP
        sheet.cell(row=offset, column=4, value=row.keywords_joined).alignment = WRAP_TOP
        sheet.cell(row=offset, column=5, value=row.meta_title).alignment = WRAP_TOP

        # Live formulas, not computed values, per §9. openpyxl writes no cached result, so
        # these appear blank until a recalculating client opens the file; the authoritative
        # integers are also written into the Validation log. See DECISIONS.md.
        sheet.cell(row=offset, column=6, value=f"=LEN(E{offset})").alignment = TOP
        sheet.cell(row=offset, column=7, value=row.meta_description).alignment = WRAP_TOP
        sheet.cell(row=offset, column=8, value=f"=LEN(G{offset})").alignment = TOP

        # Column I is left untouched — reserved in the original.
        sheet.cell(row=offset, column=10, value=row.product_name).alignment = TOP


def _build_keywords_sheet(sheet: Worksheet, payload: ExportPayload) -> None:
    headers = (
        "Term", "Type", "Volume", "Source", "Live data", "Data date",
        "Locale", "Geo", "Status", "Primary", "Product URL", "Row index",
    )
    _write_header(sheet, headers)
    _apply_widths(
        sheet,
        {"A": 34, "B": 14, "C": 12, "D": 22, "E": 11, "F": 14,
         "G": 9, "H": 8, "I": 13, "J": 9, "K": 46, "L": 11},
    )
    for offset, keyword in enumerate(payload.keywords, start=2):
        sheet.cell(row=offset, column=1, value=keyword.term)
        sheet.cell(row=offset, column=2, value=keyword.type)
        # Blank rather than zero when the provider had no data. A zero would read as a
        # measured volume of zero; blank plus the `unverified` status is the honest form.
        if keyword.volume is not None:
            sheet.cell(row=offset, column=3, value=keyword.volume).number_format = "#,##0"
        sheet.cell(row=offset, column=4, value=keyword.source)
        sheet.cell(row=offset, column=5, value="yes" if keyword.is_live_data else "no")
        if keyword.data_date is not None:
            cell = sheet.cell(row=offset, column=6, value=keyword.data_date)
            cell.number_format = "yyyy-mm-dd"
        sheet.cell(row=offset, column=7, value=keyword.locale)
        sheet.cell(row=offset, column=8, value=keyword.geo)
        sheet.cell(row=offset, column=9, value=keyword.status)
        sheet.cell(row=offset, column=10, value="yes" if keyword.is_primary else "")
        sheet.cell(row=offset, column=11, value=keyword.product_url)
        sheet.cell(row=offset, column=12, value=keyword.row_index)


def _build_geo_sheet(sheet: Worksheet, payload: ExportPayload) -> None:
    headers = ("Row index", "Product name", "Product URL", "Tracked prompt",
               "Answer block", "FAQPage JSON-LD")
    _write_header(sheet, headers)
    _apply_widths(sheet, {"A": 11, "B": 30, "C": 44, "D": 52, "E": 64, "F": 64})

    offset = 2
    for geo_row in payload.geo_rows:
        # One line per tracked prompt, so the sheet is filterable by prompt. The answer
        # block and JSON-LD repeat only on the first line of each row's group.
        prompts = geo_row.prompts or ("",)
        for position, prompt in enumerate(prompts):
            sheet.cell(row=offset, column=1, value=geo_row.row_index).alignment = TOP
            sheet.cell(row=offset, column=2, value=geo_row.product_name).alignment = TOP
            sheet.cell(row=offset, column=3, value=geo_row.product_url).alignment = TOP
            sheet.cell(row=offset, column=4, value=prompt).alignment = WRAP_TOP
            if position == 0:
                sheet.cell(row=offset, column=5, value=geo_row.answer_block).alignment = WRAP_TOP
                sheet.cell(row=offset, column=6, value=geo_row.jsonld).alignment = WRAP_TOP
            offset += 1


def _build_aso_sheet(sheet: Worksheet, payload: ExportPayload) -> None:
    headers = ("Store", "Field", "Copy", "Limit", "Unit", "Characters",
               "Bytes", "Indexed", "Within limit", "Note")
    _write_header(sheet, headers)
    _apply_widths(
        sheet,
        {"A": 9, "B": 26, "C": 60, "D": 8, "E": 9, "F": 12, "G": 9, "H": 10, "I": 13, "J": 52},
    )
    for offset, aso in enumerate(payload.aso_fields, start=2):
        sheet.cell(row=offset, column=1, value=aso.store)
        sheet.cell(row=offset, column=2, value=aso.label)
        sheet.cell(row=offset, column=3, value=aso.text).alignment = WRAP_TOP
        sheet.cell(row=offset, column=4, value=aso.limit)
        sheet.cell(row=offset, column=5, value=aso.unit)
        sheet.cell(row=offset, column=6, value=aso.chars)
        sheet.cell(row=offset, column=7, value=aso.byte_length)
        sheet.cell(row=offset, column=8, value="yes" if aso.indexed else "no")
        sheet.cell(row=offset, column=9, value="yes" if aso.valid else "NO")
        sheet.cell(row=offset, column=10, value=aso.note).alignment = WRAP_TOP


def _build_validation_sheet(sheet: Worksheet, payload: ExportPayload) -> None:
    """Every row, every field, every validator result, plus skipped rows with reasons.

    This sheet also carries the authoritative character counts as plain integers. Sheet 1
    holds them as live `LEN()` formulas per §9, which some viewers render blank because
    openpyxl writes no cached value — so the numbers that prove the limits were enforced
    are guaranteed to be readable here.
    """
    headers = ("Row index", "Product name", "Field", "Severity", "Code", "Finding",
               "Characters", "Product URL")
    _write_header(sheet, headers)
    _apply_widths(
        sheet, {"A": 11, "B": 30, "C": 24, "D": 11, "E": 26, "F": 76, "G": 12, "H": 44}
    )

    by_row = {row.row_index: row for row in payload.rows}
    offset = 2

    for finding in payload.findings:
        row = by_row.get(finding.row_index)
        sheet.cell(row=offset, column=1, value=finding.row_index)
        sheet.cell(row=offset, column=2, value=row.product_name if row else "")
        sheet.cell(row=offset, column=3, value=finding.field)
        sheet.cell(row=offset, column=4, value=finding.severity)
        sheet.cell(row=offset, column=5, value=finding.code)
        sheet.cell(row=offset, column=6, value=finding.message).alignment = WRAP_TOP
        sheet.cell(row=offset, column=8, value=row.product_url if row else "")
        offset += 1

    if payload.findings:
        offset += 1

    sheet.cell(row=offset, column=1, value="Row summary").font = HEADER_FONT
    offset += 1
    for row in payload.rows:
        sheet.cell(row=offset, column=1, value=row.row_index)
        sheet.cell(row=offset, column=2, value=row.product_name)
        sheet.cell(row=offset, column=3, value="meta_title_en")
        sheet.cell(row=offset, column=4, value=row.fetch_status)
        sheet.cell(
            row=offset, column=6,
            value=row.skip_reason or row.fetch_note or "",
        ).alignment = WRAP_TOP
        sheet.cell(row=offset, column=7, value=len(row.meta_title.encode("utf-16-le")) // 2)
        sheet.cell(row=offset, column=8, value=row.product_url)
        offset += 1
        sheet.cell(row=offset, column=1, value=row.row_index)
        sheet.cell(row=offset, column=2, value=row.product_name)
        sheet.cell(row=offset, column=3, value="meta_description_en")
        sheet.cell(row=offset, column=4, value=row.fetch_status)
        sheet.cell(
            row=offset, column=7,
            value=len(row.meta_description.encode("utf-16-le")) // 2,
        )
        sheet.cell(row=offset, column=8, value=row.product_url)
        offset += 1

    offset += 1
    provenance = (
        ("Batch", payload.batch_no),
        ("Source file", payload.source_file_name),
        ("Export version", f"v{payload.version}"),
        ("Rows in", str(len(payload.rows))),
        ("Rows out", str(len(payload.rows))),
        ("Keyword volume provider", payload.provider_name),
        ("Volumes are live data", "yes" if payload.provider_is_live else "no"),
        ("Copy model", payload.model_name),
        ("Prompt version", payload.prompt_version),
        ("Brand suffix decision", payload.brand_suffix_note),
        ("Locale / geo", f"{payload.locale} / {payload.geo}"),
        ("Skipped rows", payload.skipped_note or "none"),
    )
    sheet.cell(row=offset, column=1, value="Provenance").font = HEADER_FONT
    offset += 1
    for label, value in provenance:
        sheet.cell(row=offset, column=1, value=label).font = HEADER_FONT
        sheet.cell(row=offset, column=2, value=value).alignment = WRAP_TOP
        offset += 1


def build_workbook(payload: ExportPayload) -> bytes:
    """Render the payload to deterministic xlsx bytes."""
    workbook = Workbook()

    main = workbook.active
    assert main is not None
    main.title = SHEET_MAIN
    _build_main_sheet(main, payload)

    _build_keywords_sheet(workbook.create_sheet(SHEET_KEYWORDS), payload)
    _build_geo_sheet(workbook.create_sheet(SHEET_GEO), payload)
    _build_aso_sheet(workbook.create_sheet(SHEET_ASO), payload)
    _build_validation_sheet(workbook.create_sheet(SHEET_VALIDATION), payload)

    # Guarantees desktop Excel recalculates the LEN() formulas on open, since openpyxl
    # writes them without a cached value.
    workbook.calculation.fullCalcOnLoad = True

    # Fixed from the Export record, never the clock, or re-download would differ.
    workbook.properties.creator = "Optimus"
    workbook.properties.lastModifiedBy = "Optimus"
    workbook.properties.created = payload.created_at
    workbook.properties.modified = payload.created_at
    workbook.properties.title = f"SEO {payload.batch_no} v{payload.version}"

    buffer = BytesIO()
    workbook.save(buffer)
    # The timestamp is re-forced after save because openpyxl overwrites `modified` from
    # the wall clock during serialisation.
    return normalise_xlsx(buffer.getvalue(), timestamp=payload.created_at)
