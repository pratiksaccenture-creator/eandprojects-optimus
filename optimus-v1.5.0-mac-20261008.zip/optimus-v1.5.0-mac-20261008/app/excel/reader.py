"""Reading the input workbook — brief §3.

The governing rule is brief §8 step 1: never reject a file for dirty data, classify and
continue. Every function here degrades to a stated classification rather than raising, so a
malformed cell produces a visible reason instead of a failed upload.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import openpyxl
import regex

from app.lib.normalise import clean_cell, normalise_category

# Re-exported: brand derivation moved to `app.lib.terms` when the keyword service needed
# the same answer to reject a competitor's term. One list, one answer, and `lib` does not
# depend on the spreadsheet layer.
from app.lib.terms import BRAND_BY_LINE, KNOWN_BRANDS, derive_brand
from app.models import FetchStatus, PageType

__all__ = [
    "BRAND_BY_LINE",
    "KNOWN_BRANDS",
    "ParsedRow",
    "ParsedWorkbook",
    "derive_brand",
    "derive_product_name",
    "looks_like_template",
    "read_any_workbook",
    "read_input_workbook",
    "read_price",
    "read_template_workbook",
]

EXPECTED_HEADERS = ("Date", "Category", "Product URL")

# The keyword-research template. Header matching is case-insensitive and trims whitespace,
# which matters: the supplied template ships with a trailing space in `Brand `, exactly as
# the output workbook does in `Keywords `.
# The columns the template is expected to carry. "Batch No/Name" is NOT among them any
# more: the campaign name is typed once on the upload page and returned as the export's
# first column, so a sheet that still has the column is read (the reader looks for it) but
# a sheet without one is not missing anything.
TEMPLATE_HEADERS = ("Product Category", "Brand", "Product Name")

# Optional, and accepted under any of these spellings. Absent on the template as supplied;
# a row without one still generates copy, with a warning that it cannot meet the
# second-sentence price rule.
PRICE_HEADERS = ("Price", "Starting Price", "Price (AED)", "Starting Price (AED)")
URL_HEADERS = ("Product URL", "URL", "Page URL")

# Hosts that serve the public site. Anything else cannot be verified by a customer or a
# search engine, so it is reported rather than assumed equivalent.
PUBLIC_HOSTS = frozenset({"www.eand.ae", "eand.ae"})

# Last path segment words that mark an editorial page rather than a product listing.
CONTENT_SEGMENT_WORDS = (
    "help", "guide", "benefit", "faq", "about", "support", "terms", "how-to", "page",
)


@dataclass(frozen=True, slots=True)
class UrlClassification:
    page_type: PageType
    fetch_status: FetchStatus
    note: str | None
    product_id: str | None = None


def classify_url(url: str) -> UrlClassification:
    """Classify one of the three URL shapes in brief §3.

    No HTTP request is made — the tool does not fetch pages (see DECISIONS.md §4). A row is
    therefore never reported as `ok`, because that would claim a fetch that never happened.
    Preprod hosts are `unreachable` on the strength of the hostname alone, which is a fact
    about the URL rather than an inference about the server.
    """
    if not url:
        return UrlClassification(
            PageType.content, FetchStatus.blocked, "No URL in this row."
        )

    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    path = parsed.path.lower()

    if not parsed.scheme or not host:
        return UrlClassification(
            PageType.content, FetchStatus.blocked, f"Not a usable URL: {url!r}."
        )

    product_id: str | None = None
    if "/eshop/" in path:
        page_type = PageType.product
        ids = parse_qs(parsed.query).get("productId") or []
        product_id = ids[0] if ids else None
    elif "/c/" in path:
        segment = path.rsplit("/", 1)[-1]
        page_type = (
            PageType.content
            if any(word in segment for word in CONTENT_SEGMENT_WORDS)
            else PageType.category
        )
    else:
        page_type = PageType.content

    if host not in PUBLIC_HOSTS:
        return UrlClassification(
            page_type,
            FetchStatus.unreachable,
            (
                f"Host {host} is not the public site, so this page cannot be reached or "
                "indexed by a search engine. Copy is generated from the category name only "
                "and nobody can verify it against a live page."
            ),
            product_id,
        )

    return UrlClassification(
        page_type,
        FetchStatus.not_attempted,
        "Page not fetched — copy is grounded in the input file only.",
        product_id,
    )


# Brand casing cannot be derived by an algorithm: "iPhone" and "AirPods" both break
# title-case, and "GPS" and "SE" both break capitalize(). An explicit map is the only
# honest way to render a product name the content team would accept.
CANONICAL_TOKENS = {
    "iphone": "iPhone", "ipad": "iPad", "ipod": "iPod", "imac": "iMac",
    "airpods": "AirPods", "airtag": "AirTag", "macbook": "MacBook",
    "ios": "iOS", "watchos": "watchOS", "elife": "eLife", "esim": "eSIM",
    "gps": "GPS", "se": "SE", "uae": "UAE", "ai": "AI", "tv": "TV",
    "anc": "ANC", "lte": "LTE", "5g": "5G", "4g": "4G",
}
MINOR_WORDS = frozenset({"with", "and", "or", "the", "for", "in", "of", "a", "an"})
TAXONOMY_PREFIXES = frozenset({"devices", "device", "smart home"})

_WORD_CORE = regex.compile(r"^(\P{L}*)(\p{L}[\p{L}\p{N}]*)(.*)$")


def _recase_word(word: str, is_first: bool) -> str:
    match = _WORD_CORE.match(word)
    if match is None:
        return word  # no letters at all: "12", "(2026)", "+", "-"
    lead, core, tail = match.groups()
    folded = core.casefold()

    if folded in CANONICAL_TOKENS:
        fixed = CANONICAL_TOKENS[folded]
    elif not is_first and folded in MINOR_WORDS:
        fixed = folded
    elif core.isupper():
        fixed = core.capitalize()  # "WATCH" -> "Watch", "ULTRA" -> "Ultra"
    elif core[0].islower() and not any(c.isupper() for c in core[1:]):
        fixed = core.capitalize()  # "pro" -> "Pro"
    else:
        fixed = core  # already deliberately mixed case
    return f"{lead}{fixed}{tail}"


def derive_product_name(category_raw: str) -> str:
    """Product name from the category, which is the only source available.

    The input has no product-name column and the tool does not fetch pages (DECISIONS.md
    §5), so the category is all there is. Source casing is inconsistent
    (`Apple WATCH ULTRA 4`, `Devices - Iphone Family`), so casing is normalised against a
    canonical brand-token map while `category_raw` is preserved untouched for display.
    """
    cleaned = clean_cell(category_raw)
    if not cleaned:
        return ""

    # Strip a leading taxonomy prefix: "Devices - iPhone 18 pro" -> "iPhone 18 pro".
    for separator in (" - ", " – ", " — "):
        if separator in cleaned:
            head, _, tail = cleaned.partition(separator)
            if tail.strip() and head.strip().casefold() in TAXONOMY_PREFIXES:
                cleaned = tail.strip()
            break

    words = cleaned.split()
    return " ".join(_recase_word(w, i == 0) for i, w in enumerate(words))


# An eshop configuration slug is a product key, not a name.
_PRODUCT_KEY = regex.compile(r"^key-prod|prod\d+t\d+", regex.IGNORECASE)


def slug_name(url: str) -> str:
    """A readable page name from the URL's last path segment, or "" if it has none.

    Used only to disambiguate rows whose categories collide — seven rows in this batch all
    carry the category `Smart Home` while pointing at smart-locks, smart-thermostat,
    smart-appliances and so on. The slug is input data, so using it invents nothing, and
    without it those rows cannot have distinct titles.
    """
    path = urlparse(url).path
    segment = path.rsplit("/", 1)[-1]
    for suffix in (".html", ".htm", ".aspx"):
        if segment.lower().endswith(suffix):
            segment = segment[: -len(suffix)]
    if not segment or _PRODUCT_KEY.search(segment):
        return ""
    words = [w for w in regex.split(r"[-_]+", segment) if w]
    if not words:
        return ""
    return " ".join(_recase_word(w, i == 0) for i, w in enumerate(words))


@dataclass(frozen=True, slots=True)
class ParsedRow:
    row_index: int
    category_raw: str
    category_norm: str
    product_url: str
    product_name: str
    page_type: PageType
    fetch_status: FetchStatus
    fetch_note: str | None
    product_id: str | None
    date_serial: float | None
    date_number_format: str | None
    date_value: dt.datetime | None
    go_live_raw: str | None
    skip_reason: str | None
    brand: str = ""
    brand_derived: bool = False
    price_aed: float | None = None
    batch_no: str = ""


@dataclass(frozen=True, slots=True)
class ParsedWorkbook:
    sheet_name: str
    headers: tuple[str, ...]
    rows: tuple[ParsedRow, ...]
    header_warnings: tuple[str, ...] = field(default=())
    # "template" for the keyword-research sheet, "legacy" for the original URL batch file.
    layout: str = "legacy"

    @property
    def unreachable_count(self) -> int:
        return sum(1 for r in self.rows if r.fetch_status is FetchStatus.unreachable)

    @property
    def skipped_count(self) -> int:
        return sum(1 for r in self.rows if r.skip_reason)

    @property
    def derived_brand_count(self) -> int:
        return sum(1 for r in self.rows if r.brand_derived)

    @property
    def priced_count(self) -> int:
        return sum(1 for r in self.rows if r.price_aed is not None)

    @property
    def batch_numbers(self) -> tuple[str, ...]:
        seen: list[str] = []
        for row in self.rows:
            if row.batch_no and row.batch_no not in seen:
                seen.append(row.batch_no)
        return tuple(seen)


def _column_map(header_row: tuple[Any, ...]) -> tuple[dict[str, int], tuple[str, ...]]:
    """Locate the expected columns by header text, tolerating case and stray whitespace."""
    found: dict[str, int] = {}
    warnings: list[str] = []
    seen = [clean_cell(value) for value in header_row]

    for expected in EXPECTED_HEADERS:
        target = expected.casefold()
        for index, actual in enumerate(seen):
            if actual.casefold() == target:
                found[expected] = index
                break
        else:
            warnings.append(f'Expected a "{expected}" column; none found.')

    extras = [
        actual for actual in seen
        if actual and actual.casefold() not in {e.casefold() for e in EXPECTED_HEADERS}
    ]
    if extras:
        warnings.append("Extra columns ignored: " + ", ".join(repr(e) for e in extras) + ".")
    return found, tuple(warnings)


def _read_date(cell: Any) -> tuple[float | None, str | None, dt.datetime | None]:
    """Parse permissively. Two number formats coexist in the fixture and neither may throw."""
    value = cell.value
    number_format = cell.number_format if cell.number_format != "General" else None

    if isinstance(value, dt.datetime):
        serial = (value - dt.datetime(1899, 12, 30)).days
        return float(serial), number_format, value
    if isinstance(value, dt.date):
        as_datetime = dt.datetime(value.year, value.month, value.day)
        serial = (as_datetime - dt.datetime(1899, 12, 30)).days
        return float(serial), number_format, as_datetime
    if isinstance(value, (int, float)):
        try:
            resolved = dt.datetime(1899, 12, 30) + dt.timedelta(days=float(value))
        except (OverflowError, ValueError):
            return float(value), number_format, None
        return float(value), number_format, resolved
    text = clean_cell(value)
    if not text:
        return None, None, None
    for pattern in ("%d-%b-%y", "%d-%b-%Y", "%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y"):
        try:
            resolved = dt.datetime.strptime(text, pattern)
        except ValueError:
            continue
        serial = (resolved - dt.datetime(1899, 12, 30)).days
        return float(serial), number_format, resolved
    return None, number_format, None


def _find_column(headers: list[str], *candidates: str) -> int | None:
    """Index of the first header matching any candidate, ignoring case and whitespace."""
    wanted = [c.casefold() for c in candidates]
    for index, actual in enumerate(headers):
        if actual.casefold() in wanted:
            return index
    return None


def read_price(value: Any) -> float | None:
    """A price cell as a number, or None.

    Permissive about how it was typed — 3499, "3,499", "AED 3,499", "3499.00" all read the
    same — and silent about anything it cannot parse, because brief §8 step 1 says dirty
    data is classified, never rejected. A cell it cannot read becomes "no price supplied",
    which the description validator then reports.
    """
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value) if value > 0 else None
    text = clean_cell(value)
    if not text:
        return None
    digits = regex.sub(r"[^\d.]", "", text.replace(",", ""))
    if not digits or digits.count(".") > 1:
        return None
    try:
        parsed = float(digits)
    except ValueError:
        return None
    return parsed if parsed > 0 else None


def looks_like_template(headers: list[str]) -> bool:
    """Whether this sheet is the keyword-research template rather than the legacy file.

    Decided on the two columns that only the template has. Sniffing beats asking: the team
    will have both file shapes in circulation for a while, and a wrong answer at upload is
    a confusing error much later.
    """
    folded = {h.casefold() for h in headers}
    return "product name" in folded and (
        "product category" in folded or "batch no/name" in folded
    )


def read_template_workbook(path: Path, sheet_name: str | None = None) -> ParsedWorkbook:
    """Read the four-column keyword-research template.

    Columns: Batch No/Name, Product Category, Brand, Product Name, plus an optional Price
    and an optional Product URL. No dates, no URLs required — the research runs from the
    product name and category, which is the whole point of the pivot.
    """
    workbook = openpyxl.load_workbook(path, data_only=True)
    sheet = workbook[sheet_name] if sheet_name else workbook[workbook.sheetnames[0]]

    header_cells = next(sheet.iter_rows(min_row=1, max_row=1), ())
    headers = [clean_cell(c.value) for c in header_cells]

    batch_col = _find_column(headers, "Batch No/Name", "Batch No", "Batch", "Batch Name")
    category_col = _find_column(headers, "Product Category", "Category")
    brand_col = _find_column(headers, "Brand")
    name_col = _find_column(headers, "Product Name", "Product")
    price_col = _find_column(headers, *PRICE_HEADERS)
    url_col = _find_column(headers, *URL_HEADERS)

    warnings: list[str] = []
    if name_col is None:
        warnings.append('No "Product Name" column found; nothing can be researched.')
    if category_col is None:
        warnings.append('No "Product Category" column found.')
    if price_col is None:
        warnings.append(
            "No price column. Descriptions will be written without the starting price "
            "the guidelines ask for; add one per row on the copy page, or add a "
            '"Price" column to the sheet.'
        )

    def cell(cells: tuple[Any, ...], index: int | None) -> Any:
        return cells[index].value if index is not None and index < len(cells) else None

    rows: list[ParsedRow] = []
    for offset, cells in enumerate(sheet.iter_rows(min_row=2), start=1):
        product_name = clean_cell(cell(cells, name_col))
        category_raw = clean_cell(cell(cells, category_col))
        # The template is formatted down to row 101 with nine rows of data. A row with
        # neither a name nor a category is spreadsheet formatting, not a product.
        if not product_name and not category_raw:
            continue

        supplied_brand = clean_cell(cell(cells, brand_col))
        brand = supplied_brand or derive_brand(product_name)
        product_url = clean_cell(cell(cells, url_col))

        rows.append(
            ParsedRow(
                row_index=offset,
                category_raw=category_raw,
                category_norm=normalise_category(category_raw),
                product_url=product_url,
                product_name=product_name,
                # Nothing is fetched by default and no URL is required, so the row is
                # neither reachable nor unreachable — it was never a page to begin with.
                page_type=PageType.product,
                fetch_status=FetchStatus.not_attempted,
                fetch_note=(
                    None if product_url
                    else "No URL supplied; research runs from the product name and category."
                ),
                product_id=None,
                date_serial=None,
                date_number_format=None,
                date_value=None,
                go_live_raw=None,
                skip_reason=None if product_name else "No product name in this row.",
                brand=brand,
                brand_derived=bool(brand) and not supplied_brand,
                price_aed=read_price(cell(cells, price_col)),
                batch_no=clean_cell(cell(cells, batch_col)),
            )
        )

    return ParsedWorkbook(
        sheet_name=str(sheet.title),
        headers=tuple(headers),
        rows=tuple(rows),
        header_warnings=tuple(warnings),
        layout="template",
    )


def read_any_workbook(path: Path, sheet_name: str | None = None) -> ParsedWorkbook:
    """Read either input format, deciding from the headers."""
    workbook = openpyxl.load_workbook(path, data_only=True)
    sheet = workbook[sheet_name] if sheet_name else workbook[workbook.sheetnames[0]]
    headers = [clean_cell(c.value) for c in next(sheet.iter_rows(min_row=1, max_row=1), ())]
    if looks_like_template(headers):
        return read_template_workbook(path, sheet_name)
    return read_input_workbook(path, sheet_name)


def read_input_workbook(path: Path, sheet_name: str | None = None) -> ParsedWorkbook:
    workbook = openpyxl.load_workbook(path, data_only=True)
    sheet = workbook[sheet_name] if sheet_name else workbook[workbook.sheetnames[0]]

    header_cells = next(sheet.iter_rows(min_row=1, max_row=1), ())
    headers = tuple(clean_cell(c.value) for c in header_cells)
    columns, header_warnings = _column_map(tuple(c.value for c in header_cells))

    category_col = columns.get("Category")
    url_col = columns.get("Product URL")
    date_col = columns.get("Date")

    rows: list[ParsedRow] = []
    for offset, cells in enumerate(sheet.iter_rows(min_row=2), start=1):
        category_raw = clean_cell(cells[category_col].value) if category_col is not None else ""
        product_url = clean_cell(cells[url_col].value) if url_col is not None else ""

        if not category_raw and not product_url:
            continue  # genuinely blank spreadsheet row

        serial, number_format, date_value = (
            _read_date(cells[date_col]) if date_col is not None else (None, None, None)
        )
        classification = classify_url(product_url)
        skip_reason = None if product_url else "No product URL in this row."

        rows.append(
            ParsedRow(
                row_index=offset,
                category_raw=category_raw,
                category_norm=normalise_category(category_raw),
                product_url=product_url,
                product_name=derive_product_name(category_raw),
                page_type=classification.page_type,
                fetch_status=classification.fetch_status,
                fetch_note=classification.note,
                product_id=classification.product_id,
                date_serial=serial,
                date_number_format=number_format,
                date_value=date_value,
                go_live_raw=None,
                skip_reason=skip_reason,
                brand=derive_brand(derive_product_name(category_raw)),
                brand_derived=True,
            )
        )

    return ParsedWorkbook(
        sheet_name=str(sheet.title),
        headers=headers,
        rows=tuple(_disambiguate_names(rows)),
        header_warnings=header_warnings,
        layout="legacy",
    )


def _disambiguate_names(rows: list[ParsedRow]) -> list[ParsedRow]:
    """Give rows sharing a product name a distinct one derived from their URL.

    Without this, the seven `Smart Home` rows all generate the same title, which the
    uniqueness validator rejects and which would leave a third of the batch unexportable
    for a reason the input never actually forced. Rows whose URL yields no readable slug
    keep the category name and remain genuinely ambiguous — that is then a data-quality
    finding for the team, not something to paper over.
    """
    counts: dict[str, int] = {}
    for row in rows:
        key = row.product_name.casefold()
        counts[key] = counts.get(key, 0) + 1

    out: list[ParsedRow] = []
    for row in rows:
        if counts.get(row.product_name.casefold(), 0) > 1:
            derived = slug_name(row.product_url)
            if derived:
                out.append(replace(row, product_name=derived))
                continue
        out.append(row)
    return out


# Reading the seeded keyword volumes deliberately does NOT live here. A search volume may
# only originate inside `app.providers.keywords`, which owns the question of where volumes
# come from regardless of the storage format behind them — a spreadsheet for the fixture
# provider, HTTP for the live ones. `tests/test_no_llm_volumes.py` enforces that boundary,
# and it caught this function sitting in the wrong module.
# See `app.providers.keywords._fixture.read_keyword_seed`.
