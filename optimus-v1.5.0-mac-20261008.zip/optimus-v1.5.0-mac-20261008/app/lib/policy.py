"""Editorial and store policy — the knobs the content team would review.

Everything here is data, not logic, so a non-engineer can audit what the tool forbids and
what limits it enforces. Severity is assigned per rule rather than per validator, because
brief §6 says errors block export and warnings do not, and these rules do not all deserve
to block.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

Severity = Literal["error", "warning"]


@dataclass(frozen=True, slots=True)
class BannedRule:
    code: str
    pattern: str
    severity: Severity
    label: str
    reason: str
    # Whether the rule also applies to a keyword list. Most do not: keyword research is a
    # record of what people actually type, and "apple watch price in uae" is a real query
    # at 1,600 searches a month in the seed data. Banning it there would discard genuine
    # demand signal. Only rules about things we must never associate with the brand at all
    # — competitor trademarks — carry into keyword lists.
    applies_to_keywords: bool = False


# Brief §1 rule 3 and §6. Patterns are case-insensitive regexes applied to indexed fields.
#
# Price, tariff and stock claims are errors: they are the named defect the tool exists to
# remove, and they go stale in a way that misleads a customer reading a search result.
#
# Superlatives and availability language are warnings. They are weak copy and they date
# quickly, but they are not factual claims about money or stock, and blocking every
# instance of "latest" would reject most legitimate launch copy. A human decides.
BANNED_RULES: tuple[BannedRule, ...] = (
    BannedRule(
        code="BANNED_CURRENCY",
        pattern=r"\bAED\b|\bد\.إ|\bdirham",
        severity="error",
        label="currency reference",
        reason="Prices go stale and must not appear in an indexed field.",
    ),
    BannedRule(
        code="BANNED_RECURRING_PRICE",
        pattern=r"/\s*month|\bper\s+month\b|\bmonthly\b|\bp/m\b",
        severity="error",
        label="recurring price",
        reason="Tariff terms change; an indexed page must not quote them.",
    ),
    BannedRule(
        code="BANNED_INSTALMENT",
        pattern=r"\binstal?lment\b|\bEMI\b|\bpay\s+monthly\b|\b0%\s*(?:APR|interest)\b",
        severity="error",
        label="instalment plan",
        reason="Instalment terms are commercial conditions, not page content.",
    ),
    BannedRule(
        code="BANNED_PRICE_WORD",
        pattern=r"\bprice[sd]?\b|\bcost[s]?\b|\bdiscount\b|\bcashback\b|\b\d+%\s*off\b|\bsave\s+\d",
        severity="error",
        label="price or discount claim",
        reason="Promotional pricing must not be indexed.",
    ),
    BannedRule(
        code="BANNED_FREE_OFFER",
        pattern=r"\bfree\s+(?:delivery|shipping|gift|trial|data|minutes)\b|\bget\s+it\s+free\b",
        severity="error",
        label="free-offer claim",
        reason="Offers expire; the indexed page outlives them.",
    ),
    BannedRule(
        code="BANNED_STOCK",
        pattern=(
            r"\bin\s+stock\b|\bout\s+of\s+stock\b|\blimited\s+stock\b"
            r"|\bwhile\s+stocks?\s+last\b|\bsold\s+out\b|\bonly\s+\d+\s+left\b"
        ),
        severity="error",
        label="stock claim",
        reason="Stock state changes hourly and cannot be indexed truthfully.",
    ),
    BannedRule(
        code="BANNED_COMPETITOR",
        pattern=r"\bdu\.ae\b|\bVirgin\s+Mobile\b|\bVodafone\b|\bZain\b|\bSTC\b|\bOoredoo\b",
        severity="error",
        label="competitor trademark",
        reason="Competitor marks must not appear in e& copy.",
        applies_to_keywords=True,
    ),
    BannedRule(
        code="WARN_SUPERLATIVE",
        pattern=(
            r"\bbest\b|\bultimate\b|\bfastest\b|\bworld'?s\s+\w+est\b|\b#1\b"
            r"|\bunbeatable\b|\bperfect\b|\bnumber\s+one\b"
        ),
        severity="warning",
        label="unproven superlative",
        reason="Unproven claim. Keep it only if marketing can substantiate it.",
    ),
    BannedRule(
        code="WARN_AVAILABILITY",
        # "pre-order" was in this pattern and is ALSO one of the six action verbs the
        # guidelines name — "such as: Buy, Shop, Get, Pre-order, Explore, Discover". So
        # following the guideline, using the guideline's own example, earned a warning
        # from a rule of ours. The team's document wins; the rest of the pattern stands,
        # because "coming soon" and "available now" date a page in a way "pre-order"
        # does not.
        pattern=(
            r"\bcoming\s+soon\b|\bnow\s+available\b"
            r"|\bjust\s+launched\b|\bavailable\s+now\b"
        ),
        severity="warning",
        label="availability or timing claim",
        reason="Dates the page. Review before a launch window closes.",
    ),
)


# Brief §7. Apple's and Google's store field limits are hard store rules.
# `unit` matters: Apple's keyword field is measured in BYTES, not characters.
@dataclass(frozen=True, slots=True)
class StoreField:
    key: str
    store: Literal["apple", "play"]
    label: str
    limit: int
    unit: Literal["chars", "bytes"]
    indexed: bool
    note: str


STORE_FIELDS: tuple[StoreField, ...] = (
    StoreField("apple_name", "apple", "Apple app name", 30, "chars", True,
               "Highest indexing weight of any store field."),
    StoreField("apple_subtitle", "apple", "Apple subtitle", 30, "chars", True, "Indexed."),
    StoreField("apple_keywords", "apple", "Apple keyword field", 100, "bytes", True,
               "Measured in bytes. Arabic consumes roughly two bytes per character."),
    StoreField("apple_promo", "apple", "Apple promotional text", 170, "chars", False,
               "Not indexed. Conversion copy only."),
    StoreField("apple_description", "apple", "Apple description", 4000, "chars", False,
               "Not indexed. Conversion copy only."),
    StoreField("play_title", "play", "Play title", 30, "chars", True, "Indexed."),
    StoreField("play_short", "play", "Play short description", 80, "chars", True, "Indexed."),
    StoreField("play_full", "play", "Play full description", 4000, "chars", True,
               "Fully indexed. Worth writing keywords into."),
)

# The asymmetry that drives store copy strategy, per brief §7: on iOS the entire indexed
# budget is 160 characters across three fields, so repetition wastes it. On Play the long
# description is fully indexed and rewards keyword coverage.
APPLE_INDEXED_BUDGET_CHARS = 30 + 30 + 100
PLAY_INDEXED_BUDGET_CHARS = 30 + 80 + 4000


# Brief §7 explicitly flags these as placeholders pending the app team. They are surfaced
# here, labelled unconfirmed in the UI, and must not be presented as agreed limits.
@dataclass(frozen=True, slots=True)
class AppContentLimit:
    key: str
    label: str
    limit: int
    confirmed: bool


APP_CONTENT_LIMITS: tuple[AppContentLimit, ...] = (
    AppContentLimit("app_headline", "Screen headline", 40, False),
    AppContentLimit("app_subhead", "Screen subhead", 90, False),
    AppContentLimit("app_cta", "Call to action", 20, False),
)

APP_CONTENT_LIMITS_NOTE = (
    "Unconfirmed. These three limits are placeholders taken from the brief and have not "
    "been agreed with the app team. Do not treat them as approved."
)


BRAND_SUFFIX = " | e&"

# Brief §6: warn when the primary keyword is not inside the first 40% of the title.
PRIMARY_KEYWORD_HEAD_FRACTION = 0.4

# Brief §6 coverage map: upper bound on how often one term may occur in a field.
#
# Function words are excluded and a minimum repeat count applies. Without both, a normal
# 22-word description trips the rule for containing "the" twice, and a validation panel
# full of findings like that trains a reviewer to ignore the panel — which costs more than
# the rule gains.
MAX_TERM_DENSITY = 0.09
MIN_TERM_REPEATS = 3

DENSITY_STOPWORDS = frozenset({
    "a", "an", "and", "are", "as", "at", "be", "by", "can", "for", "from", "get", "has",
    "have", "in", "is", "it", "its", "of", "on", "or", "our", "that", "the", "their",
    "them", "then", "there", "these", "this", "to", "up", "with", "you", "your",
})

# Product families and model lines used by stale-generation detection. A curated list is
# safer than treating any trailing integer as a generation number.
PRODUCT_FAMILIES: tuple[str, ...] = ("iphone", "watch", "airpods", "ipad", "mac", "galaxy")
PRODUCT_LINES: tuple[str, ...] = ("ultra", "series", "se", "pro", "max", "air", "mini", "plus")


# ================================================================ SEO Copy Guidelines
#
# Source: "SEO Copy Guidelines_21Sep2026 v2.docx", supplied by the content team on
# 2026-09-28. Where these and the original brief disagree, these win — they are the team's
# current written standard and they are newer. Each divergence is recorded in
# DECISIONS.md §28.
#
# Encoded as data so a non-engineer can read what the tool enforces and check it against
# the document, rather than taking an engineer's word for it.


# --- Guideline: "Follow UK English spelling and conventions in titles and descriptions
# (e.g. colour, optimise, instalment, favourite), except where a brand name or product name
# is officially written in US spelling."
#
# The exception is the reason this is a mapping checked against context rather than a
# blanket find-and-replace: Oppo's ColorOS and Samsung's Galaxy Z Flip "Color Edition" are
# officially US-spelled, and correcting them would be an error, not a fix. The validator
# skips any match that falls inside the product name or brand.
UK_SPELLINGS: tuple[tuple[str, str], ...] = (
    ("color", "colour"),
    ("colors", "colours"),
    ("colored", "coloured"),
    ("installment", "instalment"),
    ("installments", "instalments"),
    ("favorite", "favourite"),
    ("favorites", "favourites"),
    ("optimize", "optimise"),
    ("optimized", "optimised"),
    ("customize", "customise"),
    ("customized", "customised"),
    ("personalize", "personalise"),
    ("personalized", "personalised"),
    ("organize", "organise"),
    ("prioritize", "prioritise"),
    ("maximize", "maximise"),
    ("minimize", "minimise"),
    ("analyze", "analyse"),
    ("recognize", "recognise"),
    ("realize", "realise"),
    ("center", "centre"),
    ("centers", "centres"),
    ("catalog", "catalogue"),
    ("fiber", "fibre"),
    ("aluminum", "aluminium"),
    ("jewelry", "jewellery"),
    ("gray", "grey"),
    ("defense", "defence"),
    ("traveling", "travelling"),
    ("behavior", "behaviour"),
    ("neighborhood", "neighbourhood"),
)


# --- Guideline: "Use action verbs that reflect search intent, such as: Buy, Shop, Get,
# Pre-order, Explore, Discover."
#
# A warning rather than an error: the list is given as examples ("such as"), so treating it
# as exhaustive would reject perfectly good copy that opens with a verb the document did
# not happen to name.
ACTION_VERBS: tuple[str, ...] = (
    "buy", "shop", "get", "pre-order", "preorder", "order", "explore", "discover",
    "find", "browse", "compare", "upgrade", "choose", "own", "experience",
)


# --- Guideline: "Every product description must mention the starting price in the second
# sentence. The second sentence must also mention SmartPay... Shop <Product Name> from
# AED <XXX> via SmartPay with e&."
#
# SmartPay is unconditional; the figure is not. A price appears only when a human supplied
# one, either in the input sheet or by typing it into the row. See DECISIONS.md §28 —
# the model is never permitted to produce a figure, and a price that does not match what a
# human supplied is a blocking error regardless of where it came from.
SMARTPAY_TERM = "SmartPay"
PRICE_SENTENCE_TEMPLATE = "Shop {product} from AED {price} via SmartPay with e&."
SMARTPAY_SENTENCE_TEMPLATE = "Shop {product} via SmartPay with e&."
CURRENCY_PREFIX = "AED"


def format_price(value: float) -> str:
    """`3499.0` -> `3,499`; `99.5` -> `99.50`.

    Thousands separated because that is how the guideline's own example reads, and decimals
    kept only when they carry information — "AED 3,499.00" in a 160-character budget spends
    three characters saying nothing.
    """
    if value == int(value):
        return f"{int(value):,}"
    return f"{value:,.2f}"


# --- Instruction from the content team, 2026-09-28: look up volumes for product, brand and
# category terms; do not look up volumes for specifications, colours or other attributes.
#
# The reasoning is sound — "pearl white" and "case size 42mm" carry no search demand, and
# pricing them wastes both API cost and screen space. What follows is the boundary, kept as
# patterns so it can be argued with.
#
# One known cost of the rule, recorded rather than silently absorbed: storage is the single
# attribute that behaves like a product term, because "iphone 17 512gb" is a real query.
# Under this rule its demand goes unmeasured. Moving storage out of this list is the only
# change needed to measure it.
SPEC_TERM_PATTERNS: tuple[tuple[str, str], ...] = (
    ("storage", r"\b\d+\s?(?:gb|tb|mb)\b"),
    ("memory", r"\bmemory\b|\bram\b|\bstorage\b"),
    ("dimension", r"\b\d+(?:\.\d+)?\s?(?:mm|cm|inch|inches|\"|')\b|\bcase\s+size\b"),
    ("resolution", r"\b\d+k\b|\b\d+p\b|\b\d+\s?mp\b|\b\d+\s?hz\b"),
    ("model_code", r"\b[a-z]{2,}\d{3,}[a-z0-9/\-]*\b"),
    ("generation_suffix", r"\(\s*\d+(?:st|nd|rd|th)\s+gen\.?\s*\)"),
)

# Colour and material words. Separate from the patterns above because they are a closed
# vocabulary rather than a shape, and because a few of them — titanium, ceramic — are also
# genuine product-line names ("Apple Watch Ultra Titanium"), so they are removed from
# keyword lookup but NOT from copy.
ATTRIBUTE_WORDS: frozenset[str] = frozenset({
    "white", "black", "silver", "gold", "blue", "red", "green", "pink", "purple",
    "grey", "gray", "midnight", "starlight", "graphite", "beige", "cream", "sand",
    "lavender", "mint", "yellow", "orange", "brown", "pearl", "rose", "space",
    "aluminium", "aluminum", "titanium", "ceramic", "stainless", "steel", "leather",
    "silicone", "fabric", "nylon", "glass", "plastic",
})


# --- The six buckets the content team currently produces by hand in ChatGPT, one prompt
# each. Reproduced here so the tool does the same job against the same structure, which is
# what makes its output reviewable by the people who do it manually today.
@dataclass(frozen=True, slots=True)
class KeywordBucket:
    key: str
    label: str
    prompt_hint: str
    # Whether terms in this bucket are sent to the volume provider. False means the bucket
    # is a business rule rather than a demand signal, and a missing number for it is
    # expected rather than a gap.
    priced: bool


KEYWORD_BUCKETS: tuple[KeywordBucket, ...] = (
    KeywordBucket("brand", "Brand", "The manufacturer: Apple, Samsung, Xiaomi.", True),
    KeywordBucket("product", "Product", "The specific model: iPhone 17, Razr 40 Ultra.", True),
    KeywordBucket("device", "Device type", "What kind of thing it is: foldable phone, robot vacuum.", True),
    KeywordBucket("category", "Category", "The shopping category: smartphones, wearables.", True),
    # A judgement call, flagged to the team: these are search phrases rather than product
    # attributes, and the manual process prices them before sorting, so they are priced
    # here too. Set `priced=False` to follow a stricter reading of the instruction.
    KeywordBucket("usp", "USP / intent", "Why someone buys: best camera phone, latest launch.", True),
    # Never priced. SmartPay is a standing commercial requirement with no meaningful search
    # demand; showing it with a null volume is the honest result, not a failed lookup.
    KeywordBucket("smartpay", "SmartPay", "Always included. A business rule, not a demand signal.", False),
)

BUCKETS_BY_KEY: dict[str, KeywordBucket] = {b.key: b for b in KEYWORD_BUCKETS}
PRICED_BUCKETS: frozenset[str] = frozenset(b.key for b in KEYWORD_BUCKETS if b.priced)

# How many seed terms the model proposes per row. DataForSEO's keywords_for_keywords
# endpoint accepts at most 20 seeds per request and expands them into the long tail, so
# there is no benefit to asking the model for more than it can send.
MAX_SEEDS_PER_ROW = 20

# How many expanded terms survive onto the screen, highest volume first. The endpoint can
# return thousands; a reviewer can read a dozen.
MAX_KEYWORDS_SHOWN = 12

# Location phrasing, which copy must not add on its own.
#
# The tool used to put "in the UAE" into almost every title and description, and it was
# the tool's idea, not a requirement. Nothing in the brief or the SEO Copy Guidelines asks
# for it: the brief names the UAE to say whose team this is and which region the model
# must be hosted in, and the guidelines' rules are spelling, an action verb, SmartPay,
# the character limits, keyword placement and uniqueness. No geography.
#
# What it produced was bad copy — "airpodsmax2 Apple Headphones in the UAE" — and it spent
# characters twice, since the phrase usually landed in the title AND the description. The
# page already belongs to a UAE store; saying so is a waste of a 60-character budget.
#
# So a location may appear only where a person put one: inside a keyword they tiered, or
# in text they typed. `no_unrequested_location` enforces that.
#
# Deliberately NOT in this list: "emirates" on its own, which is a brand name in this
# market ("Emirates" the airline, "Etisalat by e&"), and "gulf", which appears in product
# names. Both would catch copy that is not making a geographic claim at all.
LOCATION_PATTERN = (
    r"\bu\.?\s?a\.?\s?e\b|\bunited\s+arab\s+emirates\b|\bdubai\b|\babu\s+dhabi\b"
    r"|\bsharjah\b|\bajman\b|\bfujairah\b|\bras\s+al\s+khaimah\b|\bumm\s+al\s+quwain\b"
    r"|\bmiddle\s+east\b"
)

# How many rows start work immediately, and how many each scroll releases.
#
# Eight because it fills a screen without filling the queue: the server runs three rows at
# a time, so eight is a couple of waves rather than a backlog, and the reader sees
# something finish while the rest are still going. A batch at or under this size behaves
# exactly as it did before lazy loading existed — everything starts at once.
ROWS_PER_PAGE = 8

# How many selling points are kept per row.
#
# Six because each one is a claim a person has to read and take responsibility for, and a
# list long enough to skim is a list that gets ticked without being read. The limit is on
# what is STORED, not on what is asked for: a model returning more has the surplus dropped
# rather than the row rejected.
MAX_USPS = 6

# How long one may be. A USP is meant to be liftable into a 160-character description, so
# a sentence that cannot fit inside one is not a USP.
MAX_USP_CHARS = 80

# How many seeds are used as the root of an expansion, out of the twenty that get priced.
#
# Measured: twenty seeds returned 13,229 ideas and took 36 seconds for one row. The extra
# seeds were not buying relevance, they were buying noise — the broad ones especially,
# which expand into a whole category rather than a product. Four product-level seeds
# cover the phrasings people actually use for one item.
MAX_EXPANSION_SEEDS = 4

# Sent as the request's `limit`, and measured NOT to be honoured by the Google Ads
# keywords-for-keywords endpoint: asking for 120 still returned 2,483. Kept because it
# costs nothing and a future endpoint may respect it, but the real lever on response size
# is `MAX_EXPANSION_SEEDS` above — narrowing the seeds took one row from 13,229 ideas and
# 36 seconds to 2,483 and 10.
EXPANSION_LIMIT = 120
