"""SERP surface specifications — all values approximate and configurable, per brief §6.

Two different pixel models live here, because titles and descriptions truncate differently:

  * A title renders on ONE line and is clipped at the container's width. A single-line
    advance-width budget is the right model.
  * A description WRAPS and is clipped after a line count. Its real limit is
    container_px x max_lines, not a single-line width.

The brief gives only single-line figures (~920px desktop, ~680px mobile for descriptions).
Those do not reconcile with its own character guides at 14px Arial, where the mean advance
is about 7px: 920px holds roughly 131 characters, short of the stated 155 upper guide, and
680px holds roughly 97, short of the stated "first ~120 chars must fit". §6 calls these
values approximate and configurable, so both models are kept rather than one being quietly
discarded — `total_px_budget` holds the brief's figures verbatim and is what the pixelLimit
validator gates on, while `container_px` x `max_lines` drives the SERP preview's truncation
mark, which is the visually honest representation. Mobile is deliberately given a smaller
wrapped budget than desktop (800px vs 1200px) to preserve the brief's ordering; real mobile
SERPs often show a third line, which is why `max_lines` is configuration and not a constant.
See DECISIONS.md.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

FieldKind = Literal["title", "description"]
Device = Literal["desktop", "mobile"]


@dataclass(frozen=True, slots=True)
class Surface:
    key: str
    kind: FieldKind
    device: Device
    font_px: float
    total_px_budget: float
    container_px: float
    max_lines: int
    char_guide_min: int
    char_guide_max: int
    char_hard_limit: int

    @property
    def wrapped_px_budget(self) -> float:
        return self.container_px * self.max_lines


TITLE_DESKTOP = Surface(
    key="title_desktop",
    kind="title",
    device="desktop",
    font_px=20.0,
    total_px_budget=600.0,
    container_px=600.0,
    max_lines=1,
    char_guide_min=50,
    char_guide_max=60,
    char_hard_limit=60,
)

TITLE_MOBILE = Surface(
    key="title_mobile",
    kind="title",
    device="mobile",
    font_px=20.0,
    total_px_budget=460.0,
    container_px=460.0,
    max_lines=1,
    char_guide_min=50,
    char_guide_max=60,
    char_hard_limit=60,
)

# The description budgets are the WRAPPED area, container width x line count, not the
# brief's single-line figures of 920px and 680px.
#
# Those figures were quietly the binding constraint. At 14px Arial the mean advance is
# about 7px, so 920px is roughly 131 characters — which means a description obeying the
# team's own written rule of "160 characters or fewer" failed on pixels instead, and the
# tool rejected copy the guidelines explicitly permit. A limit that overrides the stated
# rule without saying so is worse than no limit.
#
# 600px x 2 lines is the area Google actually renders a desktop description into, and it
# comfortably holds 160 characters, so the two gates now agree about what fits. Pixel
# measurement still earns its place: it catches text that is wide for its length, which
# is the case a character count cannot see. The brief calls these values "approximate and
# configurable"; this is that configuration. DECISIONS.md §28.
DESCRIPTION_DESKTOP = Surface(
    key="description_desktop",
    kind="description",
    device="desktop",
    font_px=14.0,
    total_px_budget=1200.0,
    container_px=600.0,
    max_lines=2,
    char_guide_min=120,
    char_guide_max=155,
    char_hard_limit=160,
)

DESCRIPTION_MOBILE = Surface(
    key="description_mobile",
    kind="description",
    device="mobile",
    font_px=14.0,
    total_px_budget=800.0,
    container_px=400.0,
    max_lines=2,
    char_guide_min=120,
    char_guide_max=155,
    char_hard_limit=160,
)

SURFACES: dict[str, Surface] = {
    s.key: s
    for s in (TITLE_DESKTOP, TITLE_MOBILE, DESCRIPTION_DESKTOP, DESCRIPTION_MOBILE)
}

# Which surface gates each Tier 1 field. Both devices are reported in the UI; the
# desktop surface is the one that blocks export, because it is the wider budget and
# therefore the weaker claim — failing it means the copy is too long everywhere.
GATING_SURFACE: dict[str, Surface] = {
    "meta_title_en": TITLE_DESKTOP,
    "meta_description_en": DESCRIPTION_DESKTOP,
}

PREVIEW_SURFACES: dict[str, tuple[Surface, Surface]] = {
    "meta_title_en": (TITLE_DESKTOP, TITLE_MOBILE),
    "meta_description_en": (DESCRIPTION_DESKTOP, DESCRIPTION_MOBILE),
}
