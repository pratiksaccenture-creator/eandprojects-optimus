"""Text normalisation shared by keyword handling, validation and grouping.

Brief §3 requires categories to be normalised for grouping while the original is preserved
for display, and the reference keyword cells are full of trailing spaces, doubled spaces and
case variants that must collapse to one term when deduplicating.
"""

from __future__ import annotations

import unicodedata

import regex

_WHITESPACE = regex.compile(r"\s+")
_NON_ALNUM = regex.compile(r"[^\p{L}\p{N}]+")


def collapse_spaces(text: str) -> str:
    return str(_WHITESPACE.sub(" ", text)).strip()


def clean_cell(value: object) -> str:
    """Coerce a spreadsheet cell to a trimmed string.

    Whitespace-only cells become empty — the reference workbook has a cell holding a single
    space (`keywords!F15`) which must not be mistaken for content.
    """
    if value is None:
        return ""
    return collapse_spaces(str(value))


def normalise_term(term: str) -> str:
    """Canonical form for comparing and deduplicating keyword terms.

    Case-insensitive, whitespace-collapsed and NFC-normalised, so `apple watch `,
    `Apple Watch` and `apple  watch` are one term.
    """
    return collapse_spaces(unicodedata.normalize("NFC", term)).casefold()


def normalise_category(category: str) -> str:
    """Canonical form for grouping categories.

    Collapses punctuation and case so `Devices - Iphone Family`, `Devices - iPhone family`
    and `devices  iphone  family` group together.
    """
    folded = unicodedata.normalize("NFC", category).casefold()
    return collapse_spaces(_NON_ALNUM.sub(" ", folded))


def split_keyword_cell(cell: str) -> list[str]:
    """Split a comma-separated keyword cell, preserving order and dropping empties.

    Duplicates are deliberately NOT removed — the duplication is a defect the validators
    must be able to see and report.
    """
    return [part for raw in cell.split(",") if (part := collapse_spaces(raw))]


def dedupe_terms(terms: list[str]) -> list[str]:
    """First-wins deduplication on the normalised form, preserving original casing."""
    seen: set[str] = set()
    out: list[str] = []
    for term in terms:
        key = normalise_term(term)
        if key and key not in seen:
            seen.add(key)
            out.append(term)
    return out


def duplicate_terms(terms: list[str]) -> dict[str, int]:
    """Normalised term -> occurrence count, for terms appearing more than once."""
    counts: dict[str, int] = {}
    for term in terms:
        key = normalise_term(term)
        if key:
            counts[key] = counts.get(key, 0) + 1
    return {term: n for term, n in sorted(counts.items()) if n > 1}
