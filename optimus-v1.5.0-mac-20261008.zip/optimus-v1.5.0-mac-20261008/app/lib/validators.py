"""The validator set — brief §6.

Every rule here is a pure function. Nothing touches the database, so every one is unit
testable against literal inputs. Brief §6 is explicit that a prompt asking for "under 60
characters" is a suggestion and only a validator is a rule.

Two tiers exist because some rules cannot be decided from one field:

  FieldValidator   (text, FieldContext) -> [Finding]      decidable from one string
  BatchValidator   (BatchSnapshot)      -> [Finding]      needs every row, or the registry

`brandSuffixPolicy` spans both: the batch decides once whether ` | e&` is applied, then
each row is checked for consistency against that decision.
"""

from __future__ import annotations

import json
import unicodedata
from dataclasses import dataclass, field as dc_field
from typing import Callable, Literal, Mapping, Sequence

import regex

from app.lib import limits, normalise
from app.lib.policy import (
    ACTION_VERBS,
    BANNED_RULES,
    BRAND_SUFFIX,
    CURRENCY_PREFIX,
    DENSITY_STOPWORDS,
    LOCATION_PATTERN,
    MAX_TERM_DENSITY,
    MIN_TERM_REPEATS,
    PRIMARY_KEYWORD_HEAD_FRACTION,
    PRODUCT_FAMILIES,
    PRODUCT_LINES,
    SMARTPAY_TERM,
    STORE_FIELDS,
    UK_SPELLINGS,
    BannedRule,
    Severity,
)
from app.lib.surfaces import Surface

# ---------------------------------------------------------------- findings


@dataclass(frozen=True, slots=True, order=True)
class Finding:
    code: str
    severity: Severity
    message: str
    field: str

    @property
    def blocks_export(self) -> bool:
        return self.severity == "error"


def has_errors(findings: Sequence[Finding]) -> bool:
    return any(f.severity == "error" for f in findings)


def sort_findings(findings: Sequence[Finding]) -> list[Finding]:
    """Deterministic order, so the validation log and export bytes are reproducible."""
    return sorted(findings, key=lambda f: (f.field, f.severity, f.code, f.message))


# ---------------------------------------------------------------- product identity

_YEAR_IN_PARENS = regex.compile(r"\((?:19|20)\d{2}\)")
_UNIT_NUMBER = regex.compile(
    r"\b\d+\s*(?:gb|tb|mb|mm|cm|hz|khz|mhz|ghz|mp|mah|wh|w|hrs?|hours?|inch|in|g)\b",
    regex.IGNORECASE,
)
_WIFI = regex.compile(r"wi-?fi\s*\d+", regex.IGNORECASE)
_STANDALONE_NUMBER = regex.compile(r"(?<!\w)(\d{1,2})(?!\w)")


@dataclass(frozen=True, slots=True)
class ProductIdentity:
    """What a product name tells us, parsed conservatively.

    A generation is not "any trailing integer": `128GB`, `45mm`, `5G` and `Wi-Fi 7` all
    contain integers that are not generations, and `SE`, `XS` and `Plus` are generations
    that are not integers. Anything uncertain yields `None` rather than a guess.
    """

    family: str | None = None
    line: str | None = None
    generation: int | None = None

    @property
    def is_known(self) -> bool:
        return self.family is not None and self.generation is not None


def parse_identity(product_name: str) -> ProductIdentity:
    if not product_name:
        return ProductIdentity()

    # NFKC folds Arabic-Indic digits to ASCII so ٤ parses as 4.
    text = unicodedata.normalize("NFKC", product_name)
    text = _YEAR_IN_PARENS.sub(" ", text)
    folded = text.casefold()

    family = next((f for f in PRODUCT_FAMILIES if f in folded), None)

    # Collect every model-line token present, ordered as it appears, so "iPhone 18 Pro Max"
    # yields "pro max" rather than just "pro".
    found: list[tuple[int, str]] = []
    for token in PRODUCT_LINES:
        match = regex.search(rf"\b{regex.escape(token)}\b", folded)
        if match:
            found.append((match.start(), token))
    line = " ".join(t for _, t in sorted(found)) or None

    stripped = _WIFI.sub(" ", folded)
    stripped = _UNIT_NUMBER.sub(" ", stripped)
    number = _STANDALONE_NUMBER.search(stripped)
    generation = int(number.group(1)) if number else None

    return ProductIdentity(family=family, line=line, generation=generation)


def _generation_references(text: str, identity: ProductIdentity) -> set[int]:
    """Generation numbers mentioned in `text` for the SAME family and line as `identity`.

    Only same-line comparisons are made. Cross-line comparison is semantically invalid:
    an Apple Watch Ultra 2 is newer than a Series 9, so "lower number" means nothing
    across lines.
    """
    folded = normalise.normalise_term(text)
    folded = _WIFI.sub(" ", folded)
    folded = _UNIT_NUMBER.sub(" ", folded)

    patterns: list[str] = []
    if identity.line:
        esc = regex.escape(identity.line)
        patterns += [rf"\b{esc}\s+(\d{{1,2}})\b", rf"\b(\d{{1,2}})\s+{esc}\b"]
    if identity.family:
        patterns.append(rf"\b{regex.escape(identity.family)}\s+(\d{{1,2}})\b")

    out: set[int] = set()
    for pattern in patterns:
        for match in regex.finditer(pattern, folded):
            out.add(int(match.group(1)))
    return out


# ---------------------------------------------------------------- field context


@dataclass(frozen=True, slots=True)
class FieldContext:
    field: str
    row_index: int
    locale: str = "en"
    surface: Surface | None = None
    char_limit: int | None = None
    # True means "at most N", which is what both the SEO Copy Guidelines ("60 characters
    # or fewer", "160 characters or fewer") and the app store limits say. False means
    # "under N", the older reading taken from the spreadsheet's `<60` / `<160` column
    # headers. The guidelines are the team's current standard, so inclusive is the default.
    char_limit_inclusive: bool = True
    byte_limit: int | None = None
    product_name: str = ""
    brand: str = ""
    identity: ProductIdentity = dc_field(default_factory=ProductIdentity)
    primary_keyword: str | None = None
    secondary_keywords: tuple[str, ...] = ()
    # The terms a person put a tier on, which is a narrower thing than
    # `secondary_keywords` above — that is every approved term on the row. Used by
    # `no_unrequested_location`, where the question is not "is this term available?" but
    # "did a human ask for this?".
    requested_terms: tuple[str, ...] = ()
    # True when the text being validated was typed by a person rather than generated.
    # A rule that exists to stop the MODEL adding something must not then refuse the same
    # words from the human it defers to.
    human_edited: bool = False
    brand_suffix_applied: bool | None = None
    is_indexed: bool = True
    tier: Literal[1, 2] = 1

    # The price a human supplied for this row, already formatted ("3,499"), or None.
    #
    # This is the ONLY way a figure may legally appear in an indexed field. It is carried
    # on the context rather than read from configuration so that the permission is scoped
    # to one row and one number: a price that does not match this string stays a blocking
    # error, whoever produced it. See `no_banned_terms` and `price_matches_supplied`.
    allowed_price: str | None = None


FieldValidator = Callable[[str, FieldContext], list[Finding]]


# ---------------------------------------------------------------- universal validators


def char_limit(text: str, ctx: FieldContext) -> list[Finding]:
    """Hard character ceiling, measured the way Excel measures it.

    Inclusivity is not cosmetic, and the answer changed when the SEO Copy Guidelines
    arrived. They say "Keep meta titles at 60 characters or fewer" and "Keep meta
    descriptions at 160 characters or fewer" — at most, not under. App store limits read
    the same way: Apple accepts a 30-character subtitle, so failing one would invent a rule
    the store does not have.

    So inclusive is the default. The older exclusive reading came from the team's own
    column headers, `Character count (<60)` and `(<160)`, under which the reference file's
    160-character description was a defect. Under the guidelines it is compliant.
    `char_limit_inclusive=False` restores the stricter reading. DECISIONS.md §28.
    """
    ceiling = ctx.char_limit if ctx.char_limit is not None else (
        ctx.surface.char_hard_limit if ctx.surface else None
    )
    if ceiling is None:
        return []
    count = limits.char_count(text)
    over = count > ceiling if ctx.char_limit_inclusive else count >= ceiling
    if over:
        allowance = (
            f"a limit of {ceiling}" if ctx.char_limit_inclusive
            else f"a limit of under {ceiling}"
        )
        return [
            Finding(
                code="CHAR_LIMIT",
                severity="error",
                message=f"Too long: {count} characters against {allowance}.",
                field=ctx.field,
            )
        ]
    if ctx.surface and count < ctx.surface.char_guide_min:
        # Reported, not prescribed.
        #
        # The brief calls 50-60 and 120-155 a "Character guide", "all approximate and
        # configurable". This used to read "50-60 uses the space available", which is an
        # instruction, and the prompt carried a matching "aim for 50-60" — so a compliant
        # 45-character title was nagged for being short, and the model's cheapest way to
        # satisfy the nag was filler. "in the UAE" was the filler nearest to hand.
        #
        # The ceiling is the rule and it is an error. This is information: here is how much
        # of the rendered space you are using, decide if that is what you wanted.
        return [
            Finding(
                code="CHAR_SHORT",
                severity="warning",
                message=(
                    f"Uses {count} of the {ctx.surface.char_hard_limit} characters "
                    f"available (guide: {ctx.surface.char_guide_min}-"
                    f"{ctx.surface.char_guide_max}). Fine if the copy says what it needs "
                    "to — do not pad it."
                ),
                field=ctx.field,
            )
        ]
    return []


def byte_limit(text: str, ctx: FieldContext) -> list[Finding]:
    """Byte ceiling. Decisive for Apple's keyword field once Arabic arrives."""
    if ctx.byte_limit is None:
        return []
    count = limits.byte_count(text)
    if count > ctx.byte_limit:
        chars = limits.char_count(text)
        return [
            Finding(
                code="BYTE_LIMIT",
                severity="error",
                message=(
                    f"Too long: {count} bytes against a limit of {ctx.byte_limit}. "
                    f"The field holds {chars} characters — this limit is measured in "
                    "bytes, and non-Latin characters cost more than one byte each."
                ),
                field=ctx.field,
            )
        ]
    return []


def pixel_limit(text: str, ctx: FieldContext) -> list[Finding]:
    """Rendered-width ceiling.

    Google truncates on width, not character count, so this gate catches a title that
    passes the character limit while still clipping on screen.
    """
    if ctx.surface is None:
        return []
    if ctx.locale.startswith("ar"):
        return [
            Finding(
                code="PIXEL_UNSUPPORTED_LOCALE",
                severity="warning",
                message=(
                    "Pixel width not checked: per-character widths are not valid for "
                    "Arabic, which needs contextual shaping."
                ),
                field=ctx.field,
            )
        ]
    width, missing = advance_for(text, ctx.surface)
    out: list[Finding] = []
    if width > ctx.surface.total_px_budget:
        out.append(
            Finding(
                code="PIXEL_LIMIT",
                severity="error",
                message=(
                    f"Too wide: about {width:.0f}px against a budget of "
                    f"{ctx.surface.total_px_budget:.0f}px, so it will be cut off on "
                    f"{ctx.surface.device}."
                ),
                field=ctx.field,
            )
        )
    if missing:
        out.append(
            Finding(
                code="PIXEL_UNKNOWN_GLYPHS",
                severity="warning",
                message=(
                    f"{missing} character(s) are not in the font metrics table, so the "
                    "width estimate is less reliable here."
                ),
                field=ctx.field,
            )
        )
    return out


def advance_for(text: str, surface: Surface) -> tuple[float, int]:
    return limits.advance_width(text, surface.font_px)


def primary_keyword_present(text: str, ctx: FieldContext) -> list[Finding]:
    if not ctx.primary_keyword:
        return []
    haystack = normalise.normalise_term(text)
    needle = normalise.normalise_term(ctx.primary_keyword)
    if needle not in haystack:
        return [
            Finding(
                code="PRIMARY_KEYWORD_MISSING",
                severity="error",
                message=f'Primary keyword "{ctx.primary_keyword}" does not appear.',
                field=ctx.field,
            )
        ]
    position = haystack.index(needle)
    if haystack and position / len(haystack) > PRIMARY_KEYWORD_HEAD_FRACTION:
        return [
            Finding(
                code="PRIMARY_KEYWORD_LATE",
                severity="warning",
                message=(
                    f'Primary keyword "{ctx.primary_keyword}" appears late; the first '
                    f"{int(PRIMARY_KEYWORD_HEAD_FRACTION * 100)}% of the field carries "
                    "more weight."
                ),
                field=ctx.field,
            )
        ]
    return []


def sanctioned_price_fragment(ctx: FieldContext) -> str:
    return f"{CURRENCY_PREFIX} {ctx.allowed_price}" if ctx.allowed_price else ""


def _redact_sanctioned_price(text: str, ctx: FieldContext) -> str:
    """Remove the one price a human authorised, so the banned-term rules see the rest.

    The SEO Copy Guidelines require a starting price in the second sentence; the brief
    forbids prices outright. This is where the two are reconciled, and the reconciliation
    is deliberately narrow: exactly the string a human supplied for this row is removed
    before the rules run, and everything else stays forbidden.

    So "Shop the iPhone 17 from AED 3,499 via SmartPay with e&." passes when 3,499 is the
    supplied figure, while "...from AED 3,299..." fails, "...AED 3,499 or AED 99/month..."
    fails on the second figure, and any price at all fails on a row where nobody supplied
    one. The model cannot talk its way past this: it has no way to change `allowed_price`.
    """
    fragment = sanctioned_price_fragment(ctx)
    if not fragment:
        return text
    return str(regex.sub(regex.escape(fragment), " ", text, flags=regex.IGNORECASE))


def no_banned_terms(text: str, ctx: FieldContext) -> list[Finding]:
    if not ctx.is_indexed:
        return []
    haystack = _redact_sanctioned_price(text, ctx)
    out: list[Finding] = []
    for rule in BANNED_RULES:
        match = regex.search(rule.pattern, haystack, regex.IGNORECASE)
        if match:
            out.append(
                Finding(
                    code=rule.code,
                    severity=rule.severity,
                    message=f'Contains a {rule.label} ("{match.group(0).strip()}"). {rule.reason}',
                    field=ctx.field,
                )
            )
    return out


def no_unrequested_location(text: str, ctx: FieldContext) -> list[Finding]:
    """A location may appear only where a person put one.

    The tool used to write "in the UAE" into nearly every title and description, and it
    was the tool's own idea — three instructions of mine, none of them a requirement:
    `COPY_SYSTEM` described e& as a retailer "in the United Arab Emirates", every prompt
    carried a "Market: United Arab Emirates" line, and a money rule told the model that for
    "<product> price in uae" it should "write about the product in the UAE".

    Nothing in the brief or the SEO Copy Guidelines asks for it. The brief names the UAE to
    say whose team this is and which region the model must be hosted in; the guidelines
    cover spelling, an action verb, SmartPay, the limits, keyword placement and uniqueness.

    And it was bad copy. "airpodsmax2 Apple Headphones in the UAE" reads like a template,
    and the phrase usually appeared in the title AND the description — spending twice from
    a 60-character budget to tell a reader something the storefront already tells them.

    Two ways a location is legitimate, both of them a person's decision:

      * a keyword they tiered contains one, so "projector in uae" is what the page targets;
      * they typed it themselves, which `human_edited` carries.

    An error rather than a warning, so the regeneration loop removes it: a warning would
    report the phrase and leave it in the copy, which is the opposite of the ask.
    """
    if not ctx.is_indexed:
        return []
    match = regex.search(LOCATION_PATTERN, text, regex.IGNORECASE)
    if match is None:
        return []
    if ctx.human_edited:
        return []
    if any(
        regex.search(LOCATION_PATTERN, term, regex.IGNORECASE)
        for term in ctx.requested_terms
    ):
        return []
    found = match.group(0).strip()
    return [
        Finding(
            code="UNREQUESTED_LOCATION",
            severity="error",
            message=(
                f'Adds a location ("{found}") that nobody asked for. Say where only when '
                "a keyword you are targeting says it, or when you type it yourself."
            ),
            field=ctx.field,
        )
    ]


def banned_in_copy(term: str) -> BannedRule | None:
    """The rule that bars this term from an indexed field, or None if none does.

    The same rule set as `no_banned_terms`, asked the other way round and about a keyword
    rather than a finished field. Keyword tiering needs this: a term that can never legally
    appear in an indexed field must never be handed to the model as one to include.

    Without it the tool contradicted itself. Research measured "projector price in uae" at
    1,900 searches a month — real demand, correctly recorded — auto-tiering promoted it to
    secondary on volume alone, the copy prompt asked the model to work the secondaries in,
    the model obliged, and `no_banned_terms` then failed the row for containing "price".
    Three parts each behaving correctly, producing a guaranteed failure. Volume says how
    many people search a term; it says nothing about whether we may publish it.

    Warnings are deliberately not consulted. A superlative in a keyword is a term a human
    may still choose to use carefully, and it does not block export; only the rules that do
    block are grounds for keeping a term away from the prompt.

    There is no sanctioned-price redaction here, unlike `no_banned_terms`. A keyword is
    never the field a human authorised a figure for, so "AED" in a keyword is always a bar.
    """
    for rule in BANNED_RULES:
        if rule.severity != "error":
            continue
        if regex.search(rule.pattern, term, regex.IGNORECASE):
            return rule
    return None


# ---------------------------------------------------------------- SEO Copy Guidelines
#
# One validator per guideline, named after it, so the content team can read this list
# against their own document and see what is enforced and what is not.


def uk_english(text: str, ctx: FieldContext) -> list[Finding]:
    """Guideline: UK spelling, "except where a brand name or product name is officially
    written in US spelling".

    That exception is the whole difficulty. Oppo ships ColorOS and Samsung has sold a
    "Color Edition"; correcting those would introduce an error rather than remove one. So a
    match is only reported when it falls outside the product name and the brand — the two
    places the guideline says to leave alone.
    """
    protected = f"{ctx.product_name} {ctx.brand}".lower()
    out: list[Finding] = []
    for us, uk in UK_SPELLINGS:
        for match in regex.finditer(rf"\b{regex.escape(us)}\b", text, regex.IGNORECASE):
            if match.group(0).lower() in protected:
                continue
            out.append(
                Finding(
                    code="US_SPELLING",
                    severity="warning",
                    message=f'"{match.group(0)}" is US spelling; UK English asks for "{uk}".',
                    field=ctx.field,
                )
            )
            break  # one finding per word is enough to act on
    return out


def action_verb_present(text: str, ctx: FieldContext) -> list[Finding]:
    """Guideline: "Use action verbs that reflect search intent, such as: Buy, Shop, Get,
    Pre-order, Explore, Discover."

    A warning, not an error, and only on descriptions. The document says "such as", so the
    list is illustrative — treating it as exhaustive would reject good copy that opens with
    a verb the document happens not to name. A title at 60 characters often cannot afford
    a verb at all without losing the keyword, and the guideline's front-loading rule is
    about the keyword, not the verb.
    """
    if ctx.field != "meta_description_en":
        return []
    lowered = f" {text.lower()} "
    if any(f" {verb} " in lowered or lowered.lstrip().startswith(verb) for verb in ACTION_VERBS):
        return []
    return [
        Finding(
            code="NO_ACTION_VERB",
            severity="warning",
            message=(
                "No action verb. The guidelines ask for intent-led language such as Shop, "
                "Buy, Get, Explore or Discover."
            ),
            field=ctx.field,
        )
    ]


def smartpay_mentioned(text: str, ctx: FieldContext) -> list[Finding]:
    """Guideline: "The second sentence must also mention SmartPay, e&'s instalment option."

    Unconditional, unlike the price — SmartPay is a standing commercial requirement that
    does not go stale, so it belongs in every description whether or not a figure was
    supplied.
    """
    if ctx.field != "meta_description_en":
        return []
    if SMARTPAY_TERM.lower() in text.lower():
        return []
    return [
        Finding(
            code="NO_SMARTPAY",
            severity="warning",
            message="Does not mention SmartPay, which the guidelines require in every description.",
            field=ctx.field,
        )
    ]


def price_sentence(text: str, ctx: FieldContext) -> list[Finding]:
    """Guideline: "Every product description must mention the starting price in the second
    sentence."

    Two different failures, deliberately at different severities:

      * A price was supplied and the copy does not use it — a WARNING. The copy is still
        publishable; it just does not meet this guideline, and the reviewer should see that
        rather than be blocked by it.
      * No price was supplied at all — also a warning, and it names the fix, because the
        team chose to make the price optional per row.

    A price that was NOT supplied but appears anyway is not handled here. That is an error,
    and it is caught by `no_banned_terms`, which only ever forgives the exact figure a
    human entered.
    """
    if ctx.field != "meta_description_en":
        return []
    if not ctx.allowed_price:
        return [
            Finding(
                code="NO_PRICE_SUPPLIED",
                severity="warning",
                message=(
                    "No price supplied for this row, so the description cannot meet the "
                    "second-sentence price rule. Add one to the input sheet, or use "
                    "Regenerate with price."
                ),
                field=ctx.field,
            )
        ]
    if sanctioned_price_fragment(ctx).lower() not in text.lower():
        return [
            Finding(
                code="PRICE_NOT_USED",
                severity="warning",
                message=(
                    f"A price of {sanctioned_price_fragment(ctx)} was supplied but does "
                    "not appear in the description."
                ),
                field=ctx.field,
            )
        ]
    return []


def no_banned_terms_in_keywords(text: str, ctx: FieldContext) -> list[Finding]:
    """Banned-term rules that carry into a keyword list.

    Deliberately much narrower than `no_banned_terms`. A keyword list records what people
    actually search for, so price and availability language belongs there — the seed data
    contains "apple watch price in uae" at 1,600 searches a month, which is real demand,
    not a defect. Only rules about associations we must never make at all, meaning
    competitor trademarks, apply here.
    """
    out: list[Finding] = []
    for rule in BANNED_RULES:
        if not rule.applies_to_keywords:
            continue
        match = regex.search(rule.pattern, text, regex.IGNORECASE)
        if match:
            out.append(
                Finding(
                    code=rule.code,
                    severity=rule.severity,
                    message=f'Contains a {rule.label} ("{match.group(0).strip()}"). {rule.reason}',
                    field=ctx.field,
                )
            )
    return out


def no_stale_generation(text: str, ctx: FieldContext) -> list[Finding]:
    identity = ctx.identity
    if identity.generation is None:
        if ctx.product_name:
            return []
        return [
            Finding(
                code="STALE_GEN_NOT_CHECKED",
                severity="warning",
                message=(
                    "Generation not checked: no product name is known for this row, so a "
                    "stale model number could not be ruled out."
                ),
                field=ctx.field,
            )
        ]
    stale = sorted(g for g in _generation_references(text, identity) if g < identity.generation)
    if not stale:
        return []
    listed = ", ".join(str(g) for g in stale)
    return [
        Finding(
            code="STALE_GENERATION",
            severity="error",
            message=(
                f"Mentions an older generation ({listed}) on a "
                f"{ctx.product_name} row. Remove the superseded model number."
            ),
            field=ctx.field,
        )
    ]


def no_double_space(text: str, ctx: FieldContext) -> list[Finding]:
    if "  " in text:
        return [
            Finding(
                code="DOUBLE_SPACE",
                severity="error",
                message="Contains a double space.",
                field=ctx.field,
            )
        ]
    return []


def no_trailing_whitespace(text: str, ctx: FieldContext) -> list[Finding]:
    if text != text.strip():
        return [
            Finding(
                code="EDGE_WHITESPACE",
                severity="error",
                message="Starts or ends with a space.",
                field=ctx.field,
            )
        ]
    return []


def no_glued_em_dash(text: str, ctx: FieldContext) -> list[Finding]:
    """An em or en dash needs space around it, or it reads as one run-on word."""
    match = regex.search(r"\w[—–]|[—–]\w", text)
    if match:
        return [
            Finding(
                code="GLUED_DASH",
                severity="error",
                message=f'Dash is glued to a word ("{match.group(0)}"). Add spaces around it.',
                field=ctx.field,
            )
        ]
    return []


def brand_suffix_consistent(text: str, ctx: FieldContext) -> list[Finding]:
    """Per-row half of the batch-wide brand decision.

    Whether ` | e&` is used is decided once for the whole batch by
    `decide_brand_suffix`. This only checks the row agrees with that decision, which is
    what stops the reference file's pattern of one title in five carrying the suffix.
    """
    if ctx.brand_suffix_applied is None or ctx.field != "meta_title_en":
        return []
    present = text.rstrip().endswith(BRAND_SUFFIX.strip())
    if ctx.brand_suffix_applied and not present:
        return [
            Finding(
                code="BRAND_SUFFIX_MISSING",
                severity="error",
                message=f'Missing the "{BRAND_SUFFIX.strip()}" suffix that the rest of the batch uses.',
                field=ctx.field,
            )
        ]
    if not ctx.brand_suffix_applied and present:
        return [
            Finding(
                code="BRAND_SUFFIX_UNEXPECTED",
                severity="error",
                message=(
                    f'Carries the "{BRAND_SUFFIX.strip()}" suffix, but it is switched off '
                    "for this batch because it does not fit every title."
                ),
                field=ctx.field,
            )
        ]
    return []


def term_density(text: str, ctx: FieldContext) -> list[Finding]:
    """Coverage map upper bound — flags a content word repeated beyond a sane share.

    Function words are excluded and a term must repeat at least `MIN_TERM_REPEATS` times.
    Reporting that "the" occurs twice is technically true and practically useless, and a
    panel full of findings like that teaches a reviewer to stop reading the panel.
    """
    words = regex.findall(r"\p{L}[\p{L}\p{N}'-]*", normalise.normalise_term(text))
    if len(words) < 8:
        return []
    counts: dict[str, int] = {}
    for word in words:
        if word in DENSITY_STOPWORDS:
            continue
        counts[word] = counts.get(word, 0) + 1
    out: list[Finding] = []
    for word, count in sorted(counts.items()):
        if count >= MIN_TERM_REPEATS and count / len(words) > MAX_TERM_DENSITY:
            out.append(
                Finding(
                    code="TERM_DENSITY",
                    severity="warning",
                    message=(
                        f'"{word}" appears {count} times in {len(words)} words '
                        f"({count / len(words):.0%}), above the "
                        f"{MAX_TERM_DENSITY:.0%} guide."
                    ),
                    field=ctx.field,
                )
            )
    return out


FIELD_VALIDATORS: tuple[FieldValidator, ...] = (
    char_limit,
    byte_limit,
    pixel_limit,
    primary_keyword_present,
    no_banned_terms,
    no_unrequested_location,
    no_stale_generation,
    no_double_space,
    no_trailing_whitespace,
    no_glued_em_dash,
    brand_suffix_consistent,
    term_density,
    # SEO Copy Guidelines, 2026-09-28.
    uk_english,
    action_verb_present,
    smartpay_mentioned,
    price_sentence,
)


def validate_field(text: str, ctx: FieldContext) -> list[Finding]:
    findings: list[Finding] = []
    for validator in FIELD_VALIDATORS:
        findings.extend(validator(text, ctx))
    return sort_findings(findings)


# ---------------------------------------------------------------- keyword cell validators


def validate_keyword_cell(cell: str, ctx: FieldContext) -> list[Finding]:
    """Validate a comma-separated keyword cell.

    This is where the reference file's worst keyword defects live: D12 holds 22 terms of
    which 7 are exact duplicates, and D13 carries `apple watch ultra 3` on an Ultra 4 row.
    """
    terms = normalise.split_keyword_cell(cell)
    findings: list[Finding] = []

    duplicates = normalise.duplicate_terms(terms)
    if duplicates:
        listed = ", ".join(f'"{t}" x{n}' for t, n in list(duplicates.items())[:5])
        more = "" if len(duplicates) <= 5 else f" and {len(duplicates) - 5} more"
        findings.append(
            Finding(
                code="KEYWORD_DUPLICATES",
                severity="error",
                message=(
                    f"{len(duplicates)} term(s) repeat in a list of {len(terms)}: "
                    f"{listed}{more}."
                ),
                field=ctx.field,
            )
        )

    findings.extend(no_stale_generation(cell, ctx))
    findings.extend(no_banned_terms_in_keywords(cell, ctx))

    if cell != cell.strip():
        findings.append(
            Finding(
                code="EDGE_WHITESPACE",
                severity="error",
                message="Keyword list starts or ends with a space.",
                field=ctx.field,
            )
        )

    cross_line = _cross_line_terms(terms, ctx.identity)
    if cross_line:
        findings.append(
            Finding(
                code="KEYWORD_CROSS_LINE",
                severity="warning",
                message=(
                    f"{len(cross_line)} term(s) name a different model line than this row: "
                    + ", ".join(f'"{t}"' for t in cross_line[:3])
                    + "."
                ),
                field=ctx.field,
            )
        )
    return sort_findings(findings)


def _cross_line_terms(terms: Sequence[str], identity: ProductIdentity) -> list[str]:
    """Terms naming a model line this row is not.

    Distinct from staleness: `apple watch ultra 3` on a Series 12 row is not an older
    generation of that row's line, it is a different product entirely.
    """
    if not identity.family or not identity.line:
        return []
    own = set(identity.line.split())
    out: list[str] = []
    for term in terms:
        folded = normalise.normalise_term(term)
        if identity.family not in folded:
            continue
        mentioned = {t for t in PRODUCT_LINES if regex.search(rf"\b{t}\b", folded)}
        if mentioned and not (mentioned & own):
            out.append(term)
    return out


# ---------------------------------------------------------------- store fields


def validate_store_field(text: str, key: str, row_index: int = 0) -> list[Finding]:
    """Apple and Play store fields, per brief §7. These are hard store rules."""
    spec = next((f for f in STORE_FIELDS if f.key == key), None)
    if spec is None:
        raise KeyError(f"unknown store field: {key}")
    ctx = FieldContext(
        field=key,
        row_index=row_index,
        char_limit=spec.limit if spec.unit == "chars" else None,
        # Store limits are "at most N", not "under N".
        char_limit_inclusive=True,
        byte_limit=spec.limit if spec.unit == "bytes" else None,
        is_indexed=spec.indexed,
    )
    findings = [*char_limit(text, ctx), *byte_limit(text, ctx), *no_banned_terms(text, ctx)]
    if key == "apple_keywords":
        findings.extend(_apple_keyword_rules(text))
    return sort_findings(findings)


def _apple_keyword_rules(text: str) -> list[Finding]:
    out: list[Finding] = []
    if regex.search(r",\s+", text):
        out.append(
            Finding(
                code="APPLE_KEYWORD_SPACES",
                severity="error",
                message=(
                    "Remove the spaces after commas. Apple counts them against the "
                    "100-byte budget and they buy nothing."
                ),
                field="apple_keywords",
            )
        )
    return out


def apple_keyword_overlap(keywords: str, app_name: str, subtitle: str) -> list[Finding]:
    """No word in the app name or subtitle may reappear in the keyword field.

    Apple already indexes the name and subtitle, so a repeat spends part of a 100-byte
    budget on a term that is already covered.
    """
    def words(value: str) -> set[str]:
        return {
            w for w in regex.findall(r"\p{L}[\p{L}\p{N}]*", normalise.normalise_term(value))
            if len(w) > 2
        }

    claimed = words(app_name) | words(subtitle)
    repeated = sorted(words(keywords) & claimed)
    if not repeated:
        return []
    return [
        Finding(
            code="APPLE_KEYWORD_OVERLAP",
            severity="error",
            message=(
                f"{len(repeated)} word(s) already indexed in the app name or subtitle: "
                + ", ".join(f'"{w}"' for w in repeated[:5])
                + ". Repeating them wastes the keyword budget."
            ),
            field="apple_keywords",
        )
    ]


# ---------------------------------------------------------------- batch tier


@dataclass(frozen=True, slots=True)
class RowSnapshot:
    row_index: int
    category_norm: str
    category_raw: str
    url: str
    product_name: str
    title: str = ""
    description: str = ""
    primary_keyword: str | None = None
    keyword_terms: tuple[str, ...] = ()
    skipped_reason: str | None = None

    @property
    def identity(self) -> ProductIdentity:
        return parse_identity(self.product_name)


@dataclass(frozen=True, slots=True)
class BatchSnapshot:
    rows: tuple[RowSnapshot, ...]
    # (category_norm, normalised term) -> row_index that already claims it
    registry: Mapping[tuple[str, str], int] = dc_field(default_factory=dict)
    locale: str = "en"


BatchValidator = Callable[[BatchSnapshot], list[Finding]]


@dataclass(frozen=True, slots=True)
class BrandDecision:
    applied: bool
    reason: str
    blocking_row: int | None = None

    def to_json(self) -> str:
        return json.dumps(
            {"applied": self.applied, "reason": self.reason, "blocking_row": self.blocking_row},
            sort_keys=True,
        )


def decide_brand_suffix(snapshot: BatchSnapshot, surface: Surface) -> BrandDecision:
    """Decide once, for the whole batch, whether titles carry ` | e&`.

    Brief §6 requires one decision across the batch rather than per row. The suffix is
    applied only if every title still fits both the character and pixel budget with it,
    because a suffix on some rows and not others is the reference file's defect.

    The blocking row is named so the UI can explain why the suffix is off, which otherwise
    reads as a bug.
    """
    candidates = [r for r in snapshot.rows if r.title and not r.skipped_reason]
    if not candidates:
        return BrandDecision(False, "No titles to decide on yet.")

    for row in sorted(candidates, key=lambda r: r.row_index):
        base = row.title.rstrip()
        if base.endswith(BRAND_SUFFIX.strip()):
            continue
        suffixed = base + BRAND_SUFFIX
        chars = limits.char_count(suffixed)
        width, _ = advance_for(suffixed, surface)
        # `>` not `>=`: the guidelines say "60 characters or fewer", so a title that lands
        # exactly on the limit with the suffix fits and must not block the whole batch.
        if chars > surface.char_hard_limit or width > surface.total_px_budget:
            return BrandDecision(
                applied=False,
                reason=(
                    f'Switched off for the whole batch: row {row.row_index} '
                    f'("{base}") would reach {chars} characters and {width:.0f}px with '
                    f"the suffix, past the {surface.char_hard_limit}-character and "
                    f"{surface.total_px_budget:.0f}px budgets."
                ),
                blocking_row=row.row_index,
            )
    return BrandDecision(
        applied=True,
        reason=f"Applied to all {len(candidates)} titles; every one still fits both budgets.",
    )


def unique_titles(snapshot: BatchSnapshot) -> list[Finding]:
    """No two rows may share a title."""
    by_title: dict[str, list[int]] = {}
    for row in snapshot.rows:
        if row.title and not row.skipped_reason:
            by_title.setdefault(normalise.normalise_term(row.title), []).append(row.row_index)
    out: list[Finding] = []
    for _, rows in sorted(by_title.items()):
        if len(rows) > 1:
            owner, *dupes = sorted(rows)
            for row_index in dupes:
                out.append(
                    Finding(
                        code="DUPLICATE_TITLE",
                        severity="error",
                        message=(
                            f"Same title as row {owner}. Two pages competing on one title "
                            "split their own ranking."
                        ),
                        field=f"row{row_index}.meta_title_en",
                    )
                )
    return out


def cannibalisation(snapshot: BatchSnapshot) -> list[Finding]:
    """Flag a primary keyword claimed by more than one page.

    Three checks, because the risk shows up three ways:

      CANNIBALISATION           two rows in the SAME category share a primary. This is the
                                case brief §8 step 2 names.
      CANNIBALISATION_BATCH     two rows in DIFFERENT categories share a primary. Worth
                                reporting separately because the spreadsheet's categories
                                are per-variant — six Apple Watch rows here sit under six
                                different category labels while competing for one term, so
                                the same-category check alone would see nothing.
      CANNIBALISATION_REGISTRY  an earlier batch already claimed the term.

    All three are warnings. Two pages sharing a term is sometimes deliberate, so this
    informs a human rather than blocking them.
    """
    out: list[Finding] = []
    by_category: dict[tuple[str, str], int] = {}
    by_term: dict[str, int] = {}

    for row in sorted(snapshot.rows, key=lambda r: r.row_index):
        if not row.primary_keyword or row.skipped_reason:
            continue
        term = normalise.normalise_term(row.primary_keyword)
        field = f"row{row.row_index}.primary_keyword"

        category_owner = by_category.get((row.category_norm, term))
        if category_owner is not None:
            out.append(
                Finding(
                    code="CANNIBALISATION",
                    severity="warning",
                    message=(
                        f'"{row.primary_keyword}" is already the primary for row '
                        f'{category_owner} in "{row.category_raw}". Two pages targeting '
                        "one term in one category compete with each other."
                    ),
                    field=field,
                )
            )
        else:
            by_category[(row.category_norm, term)] = row.row_index
            registered = snapshot.registry.get((row.category_norm, term))
            if registered is not None and registered != row.row_index:
                out.append(
                    Finding(
                        code="CANNIBALISATION_REGISTRY",
                        severity="warning",
                        message=(
                            f'"{row.primary_keyword}" is already the primary for row '
                            f"{registered} in this category, from an earlier batch."
                        ),
                        field=field,
                    )
                )

        term_owner = by_term.get(term)
        if term_owner is None:
            by_term[term] = row.row_index
        elif category_owner is None:
            out.append(
                Finding(
                    code="CANNIBALISATION_BATCH",
                    severity="warning",
                    message=(
                        f'"{row.primary_keyword}" is also the primary for row {term_owner}, '
                        f'under a different category ("{row.category_raw}" here). Consider '
                        "a more specific primary for one of them."
                    ),
                    field=field,
                )
            )
    return out


BATCH_VALIDATORS: tuple[BatchValidator, ...] = (unique_titles, cannibalisation)


def validate_batch(snapshot: BatchSnapshot) -> list[Finding]:
    findings: list[Finding] = []
    for validator in BATCH_VALIDATORS:
        findings.extend(validator(snapshot))
    return sort_findings(findings)
