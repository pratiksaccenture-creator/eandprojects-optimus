"""Term shaping: what a phrase is about, and which parts of it people actually search.

Pure functions over strings, in `lib` rather than in a service because three very
different callers need the same answers and must not drift apart:

  * the keyword service, deciding which terms are worth paying to measure
  * the copy providers, deciding which words of a product name belong in a 60-character
    title
  * the export, deciding which researched terms reached the copy

If the fixture provider trimmed product names by one rule and the keyword service filtered
them by another, an offline demo would show different keywords from a live run for reasons
nobody could see.
"""

from __future__ import annotations

import regex

from app.lib.normalise import normalise_term
from app.lib.policy import (
    ATTRIBUTE_WORDS,
    DENSITY_STOPWORDS,
    PRODUCT_LINES,
    SPEC_TERM_PATTERNS,
)

_SPEC_PATTERNS = tuple(
    regex.compile(pattern, regex.IGNORECASE) for _, pattern in SPEC_TERM_PATTERNS
)

# Words that say nothing about which product a term is for.
_UNSPECIFIC = frozenset({
    "uae", "dubai", "abu", "dhabi", "online", "buy", "shop", "price", "prices", "latest",
    "best", "new", "cheap", "deal", "deals", "offer", "offers", "in", "near", "me",
})

_JOINERS = frozenset({"+", "-", "with", "and"})


# Brands seen in e&'s catalogue.
#
# A curated list rather than "the first word of the product name", because the first word
# is the brand often enough to be tempting and wrong often enough to matter: on a row
# named "Smart Appliances" the first-word guess produced the brand "Smart", which became
# a keyword seed, matched "smartphone", and ended up the primary keyword for a page about
# dishwashers.
#
# It lives in `lib` rather than beside the spreadsheet reader because three different
# callers need the same answer: the reader filling in a missing Brand column, the keyword
# service rejecting a competitor's term, and the copy layer. One list, one answer.
KNOWN_BRANDS: tuple[str, ...] = (
    "Apple", "Samsung", "Xiaomi", "Redmi", "Google", "Huawei", "Honor", "Oppo", "Vivo",
    "OnePlus", "Realme", "Nothing", "Motorola", "Nokia", "Sony", "PlayStation", "Microsoft",
    "Xbox", "Nintendo", "LG", "TCL", "Hisense", "Lenovo", "HP", "Dell", "Asus", "Acer",
    "MSI", "AOC", "BenQ", "Logitech", "Razer", "Anker", "Soundcore", "Bose", "JBL", "Beats",
    "Marshall", "Sonos", "Sennheiser", "Dyson", "Eufy", "Roborock", "Ecovacs", "Ring",
    "Nest", "Arlo", "Philips", "Tapo", "TP-Link", "Netgear", "Belkin", "Garmin", "Fitbit",
    "Amazfit", "Nikon", "Canon", "GoPro", "DJI", "Insta360", "Kindle", "Amazon", "Meta",
    "Oculus", "Aqara", "Yale", "Nanoleaf", "Govee", "Braun", "Oral-B",
)

# Product lines that name their manufacturer unambiguously. Consulted only after the brand
# list, so "Apple iPhone 17" still matches on "Apple"; this catches the names that omit the
# maker, like "iPhone 18 Pro Max" or a returned keyword of just "ipad". Every entry is a
# line sold by exactly one company — anything contested does not belong here.
BRAND_BY_LINE: tuple[tuple[str, str], ...] = (
    ("apple watch", "Apple"), ("iphone", "Apple"), ("ipad", "Apple"),
    ("airpods", "Apple"), ("macbook", "Apple"), ("imac", "Apple"), ("airtag", "Apple"),
    ("galaxy", "Samsung"), ("redmi", "Xiaomi"), ("poco", "Xiaomi"),
    ("pixel", "Google"), ("razr", "Motorola"), ("moto", "Motorola"),
    ("playstation", "Sony"), ("bravia", "Sony"),
    ("xbox", "Microsoft"), ("surface", "Microsoft"),
    ("thinkpad", "Lenovo"), ("ideapad", "Lenovo"),
    ("kindle", "Amazon"), ("echo", "Amazon"),
)


def derive_brand(product_name: str) -> str:
    """The manufacturer, read off a product name or a keyword. "" when there is none.

    Earliest match wins, not longest. "Sony PlayStation PS5" contains two known names and
    the manufacturer is the one in front — product lines trail their makers, so position
    separates them where length does not. Length only breaks a tie at the same position,
    which is how "TP-Link" beats a hypothetical "TP".

    Returns "" rather than guessing when nothing matches. An empty brand is a visible gap
    that a human or a model can reason around; a wrong one propagates in silence.
    """
    cleaned = " ".join(str(product_name or "").split())
    if not cleaned:
        return ""
    padded = f" {cleaned.casefold()} "

    best: tuple[int, int, str] | None = None
    for brand in KNOWN_BRANDS:
        position = padded.find(f" {brand.casefold()} ")
        if position < 0:
            continue
        candidate = (position, -len(brand), brand)
        if best is None or candidate < best:
            best = candidate
    if best is not None:
        return best[2]

    for line, brand in BRAND_BY_LINE:
        if f" {line} " in padded:
            return brand
    return ""


def is_attribute_term(term: str) -> bool:
    """Whether a term is a product attribute rather than something people search for.

    The content team's instruction: measure demand for product, brand and category terms;
    do not measure it for specifications, colours or features. This is that boundary.

    A term counts as an attribute when it matches a specification shape — "512GB", "42mm",
    "2K", a model code — or when every word in it is a colour or material. The second
    condition matters: "pearl white" is an attribute, but "white iphone 17" is a real
    query and keeps its product term, so an all-words test is right where an any-word test
    would throw away demand.
    """
    cleaned = normalise_term(term)
    if not cleaned:
        return True
    if any(pattern.search(cleaned) for pattern in _SPEC_PATTERNS):
        return True
    words = cleaned.split()
    return bool(words) and all(word in ATTRIBUTE_WORDS for word in words)


def strip_attributes(product_name: str) -> str:
    """The searchable core of a product name, lowercased.

    "Apple Watch Series 12 GPS + Cellular Ceramic | Pearl White | Case Size 42MM" becomes
    "apple watch series 12 gps cellular". Pipe-separated segments that are wholly
    attributes are dropped whole; inside what remains, colour and material words go and
    specification shapes go.

    This is what makes the volume lookup worth paying for. Sent verbatim, that product
    name expands into nothing, because nobody types it. It is also what lets a 75-character
    product name fit a 60-character title without truncating mid-word.
    """
    segments = [s.strip() for s in regex.split(r"[|/]", product_name) if s.strip()]
    kept: list[str] = []
    for index, segment in enumerate(segments):
        # The first segment carries the product; later ones are usually variant detail.
        if index > 0 and is_attribute_term(segment):
            continue
        kept.append(segment)

    words: list[str] = []
    for word in normalise_term(" ".join(kept or segments)).split():
        if word in ATTRIBUTE_WORDS or word in _JOINERS:
            continue
        if any(pattern.fullmatch(word) for pattern in _SPEC_PATTERNS):
            continue
        words.append(word)
    return " ".join(words)


def display_name(product_name: str, *, max_words: int = 12) -> str:
    """A product name trimmed for copy: original casing, distinguishing words kept.

    Related to `strip_attributes` but deliberately NOT the same rule, and the difference
    is the point.

    For a keyword, "ceramic" is noise — nobody searches it, and measuring it wastes the
    budget. For a title it can be the only thing that exists: this batch contains three
    Apple Watch Series 12 Cellular rows differing only by Aluminium, Titanium and Ceramic.
    Dropping the material there produced three identical titles, which the uniqueness
    validator correctly rejects and which would leave those rows unexportable.

    So this keeps colour and material, and drops only what carries no meaning in a title:
    specification shapes like "512GB" and "42MM", model codes, and trailing
    pipe-separated segments that are nothing but attributes.

    `max_words` is a safety valve, not a compression strategy. It was 6, which cut
    "Aluminium" off the end of "Apple Watch Series 12 GPS + Cellular Aluminium" and gave
    three rows the same title again by a different route. Shortening for length is the
    caller's job, and the caller knows which words it can afford to lose.
    """
    segments = [s.strip() for s in regex.split(r"[|/]", product_name) if s.strip()]
    if not segments:
        return product_name.strip()

    out: list[str] = []
    for word in segments[0].split():
        folded = normalise_term(word)
        if not folded or folded in _JOINERS:
            continue
        if any(pattern.fullmatch(folded) for pattern in _SPEC_PATTERNS):
            continue
        out.append(word)
        if len(out) >= max_words:
            break
    return " ".join(out) or segments[0]


_TRAILING_NUMBER = regex.compile(r"^[a-z]{1,4}(\d{1,2})$")


def _model_qualifiers(text: str) -> set[str]:
    """Words in `text` that pin it to a specific model: a line name or a generation.

    Generations hide inside tokens as often as they stand alone. "PS5" and "A11" carry
    theirs welded to a prefix, and reading only standalone digits meant a PlayStation 5
    row exposed no generation at all — so "playstation 5", the single most correct term
    for that product, was rejected as belonging to a different model while "playstation
    6" was rejected for the same reason. Both wrong, one expensively so.
    """
    out: set[str] = set()
    for word in normalise_term(text).split():
        if word in PRODUCT_LINES:
            out.add(word)
        elif word.isdigit() and len(word) <= 2:
            out.add(word)
        else:
            match = _TRAILING_NUMBER.match(word)
            if match:
                out.add(match.group(1))
    return out


def names_a_different_model(term: str, product_name: str) -> bool:
    """Whether `term` is pinned to a model this page is not about.

    Keyword expansion does not know which SKU it is working for. Asked to expand
    "iphone 18 pro" it will happily return "iphone 18 pro max", which has more demand and
    is a different phone. Left alone, that term outranks the correct one, becomes the
    primary keyword, and points the page at a product e& is not selling on it.

    The test is asymmetric on purpose. A term may be BROADER than the product — "iphone 18"
    on an iPhone 18 Pro Max page is the same phone described loosely, and "smart watch" on
    an Apple Watch page is what a customer calls it. What it may not do is add a model
    qualifier the product does not have: "max" where there is no Max, "series 12" on an
    Ultra 4.

    A product with no model markers of its own is not filtered. There is no baseline to
    compare against, and rejecting every numbered term on that basis threw away good
    ones.
    """
    product_qualifiers = _model_qualifiers(product_name)
    if not product_qualifiers:
        return False
    return bool(_model_qualifiers(term) - product_qualifiers)


def shares_a_word_with_product(term: str, product_name: str) -> bool:
    """Whether `term` has any meaningful word in common with the product name.

    A primary keyword the page cannot naturally contain is not a usable primary. Expansion
    around a brand seed returns the bare brand, which has enormous volume and belongs to
    every page the brand sells — targeting a page called "iPhone Family" at "apple" is
    both unwinnable and a guaranteed collision with every other Apple page in the batch.

    Overlap is a weak test on purpose. "smart watch" keeps "watch" from "Apple Watch Ultra
    4" and stays eligible, which is right: it is a real way customers describe the thing.
    """
    stop = DENSITY_STOPWORDS | _UNSPECIFIC
    term_words = {w for w in normalise_term(term).split() if w not in stop}
    product_words = {w for w in normalise_term(product_name).split() if w not in stop}
    if not term_words:
        # Nothing but market and intent words — "buy online in uae" describes a shopper,
        # not a product, so it cannot be what any page is about.
        return False
    if not product_words:
        # No product name to judge against. Do not filter on no evidence.
        return True
    return bool(term_words & product_words)


def has_repeated_word(term: str) -> bool:
    """Whether a short phrase says the same word twice.

    Keyword expansion returns these routinely — "robot vacuum robot", "robot robot vacuum
    cleaner", "robot vacuum cleaner robot" all came back for one product, each with the
    same 3,600 volume, and one of them became the primary keyword. They are artefacts of
    how the ads platform permutes terms, not phrases anybody types, and a page targeted at
    "robot vacuum robot" looks machine-written because it is.

    Only applied to short phrases. A longer natural query can legitimately repeat a word.
    """
    words = normalise_term(term).split()
    if len(words) > 5:
        return False
    return len(set(words)) != len(words)


def names_another_brand(term: str, brand: str) -> bool:
    """Whether a term belongs to a manufacturer other than this row's.

    Expansion does not know whose page it is working on. Seeded with "robot vacuum" it
    returned "dyson vacuum" and "dyson sweeper"; seeded from a Samsung tablet it returned
    "ipad", "apple ipad" and "lenovo tablet". Left in, those become supporting keywords
    handed to the copy model — a competitor's brand written into e&'s own product page,
    which the SEO Copy Guidelines rule out and which no reviewer would pass.

    Generic terms are kept: "robot vacuum" and "tablet" name no manufacturer and are
    exactly what this page should target. With no brand known for the row, nothing is
    filtered — there is no evidence to filter on.
    """
    if not brand:
        return False
    other = derive_brand(term)
    return bool(other) and other.casefold() != brand.casefold()


def category_phrases(category_raw: str) -> tuple[str, ...]:
    """Search-usable phrases from a category cell, most specific first.

    The template's categories are inconsistent — "Smart Home", "Wearables | Apple Watches",
    "Smart Home & Monitorting" (the typo is in the source). Splitting on the separators and
    keeping each part gives both "wearables" and "apple watches", which are different
    queries with different demand, and costs nothing when there is only one part.
    """
    parts = [p.strip() for p in regex.split(r"[|/&,]|\s+-\s+", category_raw) if p.strip()]
    phrases = [normalise_term(p) for p in reversed(parts)]
    return tuple(p for p in phrases if p)
