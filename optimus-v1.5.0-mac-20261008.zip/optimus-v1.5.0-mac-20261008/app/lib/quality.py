"""Quality gate for terms the volume provider returns.

Expansion asks Google what people type around a seed, and Google answers honestly — which
is not the same as usefully. A Samsung Galaxy Fold row came back with:

    samsung galaxy       40,500   the page's own term
    semsem galaxy        40,500   not a word, not a brand, not this product
    samsung s24 ultra    33,100   a different phone, and it was tiered SECOND
    samsung a56          27,100   a different phone
    samsung a17          18,100   a different phone

Three of those are real demand for products that are not this page, and one is noise. Left
alone they get measured, ranked by volume, auto-tiered, and handed to the copy model — so
a page about a foldable optimises for an S24 Ultra.

The existing filters in `keyword_service` caught some of this and missed the rest:

  `names_a_different_model`  returns False when the PRODUCT has no numeric qualifier, and
                             "Samsung Galaxy Fold" has none — so every other Samsung model
                             sailed through.
  `names_another_brand`      only knows brands it has heard of. "semsem" is not a brand.
  `has_repeated_word`        catches ads-platform permutations, not foreign tokens.

So the rule here is the other way round: instead of listing what is bad, require every
word to be **accounted for**. A row's vocabulary is its product name, its brand, its
category, the seeds it was researched with, and a small set of words people put around any
product. A term carrying a word from none of those is not a term about this product.

Everything in this module is a pure function over strings. Nothing imports the ORM, and
nothing here can produce or alter a figure.
"""

from __future__ import annotations

from functools import lru_cache

import regex

from app.lib.normalise import normalise_term
from app.lib.policy import ATTRIBUTE_WORDS, DENSITY_STOPWORDS
from app.lib.terms import KNOWN_BRANDS

# Words that legitimately sit next to any product, so they are never "unaccounted for".
#
# Shopping intent, place, condition, audience, and the handful of generic qualifiers that
# appear in real queries. Kept deliberately small: the point of the accounting rule is that
# a row's own seeds supply most of its vocabulary, and a large allowlist would let noise
# back in through the front door.
GENERIC_VOCABULARY: frozenset[str] = frozenset({
    # intent
    "buy", "shop", "order", "online", "price", "prices", "cost", "deal", "deals",
    "offer", "offers", "discount", "sale", "cheap", "cheapest", "best", "top",
    "review", "reviews", "compare", "comparison", "vs", "alternative", "alternatives",
    "where", "how", "what", "which", "who", "why", "near", "me", "store", "stores",
    "shopping", "delivery", "installment", "instalment", "instalments", "monthly",
    # place
    "uae", "dubai", "abu", "dhabi", "sharjah", "ajman", "emirates", "gulf",
    # condition and availability
    "new", "latest", "newest", "used", "refurbished", "original", "genuine", "official",
    "authentic", "warranty", "stock", "available",
    # audience and use
    "kids", "children", "adults", "women", "men", "home", "office", "car", "outdoor",
    "indoor", "travel", "gaming", "gamer", "work", "school", "student", "professional",
    "business", "family", "bedroom", "living", "room", "portable", "wireless",
    "bluetooth", "smart", "mini", "pro", "max", "plus", "ultra", "lite", "air",
    # shapes of a product query
    "model", "models", "version", "generation", "gen", "series", "edition", "set",
    "kit", "bundle", "accessories", "accessory", "case", "cover", "charger", "cable",
    "spec", "specs", "specification", "specifications", "features", "feature",
})

# Profanity and slurs, as stems, matched on word boundaries.
#
# A keyword list is a document people read and paste into a brief; a term that Google
# reports and nobody would ever print has no business being measured, let alone ranked.
# Stems rather than exhaustive forms, because "<stem>s" and "<stem>ing" are the same
# problem. Deliberately short and clinical — this is a content filter, not a dictionary.
PROFANITY_STEMS: tuple[str, ...] = (
    "fuck", "shit", "cunt", "bitch", "bastard", "dick", "cock", "pussy", "whore",
    "slut", "wank", "bollock", "arsehole", "asshole", "nigg", "faggot", "retard",
    "porn", "xxx", "sex", "nude", "naked", "escort", "viagra",
)

_PROFANITY = regex.compile(
    r"\b(?:" + "|".join(PROFANITY_STEMS) + r")\w*\b", regex.IGNORECASE
)

# A model designator: a letter-and-number code (s24, a56, n130, xm5, z9) or a bare
# generation number followed by a line word. These are what distinguish one product in a
# family from another, so one that is not in the product name names a different product.
_DESIGNATOR = regex.compile(r"^[a-z]{1,3}\d{1,4}[a-z]?$")
_LINE_WORDS = frozenset({"pro", "ultra", "plus", "max", "mini", "lite", "air", "fe"})

#: Below this length a token is too short to judge — "s", "4k", "hd" are not evidence.
MIN_JUDGED_TOKEN = 4

#: How far a token may be from a brand name before it stops being a misspelling of it.
#: One or two edits catches "sasmung", "samsnug", "iphonne"; three would start catching
#: genuinely different words.
MAX_BRAND_EDITS = 2


def is_profane(term: str) -> bool:
    return _PROFANITY.search(term) is not None


@lru_cache(maxsize=4096)
def _edit_distance(left: str, right: str) -> int:
    """Levenshtein distance. Hand-rolled to avoid a dependency for twenty lines."""
    if left == right:
        return 0
    if not left:
        return len(right)
    if not right:
        return len(left)

    previous = list(range(len(right) + 1))
    for i, lchar in enumerate(left, start=1):
        current = [i]
        for j, rchar in enumerate(right, start=1):
            current.append(
                min(
                    previous[j] + 1,          # deletion
                    current[j - 1] + 1,       # insertion
                    previous[j - 1] + (lchar != rchar),  # substitution
                )
            )
        previous = current
    return previous[-1]


#: `KNOWN_BRANDS` is title-cased for display ("AOC", "Philips"); terms are lowercase
#: throughout. Folded once here rather than at every comparison.
_BRANDS_FOLDED: frozenset[str] = frozenset(b.casefold() for b in KNOWN_BRANDS)


def misspelled_brand(token: str) -> str | None:
    """The brand a token is a near-miss of, or None.

    Returns the brand so the reason can name it: "sasmung" is more usefully reported as
    "looks like a misspelling of samsung" than as "unrecognised".
    """
    folded = token.casefold()
    if len(folded) < 5 or folded in _BRANDS_FOLDED:
        return None
    for brand in _BRANDS_FOLDED:
        if len(brand) < 5:
            continue
        # Length guard first: it is cheap, and it stops a short brand matching a short
        # ordinary word — "sony" and "pony" are one edit apart.
        if abs(len(brand) - len(folded)) > MAX_BRAND_EDITS:
            continue
        if _edit_distance(folded, brand) <= MAX_BRAND_EDITS:
            return brand
    return None


def _vocabulary(
    *, product_name: str, brand: str, category: str, seeds: tuple[str, ...]
) -> frozenset[str]:
    """Every word this row is entitled to use.

    The seeds matter most. They are what the row was researched with — the model's and the
    derivation's idea of what this product is called — so they carry the product's real
    vocabulary without anyone maintaining a list.
    """
    words: set[str] = set()
    for source in (product_name, brand, category, *seeds):
        words.update(normalise_term(source).split())
    words.update(GENERIC_VOCABULARY)
    words.update(DENSITY_STOPWORDS)
    words.update(ATTRIBUTE_WORDS)
    # Any brand we know of. A term naming a DIFFERENT manufacturer is rejected by
    # `names_another_brand` in the research path, which knows whose row it is; this gate
    # does not, so treating a real brand name as unaccounted-for would have it reporting
    # "'apple' is not a word this product's research accounts for" on a Samsung row — true,
    # unhelpful, and the wrong rule's job.
    words.update(_BRANDS_FOLDED)
    return frozenset(words)


def rejection_reason(
    term: str,
    *,
    product_name: str,
    brand: str = "",
    category: str = "",
    seeds: tuple[str, ...] = (),
) -> str | None:
    """Why this term should not be kept, or None if it is fine.

    Ordered so the reason a reader gets is the most specific one available: profanity
    first, then a recognisable misspelling, then a different product, then the catch-all.
    """
    cleaned = normalise_term(term)
    if not cleaned:
        return "empty"

    if is_profane(cleaned):
        return "profanity"

    vocabulary = _vocabulary(
        product_name=product_name, brand=brand, category=category, seeds=seeds
    )
    name_words = set(normalise_term(product_name).split())
    tokens = cleaned.split()

    for token in tokens:
        if token in vocabulary:
            continue

        looks_like = misspelled_brand(token)
        if looks_like is not None:
            return f"{token!r} looks like a misspelling of {looks_like!r}"

        # A model code that is not this model. "samsung s24 ultra" on a Galaxy Fold row:
        # `s24` is a designator, and the Fold's name contains no designator at all, which
        # is exactly the case the older check could not see.
        if _DESIGNATOR.match(token) and token not in name_words:
            return f"{token!r} is another product's model code"

        if len(token) >= MIN_JUDGED_TOKEN:
            return f"{token!r} is not a word this product's research accounts for"

    # A bare generation number beside a line word, where the product name has neither.
    # "galaxy s25" is caught above by the designator; "galaxy 25 ultra" needs this.
    for first, second in zip(tokens, tokens[1:]):
        if first.isdigit() and second in _LINE_WORDS:
            if first not in name_words:
                return f"{first + ' ' + second!r} is another product's variant"

    return None
