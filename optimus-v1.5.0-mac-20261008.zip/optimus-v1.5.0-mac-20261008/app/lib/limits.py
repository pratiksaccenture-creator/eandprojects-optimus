"""Text measurement — the technical core, per brief §6.

Every number this module produces is traceable to either a Unicode rule or the vendored
font metrics table (see `advance_widths.json` and its `_provenance` block). Nothing here
estimates without saying so.

Four counts exist because they disagree, and the disagreements matter:

  chars      UTF-16 code units. This is what Excel's LEN() counts, so it is the only
             count allowed to mean the same thing as the `Character count (<60)` column.
  graphemes  What a reader would call "a character". Diverges from `chars` for Arabic
             (each tashkeel mark is its own code unit but not its own grapheme) and for
             emoji (a flag is 4 UTF-16 units, 2 code points, 1 grapheme).
  bytes      NFC-normalised UTF-8. Apple's keyword field limit is 100 BYTES, not 100
             characters, which is decisive once Arabic arrives.
  pixels     Advance-width sum. Google truncates on rendered width, not character count,
             so a 58-character title of capitals can clip while a 62-character one survives.
"""

from __future__ import annotations

import json
import unicodedata
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import regex

from app.lib.surfaces import (
    DESCRIPTION_DESKTOP,
    TITLE_DESKTOP,
    Surface,
)

_TABLE_PATH = Path(__file__).with_name("advance_widths.json")


@dataclass(frozen=True, slots=True)
class FontMetrics:
    units_per_em: int
    fallback_width: int
    widths: dict[int, int]
    provenance: dict[str, object]


@lru_cache(maxsize=1)
def font_metrics() -> FontMetrics:
    payload = json.loads(_TABLE_PATH.read_text(encoding="utf-8"))
    return FontMetrics(
        units_per_em=int(payload["units_per_em"]),
        fallback_width=int(payload["fallback_width"]),
        widths={int(k): int(v) for k, v in payload["widths"].items()},
        provenance=payload["_provenance"],
    )


@dataclass(frozen=True, slots=True)
class Measurement:
    chars: int
    graphemes: int
    bytes: int
    pixels_title: float
    pixels_desc: float
    missing_glyphs: int


def char_count(text: str) -> int:
    """UTF-16 code units, matching Excel's LEN().

    `len(text)` counts code points and is wrong here: the UAE flag emoji is 2 code
    points but 4 UTF-16 units, and Excel would report 4.
    """
    return len(text.encode("utf-16-le")) // 2


def grapheme_count(text: str) -> int:
    return len(regex.findall(r"\X", text))


def byte_count(text: str) -> int:
    """NFC-normalised UTF-8 bytes.

    Normalising first matters: decomposed Arabic harakat roughly double the byte count,
    and a store counts the bytes actually submitted.
    """
    return len(unicodedata.normalize("NFC", text).encode("utf-8"))


def advance_width(text: str, font_px: float) -> tuple[float, int]:
    """Return (width in px, count of characters absent from the metrics table)."""
    fm = font_metrics()
    total = 0
    missing = 0
    for char in text:
        width = fm.widths.get(ord(char))
        if width is None:
            width = fm.fallback_width
            missing += 1
        total += width
    return total / fm.units_per_em * font_px, missing


def measure(text: str) -> Measurement:
    px_title, miss_title = advance_width(text, TITLE_DESKTOP.font_px)
    px_desc, _ = advance_width(text, DESCRIPTION_DESKTOP.font_px)
    return Measurement(
        chars=char_count(text),
        graphemes=grapheme_count(text),
        bytes=byte_count(text),
        pixels_title=round(px_title, 1),
        pixels_desc=round(px_desc, 1),
        missing_glyphs=miss_title,
    )


@dataclass(frozen=True, slots=True)
class Truncation:
    """Where a surface clips the text.

    `visible` + `clipped` always reconstruct the input exactly, so a preview can mark the
    boundary by wrapping each part in its own element rather than positioning a ruler at a
    pixel offset — a ruler would visibly land in the wrong place whenever these estimated
    metrics disagree with the browser's real rendering.
    """

    visible: str
    clipped: str
    used_px: float
    budget_px: float
    lines: tuple[str, ...]

    @property
    def truncated(self) -> bool:
        return bool(self.clipped)

    @property
    def fill_ratio(self) -> float:
        return self.used_px / self.budget_px if self.budget_px else 0.0


def _split_runs(text: str) -> list[str]:
    """Split into wrappable runs, each trailing whitespace kept with its word."""
    return regex.findall(r"\S+\s*", text) or ([text] if text else [])


def wrap_lines(text: str, font_px: float, container_px: float) -> list[str]:
    """Greedy word wrap using advance widths. Trailing space is not counted at a line
    break, matching how a browser lays out a wrapped line."""
    lines: list[str] = []
    current = ""
    for run in _split_runs(text):
        candidate = current + run
        width, _ = advance_width(candidate.rstrip(), font_px)
        if current and width > container_px:
            lines.append(current)
            current = run
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines


def truncate(text: str, surface: Surface) -> Truncation:
    """Clip `text` the way `surface` would.

    Single-line surfaces (titles) clip mid-word at the exact pixel budget, as a browser
    does. Multi-line surfaces (descriptions) wrap and clip after `max_lines`.
    """
    if surface.max_lines <= 1:
        return _truncate_single_line(text, surface)
    return _truncate_wrapped(text, surface)


def _truncate_single_line(text: str, surface: Surface) -> Truncation:
    fm = font_metrics()
    budget_units = surface.container_px / surface.font_px * fm.units_per_em
    running = 0.0
    cut = len(text)
    for index, char in enumerate(text):
        running += fm.widths.get(ord(char), fm.fallback_width)
        if running > budget_units:
            cut = index
            break
    used, _ = advance_width(text[:cut], surface.font_px)
    return Truncation(
        visible=text[:cut],
        clipped=text[cut:],
        used_px=round(used, 1),
        budget_px=surface.container_px,
        lines=(text[:cut],),
    )


def _truncate_wrapped(text: str, surface: Surface) -> Truncation:
    lines = wrap_lines(text, surface.font_px, surface.container_px)
    kept = lines[: surface.max_lines]
    visible = "".join(kept)
    used, _ = advance_width(max(kept, key=len) if kept else "", surface.font_px)
    total_used, _ = advance_width(visible.rstrip(), surface.font_px)
    return Truncation(
        visible=visible,
        clipped=text[len(visible) :],
        used_px=round(total_used, 1),
        budget_px=surface.wrapped_px_budget,
        lines=tuple(kept),
    )


def metrics_provenance() -> dict[str, object]:
    """Exposed so the UI can state where the pixel numbers come from, per brief §0."""
    return dict(font_metrics().provenance)
