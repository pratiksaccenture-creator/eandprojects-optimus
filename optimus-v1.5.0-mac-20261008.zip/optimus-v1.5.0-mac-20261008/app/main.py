"""Application entry point.

Brief §11: `npm install && npm run dev` equivalent must work with NO environment variables
set, in fixture mode, end to end. Everything here has a working default and the database is
created and seeded on first start.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from app.config import BUILD_VERSION, ROOT, settings
from app.db import create_all
from app.routers import dev, history, wizard
from app.services import volume_cache
from app.web import templates


@asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    create_all()
    from app.services.seed import ensure_demo_batch

    # Brief §10 step 9: the tool should open with something to show.
    await ensure_demo_batch()
    yield


app = FastAPI(title="Optimus", lifespan=lifespan)

app.mount("/static", StaticFiles(directory=str(ROOT / "app" / "static")), name="static")

# One journey, one router. The lab — a second pair of pages at /batch/{id}/lab/... where
# tiers and lazy loading were tried out before they were trusted — is gone: both features
# graduated into the pages below, so a second set of routes rendering the same partials
# was two things to keep in step and one of them unused.
app.include_router(wizard.router)
app.include_router(history.router)
# JSON only, unlinked. The app-store tab is set aside in archive/full-ui.
app.include_router(dev.router)


@app.exception_handler(500)
async def server_error(request: Request, exc: Exception) -> HTMLResponse:
    """Brief §1 rule 6: failures are visible, never silent.

    A partial request gets an inline error fragment so a failed row renders a stated reason
    instead of leaving a skeleton shimmering on screen for the rest of the demo.
    """
    if request.headers.get("X-Partial") == "1":
        return HTMLResponse(
            f'<div class="row-error" role="alert">This step failed: {exc}</div>',
            status_code=500,
        )
    return templates.TemplateResponse(
        request, "error.html", {"detail": str(exc)}, status_code=500
    )


@app.get("/healthz")
async def healthz() -> dict[str, object]:
    config = settings()
    return {
        "ok": True,
        "build": BUILD_VERSION,
        "keyword_provider": config.keyword_provider,
        "llm_provider": config.llm_provider,
        "page_provider": config.page_provider,
        "fully_live": config.fully_live,
        "demo_pacing_ms": config.demo_pacing_ms,
        # What the volume cache is holding and how many paid lookups it has avoided.
        # Here rather than on a screen because it is an operational fact, like the
        # provider names — but an unmeasurable saving is an unverifiable claim.
        "volume_cache": volume_cache.statistics(),
    }
