# Start the tool. No environment variables are required — it runs in fixture mode with
# seeded data and no external API keys, per brief §11.
#
#   .\run.ps1            start on http://localhost:8123
#   .\run.ps1 -Setup     create the virtualenv and install dependencies first
#   .\run.ps1 -Check     run the tests and the type checker, then exit
#   .\run.ps1 -Keys      verify the live API credentials, then exit (costs nothing)

param(
    [switch]$Setup,
    [switch]$Check,
    [switch]$Keys,
    [int]$Port = 8123
)

$ErrorActionPreference = "Stop"
$python = ".\.venv\Scripts\python.exe"

if ($Setup -or -not (Test-Path $python)) {
    Write-Host "Creating virtualenv and installing dependencies..." -ForegroundColor Cyan
    python -m venv .venv
    & $python -m pip install --upgrade pip --quiet
    & $python -m pip install -r requirements.txt
    Write-Host "Extracting font metrics..." -ForegroundColor Cyan
    & $python tools\extract_font_metrics.py
}

if ($Keys) {
    & $python tools\check_credentials.py
    exit $LASTEXITCODE
}

if ($Check) {
    Write-Host "`nRunning tests..." -ForegroundColor Cyan
    & $python -m pytest
    if (-not $?) { exit 1 }
    Write-Host "`nType checking..." -ForegroundColor Cyan
    & $python -m mypy
    if (-not $?) { exit 1 }
    Write-Host "`nAll checks passed." -ForegroundColor Green
    exit 0
}

Write-Host "Starting on http://127.0.0.1:$Port" -ForegroundColor Green
Write-Host "Credentials come from .env. Run '.\run.ps1 -Keys' to check them (free)." -ForegroundColor DarkGray
& $python -m uvicorn app.main:app --port $Port --reload
