# Changelog

The build is reported in the masthead and by `/healthz`. There is no git on this machine,
so the version in `app/config.py` is bumped by hand and this file is the record.

Reasoning behind each change is in [DECISIONS.md](DECISIONS.md); the section numbers below
point at it.

---

## 1.5.0 — 8 October 2026

Provenance, after the cache justification was challenged and did not hold up.

### Fixed

- **`data_date` was recording the time of the request, not the age of the figure.**
  `_dataforseo.py` set `collected = datetime.now()` and stored it as every figure's date,
  so the tool could not say what period any number it held described. The Google Ads
  endpoints return `monthly_searches` — the per-month breakdown the average is taken over
  — and both parsers were discarding it.

  Now parsed. `read_period()` returns the last month covered and how many months the
  average spans; both are stored on `Keyword` and `VolumeCache`. A response with no
  breakdown yields **None**, never today. A source-level test asserts `data_date` is never
  assigned from the clock in that module.
- **The cache expired on `fetched_at`, which has no relationship to the age of the data.**
  A figure bought yesterday can already describe a window that closed months ago. Expiry
  now reads the data's own vintage (`VOLUME_MAX_VINTAGE_DAYS`, 75), with
  `VOLUME_RECHECK_DAYS` (14) as a cost guard — the vintage rule alone does not terminate,
  because re-fetching a genuinely old window returns the same old window.

  Entries with no recorded vintage are never served: the rows written while the provider
  recorded `now()` hold a value that is wrong under the column's new meaning.
- **`create_all()` never added columns to existing tables.** Adding `months_covered` to
  `keywords` and `volume_cache` would have broken every query against them on any
  database with data in it — "no such column" on a database that looks healthy.
  `add_missing_columns()` now adds nullable columns on start, refuses anything that would
  need a value inventing for existing rows, and never drops or renames.

### Changed

- **The keywords page states the vintage of its figures**: "Search volumes cover the 12
  months to September 2026", and says when a row spans two published windows rather than
  quoting only the newest. It also says plainly that these are averages on a rounded
  scale and should be read as orders of magnitude.
- **DECISIONS.md §38 rewritten.** The old justification — "Google updates it monthly, so a
  reading on the 1st and the 20th are the same number" — overstated what we know. The
  argument is now **bucketing**: reported volumes sit on a discrete ladder, so demand can
  move several percent without the published number changing. Recorded as limitations
  rather than left implied: Google publishes no documented refresh cadence, the window
  rolls so seasonality bites (a "Ramadan" campaign is exactly that case), and DataForSEO's
  own cadence is unverified.

No copy was regenerated. This release changes provenance and wording, not output.

---

## 1.4.0 — 7 October 2026

### Added

- **A volume cache.** DataForSEO bills per request and the tool was repeating itself:
  every batch with a Samsung phone bought "samsung", every projector row bought
  "projector". Figures are now reused for `VOLUME_CACHE_DAYS` (default **30**), keyed on
  term + market + locale.

  Safe because the figure is a twelve-month average Google itself updates monthly — a
  reading taken on the 1st and one taken on the 20th are the same number. The TTL is
  enforced, not just recorded: a cache with no expiry would serve a figure nobody could
  date. A measured absence is cached too, because asking again costs the same and the
  answer is the same. **The expansion is deliberately not cached** — "what else do people
  type" moves as search behaviour does, and freezing it would freeze a row's long tail.

  Also consulted by **Add & measure** and **Save & re-measure**, which were the two places
  a user's click bought a figure the batch already had. `/healthz` reports what the cache
  holds and how many lookups it has avoided. `VOLUME_CACHE_DAYS=0` is a real bypass.

- **A quality gate on what the provider returns** (`app/lib/quality.py`). A Galaxy Fold row
  came back with `semsem galaxy` (not a word), and `samsung s24 ultra`, `samsung a56`,
  `samsung a17` — three other phones, one of which had been **tiered second** on volume
  alone. All real demand; none of it this page.

  The old filters could not see it: `names_a_different_model` returns False when the
  product has no numeric qualifier, and "Galaxy Fold" has none. So the rule now runs the
  other way round — every word must be **accounted for** by the row's own vocabulary: its
  name, brand, filing category, and the seeds it was researched with. Plus a profanity
  filter and brand-misspelling detection by edit distance, so "sasmung" is reported as
  what it is.

### Changed

- **"Batch number" is now "Campaign/File Name"**, and the input sheet no longer needs a
  batch column. The name is typed once at upload and comes back as the **first column of
  the export**, so the delivered sheet records which run produced it without anyone
  maintaining a column. Sheets that still carry a batch column are read as before.
- **The length guide stopped being an instruction.** The prompt said "aim for 50-60" and
  `CHAR_SHORT` warned under it, so a compliant 45-character title was nagged for being
  short — and the model's cheapest way to satisfy the nag was filler. That is the
  mechanism that produced "in the UAE". The ceiling is still an error; the guide now
  reports how much space is used and says not to pad. DECISIONS.md §35.
- **The filing category is labelled as internal and must not be printed.** It was being
  turned into customer-facing copy: a *monitor* described as "listed under Smart Home",
  products placed "in our Smart Home range" — a claim about e&'s merchandising, from a
  spreadsheet cell.
- **"Pre-order" no longer warns.** It is one of the six action verbs the guidelines name,
  and `WARN_AVAILABILITY` was flagging it — so following the guideline, using the
  guideline's own example, earned a warning from a rule of ours. "Coming soon" and
  "available now" still warn.

---

## 1.3.0 — 7 October 2026

### Fixed

- **Copy no longer adds "in the UAE" — or any other place — on its own.** It was appearing
  in nearly every title and description, often in both, and it was never a requirement:
  nothing in the brief or the SEO Copy Guidelines asks for it. Three instructions were
  producing it, all of them in prompts written for this build: `COPY_SYSTEM` described e&
  as a retailer "in the United Arab Emirates", every request carried a
  `Market: United Arab Emirates` line, and a money rule told the model to "write about the
  product in the UAE". All three are gone.

  It was also poor craft and expensive: `iPhone 17 Pro by Apple in the UAE | e&` spends a
  38-character title telling a reader which country they are shopping in, and the phrase had
  become the model's default way of making titles differ across a batch.

  A location may now appear only where a **person** put one — inside a keyword they tiered,
  or in text they typed. `no_unrequested_location` is an **error**, so the regeneration loop
  removes it rather than reporting it and leaving it in place. `PLACE` rules added to the
  system prompt, with the keyword exception stated. The offline templates were cleaned too:
  a rule enforced only when a model is being paid for is not a rule. DECISIONS.md §34.

---

## 1.2.1 — 7 October 2026

### Fixed

- **A row with no selling points was a dead end.** Three rows of a seven-row batch came
  back with none, and nothing could be done about it: USPs are written during research,
  research does not re-run for a row that already has keywords, and the screen said
  "none proposed" — which reads as *this product has no selling points* rather than *we
  did not get any*.

  The cause is the model, not the plumbing. `IdeasSchema.usps` has a default of `[]`, so a
  reply that simply omits the field parses cleanly as "no selling points", and the same
  product asked twice gives different answers — row 4 of that batch returned nothing on
  one attempt and three claims on the next. Keeping the default is still right: a model
  that cannot identify a product SHOULD return none rather than invent claims, and the
  prompt tells it so.

  So the fix is a retry, not a stricter schema:
  - **`POST /batch/{id}/rows/{n}/usps/propose`** asks the model again for one row. One
    seed-model call, no volume lookup — the measured keywords are untouched. Additive, so
    a claim someone typed by hand survives it and asking twice cannot duplicate a claim.
  - The empty state says what it means and carries a **"Propose selling points"** button.
  - The swallowed ideation failure in `propose_candidates` is now **logged**. Falling back
    to derived seeds is still correct behaviour, but it costs the row its selling points,
    and a silent `except` made that indistinguishable from the model declining.

---

## 1.2.0 — 7 October 2026

**One build, one journey.** Nothing new to learn; one thing fewer to explain.

### Changed

- **The lab is gone.** `/batch/{id}/lab/step/2` and `/lab/step/3` existed so tiers and
  lazy loading could be tried without risking a demo. Both graduated, which left two sets
  of routes rendering the same partials — two things to keep in step, one of them unused.
  `routers/lab.py`, `lab_keywords.html`, `lab_copy.html` and the `Lab` badge are deleted.
- **Row-at-a-time paging is now on the real pages.** The first `ROWS_PER_PAGE` (8) rows
  start on load; the rest say "loads when you scroll down" and are released 8 at a time by
  scrolling, or by a real button for keyboard and screen-reader users. The eager budget
  goes to rows that still need work, so a reload mid-run resumes rather than stalling.

  **A batch of 8 or fewer behaves exactly as it always did** — every row starts at once —
  so this is invisible until a batch is big enough for it to matter.
- `PAGE_SIZE` moved from `routers/lab.py` to `policy.ROWS_PER_PAGE`, with the other
  reviewable limits.
- `tests/test_lab.py` → `tests/test_tiers_and_paging.py`. The isolation tests that asserted
  the lab changed nothing became `TestThereIsOneJourney`, which asserts the lab routes
  return 404 and no page still wears the badge — the same tests doing the opposite job.

### Still not reachable from the UI

Unchanged by this release, and worth stating because it is the largest gap: every row
generates **11** copy fields and the page shows **2**. The H1, AEO answer block, three
benefit bullets, three FAQ pairs with FAQPage JSON-LD, 8–12 GEO prompts and the app-store
copy are all written, validated on length and stored — then shown nowhere and exported
nowhere. Also set aside: the ASO tab and the SERP truncation preview, in `archive/full-ui/`.

---

## 1.1.0 — 6 October 2026

The keywords page becomes a working surface rather than a report.

### Added

- **Keyword tiers on the real page.** Primary / secondary / tertiary selection, built and
  proven on the lab page, now on `/batch/{id}/step/2`. Each tier reaches the model as a
  distinct instruction, which implements the guidelines' "primary keyword and, where
  possible, secondary and tertiary keywords". Colour is never the only signal — chips
  carry `1st` / `2nd` / `3rd` as text. §31
- **Add, edit and remove keywords.** Editing a term **re-measures** it: the stored figure
  belongs to the old wording, so it is replaced rather than carried across, and a term the
  provider has no data for comes back visibly unmeasured. Removals are recoverable and
  reuse the stored figure. §31
- **Selling points per row.** Model-proposed USPs beside the keywords, so a writer has
  something to write *from* — keywords say what people search, never why anyone buys.
  Nothing reaches copy unticked; ticking records who and when; a claim not read off a page
  is flagged for checking, and that flag is never set from the model's own say-so. §31
- **Build version** in the masthead and `/healthz`.

### Changed

- `propose_keywords` returns an `IdeationResult` (terms **and** USPs) from one model call
  rather than a tuple of terms. USPs ride along on the ideation request, so the feature
  costs no extra round trip on the slowest page in the tool. §31
- The lab page keeps lazy loading only, and now renders the **same** row partial and calls
  the **same** endpoints as the real page. `_lab_keyword_row.html` deleted rather than
  left to drift. §31

### Fixed

- **A price-intent keyword could be promoted into copy it was forbidden to appear in.**
  Research measured `projector price in uae` at 1,900/month, auto-tiering promoted it on
  volume alone, the prompt asked the model to use it, and the banned-term validator then
  failed the row for containing "price". Three parts each behaving correctly, producing a
  guaranteed failure. Demand and publishability are now separate properties:
  `validators.banned_in_copy` decides the second, such terms are never auto-tiered and
  cannot be tiered by hand, and the chip stays on screen with its volume marked
  `research only`. §30
- A test that had silently stopped being able to fail:
  `test_the_primary_is_specific_not_the_biggest_number` sliced the HTML on a `<td>` marker
  that no longer existed, so it ran against the whole page. Now asserts against the
  database.

### Known limitations

- Product names arriving as unspaced slugs (`airpodsmax2`) match no search terms, so those
  rows get no primary keyword. Input dirt — surfaced, not patched.
- Copy rows are written one at a time; research overlaps, generation does not.
- Nothing is cached between batches: the same term researched twice is paid for twice.
- `research only` terms are visible on screen but absent from the export, because that
  column is "keywords used in the copy" and these never can be.

---

## 1.0.0 — 30 September 2026

The build presented to leadership.

- Four-column input template → keywords with real volumes → human approval → copy inside
  hard character *and* pixel limits → the input sheet returned with Meta Title, Meta
  Description and Keywords & Volumes appended.
- DataForSEO and OpenAI wired as the live pair, behind provider seams that a structural
  test keeps private. §25
- **An LLM never produces a search volume** — enforced by an AST test proving no path
  exists from a model to `Keyword.volume`, not by convention.
- Seeded volumes removed from every default path: an unconfigured provider refuses at the
  point of use rather than substituting the 29 figures collected once for an Apple batch.
  §29
- Credentials never start spending money by themselves: startup no longer researches a
  demo batch. §27
- The SEO Copy Guidelines as validators, each named after the guideline it enforces, so a
  content person can read the list against their own document. §28
- Price handling reconciled between a brief that forbids prices and guidelines that
  require one: a figure may appear only when it exactly matches one a human supplied. §28
